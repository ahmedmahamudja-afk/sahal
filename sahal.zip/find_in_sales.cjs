const fs = require('fs');
const content = fs.readFileSync('src/components/business/SalesModule.tsx', 'utf8');
const lines = content.split('\n');
lines.forEach((line, i) => {
  if (line.includes('<input')) {
    console.log(`[${i+1}] ${line.trim()}`);
  }
});
