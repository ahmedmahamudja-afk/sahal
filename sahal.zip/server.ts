import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Body parser middleware
  app.use(express.json());

  // === BACKEND API ROUTES ===
  // Example API health route
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // Example API data route (You can replace this with Supabase logic on the backend if preferred)
  app.get('/api/info', (req, res) => {
    res.json({ message: 'Welcome to SAHAL System API', version: '1.0.0' });
  });

  // === FRONTEND SERVING ===
  if (process.env.NODE_ENV !== 'production') {
    // Development mode: Use Vite Middleware
    console.log('Starting in Development Mode with Vite Middleware');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    
    app.use(vite.middlewares);
  } else {
    // Production mode: Serve static files from dist
    console.log('Starting in Production Mode');
    const distPath = path.join(__dirname, 'dist');
    
    app.get('/', (req, res) => {
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
      res.sendFile(path.join(distPath, 'index.html'));
    });

    app.use(express.static(distPath, {
      maxAge: '1y',
      etag: true,
      index: false,
    }));

    app.get('*', (req, res) => {
      const indexPath = path.join(distPath, 'index.html');
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(404).send('Application build not found (dist/index.html is missing). Please make sure you ran "npm run build".');
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
});
