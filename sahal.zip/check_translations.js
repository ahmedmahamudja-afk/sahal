
const translations = {
  so: {
    hospital_name: 'Isbitaalka Sahal',
    // ... (rest of the keys)
  },
  en: {
    hospital_name: 'Sahal Hospital',
    // ... (rest of the keys)
  }
};

// I will just use grep to check for keys in the file instead of a script
