const fs = require("fs");
const path = require("path");

function walkDir(dir, callback) {
  fs.readdirSync(dir).forEach(f => {
    let dirPath = path.join(dir, f);
    let isDirectory = fs.statSync(dirPath).isDirectory();
    isDirectory ? walkDir(dirPath, callback) : callback(path.join(dir, f));
  });
}

const usedKeys = new Set();
walkDir("src", (filePath) => {
  if (filePath.endsWith(".tsx") || filePath.endsWith(".ts")) {
    const content = fs.readFileSync(filePath, "utf-8");
    const regex = /t\(['"`]([a-z0-9_]+)['"`]/g;
    let match;
    while ((match = regex.exec(content)) !== null) {
      usedKeys.add(match[1]);
    }
  }
});

const translations = fs.readFileSync("src/translations.ts", "utf-8");
const definedRegex = /^\s*([a-z0-9_]+):/gm;
const definedKeys = new Set();
let match;
while ((match = definedRegex.exec(translations)) !== null) {
  definedKeys.add(match[1]);
}

const missing = [...usedKeys].filter(x => !definedKeys.has(x));
console.log("Missing keys:", missing);
