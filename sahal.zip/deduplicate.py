
import re
import sys

def deduplicate_translations(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Find each language block
    # so: { ... }, en: { ... }, ...
    lang_blocks = re.split(r'(\w+:\s*{)', content)
    
    new_content = lang_blocks[0]
    
    for i in range(1, len(lang_blocks), 2):
        header = lang_blocks[i]
        block_content = lang_blocks[i+1]
        
        # Find the end of this block
        # This is tricky because of nested objects, but translations.ts is flat
        # We find the next }, or the end of the string
        # Actually, let's find the content until the next lang header or closing of translations object
        
        # Find closing brace of this lang block
        # Since it's flat: key: 'value',
        match = re.search(r'^\s*},', block_content, re.MULTILINE)
        if match:
            end_pos = match.start()
            entry_content = block_content[:end_pos]
            remainder = block_content[end_pos:]
        else:
            # Maybe last block
            match = re.search(r'^\s*};', block_content, re.MULTILINE)
            if match:
                end_pos = match.start()
                entry_content = block_content[:end_pos]
                remainder = block_content[end_pos:]
            else:
                entry_content = block_content
                remainder = ""

        # Deduplicate entry_content
        lines = entry_content.split('\n')
        seen_keys = set()
        new_lines = []
        for line in lines:
            # key: 'value',
            key_match = re.match(r'^\s*(\w+):', line)
            if key_match:
                key = key_match.group(1)
                if key in seen_keys:
                    # Duplicate! skip it
                    continue
                seen_keys.add(key)
            new_lines.append(line)
        
        new_content += header + '\n'.join(new_lines) + remainder

    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(new_content)

if __name__ == "__main__":
    deduplicate_translations(sys.argv[1])
