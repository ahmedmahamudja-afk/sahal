import React, { useState, useEffect } from 'react';
import { supabase } from '../../supabase';
import { Service, UserProfile, Branch, Tenant } from '../../types';
import { Plus, Search, Edit2, Trash2, Briefcase, DollarSign, RefreshCw, Landmark } from 'lucide-react';

import { useLanguage } from '../LanguageContext';
import Modal from '../Modal';

export default function ServicesModule({ user }: { user: UserProfile }) {
  const { t } = useLanguage();
  const [services, setServices] = useState<Service[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [tenant, setTenant] = useState<Tenant | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingService, setEditingService] = useState<Service | null>(null);
  const [uploading, setUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  useEffect(() => {
    fetchServices();
  }, [user.tenantId, user.branchId]);

  const openConfirm = (title: string, message: string, onConfirm: () => void) => {
    setConfirmModal({
      isOpen: true,
      title,
      message,
      onConfirm: () => {
        onConfirm();
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const RenderConfirmModal = () => (
    confirmModal.isOpen ? (
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
        <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden p-6 space-y-6">
          <div className="flex items-center gap-4 p-4 bg-rose-50 rounded-2xl text-rose-600">
            <Trash2 size={24} />
            <p className="text-sm font-medium">{confirmModal.message}</p>
          </div>
          <div className="flex gap-3">
            <button 
              onClick={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
              className="flex-1 px-4 py-2 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 transition-all"
            >
              {t('cancel')}
            </button>
            <button 
              onClick={confirmModal.onConfirm}
              className="flex-1 px-4 py-2 bg-rose-600 text-white rounded-xl font-bold hover:bg-rose-700 transition-all shadow-lg shadow-rose-200"
            >
              {t('delete')}
            </button>
          </div>
        </div>
      </div>
    ) : null
  );

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: 0,
    category: '',
    imageUrl: '',
    offerPrice: 0,
    discountPercentage: 0,
    branchId: user.branchId || ''
  });

  const fetchServices = async () => {
    if (!user.tenantId) return;
    setLoading(true);
    try {
      let servicesQuery = supabase
        .from('services')
        .select('*')
        .eq('tenant_id', user.tenantId);
      
      if (user.branchId) {
        servicesQuery = servicesQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
      }

      const [servicesRes, branchesRes, tenantRes] = await Promise.all([
        servicesQuery,
        supabase
          .from('branches')
          .select('*')
          .eq('tenant_id', user.tenantId),
        supabase
          .from('tenants')
          .select('*')
          .eq('id', user.tenantId)
          .single()
      ]);

      if (tenantRes.data) {
        setTenant(tenantRes.data as Tenant);
      }

      if (branchesRes.data) {
        setBranches(branchesRes.data);
      }

      const servicesData = servicesRes.data || [];
      const mappedServices = servicesData.map((s: any) => ({
        id: s.id,
        name: s.name,
        description: s.description,
        price: s.price,
        category: s.category,
        imageUrl: s.image_url,
        offerPrice: s.offer_price,
        discountPercentage: s.discount_percentage,
        tenantId: s.tenant_id,
        branchId: s.branch_id,
        createdAt: s.created_at
      }));
      setServices(mappedServices);
    } catch (error) {
      console.error("Error fetching services:", error);
    } finally {
      setLoading(false);
    }
  };

  const compressImage = async (file: File): Promise<Blob> => {
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error("Compression timeout")), 10000);
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          clearTimeout(timeout);
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          const maxDim = 800;
          if (width > height && width > maxDim) {
            height = (height * maxDim) / width;
            width = maxDim;
          } else if (height > maxDim) {
            width = (width * maxDim) / height;
            height = maxDim;
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          canvas.toBlob((blob) => {
            if (blob) resolve(blob);
            else reject(new Error("Blob creation failed"));
          }, 'image/jpeg', 0.8);
        };
        img.onerror = () => {
          clearTimeout(timeout);
          reject(new Error("Image loading failed"));
        };
        img.src = e.target?.result as string;
      };
      reader.onerror = () => {
        clearTimeout(timeout);
        reject(new Error("File reading failed"));
      };
      reader.readAsDataURL(file);
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.tenantId || uploading) return;
    setUploading(true);
    try {
      let finalImageUrl = formData.imageUrl;
      if (selectedFile) {
        const compressed = await compressImage(selectedFile);
        const fileName = `${Date.now()}_${selectedFile.name.replace(/[^a-zA-Z0-9.]/g, '_')}`;
        const filePath = `tenants/${user.tenantId}/${fileName}`;
        const { error: uploadError } = await supabase.storage
          .from('app-images')
          .upload(filePath, compressed, {
            contentType: 'image/jpeg',
            cacheControl: '3600',
            upsert: true
          });
        if (uploadError) throw uploadError;
        const { data: { publicUrl } } = supabase.storage.from('app-images').getPublicUrl(filePath);
        finalImageUrl = publicUrl;
      }

      const serviceData = {
        name: formData.name,
        description: formData.description,
        price: formData.price,
        category: formData.category,
        image_url: finalImageUrl,
        offer_price: formData.offerPrice,
        discount_percentage: formData.discountPercentage,
        tenant_id: user.tenantId,
        branch_id: formData.branchId || user.branchId || null
      };

      if (editingService) {
        const { error: updateError } = await supabase.from('services').update({
          ...serviceData,
          updated_at: new Date().toISOString()
        }).eq('id', editingService.id);
        if (updateError) throw updateError;
      } else {
        const { error: insertError } = await supabase.from('services').insert({
          ...serviceData,
          created_at: new Date().toISOString()
        });
        if (insertError) throw insertError;
      }
      
      setIsModalOpen(false);
      setEditingService(null);
      setSelectedFile(null);
      setFormData({ name: '', description: '', price: 0, category: '', imageUrl: '', offerPrice: 0, discountPercentage: 0, branchId: user.branchId || '' });
      fetchServices();
    } catch (error: any) {
      console.error("Error saving service:", error);
      alert("Cillad keydinta: " + (error.message || "Unknown error"));
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!user.tenantId) return;
    openConfirm(t('delete'), t('delete_confirm'), async () => {
      try {
        await supabase.from('services').delete().eq('id', id);
        fetchServices();
      } catch (error) {
        console.error("Error deleting service:", error);
      }
    });
  };

  const openEdit = (service: Service) => {
    setEditingService(service);
    setSelectedFile(null);
    setFormData({
      name: service.name,
      description: service.description || '',
      price: service.price,
      category: service.category || '',
      imageUrl: service.imageUrl || '',
      offerPrice: service.offerPrice || 0,
      discountPercentage: service.discountPercentage || 0,
      branchId: service.branchId || ''
    });
    setIsModalOpen(true);
  };

  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [branchFilter, setBranchFilter] = useState<string>('All');

  const filteredServices = services.filter(service => {
    const matchesSearch = service.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          (service.description && service.description.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = categoryFilter === 'All' || service.category === categoryFilter;
    const matchesBranch = branchFilter === 'All' || service.branchId === branchFilter;
    
    return matchesSearch && matchesCategory && matchesBranch;
  }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const uniqueCategories = React.useMemo(() => {
    const cats = services.map(s => s.category).filter(Boolean) as string[];
    return ['All', ...Array.from(new Set(cats))];
  }, [services]);

  if (loading) return <div className="p-8 text-center text-slate-500">{t('loading')}</div>;

  return (
    <div className="space-y-6">
      <RenderConfirmModal />
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-2xl font-display font-bold text-slate-900 flex items-center gap-2">
          <Briefcase className="text-indigo-600" />
          {t('services')}
        </h2>
        <div className="flex flex-wrap gap-2">
          {branches.length > 0 && !user.branchId && (
            <div className="relative group">
              <select 
                value={branchFilter}
                onChange={(e) => setBranchFilter(e.target.value)}
                className="bg-accent-soft text-accent-main pl-4 pr-10 py-2 rounded-xl text-sm font-bold border border-transparent hover:border-accent-main transition-all appearance-none cursor-pointer outline-none flex items-center gap-2"
              >
                <option value="All">{t('all_branches')}</option>
                {branches.map(branch => (
                  <option key={branch.id} value={branch.id}>{branch.name}</option>
                ))}
              </select>
              <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
                <svg className="size-4 text-accent-main" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </div>
            </div>
          )}
          <button 
            onClick={() => {
                  setEditingService(null);
                  setSelectedFile(null);
                  setFormData({ name: '', description: '', price: 0, category: '', imageUrl: '', offerPrice: 0, discountPercentage: 0, branchId: user.branchId || '' });
                  setIsModalOpen(true);
                }}
                className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-bold shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all flex items-center gap-2"
              >
            <Plus size={18} /> {t('add_service')}
          </button>
          <button 
            onClick={fetchServices}
            disabled={loading}
            className={`bg-white text-slate-700 px-4 py-2 rounded-xl text-sm font-bold border border-slate-200 hover:bg-slate-50 transition-all flex items-center gap-2 ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            <RefreshCw size={18} className={loading ? 'animate-spin' : ''} />
            {loading ? t('refreshing') : t('refresh')}
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center gap-3 bg-slate-50/50">
          <Search size={18} className="text-slate-400" />
          <input 
            type="text" 
            placeholder={t('search_product_placeholder')} 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-transparent border-none focus:outline-none text-sm w-full"
          />
        </div>
        
        {uniqueCategories.length > 1 && (
          <div className="flex gap-2 p-4 overflow-x-auto no-scrollbar border-b border-slate-100 bg-white">
            {uniqueCategories.map(cat => (
              <button
                key={cat}
                onClick={() => setCategoryFilter(cat)}
                className={`px-5 py-2.5 rounded-xl text-sm font-bold whitespace-nowrap transition-all ${
                  categoryFilter === cat 
                    ? 'bg-accent-main text-white shadow-md border border-accent-main' 
                    : 'bg-accent-soft text-accent-main border border-transparent hover:opacity-80'
                }`}
              >
                {cat === 'All' ? t('all') : cat}
              </button>
            ))}
          </div>
        )}

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-slate-500 font-medium border-b border-slate-100">
              <tr>
                <th className="px-6 py-4">{t('service_name')}</th>
                {tenant?.isMultiBranch && !user.branchId && (
                  <th className="px-6 py-4">{t('branch' as any) || 'Branch'}</th>
                )}
                <th className="px-6 py-4">{t('category' as any) || 'Category'}</th>
                <th className="px-6 py-4">{t('service_desc')}</th>
                <th className="px-6 py-4">{t('service_price')}</th>
                <th className="px-6 py-4 text-right">{t('action')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredServices.map(service => (
                <tr key={service.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4 font-medium text-slate-900 flex items-center gap-3">
                    {service.imageUrl || (service as any).image_url ? (
                      <img src={service.imageUrl || (service as any).image_url} alt={service.name} className="w-8 h-8 rounded-lg object-cover" />
                    ) : (
                      <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-400">
                        <Briefcase size={16} />
                      </div>
                    )}
                    {service.name}
                  </td>
                  {tenant?.isMultiBranch && !user.branchId && (
                    <td className="px-6 py-4">
                      {service.branchId ? (
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-indigo-50 text-indigo-700">
                          {branches.find(b => b.id === service.branchId)?.name || 'Unknown'}
                        </span>
                      ) : (
                        <span className="text-slate-400 italic text-xs">{t('all_branches')}</span>
                      )}
                    </td>
                  )}
                  <td className="px-6 py-4">
                    {service.category ? (
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-slate-100 text-slate-800">
                        {service.category}
                      </span>
                    ) : (
                      <span className="text-slate-400">-</span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-slate-500 max-w-xs truncate">{service.description || '-'}</td>
                  <td className="px-6 py-4 text-slate-900 font-bold">
                    ${(service.price || 0).toFixed(2)}
                    {service.offerPrice && service.offerPrice > 0 ? (
                      <span className="block text-[10px] text-rose-500 line-through">Offer: ${service.offerPrice}</span>
                    ) : service.discountPercentage && service.discountPercentage > 0 ? (
                      <span className="block text-[10px] text-emerald-600">-{service.discountPercentage}%</span>
                    ) : null}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button onClick={() => openEdit(service)} className="p-2 text-slate-400 hover:text-indigo-600 transition-colors">
                      <Edit2 size={16} />
                    </button>
                    <button onClick={() => handleDelete(service.id)} className="p-2 text-slate-400 hover:text-red-600 transition-colors">
                      <Trash2 size={16} />
                    </button>
                  </td>
                </tr>
              ))}
              {filteredServices.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-slate-400">
                    {t('no_products_found')}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <Modal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        title={editingService ? t('edit_service') : t('add_service')}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('service_name')}</label>
              <input required type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20" />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('category' as any) || 'Category'}</label>
              <input 
                type="text" 
                value={formData.category} 
                onChange={e => setFormData({...formData, category: e.target.value})} 
                className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20" 
                placeholder="e.g. Consultation, Repair..."
                list="service-category-suggestions"
              />
              <datalist id="service-category-suggestions">
                {uniqueCategories.filter(c => c !== 'All').map(cat => (
                  <option key={cat} value={cat} />
                ))}
              </datalist>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('service_price')}</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">$</span>
                <input required type="number" step="0.01" value={formData.price} onChange={e => setFormData({...formData, price: parseFloat(e.target.value) || 0})} className="w-full pl-8 pr-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20" />
              </div>
            </div>
            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('service_desc')}</label>
              <textarea rows={3} value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20" />
            </div>
            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Image Upload</label>
              <div className="flex items-center gap-4">
                {(formData.imageUrl || (formData as any).image_url || selectedFile) && (
                  <div className="w-16 h-16 rounded-xl bg-slate-100 overflow-hidden border border-slate-200 shrink-0">
                    <img 
                      src={selectedFile ? URL.createObjectURL(selectedFile) : (formData.imageUrl || (formData as any).image_url)} 
                      alt="Preview" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                <input 
                  type="file" 
                  accept="image/*" 
                  onChange={e => setSelectedFile(e.target.files?.[0] || null)} 
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-sm file:mr-4 file:py-1 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-bold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100" 
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Offer Price ($)</label>
              <input type="number" step="0.01" value={formData.offerPrice || 0} onChange={e => setFormData({...formData, offerPrice: parseFloat(e.target.value) || 0})} className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20" />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Discount (%)</label>
              <input type="number" step="0.1" value={formData.discountPercentage || 0} onChange={e => setFormData({...formData, discountPercentage: parseFloat(e.target.value) || 0})} className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20" />
            </div>

            {branches.length > 0 && !user.branchId && (
              <div className="md:col-span-2">
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('branch' as any) || 'Branch'}</label>
                <div className="relative">
                  <Landmark className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 size-4" />
                  <select 
                    value={formData.branchId}
                    onChange={(e) => setFormData({...formData, branchId: e.target.value})}
                    className="w-full pl-10 pr-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 appearance-none bg-white"
                  >
                    <option value="">{t('all_branches')}</option>
                    {branches.map(branch => (
                      <option key={branch.id} value={branch.id}>{branch.name}</option>
                    ))}
                  </select>
                </div>
              </div>
            )}
          </div>
          <div className="pt-4 flex gap-3">
            <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 px-4 py-2 border border-slate-200 text-slate-600 rounded-xl font-medium hover:bg-slate-50">{t('cancel')}</button>
            <button type="submit" disabled={uploading} className="flex-1 px-4 py-2 bg-indigo-600 text-white rounded-xl font-medium hover:bg-indigo-700 disabled:opacity-50">
              {uploading ? t('uploading' as any) || 'Uploading...' : (editingService ? t('save') : t('add_service'))}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
