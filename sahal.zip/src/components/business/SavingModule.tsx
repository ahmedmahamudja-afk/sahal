import React, { useState, useEffect } from 'react';
import { supabase } from '../../supabase';
import { Saving, UserProfile } from '../../types';
import { Plus, Search, Edit2, Trash2, Wallet, Target, TrendingUp, ChevronRight, X, RefreshCw } from 'lucide-react';
import { useLanguage } from '../LanguageContext';
import Modal from '../Modal';
import { motion, AnimatePresence } from 'motion/react';

export default function SavingModule({ user }: { user: UserProfile }) {
  const { t } = useLanguage();
  const [savings, setSavings] = useState<Saving[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [branches, setBranches] = useState<any[]>([]);
  const [branchFilter, setBranchFilter] = useState<string>(user.branchId || 'All');
  const [editingSaving, setEditingSaving] = useState<Saving | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    targetAmount: 0,
    currentAmount: 0,
    branchId: user.branchId || ''
  });

  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  const openConfirm = (title: string, message: string, onConfirm: () => void) => {
    setConfirmModal({
      isOpen: true,
      title,
      message,
      onConfirm: () => {
        onConfirm();
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const fetchSavings = async () => {
    if (!user.tenantId) return;
    setLoading(true);
    try {
      const [savingsRes, branchesRes] = await Promise.all([
        supabase
          .from('savings')
          .select('*')
          .eq('tenant_id', user.tenantId),
        supabase
          .from('branches')
          .select('*')
          .eq('tenant_id', user.tenantId)
      ]);
      
      let savingsData = savingsRes.data || [];
      if (user.branchId) {
        savingsData = savingsData.filter(s => s.branch_id === user.branchId || s.branch_id === null);
      }
      
      setSavings(savingsData || []);
      setBranches(branchesRes.data || []);
    } catch (error) {
      console.error("Error fetching savings:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSavings();
  }, [user.tenantId, user.branchId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.tenantId) return;
    try {
      const savingData = {
        name: formData.name,
        target_amount: formData.targetAmount,
        current_amount: formData.currentAmount,
        tenant_id: user.tenantId,
        branch_id: formData.branchId || user.branchId || null,
        created_at: editingSaving ? editingSaving.createdAt : new Date().toISOString()
      };

      if (editingSaving) {
        await supabase.from('savings').update(savingData).eq('id', editingSaving.id);
      } else {
        await supabase.from('savings').insert(savingData);
      }
      setIsModalOpen(false);
      setEditingSaving(null);
      setFormData({ name: '', targetAmount: 0, currentAmount: 0 });
      fetchSavings();
    } catch (error) {
      console.error("Error saving saving:", error);
    }
  };

  const handleDelete = async (id: string) => {
    if (!user.tenantId) return;
    openConfirm(t('delete'), t('delete_confirm'), async () => {
      try {
        const { error } = await supabase.from('savings').delete().eq('id', id);
        if (error) throw error;
        fetchSavings();
      } catch (error) {
        console.error("Error deleting saving:", error);
      }
    });
  };

  const openEdit = (s: Saving) => {
    setEditingSaving(s);
    setFormData({
      name: s.name || '',
      targetAmount: s.targetAmount || 0,
      currentAmount: s.currentAmount || 0,
      branchId: (s as any).branchId || ''
    });
    setIsModalOpen(true);
  };

  const filteredSavings = savings.filter(s => {
    const matchesSearch = s.name?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesBranch = branchFilter === 'All' || (s as any).branchId === branchFilter;
    return matchesSearch && matchesBranch;
  });

  const totalSaved = filteredSavings.reduce((sum, s) => sum + (s.currentAmount || 0), 0);
  const totalTarget = filteredSavings.reduce((sum, s) => sum + (s.targetAmount || 0), 0);
  const overallProgress = totalTarget > 0 ? (totalSaved / totalTarget) * 100 : 0;

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-3xl font-display font-bold text-slate-900">{t('saving_module')}</h2>
          <p className="text-slate-500">{t('manage_savings_desc' as any) || 'Track your business savings and goals.'}</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative w-64">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input
              type="text"
              placeholder={t('search_saving' as any) || 'Search saving...'}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-11 pr-4 py-3 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 font-medium text-sm transition-all"
            />
          </div>
          {branches.length > 0 && !user.branchId && (
            <div className="relative group">
              <select 
                value={branchFilter}
                onChange={(e) => setBranchFilter(e.target.value)}
                className="bg-indigo-50 text-indigo-600 pl-4 pr-10 py-3 rounded-xl text-sm font-bold border border-transparent hover:border-indigo-200 transition-all appearance-none cursor-pointer outline-none flex items-center gap-2"
              >
                <option value="All">{t('all_branches')}</option>
                {branches.map(branch => (
                  <option key={branch.id} value={branch.id}>{branch.name}</option>
                ))}
              </select>
              <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
                <svg className="size-4 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </div>
            </div>
          )}
          <button 
            onClick={fetchSavings}
            disabled={loading}
            className={`p-3 bg-white text-slate-600 rounded-xl font-bold text-sm border border-slate-200 hover:bg-slate-50 transition-all flex items-center gap-2 ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
            title={t('refresh')}
          >
            <RefreshCw size={18} className={loading ? 'animate-spin' : ''} />
          </button>
          <button
            onClick={() => {
              setEditingSaving(null);
              setFormData({ name: '', targetAmount: 0, currentAmount: 0 });
              setIsModalOpen(true);
            }}
            className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
          >
            <Plus size={20} />
            <span>{t('add_saving')}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="sahal-card p-6 bg-indigo-600 text-white">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-white/20 rounded-xl"><Wallet size={24} /></div>
            <TrendingUp size={20} className="text-indigo-200" />
          </div>
          <p className="text-indigo-100 text-xs font-bold uppercase tracking-wider mb-1">{t('total_saved' as any) || 'Total Saved'}</p>
          <h3 className="text-3xl font-display font-bold">${totalSaved.toLocaleString()}</h3>
        </div>
        <div className="sahal-card p-6">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl"><Target size={24} /></div>
          </div>
          <p className="text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">{t('total_target' as any) || 'Total Target'}</p>
          <h3 className="text-3xl font-display font-bold text-slate-900">${totalTarget.toLocaleString()}</h3>
        </div>
        <div className="sahal-card p-6">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl"><TrendingUp size={24} /></div>
            <span className="text-emerald-600 font-bold text-sm">{overallProgress.toFixed(1)}%</span>
          </div>
          <p className="text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">{t('overall_progress' as any) || 'Overall Progress'}</p>
          <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden mt-4">
            <div className="h-full bg-emerald-500 transition-all duration-1000" style={{ width: `${Math.min(overallProgress, 100)}%` }} />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredSavings.map(s => {
          const progress = s.targetAmount > 0 ? (s.currentAmount / s.targetAmount) * 100 : 0;
          return (
            <motion.div
              layout
              key={s.id}
              className="sahal-card p-6 group hover:border-indigo-200 transition-all"
            >
              <div className="flex justify-between items-start mb-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center font-bold">
                    {s.name?.[0]}
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900">{s.name}</h4>
                    <p className="text-xs text-slate-400">{t('progress' as any) || 'Progress'}: {progress.toFixed(1)}%</p>
                  </div>
                </div>
                <div className="flex gap-2 transition-opacity">
                  <button onClick={() => openEdit(s)} className="p-2 hover:bg-indigo-50 text-indigo-600 rounded-lg transition-colors">
                    <Edit2 size={16} />
                  </button>
                  <button onClick={() => handleDelete(s.id)} className="p-2 hover:bg-rose-50 text-rose-600 rounded-lg transition-colors">
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between text-sm">
                  <span className="font-bold text-slate-900">${s.currentAmount.toLocaleString()}</span>
                  <span className="text-slate-400">${s.targetAmount.toLocaleString()}</span>
                </div>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className={`h-full transition-all duration-1000 ${progress >= 100 ? 'bg-emerald-500' : 'bg-indigo-600'}`} 
                    style={{ width: `${Math.min(progress, 100)}%` }} 
                  />
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      <Modal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        title={editingSaving ? t('edit' as any) || 'Edit' : t('add_saving')}
        contentClassName="max-w-md"
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('saving_name')}</label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={e => setFormData({ ...formData, name: e.target.value })}
              className="sahal-input"
              placeholder={t('saving_name')}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('target_amount')}</label>
              <input
                type="number"
                required
                min="0"
                value={formData.targetAmount}
                onChange={e => setFormData({ ...formData, targetAmount: parseFloat(e.target.value) || 0 })}
                className="sahal-input"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('current_amount')}</label>
              <input
                type="number"
                required
                min="0"
                value={formData.currentAmount}
                onChange={e => setFormData({ ...formData, currentAmount: parseFloat(e.target.value) || 0 })}
                className="sahal-input"
              />
            </div>
          </div>
          {branches.length > 0 && !user.branchId && (
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('branch' as any) || 'Branch'}</label>
              <select 
                value={formData.branchId}
                onChange={(e) => setFormData({...formData, branchId: e.target.value})}
                className="sahal-input"
              >
                <option value="">{t('all_branches')}</option>
                {branches.map(branch => (
                  <option key={branch.id} value={branch.id}>{branch.name}</option>
                ))}
              </select>
            </div>
          )}
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="flex-1 px-6 py-4 bg-slate-100 text-slate-600 rounded-2xl font-bold hover:bg-slate-200 transition-all"
            >
              {t('cancel')}
            </button>
            <button
              type="submit"
              className="flex-1 px-6 py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
            >
              {t('save')}
            </button>
          </div>
        </form>
      </Modal>

      {/* Confirm Modal */}
      <AnimatePresence>
        {confirmModal.isOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden p-6 space-y-6"
            >
              <div className="flex items-center gap-4 p-4 bg-rose-50 rounded-2xl text-rose-600">
                <Trash2 size={24} />
                <p className="text-sm font-medium">{confirmModal.message}</p>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
                  className="flex-1 py-3 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 transition-all"
                >
                  {t('cancel')}
                </button>
                <button
                  onClick={confirmModal.onConfirm}
                  className="flex-1 py-3 bg-rose-600 text-white rounded-xl font-bold hover:bg-rose-700 transition-all shadow-lg shadow-rose-100"
                >
                  {t('confirm')}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
