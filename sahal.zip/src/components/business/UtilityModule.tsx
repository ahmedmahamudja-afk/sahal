import React, { useState, useEffect } from 'react';
import { supabase } from '../../supabase';
import { UserProfile, Tenant } from '../../types';
import { useLanguage } from '../LanguageContext';
import { 
  Home, 
  Droplets, 
  Zap, 
  Plus, 
  Trash2, 
  Edit2, 
  CheckCircle2, 
  XCircle,
  Search,
  Filter,
  User,
  Printer,
  Download,
  RefreshCw
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Modal from '../Modal';

interface UtilityModuleProps {
  user: UserProfile;
  utilityType: 'water' | 'electricity';
  initialTab?: 'overview' | 'homes' | 'records' | 'unpaid' | 'paid';
}

interface HomeNumber {
  id: string;
  number: string;
  ownerName: string;
  contact: string;
  assignedStaffName?: string;
  createdAt: string;
}

interface UtilityRecord {
  id: string;
  homeId: string;
  homeNumber: string;
  type: 'water' | 'electricity';
  month: string;
  previousReading: number;
  currentReading: number;
  consumption: number;
  rate: number;
  totalBill: number;
  isPaid: boolean;
  paidAt?: string;
  collectedBy?: string;
  recordedBy?: string;
  createdAt: string;
}

interface StaffMember {
  id: string;
  displayName: string;
  roles: string[];
}

interface UtilitySettings {
  waterRate: number;
  electricityRate: number;
}

export default function UtilityModule({ user, utilityType, initialTab }: UtilityModuleProps) {
  const { t } = useLanguage();
  const isStaff = user.isStaff;
  const canManageWater = user.staffRoles?.includes('utility_water');
  const canManageElectricity = user.staffRoles?.includes('utility_electricity');
  const isUtilityManager = user.role === 'system_manager' || user.role === 'super_admin';
  const isRestrictedStaff = isStaff && !isUtilityManager && !canManageWater && !canManageElectricity;
  const [activeTab, setActiveTab] = useState<'overview' | 'homes' | 'records' | 'unpaid' | 'paid'>(
    initialTab || (isStaff ? 'unpaid' : 'overview')
  );
  const [homes, setHomes] = useState<HomeNumber[]>([]);
  const [records, setRecords] = useState<UtilityRecord[]>([]);
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [settings, setSettings] = useState<UtilitySettings>({ waterRate: 0, electricityRate: 0 });
  const [tenant, setTenant] = useState<Tenant | null>(null);
  const [loading, setLoading] = useState(true);
  const [isSavingSettings, setIsSavingSettings] = useState(false);

  // Modals
  const [isHomeModalOpen, setIsHomeModalOpen] = useState(false);
  const [isRecordModalOpen, setIsRecordModalOpen] = useState(false);
  const [editingRecordId, setEditingRecordId] = useState<string | null>(null);

  // Forms
  const [newHome, setNewHome] = useState({ number: '', ownerName: '', contact: '', assignedStaffName: '' });
  const [newRecord, setNewRecord] = useState({
    homeId: '',
    type: 'water' as 'water' | 'electricity',
    month: new Date().toISOString().slice(0, 7),
    previousReading: 0,
    currentReading: 0,
    rate: 0,
    recordedBy: '',
    isPaidImmediately: false
  });

  const [staffFilter, setStaffFilter] = useState('');

  useEffect(() => {
    fetchData();
  }, [user.tenantId, user.branchId]);

  useEffect(() => {
    if (isRestrictedStaff) {
      setNewRecord(prev => ({ 
        ...prev, 
        recordedBy: user.displayName || user.username || '',
        rate: prev.type === 'water' ? settings.waterRate : settings.electricityRate
      }));
    } else {
      setNewRecord(prev => ({ 
        ...prev, 
        rate: prev.type === 'water' ? settings.waterRate : settings.electricityRate
      }));
    }
  }, [isRestrictedStaff, user.displayName, user.username, settings, isRecordModalOpen]);

  // Auto-fill previous reading when home or type changes
  useEffect(() => {
    if (newRecord.homeId && newRecord.type && !editingRecordId) {
      const lastRecord = records
        .filter(r => r.homeId === newRecord.homeId && r.type === newRecord.type)
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())[0];
      
      if (lastRecord) {
        setNewRecord(prev => ({ 
          ...prev, 
          previousReading: lastRecord.currentReading,
          rate: prev.type === 'water' ? settings.waterRate : settings.electricityRate
        }));
      } else {
        setNewRecord(prev => ({ 
          ...prev, 
          previousReading: 0,
          rate: prev.type === 'water' ? settings.waterRate : settings.electricityRate
        }));
      }
    }
  }, [newRecord.homeId, newRecord.type, records, settings]);

  const fetchData = async () => {
    try {
      setLoading(true);

      // Fetch Tenant
      const { data: tenantData } = await supabase
        .from('tenants')
        .select('*')
        .eq('id', user.tenantId)
        .single();
      if (tenantData) {
        setTenant(tenantData);
      }

      // Fetch Homes
      let homesQuery = supabase
        .from('homes')
        .select('*')
        .eq('tenant_id', user.tenantId);
      if (user.branchId) homesQuery = homesQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
      const { data: homesData } = await homesQuery;
      setHomes(homesData || []);

      // Fetch Records
      let recordsQuery = supabase
        .from('utility_records')
        .select('*')
        .eq('tenant_id', user.tenantId)
        .eq('type', utilityType);
      if (user.branchId) recordsQuery = recordsQuery.eq('branch_id', user.branchId);
      const { data: recordsData } = await recordsQuery;
      setRecords((recordsData || []).sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()));

      // Fetch Staff
      let staffQuery = supabase
        .from('staff')
        .select('*')
        .eq('tenant_id', user.tenantId);
      if (user.branchId) staffQuery = staffQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
      const { data: staffData } = await staffQuery;
      setStaff((staffData || []).filter(s => 
        s.roles?.includes('utility') || 
        s.roles?.includes('utility_counter') || 
        s.roles?.includes('utility_water') || 
        s.roles?.includes('utility_electricity')
      ));

      // Fetch Settings
      let settingsQuery = supabase
        .from('utility_settings')
        .select('*')
        .eq('tenant_id', user.tenantId);
      if (user.branchId) settingsQuery = settingsQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
      const { data: settingsData } = await settingsQuery.order('created_at', { ascending: false }).limit(1).maybeSingle();
      if (settingsData) {
        setSettings(settingsData);
      }
    } catch (error) {
      console.error("Error fetching utility data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setIsSavingSettings(true);
      const { data: existingSettings } = await supabase
        .from('utility_settings')
        .select('id')
        .eq('tenant_id', user.tenantId)
        .eq('branch_id', user.branchId || null)
        .maybeSingle();
      
      if (!existingSettings) {
        await supabase.from('utility_settings').insert({ ...settings, tenant_id: user.tenantId, branch_id: user.branchId || null });
      } else {
        await supabase.from('utility_settings').update({ ...settings }).eq('id', existingSettings.id);
      }
      alert(t('settings_saved_success') || 'Settings saved successfully!');
    } catch (error) {
      console.error("Error saving settings:", error);
    } finally {
      setIsSavingSettings(false);
    }
  };

  const handleAddHome = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await supabase.from('homes').insert({
        ...newHome,
        tenant_id: user.tenantId,
        branch_id: user.branchId || null,
        created_at: new Date().toISOString()
      });
      setIsHomeModalOpen(false);
      setNewHome({ number: '', ownerName: '', contact: '', assignedStaffName: '' });
      fetchData();
    } catch (error) {
      console.error("Error adding home:", error);
    }
  };

  const handleAddRecord = async (e: React.FormEvent, shouldPrint: boolean = false) => {
    e.preventDefault();
    try {
      const home = homes.find(h => h.id === newRecord.homeId);
      if (!home) return;

      const consumption = newRecord.currentReading - newRecord.previousReading;
      const totalBill = consumption * newRecord.rate;

      const recordData = {
        home_id: newRecord.homeId,
        home_number: home.number,
        type: newRecord.type,
        month: newRecord.month,
        previous_reading: newRecord.previousReading,
        current_reading: newRecord.currentReading,
        consumption,
        rate: newRecord.rate,
        total_bill: totalBill,
        is_paid: newRecord.isPaidImmediately,
        paid_at: newRecord.isPaidImmediately ? new Date().toISOString() : null,
        collected_by: newRecord.isPaidImmediately ? (newRecord.recordedBy || user.displayName || user.username) : null,
        recorded_by: newRecord.recordedBy,
        created_at: new Date().toISOString(),
        tenant_id: user.tenantId,
        branch_id: user.branchId || null
      };

      if (editingRecordId) {
        await supabase.from('utility_records').update(recordData).eq('id', editingRecordId);
      } else {
        const { data: newRecordData } = await supabase.from('utility_records').insert(recordData).select().single();
        
        if (shouldPrint && newRecordData) {
          handlePrintReceipt({ ...newRecordData, ...recordData } as any);
        }
      }

      setIsRecordModalOpen(false);
      setEditingRecordId(null);
      setNewRecord({
        homeId: '',
        type: 'water',
        month: new Date().toISOString().slice(0, 7),
        previousReading: 0,
        currentReading: 0,
        rate: 0,
        recordedBy: '',
        isPaidImmediately: false
      });
      fetchData();
    } catch (error) {
      console.error("Error adding record:", error);
    }
  };

  const handleMarkPaid = async (recordId: string) => {
    try {
      await supabase.from('utility_records').update({
        is_paid: true,
        paid_at: new Date().toISOString(),
        collected_by: user.displayName || user.username
      }).eq('id', recordId);
      fetchData();
    } catch (error) {
      console.error("Error marking as paid:", error);
    }
  };

  const handleEditRecord = (record: UtilityRecord) => {
    setEditingRecordId(record.id);
    setNewRecord({
      homeId: record.homeId,
      type: record.type,
      month: record.month,
      previousReading: record.previousReading,
      currentReading: record.currentReading,
      rate: record.rate,
      recordedBy: record.recordedBy || '',
      isPaidImmediately: record.isPaid
    });
    setIsRecordModalOpen(true);
  };

  const handlePrintReceipt = (record: UtilityRecord) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const home = homes.find(h => h.number === record.homeNumber);
    const date = new Date().toLocaleDateString();

    const html = `
      <html>
        <head>
          <title>Utility Receipt - ${record.homeNumber}</title>
          <style>
            body { font-family: 'Inter', sans-serif; padding: 40px; color: #1e293b; }
            .receipt-container { max-width: 500px; margin: 0 auto; border: 1px solid #e2e8f0; padding: 30px; border-radius: 12px; }
            .header { text-align: center; border-bottom: 2px solid #f1f5f9; padding-bottom: 20px; margin-bottom: 20px; }
            .header h1 { margin: 0; color: #4f46e5; font-size: 24px; }
            .header p { margin: 5px 0 0; color: #64748b; font-size: 14px; }
            .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 25px; }
            .info-item label { display: block; font-size: 11px; font-weight: bold; text-transform: uppercase; color: #94a3b8; margin-bottom: 4px; }
            .info-item span { font-size: 15px; font-weight: 600; color: #1e293b; }
            .bill-details { background: #f8fafc; padding: 20px; border-radius: 8px; margin-bottom: 25px; }
            .bill-row { display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 14px; }
            .bill-row.total { margin-top: 15px; padding-top: 15px; border-top: 1px solid #e2e8f0; font-weight: bold; font-size: 18px; color: #0f172a; }
            .status { text-align: center; margin-top: 30px; }
            .status-badge { display: inline-block; padding: 6px 16px; rounded-radius: 20px; font-weight: bold; font-size: 12px; text-transform: uppercase; }
            .paid { background: #ecfdf5; color: #059669; border: 1px solid #10b981; border-radius: 20px; }
            .unpaid { background: #fef2f2; color: #dc2626; border: 1px solid #ef4444; border-radius: 20px; }
            .footer { text-align: center; margin-top: 40px; font-size: 12px; color: #94a3b8; }
            @media print {
              body { padding: 0; }
              .receipt-container { border: none; }
              .no-print { display: none; }
            }
          </style>
        </head>
        <body>
          <div class="receipt-container">
            <div class="header">
              ${tenant?.logoUrl ? `<img src="${tenant.logoUrl}" style="width: 60px; height: 60px; object-fit: contain; margin-bottom: 10px;" />` : ''}
              <h1>${tenant?.name || 'SAHAL UTILITY'}</h1>
              ${tenant?.location ? `<p style="font-size: 14px; margin: 2px 0;">${tenant.location}</p>` : ''}
              ${tenant?.contact ? `<p style="font-size: 14px; margin: 2px 0;">${tenant.contact}</p>` : ''}
              <p>Official Billing Receipt</p>
            </div>
            
            <div class="info-grid">
              <div class="info-item">
                <label>Home Number</label>
                <span>${record.homeNumber}</span>
              </div>
              <div class="info-item">
                <label>Owner Name</label>
                <span>${home?.ownerName || 'N/A'}</span>
              </div>
              <div class="info-item">
                <label>Billing Month</label>
                <span>${record.month}</span>
              </div>
              <div class="info-item">
                <label>Utility Type</label>
                <span style="text-transform: capitalize;">${record.type}</span>
              </div>
            </div>

            <div class="bill-details">
              <div class="bill-row">
                <span>Previous Reading:</span>
                <span>${record.previousReading} ${record.type === 'water' ? 'm³' : 'kWh'}</span>
              </div>
              <div class="bill-row">
                <span>Current Reading:</span>
                <span>${record.currentReading} ${record.type === 'water' ? 'm³' : 'kWh'}</span>
              </div>
              <div class="bill-row">
                <span>Consumption:</span>
                <span>${record.consumption} ${record.type === 'water' ? 'm³' : 'kWh'}</span>
              </div>
              <div class="bill-row">
                <span>Rate:</span>
                <span>$${record.rate.toFixed(2)}</span>
              </div>
              <div class="bill-row total">
                <span>Total Amount:</span>
                <span>$${record.totalBill.toFixed(2)}</span>
              </div>
            </div>

            <div class="status">
              <div class="status-badge ${record.isPaid ? 'paid' : 'unpaid'}">
                ${record.isPaid ? 'Payment Confirmed' : 'Payment Pending'}
              </div>
              ${record.paidAt ? `<p style="font-size: 11px; color: #64748b; margin-top: 8px;">Paid on: ${new Date(record.paidAt).toLocaleString()}</p>` : ''}
              ${record.collectedBy ? `<p style="font-size: 11px; color: #64748b;">Collected by: ${record.collectedBy}</p>` : ''}
            </div>

            ${tenant?.paymentNumbers && typeof tenant.paymentNumbers === 'object' ? `
            <div style="margin-top: 20px; padding-top: 15px; border-top: 1px dashed #e2e8f0;">
              <p style="font-size: 11px; font-weight: bold; color: #94a3b8; text-transform: uppercase; margin-bottom: 8px;">Payment Methods:</p>
              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
                ${(tenant.paymentNumbers as any).evc ? `<div style="font-size: 12px;"><span style="color: #64748b;">EVC:</span> <span style="font-weight: 600;">${(tenant.paymentNumbers as any).evc}</span></div>` : ''}
                ${(tenant.paymentNumbers as any).edahab ? `<div style="font-size: 12px;"><span style="color: #64748b;">eDahab:</span> <span style="font-weight: 600;">${(tenant.paymentNumbers as any).edahab}</span></div>` : ''}
                ${(tenant.paymentNumbers as any).zaad ? `<div style="font-size: 12px;"><span style="color: #64748b;">ZAAD:</span> <span style="font-weight: 600;">${(tenant.paymentNumbers as any).zaad}</span></div>` : ''}
                ${(tenant.paymentNumbers as any).sahal ? `<div style="font-size: 12px;"><span style="color: #64748b;">Sahal:</span> <span style="font-weight: 600;">${(tenant.paymentNumbers as any).sahal}</span></div>` : ''}
                ${(tenant.paymentNumbers as any).merchant ? `<div style="font-size: 12px;"><span style="color: #64748b;">Merchant:</span> <span style="font-weight: 600;">${(tenant.paymentNumbers as any).merchant}</span></div>` : ''}
                ${(tenant.paymentNumbers as any).bank ? `<div style="font-size: 12px;"><span style="color: #64748b;">Bank:</span> <span style="font-weight: 600;">${(tenant.paymentNumbers as any).bank}</span></div>` : ''}
              </div>
            </div>
            ` : ''}

            <div class="footer">
              <p>Thank you for your payment!</p>
              <p>${tenant?.name || 'SAHAL UTILITY'} Management</p>
              <p>Generated on ${date}</p>
            </div>
          </div>
          <script>
            window.onload = () => {
              window.print();
              // window.close(); // Optional: close window after printing
            };
          </script>
        </body>
      </html>
    `;

    printWindow.document.write(html);
    printWindow.document.close();
  };

  const handleExportPDF = (title: string, data: any[], columns: string[]) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const date = new Date().toLocaleDateString();

    const html = `
      <html>
        <head>
          <title>${title}</title>
          <style>
            body { font-family: sans-serif; padding: 40px; color: #1e293b; }
            .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #e2e8f0; padding-bottom: 20px; margin-bottom: 30px; }
            .business-name { font-size: 24px; font-weight: bold; color: #4f46e5; }
            .report-title { font-size: 18px; font-weight: bold; margin-bottom: 10px; }
            .meta { font-size: 12px; color: #64748b; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th { background: #f8fafc; text-align: left; padding: 12px; font-size: 12px; font-weight: bold; text-transform: uppercase; border-bottom: 1px solid #e2e8f0; }
            td { padding: 12px; font-size: 13px; border-bottom: 1px solid #f1f5f9; }
            .footer { margin-top: 50px; font-size: 10px; color: #94a3b8; text-align: center; }
            @media print {
              .no-print { display: none; }
            }
          </style>
        </head>
        <body>
          <div class="header">
            <div>
              <div class="business-name">${tenant?.name || 'SAHAL UTILITY'}</div>
              ${tenant?.location ? `<div style="font-size: 12px; color: #64748b;">${tenant.location}</div>` : ''}
              ${tenant?.contact ? `<div style="font-size: 12px; color: #64748b;">${tenant.contact}</div>` : ''}
              <div class="report-title">${title}</div>
            </div>
            <div class="meta">Date: ${date}</div>
          </div>
          <table>
            <thead>
              <tr>
                ${columns.map(col => `<th>${col}</th>`).join('')}
              </tr>
            </thead>
            <tbody>
              ${data.map(row => `
                <tr>
                  ${columns.map(col => `<td>${row[col] || ''}</td>`).join('')}
                </tr>
              `).join('')}
            </tbody>
          </table>
          <div class="footer">
            Generated by Sahal Utility Management System
          </div>
          <script>
            window.onload = () => {
              window.print();
            };
          </script>
        </body>
      </html>
    `;

    printWindow.document.write(html);
    printWindow.document.close();
  };

  const handleDeleteRecord = async (recordId: string) => {
    try {
      await supabase.from('utility_records').delete().eq('id', recordId);
      fetchData();
    } catch (error) {
      console.error("Error deleting record:", error);
    }
  };

  const unpaidRecords = records.filter(r => !r.isPaid);
  const paidRecords = records.filter(r => r.isPaid);

  const displayHomes = isRestrictedStaff 
    ? homes.filter(h => h.assignedStaffName === (user.displayName || user.username))
    : homes;

  const assignedHomeNumbers = new Set(displayHomes.map(h => h.number));

  const displayRecords = !isUtilityManager
    ? records.filter(r => 
        (canManageWater && r.type === 'water') || 
        (canManageElectricity && r.type === 'electricity')
      )
    : records;

  const displayUnpaid = displayRecords.filter(r => !r.isPaid);
  const displayPaid = displayRecords.filter(r => r.isPaid);

  const filteredUnpaid = staffFilter 
    ? displayUnpaid.filter(r => r.collectedBy?.toLowerCase().includes(staffFilter.toLowerCase()))
    : displayUnpaid;

  if (loading) {
    return <div className="p-8 text-center text-slate-500">Loading utility data...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header & Navigation */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-display font-bold text-slate-900">{t('utility')}</h2>
          <p className="text-slate-500 text-sm">Manage water and electricity billing</p>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2 sm:pb-0 w-full sm:w-auto items-center">
          <button 
            onClick={fetchData}
            disabled={loading}
            className={`p-3 bg-white text-slate-600 rounded-xl font-bold text-sm border border-slate-200 hover:bg-slate-50 transition-all flex items-center gap-2 ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
            title={t('refresh')}
          >
            <RefreshCw size={18} className={loading ? 'animate-spin' : ''} />
          </button>
          {/* @ts-ignore */}
          {(isStaff ? ['records', 'unpaid', 'paid'] : ['overview', 'homes', 'records', 'unpaid', 'paid']).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as any)}
              className={`px-4 py-2 rounded-xl text-sm font-bold whitespace-nowrap transition-all ${
                activeTab === tab 
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200' 
                  : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
              }`}
            >
              {t(tab as any) || tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Overview Tab */}
      {activeTab === 'overview' && !isStaff && (
        <div className="space-y-8">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="sahal-card p-6 bg-white border border-slate-100">
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl">
                  <Home size={24} />
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest text-slate-400">{t('total_homes')}</p>
                  <p className="text-2xl font-display font-bold text-slate-900">{homes.length}</p>
                </div>
              </div>
            </div>
            <div className="sahal-card p-6 bg-white border border-slate-100">
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl">
                  <CheckCircle2 size={24} />
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest text-slate-400">{t('paid_bills')}</p>
                  <p className="text-2xl font-display font-bold text-slate-900">
                    ${records.filter(r => r.isPaid).reduce((sum, r) => sum + (r.totalBill || 0), 0).toFixed(2)}
                  </p>
                </div>
              </div>
            </div>
            <div className="sahal-card p-6 bg-white border border-slate-100">
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-rose-50 text-rose-600 rounded-2xl">
                  <XCircle size={24} />
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest text-slate-400">{t('unpaid_bills')}</p>
                  <p className="text-2xl font-display font-bold text-slate-900">
                    ${records.filter(r => !r.isPaid).reduce((sum, r) => sum + (r.totalBill || 0), 0).toFixed(2)}
                  </p>
                </div>
              </div>
            </div>
            <div className="sahal-card p-6 bg-white border border-slate-100">
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-amber-50 text-amber-600 rounded-2xl">
                  <Zap size={24} />
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest text-slate-400">{t('total_potential')}</p>
                  <p className="text-2xl font-display font-bold text-slate-900">
                    ${records.reduce((sum, r) => sum + (r.totalBill || 0), 0).toFixed(2)}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Settings Section */}
          <div className="sahal-card p-8 bg-white border border-slate-100 space-y-8">
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Filter size={20} className="text-indigo-600" />
              {t('utility_settings')}
            </h3>
            
            <form onSubmit={handleSaveSettings} className="space-y-6">
              {tenant?.modules.utility_water && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 items-end">
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">{t('water_rate')} ($ per m³)</label>
                    <input 
                      type="number" step="0.01" required
                      value={settings.waterRate}
                      onChange={e => setSettings({...settings, waterRate: parseFloat(e.target.value) || 0})}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20"
                    />
                  </div>
                </div>
              )}
              
              {tenant?.modules.utility_electricity && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 items-end">
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">{t('electricity_rate')} ($ per kWh)</label>
                    <input 
                      type="number" step="0.01" required
                      value={settings.electricityRate}
                      onChange={e => setSettings({...settings, electricityRate: parseFloat(e.target.value) || 0})}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20"
                    />
                  </div>
                </div>
              )}

              <button 
                type="submit"
                disabled={isSavingSettings}
                className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-indigo-700 transition-all disabled:opacity-50"
              >
                {isSavingSettings ? t('saving') : t('save_rates')}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Homes Tab */}
      {activeTab === 'homes' && !isStaff && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <h3 className="text-lg font-bold text-slate-900">Registered Homes</h3>
              <button 
                onClick={() => handleExportPDF(
                  'Registered Homes Report',
                  displayHomes.map(h => ({ 
                    'Home Number': h.number, 
                    'Owner Name': h.ownerName, 
                    'Contact': h.contact, 
                    'Assigned Staff': h.assignedStaffName 
                  })),
                  ['Home Number', 'Owner Name', 'Contact', 'Assigned Staff']
                )}
                className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-all"
              >
                <Download size={14} /> Download PDF
              </button>
            </div>
            {!isStaff && (
              <button 
                onClick={() => setIsHomeModalOpen(true)}
                className="bg-indigo-600 text-white px-4 py-2 rounded-xl font-bold flex items-center gap-2 hover:bg-indigo-700 transition-all"
              >
                <Plus size={18} /> Add Home
              </button>
            )}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {displayHomes.map(home => (
              <div key={home.id} className="sahal-card p-6 bg-white border border-slate-100">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-slate-600">
                      <Home size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900">{home.number}</h4>
                      <p className="text-xs text-slate-500">{home.ownerName}</p>
                    </div>
                  </div>
                </div>
                <div className="text-sm text-slate-600 space-y-1">
                  <div><span className="font-medium">Contact:</span> {home.contact || 'N/A'}</div>
                  {home.assignedStaffName && (
                    <div className="flex items-center gap-1 text-indigo-600 font-medium">
                      <User size={14} />
                      <span>Staff: {home.assignedStaffName}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
            {homes.length === 0 && (
              <div className="col-span-full p-8 text-center text-slate-500 bg-slate-50 rounded-2xl border border-slate-100 border-dashed">
                No homes registered yet.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Records Tab */}
      {activeTab === 'records' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-bold text-slate-900">Utility Records</h3>
            <button 
              onClick={() => setIsRecordModalOpen(true)}
              className="bg-indigo-600 text-white px-4 py-2 rounded-xl font-bold flex items-center gap-2 hover:bg-indigo-700 transition-all"
            >
              <Plus size={18} /> New Record
            </button>
          </div>
          <div className="sahal-card overflow-hidden bg-white border border-slate-100">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50/50">
                    <th className="p-4 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">Home / Month</th>
                    <th className="p-4 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">Type</th>
                    <th className="p-4 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">Readings</th>
                    <th className="p-4 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">Consumption</th>
                    <th className="p-4 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">Recorded By</th>
                    <th className="p-4 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">Bill</th>
                    <th className="p-4 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">Status</th>
                    <th className="p-4 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {displayRecords.map(record => (
                    <tr key={record.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-4">
                        <p className="font-bold text-slate-900">{record.homeNumber}</p>
                        <p className="text-xs text-slate-500">{record.month}</p>
                      </td>
                      <td className="p-4">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold ${
                          record.type === 'water' ? 'bg-blue-50 text-blue-600' : 'bg-amber-50 text-amber-600'
                        }`}>
                          {record.type === 'water' ? <Droplets size={12} /> : <Zap size={12} />}
                          {record.type}
                        </span>
                      </td>
                      <td className="p-4">
                        <p className="text-sm text-slate-600">Prev: {record.previousReading}</p>
                        <p className="text-sm text-slate-900 font-medium">Curr: {record.currentReading}</p>
                      </td>
                      <td className="p-4 font-mono text-sm">
                        {record.consumption} {record.type === 'water' ? 'm³' : 'kWh'}
                      </td>
                      <td className="p-4 text-sm text-slate-600">{record.recordedBy || 'N/A'}</td>
                      <td className="p-4 font-bold text-slate-900">${(record.totalBill || 0).toFixed(2)}</td>
                      <td className="p-4">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold ${
                          record.isPaid ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'
                        }`}>
                          {record.isPaid ? 'Paid' : 'Unpaid'}
                        </span>
                      </td>
                      <td className="p-4 text-right">
                        <button 
                          onClick={() => handleEditRecord(record)}
                          className="text-slate-400 hover:text-indigo-600 transition-colors mr-3"
                          title="Edit Record"
                        >
                          <Edit2 size={18} />
                        </button>
                        <button 
                          onClick={() => handlePrintReceipt(record)}
                          className="text-slate-400 hover:text-indigo-600 transition-colors mr-3"
                          title="Print Receipt"
                        >
                          <Printer size={18} />
                        </button>
                        {!record.isPaid && (
                          <button 
                            onClick={() => handleMarkPaid(record.id)}
                            className="text-xs font-bold text-emerald-600 hover:text-emerald-700 mr-3"
                          >
                            Mark Paid
                          </button>
                        )}
                        {!isRestrictedStaff && (
                          <button 
                            onClick={() => handleDeleteRecord(record.id)}
                            className="text-slate-400 hover:text-rose-600 transition-colors"
                          >
                            <Trash2 size={18} />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                  {displayRecords.length === 0 && (
                    <tr>
                      <td colSpan={8} className="p-8 text-center text-slate-500">No records found.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Unpaid Tab */}
      {activeTab === 'unpaid' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div className="flex items-center gap-4">
              <h3 className="text-lg font-bold text-slate-900">Unpaid Bills</h3>
              <button 
                onClick={() => handleExportPDF(
                  'Unpaid Utility Bills Report',
                  filteredUnpaid.map(r => ({ 
                    'Home': r.homeNumber, 
                    'Month': r.month, 
                    'Type': r.type, 
                    'Consumption': `${r.consumption} ${r.type === 'water' ? 'm³' : 'kWh'}`, 
                    'Total Bill': `$${(r.totalBill || 0).toFixed(2)}`, 
                    'Recorded By': r.recordedBy 
                  })),
                  ['Home', 'Month', 'Type', 'Consumption', 'Total Bill', 'Recorded By']
                )}
                className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold text-rose-600 bg-rose-50 hover:bg-rose-100 rounded-lg transition-all"
              >
                <Download size={14} /> Download PDF
              </button>
            </div>
            <div className="relative w-full sm:w-64">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="text"
                placeholder="Filter by staff..."
                value={staffFilter}
                onChange={(e) => setStaffFilter(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredUnpaid.map(record => (
              <div key={record.id} className="sahal-card p-6 bg-white border border-rose-100 shadow-sm shadow-rose-50">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h4 className="font-bold text-slate-900 text-lg">{record.homeNumber}</h4>
                    <p className="text-xs text-slate-500">{record.month}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => handleEditRecord(record)}
                      className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                      title="Edit Record"
                    >
                      <Edit2 size={16} />
                    </button>
                    <button 
                      onClick={() => handlePrintReceipt(record)}
                      className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                      title="Print Receipt"
                    >
                      <Printer size={16} />
                    </button>
                    {!isRestrictedStaff && (
                      <button 
                        onClick={() => handleDeleteRecord(record.id)}
                        className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                        title="Delete Record"
                      >
                        <Trash2 size={16} />
                      </button>
                    )}
                    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold ${
                      record.type === 'water' ? 'bg-blue-50 text-blue-600' : 'bg-amber-50 text-amber-600'
                    }`}>
                      {record.type === 'water' ? <Droplets size={12} /> : <Zap size={12} />}
                      {record.type}
                    </span>
                  </div>
                </div>
                <div className="mb-4 space-y-1">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Consumption:</span>
                    <span className="font-mono">{record.consumption} {record.type === 'water' ? 'm³' : 'kWh'}</span>
                  </div>
                  {record.recordedBy && (
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-500">Recorded By:</span>
                      <span className="text-slate-700">{record.recordedBy}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Rate:</span>
                    <span className="font-mono">${record.rate}</span>
                  </div>
                  <div className="flex justify-between font-bold text-lg pt-2 border-t border-slate-100 mt-2">
                    <span className="text-slate-900">Total:</span>
                    <span className="text-rose-600">${(record.totalBill || 0).toFixed(2)}</span>
                  </div>
                </div>
                <button 
                  onClick={() => handleMarkPaid(record.id)}
                  className="w-full py-3 bg-emerald-50 text-emerald-600 rounded-xl font-bold hover:bg-emerald-100 transition-colors flex items-center justify-center gap-2"
                >
                  <CheckCircle2 size={18} /> Mark as Paid
                </button>
              </div>
            ))}
            {filteredUnpaid.length === 0 && (
              <div className="col-span-full p-8 text-center text-slate-500 bg-slate-50 rounded-2xl border border-slate-100 border-dashed">
                No unpaid bills found.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Paid Tab */}
      {activeTab === 'paid' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div className="flex items-center gap-4">
              <h3 className="text-lg font-bold text-slate-900">Paid Bills</h3>
              <button 
                onClick={() => handleExportPDF(
                  'Paid Utility Bills Report',
                  displayPaid
                    .filter(r => !staffFilter || r.collectedBy?.toLowerCase().includes(staffFilter.toLowerCase()))
                    .map(r => ({ 
                      'Home': r.homeNumber, 
                      'Month': r.month, 
                      'Type': r.type, 
                      'Total Paid': `$${(r.totalBill || 0).toFixed(2)}`, 
                      'Collected By': r.collectedBy, 
                      'Paid Date': r.paidAt ? new Date(r.paidAt).toLocaleDateString() : '' 
                    })),
                  ['Home', 'Month', 'Type', 'Total Paid', 'Collected By', 'Paid Date']
                )}
                className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold text-emerald-600 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-all"
              >
                <Download size={14} /> Download PDF
              </button>
            </div>
            <div className="relative w-full sm:w-64">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="text"
                placeholder="Filter by staff..."
                value={staffFilter}
                onChange={(e) => setStaffFilter(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {displayPaid
              .filter(r => !staffFilter || r.collectedBy?.toLowerCase().includes(staffFilter.toLowerCase()))
              .map(record => (
              <div key={record.id} className="sahal-card p-6 bg-white border border-emerald-100 shadow-sm shadow-emerald-50 opacity-75 hover:opacity-100 transition-opacity">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h4 className="font-bold text-slate-900 text-lg">{record.homeNumber}</h4>
                    <p className="text-xs text-slate-500">{record.month}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => handleEditRecord(record)}
                      className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                      title="Edit Record"
                    >
                      <Edit2 size={16} />
                    </button>
                    <button 
                      onClick={() => handlePrintReceipt(record)}
                      className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                      title="Print Receipt"
                    >
                      <Printer size={16} />
                    </button>
                    {!isRestrictedStaff && (
                      <button 
                        onClick={() => handleDeleteRecord(record.id)}
                        className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                        title="Delete Record"
                      >
                        <Trash2 size={16} />
                      </button>
                    )}
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-600">
                      <CheckCircle2 size={12} /> Paid
                    </span>
                  </div>
                </div>
                <div className="mb-4 space-y-1">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Total Paid:</span>
                    <span className="font-bold text-slate-900">${(record.totalBill || 0).toFixed(2)}</span>
                  </div>
                  {record.collectedBy && (
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-500">Collected By:</span>
                      <span className="text-slate-700">{record.collectedBy}</span>
                    </div>
                  )}
                  {record.recordedBy && (
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-500">Recorded By:</span>
                      <span className="text-slate-700">{record.recordedBy}</span>
                    </div>
                  )}
                  {record.paidAt && (
                    <div className="flex justify-between text-xs text-slate-400 pt-2">
                      <span>Date:</span>
                      <span>{new Date(record.paidAt).toLocaleDateString()}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
            {displayPaid.length === 0 && (
              <div className="col-span-full p-8 text-center text-slate-500 bg-slate-50 rounded-2xl border border-slate-100 border-dashed">
                No paid bills found.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Add Home Modal */}
      <Modal 
        isOpen={isHomeModalOpen} 
        onClose={() => setIsHomeModalOpen(false)} 
        title="Add New Home"
        contentClassName="max-w-md"
      >
        <form onSubmit={handleAddHome} className="space-y-4">
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">Home Number</label>
            <input 
              type="text" required
              value={newHome.number}
              onChange={e => setNewHome({...newHome, number: e.target.value})}
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20"
              placeholder="e.g. H-101"
            />
          </div>
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">Owner Name</label>
            <input 
              type="text" required
              value={newHome.ownerName}
              onChange={e => setNewHome({...newHome, ownerName: e.target.value})}
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20"
            />
          </div>
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">Contact (Optional)</label>
            <input 
              type="text"
              value={newHome.contact}
              onChange={e => setNewHome({...newHome, contact: e.target.value})}
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20"
            />
          </div>
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">Counter Staff (Utility)</label>
            <p className="text-xs text-slate-500 mb-2">This staff member will be responsible for this home's records and payments.</p>
            <select 
              required
              value={newHome.assignedStaffName}
              onChange={e => setNewHome({...newHome, assignedStaffName: e.target.value})}
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20"
            >
              <option value="">Select Staff Member</option>
              {staff.map(s => (
                <option key={s.id} value={s.displayName}>{s.displayName}</option>
              ))}
            </select>
          </div>
          <button type="submit" className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-colors">
            Save Home
          </button>
        </form>
      </Modal>

      {/* Add Record Modal */}
      <Modal 
        isOpen={isRecordModalOpen} 
        onClose={() => {
          setIsRecordModalOpen(false);
          setEditingRecordId(null);
          setNewRecord({
            homeId: '',
            type: 'water',
            month: new Date().toISOString().slice(0, 7),
            previousReading: 0,
            currentReading: 0,
            rate: 0,
            recordedBy: '',
            isPaidImmediately: false
          });
        }} 
        title={editingRecordId ? 'Edit Utility Record' : 'Add Utility Record'}
        contentClassName="max-w-md"
      >
        <form onSubmit={handleAddRecord} className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">Select Home</label>
                  <select 
                    required
                    value={newRecord.homeId}
                    onChange={e => setNewRecord({...newRecord, homeId: e.target.value})}
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20"
                  >
                    <option value="">Select a home...</option>
                    {displayHomes.map(h => <option key={h.id} value={h.id}>{h.number} - {h.ownerName}</option>)}
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">Type</label>
                    <select 
                      value={newRecord.type}
                      onChange={e => setNewRecord({...newRecord, type: e.target.value as 'water' | 'electricity'})}
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20"
                      disabled={!isUtilityManager && (canManageWater || canManageElectricity)}
                    >
                      {(!isUtilityManager && canManageWater) || isUtilityManager ? <option value="water">Water</option> : null}
                      {(!isUtilityManager && canManageElectricity) || isUtilityManager ? <option value="electricity">Electricity</option> : null}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">Month</label>
                    <input 
                      type="month" required
                      value={newRecord.month}
                      onChange={e => setNewRecord({...newRecord, month: e.target.value})}
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">
                      {newRecord.type === 'water' ? 'Previous Reading (m³)' : 'Previous Reading (kWh)'}
                    </label>
                    <input 
                      type="number" required min="0" step="0.01"
                      value={newRecord.previousReading}
                      onChange={e => setNewRecord({...newRecord, previousReading: parseFloat(e.target.value) || 0})}
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">
                      {newRecord.type === 'water' ? 'Current Reading (m³)' : 'Current Reading (kWh)'}
                    </label>
                    <input 
                      type="number" required min="0" step="0.01"
                      value={newRecord.currentReading}
                      onChange={e => setNewRecord({...newRecord, currentReading: parseFloat(e.target.value) || 0})}
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">Rate per {newRecord.type === 'water' ? 'm³' : 'kWh'} ($)</label>
                  <input 
                    type="number" required min="0" step="0.01"
                    value={newRecord.rate}
                    onChange={e => setNewRecord({...newRecord, rate: parseFloat(e.target.value) || 0})}
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>

                {!isRestrictedStaff && (
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">Recorded By (Counter)</label>
                    <select 
                      required
                      value={newRecord.recordedBy}
                      onChange={e => setNewRecord({...newRecord, recordedBy: e.target.value})}
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20"
                    >
                      <option value="">Select Staff Member</option>
                      {staff.map(s => (
                        <option key={s.id} value={s.displayName}>{s.displayName}</option>
                      ))}
                    </select>
                  </div>
                )}

                <div className="flex items-center gap-3 p-4 bg-indigo-50 rounded-xl border border-indigo-100">
                  <input 
                    type="checkbox"
                    id="isPaidImmediately"
                    checked={newRecord.isPaidImmediately}
                    onChange={e => setNewRecord({...newRecord, isPaidImmediately: e.target.checked})}
                    className="w-5 h-5 text-indigo-600 rounded focus:ring-indigo-500"
                  />
                  <label htmlFor="isPaidImmediately" className="text-sm font-bold text-indigo-900 cursor-pointer">
                    Mark as Paid Now (Money Collected)
                  </label>
                </div>
                
                {/* Preview Calculation */}
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Consumption:</span>
                    <span className="font-mono font-bold text-slate-900">
                      {Math.max(0, newRecord.currentReading - newRecord.previousReading).toFixed(2)} units
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Estimated Bill:</span>
                    <span className="font-mono font-bold text-indigo-600">
                      ${(Math.max(0, newRecord.currentReading - newRecord.previousReading) * newRecord.rate).toFixed(2)}
                    </span>
                  </div>
                </div>

                <div className="flex gap-3">
                  <button 
                    type="submit" 
                    className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-colors"
                  >
                    {editingRecordId ? 'Update Record' : 'Save Record'}
                  </button>
                  {!editingRecordId && (
                    <button 
                      type="button"
                      onClick={(e) => handleAddRecord(e as any, true)}
                      className="px-4 py-3 bg-slate-100 text-slate-700 rounded-xl font-bold hover:bg-slate-200 transition-colors flex items-center gap-2"
                    >
                      <Printer size={18} />
                      Print
                    </button>
                  )}
                </div>
              </form>
            </Modal>
    </div>
  );
}
