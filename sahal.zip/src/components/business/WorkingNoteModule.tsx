import React, { useState, useEffect } from 'react';
import { supabase } from '../../supabase';
import { WorkingNote, UserProfile } from '../../types';
import { Plus, Search, Edit2, Trash2, FileText, ChevronRight, Clock, Calendar, RefreshCw } from 'lucide-react';
import { useLanguage } from '../LanguageContext';
import Modal from '../Modal';
import { motion, AnimatePresence } from 'motion/react';

export default function WorkingNoteModule({ user }: { user: UserProfile }) {
  const { t } = useLanguage();
  const [notes, setNotes] = useState<WorkingNote[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<WorkingNote | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    branchId: user.branchId || ''
  });

  const fetchNotes = async () => {
    if (!user.tenantId) return;
    setLoading(true);
    try {
      let query = supabase
        .from('working_notes')
        .select('*')
        .eq('tenant_id', user.tenantId)
        .not('title', 'ilike', '[CART]%')
        .order('created_at', { ascending: false });
      
      if (user.branchId) {
        query = query.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
      }
      
      const { data: notesData } = await query;
      setNotes(notesData || []);
    } catch (error) {
      console.error("Error fetching notes:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNotes();
  }, [user.tenantId, user.branchId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.tenantId) return;
    try {
      const noteData = {
        title: formData.title,
        content: formData.content,
        tenant_id: user.tenantId,
        branch_id: formData.branchId || user.branchId || null,
        created_at: editingNote ? editingNote.createdAt : new Date().toISOString()
      };

      if (editingNote) {
        await supabase.from('working_notes').update(noteData).eq('id', editingNote.id);
      } else {
        await supabase.from('working_notes').insert(noteData);
      }
      setIsModalOpen(false);
      setEditingNote(null);
      setFormData({ title: '', content: '' });
      fetchNotes();
    } catch (error) {
      console.error("Error saving note:", error);
    }
  };

  const handleDelete = async (id: string) => {
    if (!user.tenantId || !window.confirm(t('delete_confirm'))) return;
    try {
      await supabase.from('working_notes').delete().eq('id', id);
      fetchNotes();
    } catch (error) {
      console.error("Error deleting note:", error);
    }
  };

  const openEdit = (n: WorkingNote) => {
    setEditingNote(n);
    setFormData({
      title: n.title || '',
      content: n.content || ''
    });
    setIsModalOpen(true);
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-3xl font-display font-bold text-slate-900">{t('working_note')}</h2>
          <p className="text-slate-500">{t('manage_notes_desc' as any) || 'Keep track of your daily business operations and notes.'}</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={fetchNotes}
            disabled={loading}
            className={`p-3 bg-white text-slate-600 rounded-xl font-bold text-sm border border-slate-200 hover:bg-slate-50 transition-all flex items-center gap-2 ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
            title={t('refresh')}
          >
            <RefreshCw size={18} className={loading ? 'animate-spin' : ''} />
          </button>
          <button
            onClick={() => {
              setEditingNote(null);
              setFormData({ title: '', content: '' });
              setIsModalOpen(true);
            }}
            className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
          >
            <Plus size={20} />
            <span>{t('add_note')}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {notes.map(n => (
          <motion.div
            layout
            key={n.id}
            className="sahal-card p-6 group hover:border-indigo-200 transition-all flex flex-col h-full"
          >
            <div className="flex justify-between items-start mb-4">
              <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl"><FileText size={20} /></div>
              <div className="flex gap-2 transition-opacity">
                <button onClick={() => openEdit(n)} className="p-2 hover:bg-indigo-50 text-indigo-600 rounded-lg transition-colors">
                  <Edit2 size={16} />
                </button>
                <button onClick={() => handleDelete(n.id)} className="p-2 hover:bg-rose-50 text-rose-600 rounded-lg transition-colors">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
            <h4 className="text-lg font-bold text-slate-900 mb-2">{n.title}</h4>
            <p className="text-sm text-slate-500 line-clamp-4 mb-6 flex-1">{n.content}</p>
            <div className="flex items-center gap-4 pt-4 border-t border-slate-50 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
              <div className="flex items-center gap-1.5"><Calendar size={12} /> {new Date(n.createdAt).toLocaleDateString()}</div>
              <div className="flex items-center gap-1.5"><Clock size={12} /> {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
            </div>
          </motion.div>
        ))}
        {notes.length === 0 && (
          <div className="col-span-full p-20 text-center sahal-card">
            <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <FileText size={32} className="text-slate-200" />
            </div>
            <p className="text-slate-400 font-medium italic">{t('no_data')}</p>
          </div>
        )}
      </div>

      <Modal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        title={editingNote ? t('edit' as any) || 'Edit' : t('add_note')}
        contentClassName="max-w-2xl"
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('note_title')}</label>
            <input
              type="text"
              required
              value={formData.title}
              onChange={e => setFormData({ ...formData, title: e.target.value })}
              className="sahal-input"
              placeholder={t('note_title')}
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('note_content')}</label>
            <textarea
              required
              rows={8}
              value={formData.content}
              onChange={e => setFormData({ ...formData, content: e.target.value })}
              className="sahal-input resize-none"
              placeholder={t('note_content')}
            />
          </div>
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="flex-1 px-6 py-4 bg-slate-100 text-slate-600 rounded-2xl font-bold hover:bg-slate-200 transition-all"
            >
              {t('cancel')}
            </button>
            <button
              type="submit"
              className="flex-1 px-6 py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
            >
              {t('save')}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
