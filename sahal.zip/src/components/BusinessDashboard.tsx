import React, { useState, useEffect, lazy, Suspense } from 'react';
import { supabase } from '../supabase';
import { Tenant, UserProfile, InventoryItem, Sale, StaffMember, Patient, Expense, Debt, PrescriptionItem } from '../types';
import { filterByDate, getLocalDateString } from '../lib/dateUtils';
import { 
  Package, 
  ShoppingCart, 
  Wallet, 
  Receipt, 
  Users, 
  ArrowRight,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  Clock,
  Calendar,
  ChevronRight,
  Plus,
  Trash2,
  Shield,
  Key,
  UserPlus,
  Edit2,
  Eye,
  EyeOff,
  Zap,
  AlertCircle,
  CreditCard,
  Building2,
  Activity,
  Phone,
  Droplets,
  RefreshCw,
  Briefcase,
  DollarSign
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from './LanguageContext';
import DateSelector from './DateSelector';
import Modal from './Modal';

// Lazy load modules for better performance
const InventoryModule = lazy(() => import('./business/InventoryModule'));
const SalesModule = lazy(() => import('./business/SalesModule'));
const DebtsModule = lazy(() => import('./business/DebtsModule'));
const ExpensesModule = lazy(() => import('./business/ExpensesModule'));
const ReportsModule = lazy(() => import('./business/ReportsModule'));
const BusinessSettingsModule = lazy(() => import('./business/BusinessSettingsModule'));
const HospitalModule = lazy(() => import('./business/HospitalModule'));
const SubscriptionModule = lazy(() => import('./business/SubscriptionModule'));
const CRMModule = lazy(() => import('./business/CRMModule'));
const ServicesModule = lazy(() => import('./business/ServicesModule'));
const UtilityModule = lazy(() => import('./business/UtilityModule'));
const SavingModule = lazy(() => import('./business/SavingModule'));
const InvestmentModule = lazy(() => import('./business/InvestmentModule'));
const WorkingNoteModule = lazy(() => import('./business/WorkingNoteModule'));
const DailyTaskModule = lazy(() => import('./business/DailyTaskModule'));
const KeepingIdeasModule = lazy(() => import('./business/KeepingIdeasModule'));
const StaffModule = lazy(() => import('./business/StaffModule'));
const AssetsEquityModule = lazy(() => import('./business/AssetsEquityModule'));
const FinanceModule = lazy(() => import('./business/FinanceModule'));
const AIChatModule = lazy(() => import('./business/AIChatModule'));

export default function BusinessDashboard({ 
  activeTab, 
  user, 
  setActiveTab, 
  managerPhone,
  initialSearch,
  setInitialSearch,
  initialModuleTab,
  setInitialModuleTab
}: { 
  activeTab: string, 
  user: UserProfile, 
  setActiveTab: (tab: string) => void, 
  managerPhone?: string,
  initialSearch?: string,
  setInitialSearch?: (search: string) => void,
  initialModuleTab?: string,
  setInitialModuleTab?: (tab: string | undefined) => void
}) {
  const { t } = useLanguage();
  const [tenant, setTenant] = useState<Tenant | null>(null);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [pendingPrescription, setPendingPrescription] = useState<{ items: PrescriptionItem[], total: number, patientName?: string, patientPhone?: string, visitId?: string } | null>(null);
  const navigateToSales = (prescription: PrescriptionItem[], total: number, patientName?: string, patientPhone?: string, visitId?: string) => {
    setPendingPrescription({ items: prescription, total, patientName, patientPhone, visitId });
    setActiveTab('sales');
  };
  const [expenses, setExpenses] = useState<any[]>([]);
  const [debts, setDebts] = useState<any[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [utilityRecords, setUtilityRecords] = useState<any[]>([]);
  const [workingNotes, setWorkingNotes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Confirmation Modal State
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  const openConfirm = (title: string, message: string, onConfirm: () => void) => {
    setConfirmModal({
      isOpen: true,
      title,
      message,
      onConfirm: () => {
        onConfirm();
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const RenderConfirmModal = () => (
    <Modal 
      isOpen={confirmModal.isOpen} 
      onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))} 
      title={confirmModal.title}
    >
      <div className="space-y-6">
        <div className="flex items-center gap-4 p-4 bg-red-50 dark:bg-red-500/10 rounded-2xl text-red-600 dark:text-red-400 border border-red-100 dark:border-red-900/30">
          <Trash2 className="w-[var(--icon-md)] h-[var(--icon-md)]" />
          <p className="text-sm font-medium">{confirmModal.message}</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
            className="flex-1 px-6 py-4 bg-bg-sec text-ink-secondary rounded-xl font-bold hover:bg-bg-soft transition-all"
          >
            {t('cancel')}
          </button>
          <button 
            onClick={confirmModal.onConfirm}
            className="flex-1 px-6 py-4 bg-red-600 text-white rounded-xl font-bold hover:bg-red-700 transition-all shadow-lg shadow-red-200 dark:shadow-none"
          >
            {t('delete')}
          </button>
        </div>
      </div>
    </Modal>
  );

  const [selectedDate, setSelectedDate] = useState(new Date());
  const [mode, setMode] = useState<'day' | 'month' | 'year' | 'range'>('day');
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());
  
  const ModuleDisabled = ({ name }: { name: string }) => (
    <div className="flex flex-col items-center justify-center p-24 text-center">
      <div className="w-24 h-24 bg-bg-sec rounded-[2.5rem] flex items-center justify-center mb-8 border border-border-main">
        <AlertTriangle className="w-[var(--icon-lg)] h-[var(--icon-lg)] text-ink-tertiary" />
      </div>
      <h3 className="text-2xl font-display font-bold text-ink mb-3">{t('no_permission')}</h3>
      <p className="text-ink-secondary max-w-md font-medium">
        {user.isStaff 
          ? t('contact_manager')
          : t('module_disabled_desc')}
      </p>
    </div>
  );

  const fetchData = async () => {
    if (!user.tenantId) return;
    setLoading(true);
    try {
      // Helper for branch filtered queries
      const buildQuery = (table: string) => {
        let q = supabase.from(table).select('*').eq('tenant_id', user.tenantId);
        if (user.branchId) {
          q = q.eq('branch_id', user.branchId);
        }
        return q;
      };

      // Parallelize all data fetching including tenant data
      const [
        { data: tenantData },
        { data: invData },
        { data: salesData },
        { data: expData },
        { data: debtData },
        { data: patientData },
        { data: utilData },
        { data: homeData }
      ] = await Promise.all([
        supabase.from('tenants').select('*').eq('id', user.tenantId).single(),
        buildQuery('inventory'),
        buildQuery('sales').order('created_at', { ascending: false }),
        buildQuery('expenses').order('created_at', { ascending: false }),
        buildQuery('debts').order('created_at', { ascending: false }),
        buildQuery('patients'),
        buildQuery('utility_records'),
        buildQuery('working_notes')
      ]);
        
      if (tenantData) {
        setTenant({
          ...tenantData,
          logoUrl: tenantData.logo_url,
          paymentNumbers: tenantData.payment_numbers,
          subscriptionPlan: tenantData.subscription_plan,
          planExpiry: tenantData.plan_expiry,
          isLocked: tenantData.is_locked,
          isMultiBranch: tenantData.is_multi_branch
        });

        if (invData) {
          setInventory(invData.map(item => ({
            id: item.id,
            name: item.name,
            sku: item.sku,
            quantity: item.quantity,
            costPrice: item.cost_price,
            price: item.price,
            minStock: item.min_stock,
            imageUrl: item.image_url,
            tenantId: item.tenant_id,
            branchId: item.branch_id,
            createdAt: item.created_at
          })));
        }

        if (salesData) {
          setSales(salesData.map(s => ({
            id: s.id,
            items: s.items,
            total: s.total,
            tax: s.tax,
            paidAmount: s.paid_amount,
            debtAmount: s.debt_amount,
            customerName: s.customer_name,
            status: s.status,
            paymentMethods: s.payment_methods,
            tenantId: s.tenant_id,
            branchId: s.branch_id,
            createdAt: s.created_at,
            debtId: s.debt_id,
            sellerName: s.seller_name,
            creditUsed: s.credit_used
          })));
        }

        if (expData) {
          setExpenses(expData.map(e => ({
            id: e.id,
            category: e.category,
            description: e.description,
            amount: e.amount,
            date: e.date,
            tenantId: e.tenant_id,
            branchId: e.branch_id,
            createdAt: e.created_at
          })));
        }

        if (debtData) {
          setDebts(debtData.map(d => ({
            id: d.id,
            customerName: d.customer_name,
            phone: d.phone,
            amount: d.amount,
            paidAmount: d.paid_amount,
            status: d.status,
            tenantId: d.tenant_id,
            branchId: d.branch_id,
            createdAt: d.created_at,
            dueDate: d.due_date,
            type: d.type,
            description: d.description
          })));
        }

        if (patientData) {
          setPatients(patientData.map(p => ({
            id: p.id,
            name: p.name,
            phone: p.phone,
            tenantId: p.tenant_id,
            createdAt: p.created_at
          })));
        }

        if (utilData) {
          setUtilityRecords(utilData.map(r => ({
            id: r.id,
            tenantId: r.tenant_id,
            type: r.type,
            amount: r.amount,
            totalBill: r.total_bill,
            isPaid: r.is_paid,
            createdAt: r.created_at
          })));
        }

        if (homeData) {
          setWorkingNotes(homeData);
        }
      }
    } catch (error) {
      console.error("Error fetching business data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [user.tenantId, user.branchId]);

    if (loading) {
      return (
        <div className="flex items-center justify-center p-20">
          <div className="w-10 h-10 border-4 border-bg-sec border-t-indigo-600 rounded-full animate-spin" />
        </div>
      );
    }
    
    if (!tenant) return <div className="p-20 text-center font-display font-bold text-ink-tertiary uppercase tracking-widest">{t('tenant_not_found')}</div>;

  if (activeTab === 'overview') {
    if (user.isStaff) return <ModuleDisabled name={t('dashboard')} />;

    const filteredSales = sales.filter(s => filterByDate(s.createdAt, selectedDate, mode, startDate, endDate));

    const filteredDebts = debts.filter(d => filterByDate(d.createdAt, selectedDate, mode, startDate, endDate));

    const filteredExpenses = expenses.filter(e => filterByDate(e.date ? e.date.substring(0, 10) : e.createdAt, selectedDate, mode, startDate, endDate));

    const filteredUtility = utilityRecords.filter(r => filterByDate(r.createdAt, selectedDate, mode, startDate, endDate));

    const revenue = filteredSales.reduce((sum, s) => sum + s.total, 0);
    const utilityCollected = filteredUtility.filter(r => r.isPaid).reduce((sum, r) => sum + r.totalBill, 0);
    const utilityUnpaid = filteredUtility.filter(r => !r.isPaid).reduce((sum, r) => sum + r.totalBill, 0);
    const utilityPotential = utilityCollected + utilityUnpaid;

    const businessDebtPayments = filteredDebts.reduce((sum, d) => {
      if (d.type === 'business' || d.type === 'supplier') return sum + (d.paidAmount || 0);
      return sum;
    }, 0);

    const totalExpenses = filteredExpenses.reduce((sum, e) => sum + e.amount, 0) + utilityPotential + businessDebtPayments;
    
    const todayStr = getLocalDateString(new Date());
    const todayExpensesBase = expenses.filter(e => {
      const expDateStr = e.date ? e.date.substring(0, 10) : getLocalDateString(new Date(e.createdAt));
      return expDateStr === todayStr;
    }).reduce((sum, e) => sum + e.amount, 0);
    
    const todayUtility = utilityRecords.filter(r => {
      return getLocalDateString(new Date(r.createdAt)) === todayStr;
    }).reduce((sum, r) => sum + r.totalBill, 0);
    
    const todayExpenses = todayExpensesBase + todayUtility;

    const totalInventoryItems = inventory.reduce((sum, i) => sum + i.quantity, 0);
    const totalInventoryValue = inventory.reduce((sum, i) => sum + (i.quantity * (i.costPrice || 0)), 0);
    const lowStockItems = inventory.filter(i => i.quantity <= i.minStock).length;
    const totalOutstanding = filteredDebts.reduce((sum, d) => sum + (d.amount - d.paidAmount), 0);
    
    // Alert Calculations
    const overdueDebts = debts.filter(d => 
      d.status === 'unpaid' && 
      d.dueDate && 
      new Date(d.dueDate) < new Date()
    );

    const outOfStockItems = inventory.filter(i => i.quantity <= 0);
    const lowStockItemsCount = inventory.filter(i => i.quantity <= i.minStock && i.quantity > 0).length;
    
    const lossMakingSales = sales.filter(s => {
      return s.items.some((item: any) => {
        const cost = item.costPrice || 0;
        return item.price < cost;
      });
    });

    const parkedOrdersCount = workingNotes.length;

    const daysUntilExpiry = tenant?.planExpiry ? Math.ceil((new Date(tenant.planExpiry).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)) : null;
    const isSubscriptionExpired = daysUntilExpiry !== null && daysUntilExpiry <= 0;
    const isSubscriptionExpiringSoon = daysUntilExpiry !== null && daysUntilExpiry <= 7 && daysUntilExpiry > 0;

    const showSubscriptionAlert = tenant && (
      isSubscriptionExpired || 
      isSubscriptionExpiringSoon || 
      ['past_due', 'unpaid', 'suspended', 'cancelled'].includes(tenant.subscriptionStatus || '')
    );

    // Trend Calculations
    const getPreviousDateRange = () => {
      const prev = new Date(selectedDate);
      if (mode === 'day') {
        prev.setDate(prev.getDate() - 1);
      } else {
        prev.setMonth(prev.getMonth() - 1);
      }
      return prev;
    };

    const previousDate = getPreviousDateRange();

    const previousSales = sales.filter(s => filterByDate(s.createdAt, previousDate, mode === 'day' ? 'day' : 'month'));

    const previousPatients = patients.filter(p => filterByDate(p.createdAt || '', previousDate, mode === 'day' ? 'day' : 'month'));

    const previousRevenue = previousSales.reduce((sum, s) => sum + s.total, 0);

    const previousDebts = debts.filter(d => filterByDate(d.createdAt, previousDate, mode === 'day' ? 'day' : 'month'));
    const previousOutstanding = previousDebts.reduce((sum, d) => sum + (d.amount - d.paidAmount), 0);

    const previousExpenses = expenses.filter(e => filterByDate(e.date ? e.date.substring(0, 10) : e.createdAt, previousDate, mode === 'day' ? 'day' : 'month'));
    const previousBusinessDebtPayments = previousDebts.reduce((sum, d) => {
      if (d.type === 'business' || d.type === 'supplier') return sum + (d.paidAmount || 0);
      return sum;
    }, 0);
    const previousTotalExpenses = previousExpenses.reduce((sum, e) => sum + e.amount, 0) + previousBusinessDebtPayments;

    const previousUtility = utilityRecords.filter(r => filterByDate(r.createdAt, previousDate, mode === 'day' ? 'day' : 'month'));
    const previousUtilityCollected = previousUtility.filter(r => r.isPaid).reduce((sum, r) => sum + r.totalBill, 0);

    const TrendBadge = ({ current, previous, invert = false }: { current: number, previous: number, invert?: boolean }) => {
      const change = previous === 0 ? (current > 0 ? 100 : 0) : ((current - previous) / previous) * 100;
      const isPositive = change > 0;
      const isNeutral = change === 0;

      if (isNeutral) return null;

      const isGood = invert ? !isPositive : isPositive;
      const colorClass = isGood ? 'text-emerald-600 border-emerald-100 dark:border-emerald-900/30' : 'text-rose-600 border-rose-100 dark:border-rose-900/30';

      return (
        <div className={`flex items-center gap-1 text-[10px] font-bold ${colorClass} bg-surface-main/50 px-2 py-0.5 rounded-full border mt-2 w-fit`}>
          {isPositive ? <TrendingUp size={10} /> : <TrendingDown size={10} />}
          {Math.abs(change).toFixed(1)}%
          <span className="text-ink-tertiary font-normal ml-1 lowercase">{t('vs_previous')}</span>
        </div>
      );
    };

    const revenueChange = previousRevenue === 0 ? (revenue > 0 ? 100 : 0) : ((revenue - previousRevenue) / previousRevenue) * 100;

    return (
      <div className="space-y-10">
        <header className="flex flex-col lg:flex-row justify-between items-start lg:items-end gap-6">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-3">
              <span className="px-3 py-1 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 text-[10px] font-black uppercase tracking-[0.2em] rounded-full border border-indigo-100 dark:border-indigo-900/30">
                {t(tenant.type as any)} {t('settings')}
              </span>
              <div className="w-1.5 h-1.5 rounded-full bg-ink-tertiary" />
              <span className="text-[10px] font-bold text-ink-tertiary uppercase tracking-widest">{new Date().toLocaleDateString('so-SO', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</span>
            </div>
            <h1 className="text-5xl sm:text-6xl font-display font-black tracking-tighter text-[var(--ink)] uppercase leading-none">{tenant.name}</h1>
          </div>
          
          <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
            <DateSelector 
              selectedDate={selectedDate} 
              onChange={setSelectedDate} 
              mode={mode} 
              onModeChange={setMode} 
              startDate={startDate}
              endDate={endDate}
              onRangeChange={(start, end) => {
                setStartDate(start);
                setEndDate(end);
              }}
            />
            <button 
              onClick={fetchData}
              className="p-3 bg-surface-main border border-border-main rounded-2xl text-ink-tertiary hover:text-indigo-600 hover:border-indigo-100 dark:hover:border-indigo-900/50 hover:bg-indigo-50 dark:hover:bg-indigo-950/20 transition-all shadow-sm"
            >
              <RefreshCw size={20} className={loading ? 'animate-spin' : ''} />
            </button>
          </div>
        </header>

        {/* Performance Summary Banner */}
        {Math.abs(revenueChange) > 0 && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className={`p-8 rounded-[2.5rem] border-2 ${revenueChange > 0 ? 'bg-emerald-50/50 border-emerald-100 text-emerald-900' : 'bg-rose-50/50 border-rose-100 text-rose-900'} flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden`}
          >
            <div className={`absolute top-0 right-0 w-64 h-64 ${revenueChange > 0 ? 'bg-emerald-100/30' : 'bg-rose-100/30'} rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl`} />
            <div className="flex items-center gap-6 relative z-10">
              <div className={`w-16 h-16 rounded-[2rem] flex items-center justify-center shadow-xl ${revenueChange > 0 ? 'bg-emerald-500 text-white shadow-emerald-200' : 'bg-rose-500 text-white shadow-rose-200'}`}>
                {revenueChange > 0 ? <TrendingUp size={32} /> : <TrendingDown size={32} />}
              </div>
              <div>
                <h3 className="text-2xl font-display font-black uppercase tracking-tight">
                  {revenueChange > 0 ? t('growth') : t('decline')}
                </h3>
                <p className="text-base font-medium opacity-70 max-w-xl">
                  {revenueChange > 0 
                    ? `Ganacsigaagu wuxuu kordhay ${revenueChange.toFixed(1)}% marka loo eego xiligii hore. Tani waa guul weyn!`
                    : `Ganacsigaagu wuxuu hoos u dhacay ${Math.abs(revenueChange).toFixed(1)}% marka loo eego xiligii hore. Fadlan dib u eeg istiraatiijiyadaada.`
                  }
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3 relative z-10">
              <div className="text-right hidden md:block">
                <p className="text-[10px] font-black uppercase tracking-widest opacity-40 mb-1">{t('period')}</p>
                <p className="text-sm font-bold">{mode === 'day' ? t('today') : t('this_month')}</p>
              </div>
              <div className="w-px h-8 bg-current opacity-10 hidden md:block" />
              <button 
                onClick={() => setActiveTab('reports')}
                className={`px-6 py-3 rounded-2xl font-bold text-sm transition-all shadow-lg ${revenueChange > 0 ? 'bg-emerald-600 text-white shadow-emerald-100 hover:bg-emerald-700' : 'bg-rose-600 text-white shadow-rose-100 hover:bg-rose-700'}`}
              >
                {t('view_reports')}
              </button>
            </div>
          </motion.div>
        )}

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-8">
          {tenant.modules.hospital && (
            <div 
              className="sahal-card p-5 sm:p-8 relative overflow-hidden group cursor-pointer hover:shadow-xl transition-all"
              onClick={() => setActiveTab('hospital')}
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-50 dark:bg-indigo-900/10 rounded-full -translate-y-1/2 translate-x-1/2 group-hover:scale-110 transition-transform duration-500" />
              <div className="relative z-10">
                <div className="flex justify-between items-start mb-4 sm:mb-6">
                  <div className="p-2 sm:p-3 bg-indigo-600 text-white rounded-xl sm:rounded-2xl shadow-lg shadow-indigo-100 dark:shadow-none"><Users size={20} /></div>
                  <span className="text-[8px] sm:text-xs font-bold text-indigo-600 bg-indigo-50 dark:bg-indigo-950/30 px-2 py-0.5 rounded-full border border-indigo-100 dark:border-indigo-900/30">{t('patients')}</span>
                </div>
                <p className="text-[8px] sm:text-xs font-bold uppercase tracking-[0.15em] text-ink-tertiary mb-1">{t('patient_records')}</p>
                <p className="text-xl sm:text-4xl font-display font-bold text-ink tracking-tight">{patients.length} <span className="text-xs sm:text-lg font-medium text-ink-tertiary/40">{t('people_count')}</span></p>
                <div className="hidden sm:block">
                  <TrendBadge 
                    current={patients.filter(p => {
                    const pDate = new Date(p.createdAt || '');
                    if (mode === 'day') return pDate.toLocaleDateString() === selectedDate.toLocaleDateString();
                    return pDate.getMonth() === selectedDate.getMonth() && pDate.getFullYear() === selectedDate.getFullYear();
                  }).length} 
                  previous={previousPatients.length} 
                />
                </div>
              </div>
            </div>
          )}
          {tenant.modules.inventory && (
            <div 
              className="sahal-card p-6 sm:p-8 relative overflow-hidden group cursor-pointer hover:shadow-xl transition-all"
              onClick={() => setActiveTab('inventory')}
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-amber-50 rounded-full -translate-y-1/2 translate-x-1/2 group-hover:scale-110 transition-transform duration-500" />
              <div className="relative z-10">
                <div className="flex justify-between items-start mb-4 sm:mb-6">
                  <div className="p-2 sm:p-3 bg-amber-500 text-white rounded-xl sm:rounded-2xl shadow-lg shadow-amber-100 dark:shadow-none"><Package size={20} /></div>
                  <span className="text-[8px] sm:text-xs font-bold text-amber-600 bg-amber-50 dark:bg-amber-950/30 px-2 py-0.5 rounded-full border border-amber-100 dark:border-amber-900/30">{lowStockItems}</span>
                </div>
                <p className="text-[8px] sm:text-xs font-bold uppercase tracking-[0.15em] text-ink-tertiary mb-1">Value</p>
                <p className="text-xl sm:text-4xl font-display font-bold text-ink tracking-tight">${totalInventoryValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
                <p className="text-[10px] sm:text-sm font-medium text-ink-secondary mt-1">{totalInventoryItems.toLocaleString()} {t('items_count')}</p>
              </div>
            </div>
          )}
          {tenant.modules.sales && (
            <div 
              className="sahal-card p-6 sm:p-8 relative overflow-hidden group cursor-pointer hover:shadow-xl transition-all"
              onClick={() => setActiveTab('sales')}
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-50 rounded-full -translate-y-1/2 translate-x-1/2 group-hover:scale-110 transition-transform duration-500" />
              <div className="relative z-10">
                <div className="flex justify-between items-start mb-4 sm:mb-6">
                  <div className="p-2 sm:p-3 bg-emerald-500 text-white rounded-xl sm:rounded-2xl shadow-lg shadow-emerald-100 dark:shadow-none"><TrendingUp size={20} /></div>
                  <span className="text-[8px] sm:text-xs font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/30 px-2 py-0.5 rounded-full border border-emerald-100 dark:border-emerald-900/30">{mode === 'day' ? t('today') : t('month')}</span>
                </div>
                <p className="text-[8px] sm:text-xs font-bold uppercase tracking-[0.15em] text-ink-tertiary mb-1">{t('revenue')}</p>
                <p className="text-xl sm:text-4xl font-display font-bold text-ink tracking-tight">${(revenue || 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
                <div className="hidden sm:block">
                  <TrendBadge current={revenue} previous={previousRevenue} />
                </div>
              </div>
            </div>
          )}
          {(tenant.modules.utility_water || tenant.modules.utility_electricity) && !user.isStaff && (
            <>
              {tenant.modules.utility_water && (
                <div 
                  className="sahal-card p-6 sm:p-8 relative overflow-hidden group cursor-pointer hover:shadow-xl transition-all"
                  onClick={() => setActiveTab('utility_water')}
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-50 rounded-full -translate-y-1/2 translate-x-1/2 group-hover:scale-110 transition-transform duration-500" />
                  <div className="relative z-10">
                    <div className="flex justify-between items-start mb-6">
                      <div className="p-3 bg-indigo-600 text-white rounded-2xl shadow-lg shadow-indigo-100"><Droplets size={24} /></div>
                      <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full border border-indigo-100">{t('water')}</span>
                    </div>
                    <p className="text-xs font-bold uppercase tracking-[0.15em] text-slate-400 mb-1">{t('total_collected')}</p>
                    <p className="text-3xl sm:text-4xl font-display font-bold text-slate-900 tracking-tight">${(utilityRecords.filter(r => r.type === 'water' && r.isPaid).reduce((sum, r) => sum + r.totalBill, 0) || 0).toFixed(2)}</p>
                  </div>
                </div>
              )}
              {tenant.modules.utility_electricity && (
                <div 
                  className="sahal-card p-6 sm:p-8 relative overflow-hidden group cursor-pointer hover:shadow-xl transition-all"
                  onClick={() => setActiveTab('utility_electricity')}
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-50 rounded-full -translate-y-1/2 translate-x-1/2 group-hover:scale-110 transition-transform duration-500" />
                  <div className="relative z-10">
                    <div className="flex justify-between items-start mb-6">
                      <div className="p-3 bg-emerald-500 text-white rounded-2xl shadow-lg shadow-emerald-100"><Zap size={24} /></div>
                      <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100">{t('electricity')}</span>
                    </div>
                    <p className="text-xs font-bold uppercase tracking-[0.15em] text-slate-400 mb-1">{t('total_collected')}</p>
                    <p className="text-3xl sm:text-4xl font-display font-bold text-slate-900 tracking-tight">${(utilityRecords.filter(r => r.type === 'electricity' && r.isPaid).reduce((sum, r) => sum + r.totalBill, 0) || 0).toFixed(2)}</p>
                  </div>
                </div>
              )}
            </>
          )}
          {(tenant.modules.utility_water || tenant.modules.utility_electricity) && !user.isStaff && (
            <>
              {tenant.modules.utility_water && (
                <div 
                  className="sahal-card p-6 sm:p-8 relative overflow-hidden group cursor-pointer hover:shadow-xl transition-all"
                  onClick={() => {
                    setInitialModuleTab?.('unpaid');
                    setActiveTab('utility_water');
                  }}
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-rose-50 rounded-full -translate-y-1/2 translate-x-1/2 group-hover:scale-110 transition-transform duration-500" />
                  <div className="relative z-10">
                    <div className="flex justify-between items-start mb-6">
                      <div className="p-3 bg-rose-500 text-white rounded-2xl shadow-lg shadow-rose-100"><AlertCircle size={24} /></div>
                      <span className="text-xs font-bold text-rose-600 bg-rose-50 px-3 py-1 rounded-full border border-rose-100">{t('water_unpaid')}</span>
                    </div>
                    <p className="text-xs font-bold uppercase tracking-[0.15em] text-slate-400 mb-1">{t('total_unpaid')}</p>
                    <p className="text-3xl sm:text-4xl font-display font-bold text-rose-600 tracking-tight">${(utilityRecords.filter(r => r.type === 'water' && !r.isPaid).reduce((sum, r) => sum + r.totalBill, 0) || 0).toFixed(2)}</p>
                  </div>
                </div>
              )}
              {tenant.modules.utility_electricity && (
                <div 
                  className="sahal-card p-6 sm:p-8 relative overflow-hidden group cursor-pointer hover:shadow-xl transition-all"
                  onClick={() => {
                    setInitialModuleTab?.('unpaid');
                    setActiveTab('utility_electricity');
                  }}
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-rose-50 rounded-full -translate-y-1/2 translate-x-1/2 group-hover:scale-110 transition-transform duration-500" />
                  <div className="relative z-10">
                    <div className="flex justify-between items-start mb-6">
                      <div className="p-3 bg-rose-500 text-white rounded-2xl shadow-lg shadow-rose-100"><AlertCircle size={24} /></div>
                      <span className="text-xs font-bold text-rose-600 bg-rose-50 px-3 py-1 rounded-full border border-rose-100">{t('electricity_unpaid')}</span>
                    </div>
                    <p className="text-xs font-bold uppercase tracking-[0.15em] text-slate-400 mb-1">{t('total_unpaid')}</p>
                    <p className="text-3xl sm:text-4xl font-display font-bold text-rose-600 tracking-tight">${(utilityRecords.filter(r => r.type === 'electricity' && !r.isPaid).reduce((sum, r) => sum + r.totalBill, 0) || 0).toFixed(2)}</p>
                  </div>
                </div>
              )}
            </>
          )}
          {tenant.modules.expenses && (
            <div 
              className="sahal-card p-6 sm:p-8 relative overflow-hidden group cursor-pointer hover:shadow-xl transition-all"
              onClick={() => setActiveTab('expenses')}
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-slate-50 rounded-full -translate-y-1/2 translate-x-1/2 group-hover:scale-110 transition-transform duration-500" />
              <div className="relative z-10">
                <div className="flex justify-between items-start mb-6">
                  <div className="p-3 bg-slate-800 text-white rounded-2xl shadow-lg shadow-slate-100"><CreditCard size={24} /></div>
                  <span className="text-xs font-bold text-slate-600 bg-slate-50 px-3 py-1 rounded-full border border-slate-100">{t('expenses')}</span>
                </div>
                <p className="text-xs font-bold uppercase tracking-[0.15em] text-slate-400 mb-1">{t('total_expenses')}</p>
                <p className="text-3xl sm:text-4xl font-display font-bold text-slate-900 tracking-tight">${(totalExpenses || 0).toFixed(2)}</p>
                <p className="text-xs text-slate-500 mt-2">{t('today_expenses')}: <span className="font-bold">${(todayExpenses || 0).toFixed(2)}</span></p>
                <TrendBadge current={totalExpenses} previous={previousTotalExpenses} invert={true} />
              </div>
            </div>
          )}
          {tenant.modules.debts && (
            <div 
              className="sahal-card p-6 sm:p-8 relative overflow-hidden group cursor-pointer hover:shadow-xl transition-all"
              onClick={() => setActiveTab('debts')}
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-rose-50 rounded-full -translate-y-1/2 translate-x-1/2 group-hover:scale-110 transition-transform duration-500" />
              <div className="relative z-10">
                <div className="flex justify-between items-start mb-6">
                  <div className="p-3 bg-rose-500 text-white rounded-2xl shadow-lg shadow-rose-100"><Wallet size={24} /></div>
                  <span className="text-xs font-bold text-rose-600 bg-rose-50 px-3 py-1 rounded-full border border-rose-100">{t('debts')}</span>
                </div>
                <p className="text-xs font-bold uppercase tracking-[0.15em] text-slate-400 mb-1">{t('outstanding_debts')}</p>
                <p className="text-3xl sm:text-4xl font-display font-bold text-rose-600 tracking-tight">${(totalOutstanding || 0).toFixed(2)}</p>
                <TrendBadge current={totalOutstanding} previous={previousOutstanding} invert={true} />
              </div>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {/* Business Alerts */}
          <div className="sahal-card overflow-hidden">
            <div className="p-8 border-b border-border-main flex justify-between items-center">
              <div>
                <h3 className="font-display font-bold text-xl text-ink">{t('business_alerts' as any) || 'Business Alerts'}</h3>
                <p className="text-sm text-ink-secondary">{t('business_alerts_desc' as any) || 'Important issues requiring attention'}</p>
              </div>
              <div className="w-10 h-10 bg-rose-50 dark:bg-rose-950/20 rounded-xl flex items-center justify-center text-rose-500">
                <AlertCircle size={20} />
              </div>
            </div>
            <div className="divide-y divide-border-main">
              {/* Overdue Debts */}
              {overdueDebts.length > 0 && (
                <div 
                  className="p-6 flex justify-between items-center group cursor-pointer hover:bg-rose-50 transition-all border-l-4 border-rose-500"
                  onClick={() => setActiveTab('debts')}
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center">
                      <Wallet size={18} />
                    </div>
                    <div>
                      <p className="font-bold text-ink">{overdueDebts.length} {t('overdue_debts')}</p>
                      <p className="text-xs text-rose-600 font-bold uppercase tracking-widest">{t('action_required')}</p>
                    </div>
                  </div>
                  <ChevronRight size={18} className="text-ink-tertiary" />
                </div>
              )}

              {/* Parked Orders */}
              {parkedOrdersCount > 0 && (
                <div 
                  className="p-6 flex justify-between items-center group cursor-pointer hover:bg-bg-sec transition-all"
                  onClick={() => setActiveTab('sales')}
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
                      <ShoppingCart size={18} />
                    </div>
                    <div>
                      <p className="font-bold text-ink">{parkedOrdersCount} {t('parked_orders' as any) || 'Parked Orders'}</p>
                      <p className="text-xs text-ink-tertiary">{t('waiting_for_checkout' as any) || 'Items waiting in cart'}</p>
                    </div>
                  </div>
                  <ChevronRight size={18} className="text-ink-tertiary" />
                </div>
              )}

              {/* Loss Making Sales */}
              {lossMakingSales.length > 0 && (
                <div 
                  className="p-6 flex justify-between items-center group cursor-pointer hover:bg-bg-sec transition-all"
                  onClick={() => setActiveTab('reports')}
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-red-50 text-red-600 flex items-center justify-center">
                      <ArrowRight size={18} className="rotate-45" />
                    </div>
                    <div>
                      <p className="font-bold text-ink">{lossMakingSales.length} {t('loss_making_sales' as any) || 'Loss-making Sales'}</p>
                      <p className="text-xs text-ink-tertiary">{t('sold_below_cost' as any) || 'Sold below cost price'}</p>
                    </div>
                  </div>
                  <ChevronRight size={18} className="text-ink-tertiary" />
                </div>
              )}

              {/* Out of Stock */}
              {outOfStockItems.length > 0 && (
                <div 
                  className="p-6 flex justify-between items-center group cursor-pointer hover:bg-bg-sec transition-all"
                  onClick={() => {
                    setInitialSearch?.(' '); 
                    setActiveTab('inventory');
                  }}
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-800 flex items-center justify-center">
                      <Package size={18} />
                    </div>
                    <div>
                      <p className="font-bold text-ink">{outOfStockItems.length} {t('out_of_stock' as any) || 'Out of Stock'}</p>
                      <p className="text-xs text-rose-600 font-bold uppercase tracking-widest">{t('urgent' as any) || 'Urgent'}</p>
                    </div>
                  </div>
                  <ChevronRight size={18} className="text-ink-tertiary" />
                </div>
              )}

              {/* Subscription Status */}
              {showSubscriptionAlert && (
                <div 
                  className={`p-6 flex justify-between items-center group cursor-pointer hover:bg-bg-sec transition-all ${isSubscriptionExpired ? 'bg-rose-50 border-l-4 border-rose-500' : isSubscriptionExpiringSoon ? 'bg-amber-50/50 border-l-4 border-amber-500' : ''}`}
                  onClick={() => setActiveTab('subscription')}
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${isSubscriptionExpired ? 'bg-rose-100 text-rose-600' : isSubscriptionExpiringSoon ? 'bg-amber-100 text-amber-600' : 'bg-indigo-50 text-indigo-600'}`}>
                      <Shield size={18} />
                    </div>
                    <div>
                      <p className="font-bold text-ink">
                        {isSubscriptionExpired 
                          ? (t('subscription_due' as any) || 'Please, the time to pay the system fee has arrived')
                          : isSubscriptionExpiringSoon 
                            ? `${t('subscription_expiring_soon' as any) || 'Subscription Expiring Soon'} (${daysUntilExpiry} ${t('days_left' as any) || 'days left'})`
                            : (t('subscription_alert' as any) || 'Subscription Issue')
                        }
                      </p>
                      <p className={`text-xs uppercase font-bold tracking-widest ${isSubscriptionExpired ? 'text-rose-600' : isSubscriptionExpiringSoon ? 'text-amber-600' : 'text-ink-tertiary'}`}>
                        {isSubscriptionExpired ? t('expired' as any) : isSubscriptionExpiringSoon ? t('renew_now' as any) || 'Renew Now' : tenant.subscriptionStatus}
                      </p>
                    </div>
                  </div>
                  <ChevronRight size={18} className="text-ink-tertiary" />
                </div>
              )}

              {overdueDebts.length === 0 && parkedOrdersCount === 0 && lossMakingSales.length === 0 && outOfStockItems.length === 0 && tenant?.subscriptionStatus === 'active' && !showSubscriptionAlert && (
                <div className="p-16 text-center">
                  <div className="w-12 h-12 bg-emerald-50 rounded-full flex items-center justify-center mx-auto mb-4 text-emerald-500 font-bold">✓</div>
                  <p className="text-ink-tertiary font-medium italic">{t('no_alerts' as any) || 'System status normal'}</p>
                </div>
              )}
            </div>
          </div>

          {/* Recent Activity */}
          <div className="sahal-card overflow-hidden">
            <div className="p-8 border-b border-slate-100 flex justify-between items-center">
              <div>
                <h3 className="font-display font-bold text-xl text-ink">{t('recent_transactions')}</h3>
                <p className="text-sm text-ink-secondary">{t('recent_transactions_desc')}</p>
              </div>
              <div className="w-10 h-10 bg-bg-sec rounded-xl flex items-center justify-center text-ink-tertiary">
                <Clock size={20} />
              </div>
            </div>
            <div className="divide-y divide-border-main">
              {sales.length > 0 ? sales.map(sale => (
                <div key={sale.id} className="p-6 flex justify-between items-center hover:bg-bg-sec transition-colors group">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                      <ShoppingCart size={18} />
                    </div>
                    <div>
                      <p className="font-bold text-ink">{sale.customerName || t('none')}</p>
                      <p className="text-xs text-ink-tertiary font-medium">{new Date(sale.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-display font-bold text-ink">+${(sale.total || 0).toFixed(2)}</p>
                    <button className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">{t('view_receipt')}</button>
                  </div>
                </div>
              )) : (
                <div className="p-16 text-center">
                  <div className="w-12 h-12 bg-bg-sec rounded-full flex items-center justify-center mx-auto mb-4">
                    <Receipt size={24} className="text-ink-tertiary/20" />
                  </div>
                  <p className="text-ink-tertiary font-medium italic">{t('no_recent_sales')}</p>
                </div>
              )}
            </div>
            <button className="w-full py-4 bg-bg-sec text-xs font-bold text-ink-tertiary uppercase tracking-widest hover:bg-border-main hover:text-ink transition-all border-t border-border-main">
              {t('view_all_transactions')}
            </button>
          </div>

          {/* Inventory Alerts */}
          <div className="sahal-card overflow-hidden">
            <div className="p-8 border-b border-border-main flex justify-between items-center">
              <div>
                <h3 className="font-display font-bold text-xl text-ink">{t('inventory_alerts')}</h3>
                <p className="text-sm text-ink-secondary">{t('inventory_alerts_desc')}</p>
              </div>
              <div className="w-10 h-10 bg-amber-50 dark:bg-amber-950/20 rounded-xl flex items-center justify-center text-amber-500">
                <AlertTriangle size={20} />
              </div>
            </div>
            <div className="divide-y divide-border-main">
              {inventory.filter(i => i.quantity <= i.minStock).map(item => (
                <div 
                  key={item.id} 
                  className="p-6 flex justify-between items-center group cursor-pointer hover:bg-bg-sec transition-all"
                  onClick={() => {
                    setInitialSearch?.(item.name);
                    setActiveTab('inventory');
                  }}
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/20 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                      <Package size={18} />
                    </div>
                    <div>
                      <p className="font-bold text-ink">{item.name}</p>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-amber-600 dark:text-amber-400">{t('low_stock_label')} {item.quantity}</span>
                        <span className="text-[10px] text-ink-tertiary font-mono">SKU: {item.sku}</span>
                      </div>
                    </div>
                  </div>
                  <button className="p-3 bg-bg-sec text-ink-tertiary rounded-xl hover:bg-ink hover:text-surface-main transition-all duration-300">
                    <ChevronRight size={18} />
                  </button>
                </div>
              ))}
              {inventory.length === 0 && (
                <div className="p-16 text-center">
                  <div className="w-12 h-12 bg-bg-sec rounded-full flex items-center justify-center mx-auto mb-4">
                    <Package size={24} className="text-ink-tertiary/20" />
                  </div>
                  <p className="text-ink-tertiary font-medium italic">{t('stock_healthy')}</p>
                </div>
              )}
            </div>
            <button className="w-full py-4 bg-bg-sec text-xs font-bold text-ink-tertiary uppercase tracking-widest hover:bg-border-main hover:text-ink transition-all border-t border-border-main">
              {t('manage_inventory')}
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (activeTab === 'company') {
    if (user.isStaff && !user.staffRoles?.includes('company')) return <ModuleDisabled name={t('company')} />;
    return <AssetsEquityModule key={user.branchId || 'all'} user={user} />;
  }

  if (activeTab === 'ai_assistant') {
    if (user.isStaff && !user.staffRoles?.includes('ai_assistant')) return <ModuleDisabled name={t('ai_assistant')} />;
    return <AIChatModule key={user.branchId || 'all'} user={user} />;
  }

  if (activeTab === 'business') {
    return <BusinessSettingsModule key={user.branchId || 'all'} user={user} />;
  }

          if (activeTab === 'inventory') {
    if (user.isStaff && !user.staffRoles?.includes('inventory')) return <ModuleDisabled name={t('inventory')} />;
    return tenant.modules.inventory ? (
      <InventoryModule 
        key={user.branchId || 'all'}
        user={user} 
        initialSearch={initialSearch} 
        onSearchCleared={() => setInitialSearch?.('')} 
      />
    ) : <ModuleDisabled name={t('inventory')} />;
  }

  if (activeTab === 'sales') {
    if (user.isStaff && !user.staffRoles?.includes('sales')) return <ModuleDisabled name={t('sales')} />;
    return tenant.modules.sales ? (
      <SalesModule 
        key={user.branchId || 'all'}
        user={user} 
        pendingPrescription={pendingPrescription} 
        setPendingPrescription={setPendingPrescription} 
      />
    ) : <ModuleDisabled name={t('sales')} />;
  }

  if (activeTab === 'services') {
    if (user.isStaff && !user.staffRoles?.includes('services')) return <ModuleDisabled name={t('services')} />;
    return tenant.modules.services ? <ServicesModule key={user.branchId || 'all'} user={user} /> : <ModuleDisabled name={t('services')} />;
  }

  if (activeTab === 'debts') {
    if (user.isStaff && !user.staffRoles?.includes('debts')) return <ModuleDisabled name={t('debts')} />;
    return tenant.modules.debts ? <DebtsModule key={user.branchId || 'all'} user={user} /> : <ModuleDisabled name={t('debts')} />;
  }

  if (activeTab === 'expenses') {
    if (user.isStaff && !user.staffRoles?.includes('expenses')) return <ModuleDisabled name={t('expenses')} />;
    return tenant.modules.expenses ? <ExpensesModule key={user.branchId || 'all'} user={user} /> : <ModuleDisabled name={t('expenses')} />;
  }

  if (activeTab === 'crm') {
    if (user.isStaff && !user.staffRoles?.includes('crm')) return <ModuleDisabled name={t('crm')} />;
    return tenant.modules.crm ? <CRMModule key={user.branchId || 'all'} user={user} /> : <ModuleDisabled name={t('crm')} />;
  }

  if (activeTab === 'reports') {
    if (user.isStaff && !user.staffRoles?.includes('reports')) return <ModuleDisabled name={t('reports')} />;
    return tenant.modules.reports ? <ReportsModule key={user.branchId || 'all'} user={user} /> : <ModuleDisabled name={t('reports')} />;
  }

  if (activeTab === 'finance') {
    if (user.isStaff && !user.staffRoles?.includes('finance')) return <ModuleDisabled name={t('finance_management' as any) || 'Finance'} />;
    return <FinanceModule key={user.branchId || 'all'} user={user} />;
  }

  if (activeTab === 'hospital') {
    if (user.isStaff && !user.staffRoles?.some(role => role.startsWith('hospital'))) return <ModuleDisabled name={t('hospital_name')} />;
    return tenant.modules.hospital ? <HospitalModule key={user.branchId || 'all'} user={user} navigateToSales={navigateToSales} /> : <ModuleDisabled name={t('hospital_name')} />;
  }

  if (activeTab === 'saving') {
    if (user.isStaff && !user.staffRoles?.includes('saving')) return <ModuleDisabled name={t('saving_module')} />;
    return tenant.modules.saving ? <SavingModule key={user.branchId || 'all'} user={user} /> : <ModuleDisabled name={t('saving_module')} />;
  }

  if (activeTab === 'investment') {
    if (user.isStaff && !user.staffRoles?.includes('investment')) return <ModuleDisabled name={t('investment')} />;
    return tenant.modules.investment ? <InvestmentModule key={user.branchId || 'all'} user={user} /> : <ModuleDisabled name={t('investment')} />;
  }

  if (activeTab === 'working_note') {
    if (user.isStaff && !user.staffRoles?.includes('working_note')) return <ModuleDisabled name={t('working_note')} />;
    return tenant.modules.working_note ? <WorkingNoteModule key={user.branchId || 'all'} user={user} /> : <ModuleDisabled name={t('working_note')} />;
  }

  if (activeTab === 'daily_task') {
    if (user.isStaff && !user.staffRoles?.includes('daily_task')) return <ModuleDisabled name={t('daily_task')} />;
    return tenant.modules.daily_task ? <DailyTaskModule key={user.branchId || 'all'} user={user} /> : <ModuleDisabled name={t('daily_task')} />;
  }

  if (activeTab === 'keeping_ideas') {
    if (user.isStaff && !user.staffRoles?.includes('keeping_ideas')) return <ModuleDisabled name={t('keeping_ideas')} />;
    return tenant.modules.keeping_ideas ? <KeepingIdeasModule key={user.branchId || 'all'} user={user} /> : <ModuleDisabled name={t('keeping_ideas')} />;
  }

  if (activeTab === 'utility_water') {
    if (user.isStaff && !user.staffRoles?.includes('utility_water')) return <ModuleDisabled name={t('utility_water')} />;
    return tenant.modules.utility_water ? (
      <UtilityModule 
        key={user.branchId || 'all-water'}
        user={user} 
        utilityType="water" 
        initialTab={initialModuleTab as any} 
      />
    ) : <ModuleDisabled name={t('utility_water')} />;
  }

  if (activeTab === 'utility_electricity') {
    if (user.isStaff && !user.staffRoles?.includes('utility_electricity')) return <ModuleDisabled name={t('utility_electricity')} />;
    return tenant.modules.utility_electricity ? (
      <UtilityModule 
        key={user.branchId || 'all-dist'}
        user={user} 
        utilityType="electricity" 
        initialTab={initialModuleTab as any} 
      />
    ) : <ModuleDisabled name={t('utility_electricity')} />;
  }

  if (activeTab === 'subscription') {
    if (user.isStaff && !user.staffRoles?.includes('subscription')) return <ModuleDisabled name={t('subscription')} />;
    return <SubscriptionModule key={user.branchId || 'all'} user={user} managerPhone={managerPhone} />;
  }

  if (activeTab === 'users') {
    if (user.isStaff && !user.staffRoles?.includes('users')) return <ModuleDisabled name={t('staff_management')} />;
    return <StaffModule key={user.branchId || 'all'} user={user} tenant={tenant} />;
  }

  if (activeTab === 'help_center') {
    return (
      <div className="max-w-2xl mx-auto py-12 px-6">
        <div className="bg-surface-main rounded-3xl p-10 border border-border-main text-center shadow-lg">
          <div className="w-24 h-24 bg-accent-soft text-accent-main rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner">
            <Phone size={48} />
          </div>
          <h2 className="text-3xl font-display font-black text-ink mb-4">{t('help_center' as any) || 'Help Center'}</h2>
          <p className="text-ink-secondary mb-10 text-lg">
            Waxaad nagala soo xiriiri kartaa Whatsapp-ka haddii aad u baahato caawimaad ama aad qabto su'aal.
          </p>
          
          <div className="inline-flex flex-col items-center gap-6">
            <div className="flex items-center gap-4 bg-bg-sec px-8 py-5 rounded-2xl border border-border-main text-2xl font-black text-ink tracking-wider">
              {managerPhone || '+252 61 0000000'}
            </div>
            
            {managerPhone && (
              <button
                onClick={() => {
                  const cleanPhone = managerPhone.replace(/\D/g, '');
                  const message = encodeURIComponent(`Salaan, waxaan u baahanahay caawimaad.`);
                  window.open(`https://wa.me/${cleanPhone}?text=${message}`, '_blank');
                }}
                className="flex items-center gap-3 px-8 py-4 bg-[#25D366] text-white rounded-2xl hover:bg-[#1DA851] transition-all font-bold text-lg shadow-lg shadow-[#25D366]/30"
              >
                <div className="w-6 h-6 flex items-center justify-center">
                  <Phone size={24} />
                </div>
                Farriin u dir WhatsApp
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center p-24 text-center">
      <div className="w-24 h-24 bg-slate-50 rounded-[2.5rem] flex items-center justify-center mb-8">
        <Package size={48} className="text-slate-200" />
      </div>
      <h3 className="text-2xl font-display font-bold text-slate-900 mb-3">{t('under_construction')}</h3>
      <p className="text-slate-400 max-w-md">{t('stay_tuned')}</p>
      <RenderConfirmModal />
    </div>
  );
}
