import * as fs from 'fs';
import * as path from 'path';

function getKeysInFile(content) {
  const keys = new Set();
  const regex = /t\(['"]([a-zA-Z0-9_]+)['"]/g;
  let match;
  while ((match = regex.exec(content)) !== null) {
    keys.add(match[1]);
  }
  return keys;
}

function scanDir(dir) {
  let allKeys = new Set();
  const files = fs.readdirSync(dir);
  files.forEach(file => {
    const fullPath = path.join(dir, file);
    if (fs.statSync(fullPath).isDirectory()) {
      scanDir(fullPath).forEach(k => allKeys.add(k));
    } else if (fullPath.endsWith('.tsx') || fullPath.endsWith('.ts')) {
      const cnt = fs.readFileSync(fullPath, 'utf-8');
      getKeysInFile(cnt).forEach(k => allKeys.add(k));
    }
  });
  return allKeys;
}

const allUsedKeys = scanDir('src');
const trans = fs.readFileSync('src/translations.ts', 'utf-8');

const missingKeys = [];
allUsedKeys.forEach(k => {
  if (!trans.includes(`\n    ${k}:`) && !trans.includes(`\n    '${k}':`) && !trans.includes(`\n    "${k}":`) && !trans.includes(` ${k}:`)) {
    missingKeys.push(k);
  }
});

console.log('Missing Keys:', missingKeys.join(', '));
