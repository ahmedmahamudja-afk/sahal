
-- SAHAL System Database Setup Script
-- Run this in your Supabase SQL Editor

-- 1. Tenants Table
CREATE TABLE IF NOT EXISTS tenants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    type TEXT,
    modules JSONB DEFAULT '{}',
    manager_id TEXT,
    subscription_plan TEXT,
    plan_expiry TIMESTAMPTZ,
    is_locked BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    logo_url TEXT,
    status TEXT DEFAULT 'active',
    is_multi_branch BOOLEAN DEFAULT FALSE,
    location TEXT,
    contact TEXT,
    payment_numbers JSONB DEFAULT '{}'
);

-- 2. Users Table (Custom users table for the app)
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    uid TEXT UNIQUE,
    email TEXT,
    display_name TEXT,
    role TEXT,
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    username TEXT UNIQUE,
    password TEXT,
    phone TEXT,
    photo_url TEXT,
    is_staff BOOLEAN DEFAULT FALSE,
    staff_roles TEXT[] DEFAULT '{}',
    subscription JSONB DEFAULT '{}',
    is_locked BOOLEAN DEFAULT FALSE,
    is_expired BOOLEAN DEFAULT FALSE,
    plan_expiry TIMESTAMPTZ,
    branch_id UUID
);

-- 3. Staff Table
CREATE TABLE IF NOT EXISTS staff (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username TEXT UNIQUE,
    password TEXT,
    display_name TEXT,
    phone TEXT,
    photo_url TEXT,
    roles TEXT[] DEFAULT '{}',
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    branch_id UUID,
    is_locked BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    position TEXT,
    salary NUMERIC,
    address TEXT,
    email TEXT,
    status TEXT DEFAULT 'active',
    hire_date TIMESTAMPTZ
);

-- 4. Inventory Table
CREATE TABLE IF NOT EXISTS inventory (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    sku TEXT,
    quantity NUMERIC DEFAULT 0,
    cost_price NUMERIC DEFAULT 0,
    price NUMERIC DEFAULT 0,
    min_stock NUMERIC DEFAULT 0,
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    branch_id UUID,
    image_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Sales Table
CREATE TABLE IF NOT EXISTS sales (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    items JSONB DEFAULT '[]',
    total NUMERIC DEFAULT 0,
    tax NUMERIC DEFAULT 0,
    paid_amount NUMERIC DEFAULT 0,
    debt_amount NUMERIC DEFAULT 0,
    customer_name TEXT,
    status TEXT DEFAULT 'paid',
    payment_methods JSONB DEFAULT '[]',
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    branch_id UUID,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    debt_id TEXT,
    seller_name TEXT,
    credit_used NUMERIC DEFAULT 0
);

-- 6. Debts Table
CREATE TABLE IF NOT EXISTS debts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_name TEXT,
    phone TEXT,
    amount NUMERIC DEFAULT 0,
    paid_amount NUMERIC DEFAULT 0,
    status TEXT DEFAULT 'unpaid',
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    branch_id UUID,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    due_date TIMESTAMPTZ,
    type TEXT DEFAULT 'customer',
    description TEXT
);

-- 7. Expenses Table
CREATE TABLE IF NOT EXISTS expenses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    category TEXT,
    description TEXT,
    amount NUMERIC DEFAULT 0,
    date TIMESTAMPTZ DEFAULT NOW(),
    status TEXT DEFAULT 'paid',
    approval_status TEXT DEFAULT 'approved',
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    branch_id UUID,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. Customers Table
CREATE TABLE IF NOT EXISTS customers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    phone TEXT,
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    branch_id UUID,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    total_debt NUMERIC DEFAULT 0,
    total_credit NUMERIC DEFAULT 0,
    offer_percentage NUMERIC DEFAULT 0
);

-- 9. Patients Table
CREATE TABLE IF NOT EXISTS patients (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    age TEXT,
    phone TEXT,
    insurance_provider TEXT,
    type TEXT DEFAULT 'outpatient',
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    branch_id UUID,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 10. Visits Table
CREATE TABLE IF NOT EXISTS visits (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID REFERENCES patients(id) ON DELETE CASCADE,
    patient_name TEXT,
    patient_age TEXT,
    doctor_id TEXT,
    doctor_name TEXT,
    doctor_phone TEXT,
    status TEXT DEFAULT 'reception',
    registration_fee NUMERIC DEFAULT 0,
    consultation_fee NUMERIC DEFAULT 0,
    diagnosis TEXT,
    prescription JSONB DEFAULT '[]',
    total_bill NUMERIC DEFAULT 0,
    paid_amount NUMERIC DEFAULT 0,
    consultation_paid BOOLEAN DEFAULT FALSE,
    pharmacy_paid BOOLEAN DEFAULT FALSE,
    dispensed BOOLEAN DEFAULT FALSE,
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    branch_id UUID,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 11. Services Table
CREATE TABLE IF NOT EXISTS services (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    price NUMERIC DEFAULT 0,
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    branch_id UUID,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    image_url TEXT,
    offer_price NUMERIC DEFAULT 0,
    discount_percentage NUMERIC DEFAULT 0
);

-- 12. Branches Table
CREATE TABLE IF NOT EXISTS branches (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    location TEXT,
    phone TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    manager_id TEXT
);

-- 13. Savings Table
CREATE TABLE IF NOT EXISTS savings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    target_amount NUMERIC DEFAULT 0,
    current_amount NUMERIC DEFAULT 0,
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 14. Investments Table
CREATE TABLE IF NOT EXISTS investments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    amount NUMERIC DEFAULT 0,
    expected_return NUMERIC,
    status TEXT DEFAULT 'active',
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 15. Working Notes Table
CREATE TABLE IF NOT EXISTS working_notes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT,
    content TEXT,
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 16. Daily Tasks Table
CREATE TABLE IF NOT EXISTS daily_tasks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    task TEXT NOT NULL,
    completed BOOLEAN DEFAULT FALSE,
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 17. Keeping Ideas Table
CREATE TABLE IF NOT EXISTS keeping_ideas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT,
    description TEXT,
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 18. Stock Logs Table
CREATE TABLE IF NOT EXISTS stock_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    item_id UUID REFERENCES inventory(id) ON DELETE CASCADE,
    branch_id UUID,
    item_name TEXT NOT NULL,
    change NUMERIC DEFAULT 0,
    reason TEXT,
    timestamp TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Realtime for all tables
ALTER PUBLICATION supabase_realtime ADD TABLE tenants;
ALTER PUBLICATION supabase_realtime ADD TABLE users;
ALTER PUBLICATION supabase_realtime ADD TABLE staff;
ALTER PUBLICATION supabase_realtime ADD TABLE inventory;
ALTER PUBLICATION supabase_realtime ADD TABLE sales;
ALTER PUBLICATION supabase_realtime ADD TABLE expenses;
ALTER PUBLICATION supabase_realtime ADD TABLE debts;
ALTER PUBLICATION supabase_realtime ADD TABLE customers;
ALTER PUBLICATION supabase_realtime ADD TABLE patients;
ALTER PUBLICATION supabase_realtime ADD TABLE visits;
ALTER PUBLICATION supabase_realtime ADD TABLE services;
ALTER PUBLICATION supabase_realtime ADD TABLE branches;
ALTER PUBLICATION supabase_realtime ADD TABLE savings;
ALTER PUBLICATION supabase_realtime ADD TABLE investments;
ALTER PUBLICATION supabase_realtime ADD TABLE working_notes;
ALTER PUBLICATION supabase_realtime ADD TABLE daily_tasks;
ALTER PUBLICATION supabase_realtime ADD TABLE keeping_ideas;
ALTER PUBLICATION supabase_realtime ADD TABLE stock_logs;

-- Add missing columns to existing tables if they were partially created
DO $$ 
BEGIN 
    -- Add branch_id to all relevant tables if missing
    DECLARE
        t_name TEXT;
        tables_to_update TEXT[] := ARRAY['users', 'staff', 'inventory', 'sales', 'expenses', 'debts', 'customers', 'patients', 'visits', 'services'];
    BEGIN
        FOREACH t_name IN ARRAY tables_to_update LOOP
            IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = t_name) THEN
                IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = t_name AND column_name = 'branch_id') THEN
                    EXECUTE format('ALTER TABLE %I ADD COLUMN branch_id UUID', t_name);
                END IF;
            END IF;
        END LOOP;
    END;

    -- Debts table columns
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'debts') THEN
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='debts' AND column_name='description') THEN
            ALTER TABLE debts ADD COLUMN description TEXT;
        END IF;
    END IF;

    -- Sales table columns
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'sales') THEN
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='sales' AND column_name='tax') THEN
            ALTER TABLE sales ADD COLUMN tax NUMERIC DEFAULT 0;
        END IF;
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='sales' AND column_name='paid_amount') THEN
            ALTER TABLE sales ADD COLUMN paid_amount NUMERIC DEFAULT 0;
        END IF;
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='sales' AND column_name='debt_amount') THEN
            ALTER TABLE sales ADD COLUMN debt_amount NUMERIC DEFAULT 0;
        END IF;
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='sales' AND column_name='debt_id') THEN
            ALTER TABLE sales ADD COLUMN debt_id TEXT;
        END IF;
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='sales' AND column_name='seller_name') THEN
            ALTER TABLE sales ADD COLUMN seller_name TEXT;
        END IF;
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='sales' AND column_name='payment_methods') THEN
            ALTER TABLE sales ADD COLUMN payment_methods JSONB DEFAULT '[]';
        END IF;
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='sales' AND column_name='is_edited') THEN
            ALTER TABLE sales ADD COLUMN is_edited BOOLEAN DEFAULT FALSE;
        END IF;
    END IF;

    -- Staff table columns
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'staff') THEN
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='staff' AND column_name='position') THEN
            ALTER TABLE staff ADD COLUMN position TEXT;
        END IF;
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='staff' AND column_name='salary') THEN
            ALTER TABLE staff ADD COLUMN salary NUMERIC;
        END IF;
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='staff' AND column_name='address') THEN
            ALTER TABLE staff ADD COLUMN address TEXT;
        END IF;
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='staff' AND column_name='email') THEN
            ALTER TABLE staff ADD COLUMN email TEXT;
        END IF;
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='staff' AND column_name='status') THEN
            ALTER TABLE staff ADD COLUMN status TEXT DEFAULT 'active';
        END IF;
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='staff' AND column_name='hire_date') THEN
            ALTER TABLE staff ADD COLUMN hire_date TIMESTAMPTZ;
        END IF;
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='staff' AND column_name='is_locked') THEN
            ALTER TABLE staff ADD COLUMN is_locked BOOLEAN DEFAULT FALSE;
        END IF;
    END IF;

    -- Expenses table columns
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'expenses') THEN
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='expenses' AND column_name='status') THEN
            ALTER TABLE expenses ADD COLUMN status TEXT DEFAULT 'paid';
        END IF;
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='expenses' AND column_name='approval_status') THEN
            ALTER TABLE expenses ADD COLUMN approval_status TEXT DEFAULT 'approved';
        END IF;
    END IF;

    -- Stock Logs table columns
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'stock_logs') THEN
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='stock_logs' AND column_name='branch_id') THEN
            ALTER TABLE stock_logs ADD COLUMN branch_id UUID;
        END IF;
    END IF;

    -- Tenants table columns
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='tenants' AND column_name='subscription_plan') THEN
        ALTER TABLE tenants ADD COLUMN subscription_plan TEXT;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='tenants' AND column_name='location') THEN
        ALTER TABLE tenants ADD COLUMN location TEXT;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='tenants' AND column_name='contact') THEN
        ALTER TABLE tenants ADD COLUMN contact TEXT;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='tenants' AND column_name='status') THEN
        ALTER TABLE tenants ADD COLUMN status TEXT DEFAULT 'active';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='tenants' AND column_name='is_multi_branch') THEN
        ALTER TABLE tenants ADD COLUMN is_multi_branch BOOLEAN DEFAULT FALSE;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='tenants' AND column_name='payment_numbers') THEN
        ALTER TABLE tenants ADD COLUMN payment_numbers JSONB DEFAULT '{}';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='tenants' AND column_name='manager_id') THEN
        ALTER TABLE tenants ADD COLUMN manager_id TEXT;
    ELSE
        -- Ensure it is TEXT if it exists as UUID
        IF (SELECT data_type FROM information_schema.columns WHERE table_name='tenants' AND column_name='manager_id') = 'uuid' THEN
            ALTER TABLE tenants ALTER COLUMN manager_id TYPE TEXT;
        END IF;
    END IF;
END $$;

-- Disable RLS on all tables to ensure the app works correctly
ALTER TABLE tenants DISABLE ROW LEVEL SECURITY;
ALTER TABLE tenants DROP CONSTRAINT IF EXISTS tenants_type_check;
ALTER TABLE users DISABLE ROW LEVEL SECURITY;
ALTER TABLE staff DISABLE ROW LEVEL SECURITY;
ALTER TABLE inventory DISABLE ROW LEVEL SECURITY;
ALTER TABLE sales DISABLE ROW LEVEL SECURITY;
ALTER TABLE expenses DISABLE ROW LEVEL SECURITY;
ALTER TABLE debts DISABLE ROW LEVEL SECURITY;
ALTER TABLE customers DISABLE ROW LEVEL SECURITY;
ALTER TABLE patients DISABLE ROW LEVEL SECURITY;
ALTER TABLE visits DISABLE ROW LEVEL SECURITY;
ALTER TABLE services DISABLE ROW LEVEL SECURITY;
ALTER TABLE branches DISABLE ROW LEVEL SECURITY;
ALTER TABLE savings DISABLE ROW LEVEL SECURITY;
ALTER TABLE investments DISABLE ROW LEVEL SECURITY;
ALTER TABLE working_notes DISABLE ROW LEVEL SECURITY;
ALTER TABLE daily_tasks DISABLE ROW LEVEL SECURITY;
ALTER TABLE keeping_ideas DISABLE ROW LEVEL SECURITY;
ALTER TABLE stock_logs DISABLE ROW LEVEL SECURITY;

-- Landing Settings
CREATE TABLE IF NOT EXISTS landing_settings (
    id TEXT PRIMARY KEY,
    team JSONB DEFAULT '[]'::jsonb,
    contact JSONB DEFAULT '{}'::jsonb,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE landing_settings DISABLE ROW LEVEL SECURITY;

-- 19. Shareholders Table
CREATE TABLE IF NOT EXISTS shareholders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    initial_investment NUMERIC DEFAULT 0,
    current_value NUMERIC DEFAULT 0,
    share_percentage NUMERIC DEFAULT 0,
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 20. Accounts Table
CREATE TABLE IF NOT EXISTS accounts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    balance NUMERIC DEFAULT 0,
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    branch_id UUID,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 21. Account Transactions Table
CREATE TABLE IF NOT EXISTS account_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    from_account_id UUID REFERENCES accounts(id) ON DELETE SET NULL,
    to_account_id UUID REFERENCES accounts(id) ON DELETE SET NULL,
    amount NUMERIC NOT NULL,
    type TEXT NOT NULL, -- 'transfer', 'deposit', 'withdrawal', 'sale', 'expense', 'debt_payment', 'adjustment'
    description TEXT,
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    branch_id UUID,
    reference_id UUID,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Realtime for new tables
ALTER PUBLICATION supabase_realtime ADD TABLE shareholders;
ALTER PUBLICATION supabase_realtime ADD TABLE accounts;
ALTER PUBLICATION supabase_realtime ADD TABLE account_transactions;

-- Disable RLS for new tables
ALTER TABLE shareholders DISABLE ROW LEVEL SECURITY;
ALTER TABLE accounts DISABLE ROW LEVEL SECURITY;
ALTER TABLE account_transactions DISABLE ROW LEVEL SECURITY;

-- Insert default Super Admin (Ahmedmoha / A121398a)
INSERT INTO users (uid, display_name, username, password, role, created_at)
VALUES ('super_admin_001', 'System Admin', 'Ahmedmoha', 'A121398a', 'super_admin', NOW())
ON CONFLICT (username) DO UPDATE SET 
    password = EXCLUDED.password,
    uid = EXCLUDED.uid,
    display_name = EXCLUDED.display_name;

-- 22. Storage Buckets
INSERT INTO storage.buckets (id, name, public)
VALUES ('staff-photos', 'staff-photos', true), ('app-images', 'app-images', true)
ON CONFLICT (id) DO NOTHING;

-- Storage Policies
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Public Access' AND tablename = 'objects' AND schemaname = 'storage') THEN
        CREATE POLICY "Public Access" ON storage.objects FOR SELECT USING (true);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Public Insert' AND tablename = 'objects' AND schemaname = 'storage') THEN
        CREATE POLICY "Public Insert" ON storage.objects FOR INSERT WITH CHECK (true);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Public Update' AND tablename = 'objects' AND schemaname = 'storage') THEN
        CREATE POLICY "Public Update" ON storage.objects FOR UPDATE USING (true);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Public Delete' AND tablename = 'objects' AND schemaname = 'storage') THEN
        CREATE POLICY "Public Delete" ON storage.objects FOR DELETE USING (true);
    END IF;
END $$;
