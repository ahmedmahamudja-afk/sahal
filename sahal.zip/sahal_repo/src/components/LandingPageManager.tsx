import React, { useState, useEffect } from 'react';
import { supabase } from '../supabase';
import { Plus, Trash2, Save, Image as ImageIcon, Phone, Mail, MapPin } from 'lucide-react';
import { useLanguage } from './LanguageContext';

interface TeamMember {
  id: string;
  name: string;
  role: string;
  imageUrl: string;
  phone?: string;
  email?: string;
}

interface ContactInfo {
  pricingPhone: string;
  demoUrl?: string;
}

export default function LandingPageManager() {
  const { t } = useLanguage();
  const [team, setTeam] = useState<TeamMember[]>([]);
  const [contact, setContact] = useState<ContactInfo>({ pricingPhone: '', demoUrl: '' });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('landing_settings')
        .select('*')
        .eq('id', 'global-settings')
        .single();
      
      if (data && !error) {
        if (data.team) setTeam(data.team);
        if (data.contact) setContact({ ...contact, ...data.contact });
      }
    } catch (error) {
      console.error('Error fetching landing settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async () => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from('landing_settings')
        .upsert({
          id: 'global-settings',
          team: team,
          contact: contact,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;
      alert('Settings saved successfully!');
    } catch (error: any) {
      console.error('Error saving settings:', error);
      alert('Error saving settings');
    } finally {
      setSaving(false);
    }
  };

  const addTeamMember = () => {
    setTeam([...team, { id: Date.now().toString(), name: '', role: '', imageUrl: '', phone: '', email: '' }]);
  };

  const updateTeamMember = (id: string, field: keyof TeamMember, value: string) => {
    setTeam(team.map(m => m.id === id ? { ...m, [field]: value } : m));
  };

  const removeTeamMember = (id: string) => {
    setTeam(team.filter(m => m.id !== id));
  };

  if (loading) return <div>Loading...</div>;

  return (
    <div className="space-y-8 max-w-4xl mx-auto p-6">
      <div className="flex justify-between items-center bg-surface-main p-6 rounded-3xl border border-border-main">
        <div>
          <h2 className="text-2xl font-display font-black text-ink uppercase tracking-tight">Landing Page Settings</h2>
          <p className="text-ink-secondary">Manage sections displayed on the public landing page.</p>
        </div>
        <button 
          onClick={saveSettings}
          disabled={saving}
          className="px-6 py-3 bg-accent-main text-white font-bold rounded-2xl hover:bg-accent-hover transition-all flex items-center gap-2 shadow-lg shadow-accent-soft disabled:opacity-50"
        >
          <Save size={20} />
          {saving ? 'Saving...' : 'Save Settings'}
        </button>
      </div>

      <div className="bg-surface-main p-6 rounded-3xl border border-border-main space-y-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center">
            <Phone size={20} />
          </div>
          <h3 className="text-xl font-bold text-ink">Additional Settings</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-ink-secondary mb-1">WhatsApp Number</label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-tertiary" size={16} />
              <input 
                type="text" 
                value={contact.pricingPhone}
                onChange={e => setContact({...contact, pricingPhone: e.target.value})}
                className="w-full bg-bg-sec border border-border-main rounded-xl pl-10 pr-4 py-2.5 text-sm focus:ring-2 focus:ring-accent-main/20 transition-all text-ink"
                placeholder="+252 61..."
              />
            </div>
            <p className="text-xs text-ink-tertiary mt-2">This number is used for the "Contact us on WhatsApp" button in Pricing Plans.</p>
          </div>
          <div>
            <label className="block text-xs font-bold text-ink-secondary mb-1">Watch Demo Link</label>
            <div className="relative">
              <input 
                type="text" 
                value={contact.demoUrl || ''}
                onChange={e => setContact({...contact, demoUrl: e.target.value})}
                className="w-full bg-bg-sec border border-border-main rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-accent-main/20 transition-all text-ink"
                placeholder="https://youtube.com/..."
              />
            </div>
            <p className="text-xs text-ink-tertiary mt-2">The link for the "Watch Demo" button on the hero section.</p>
          </div>
        </div>
      </div>

      <div className="bg-surface-main p-6 rounded-3xl border border-border-main space-y-6">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <ImageIcon size={20} />
            </div>
            <h3 className="text-xl font-bold text-ink">Maamulka Sare</h3>
          </div>
          <button 
            onClick={addTeamMember}
            className="p-2 bg-bg-sec text-ink hover:text-accent-main rounded-xl hover:bg-surface-main transition-colors border border-border-main"
          >
            <Plus size={20} />
          </button>
        </div>

        <div className="space-y-4">
          {team.length === 0 ? (
            <div className="text-center py-8 text-ink-tertiary border-2 border-dashed border-border-main rounded-2xl">
              No team members added yet. Click + to add one.
            </div>
          ) : team.map((member, index) => (
            <div key={member.id} className="grid grid-cols-1 md:grid-cols-12 gap-4 items-start bg-bg-sec p-4 rounded-2xl border border-border-main">
              <div className="md:col-span-1 flex flex-col items-center justify-start pt-2 gap-4">
                <span className="text-xl font-black text-ink-tertiary uppercase opacity-30">#{index + 1}</span>
                <button 
                  onClick={() => removeTeamMember(member.id)}
                  className="p-2 text-ink-tertiary hover:text-rose-600 bg-surface-main hover:bg-rose-50 rounded-xl transition-colors border border-border-main mt-4"
                >
                  <Trash2 size={20} />
                </button>
              </div>
              <div className="md:col-span-11 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-ink-secondary mb-1">Name</label>
                  <input 
                    type="text" 
                    value={member.name}
                    onChange={e => updateTeamMember(member.id, 'name', e.target.value)}
                    className="w-full bg-surface-main border border-border-main rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-accent-main/20 text-ink"
                    placeholder="John Doe"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-ink-secondary mb-1">Role / Title</label>
                  <input 
                    type="text" 
                    value={member.role}
                    onChange={e => updateTeamMember(member.id, 'role', e.target.value)}
                    className="w-full bg-surface-main border border-border-main rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-accent-main/20 text-ink"
                    placeholder="CEO"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-ink-secondary mb-1">Phone Number</label>
                  <input 
                    type="text" 
                    value={member.phone || ''}
                    onChange={e => updateTeamMember(member.id, 'phone', e.target.value)}
                    className="w-full bg-surface-main border border-border-main rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-accent-main/20 text-ink"
                    placeholder="+252 61..."
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-ink-secondary mb-1">Email</label>
                  <input 
                    type="email" 
                    value={member.email || ''}
                    onChange={e => updateTeamMember(member.id, 'email', e.target.value)}
                    className="w-full bg-surface-main border border-border-main rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-accent-main/20 text-ink"
                    placeholder="info@..."
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-xs font-bold text-ink-secondary mb-1">Image URL / Upload Image</label>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      value={member.imageUrl}
                      onChange={e => updateTeamMember(member.id, 'imageUrl', e.target.value)}
                      className="flex-1 bg-surface-main border border-border-main rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-accent-main/20 text-ink"
                      placeholder="https://... or upload"
                    />
                    <input 
                      type="file" 
                      id={`file-${member.id}`}
                      className="hidden"
                      accept="image/*"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        try {
                          const fileExt = file.name.split('.').pop();
                          const fileName = `${Math.random().toString(36).substring(2)}.${fileExt}`;
                          const filePath = `landing-team/${fileName}`;
                          
                          const { error: uploadError } = await supabase.storage
                            .from('app-images')
                            .upload(filePath, file);
                            
                          if (uploadError) throw uploadError;
                          
                          const { data: { publicUrl } } = supabase.storage.from('app-images').getPublicUrl(filePath);
                          updateTeamMember(member.id, 'imageUrl', publicUrl);
                        } catch (err: any) {
                          alert('Error uploading image: ' + err.message);
                        }
                      }}
                    />
                    <button 
                      onClick={() => document.getElementById(`file-${member.id}`)?.click()}
                      className="p-2 bg-bg-sec text-ink hover:text-accent-main rounded-xl hover:bg-surface-main transition-colors border border-border-main flex-shrink-0"
                      title="Upload Image"
                    >
                      <ImageIcon size={20} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
