import React, { useState, useEffect } from 'react';
import { supabase } from '../supabase';
import { Tenant, UserProfile, StaffMember } from '../types';
import { getDefaultModulesForBusinessType } from '../utils/moduleHelpers';
import { Settings2, CheckCircle2, Circle, Building2, ExternalLink, Grid, List, X as CloseIcon, Check, Edit2, Trash2, ShieldCheck, Eye, EyeOff, DollarSign, Activity, Lock, Save, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from './LanguageContext';

import { is9DigitNumber, checkUsernameExists, USERNAME_FORMAT_ERROR, USERNAME_EXISTS_ERROR } from '../lib/validation';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  contentClassName?: string;
}

const Modal = ({ isOpen, onClose, title, children, contentClassName = '' }: ModalProps) => (
  <AnimatePresence>
    {isOpen && (
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-0 sm:p-6">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
        />
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className={`relative w-full ${contentClassName.includes('max-w-') ? '' : 'max-w-lg'} bg-white sm:rounded-[2rem] shadow-2xl overflow-hidden h-full sm:h-auto overflow-y-auto ${contentClassName}`}
        >
          <div className="p-6 sm:p-8 border-b border-slate-100 flex justify-between items-center sticky top-0 bg-white z-10">
            <h3 className="text-xl sm:text-2xl font-bold text-slate-900">{title}</h3>
            <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-xl transition-colors">
              <CloseIcon size={20} className="text-slate-400" />
            </button>
          </div>
          <div className="p-6 sm:p-8">
            {children}
          </div>
        </motion.div>
      </div>
    )}
  </AnimatePresence>
);

const moduleLabels: Record<string, string> = {
  inventory: 'inventory',
  sales: 'sales_pricing',
  debts: 'debt_management',
  crm: 'crm_supply',
  expenses: 'expenses',
  tax: 'tax_management',
  alerts: 'alert_system',
  reports: 'reports',
  hospital: 'hospital_section'
};

export default function SystemManagerDashboard({ activeTab, user }: { activeTab: string, user: UserProfile }) {
  const { t } = useLanguage();
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [isRegisterModalOpen, setIsRegisterModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingTenant, setEditingTenant] = useState<Tenant | null>(null);
  const [showBusinessPassword, setShowBusinessPassword] = useState(false);
  const [newBusiness, setNewBusiness] = useState({
    name: '',
    type: 'retail',
    subscriptionPlan: 'monthly',
    customPrice: '',
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0],
    adminUsername: '',
    adminPassword: '',
    location: '',
    contact: '',
    status: 'active' as 'active' | 'limited',
    isLocked: false,
    logoUrl: '',
    paymentNumbers: {
      evc: '',
      edahab: '',
      zaad: '',
      sahal: '',
      bank: '',
      merchant: ''
    },
    planExpiry: new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0],
    modules: getDefaultModulesForBusinessType('retail')
  });
  const [submitting, setSubmitting] = useState(false);
  const [registerError, setRegisterError] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<{type: 'success' | 'error', text: string} | null>(null);

  // Profile Settings State
  const [profileData, setProfileData] = useState({
    displayName: user.displayName || '',
    phone: user.phone || '',
    password: user.password || '',
    confirmPassword: user.password || ''
  });
  const [profileSuccess, setProfileSuccess] = useState<string | null>(null);
  const [profileError, setProfileError] = useState<string | null>(null);
  const [showProfilePassword, setShowProfilePassword] = useState(false);

  const safeIso = (dateStr: any) => {
    if (!dateStr) return new Date().toISOString();
    const d = new Date(dateStr);
    return isNaN(d.getTime()) ? new Date().toISOString() : d.toISOString();
  };

  // Confirmation Modal State
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  const openConfirm = (title: string, message: string, onConfirm: () => void) => {
    setConfirmModal({
      isOpen: true,
      title,
      message,
      onConfirm: () => {
        onConfirm();
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const RenderConfirmModal = () => (
    <Modal 
      isOpen={confirmModal.isOpen} 
      onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))} 
      title={confirmModal.title}
    >
      <div className="space-y-6">
        <div className="flex items-center gap-4 p-4 bg-rose-50 rounded-2xl text-rose-600">
          <Trash2 size={24} />
          <p className="text-sm font-medium">{confirmModal.message}</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
            className="flex-1 px-6 py-4 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 transition-all"
          >
            {t('cancel')}
          </button>
          <button 
            onClick={confirmModal.onConfirm}
            className="flex-1 px-6 py-4 bg-rose-600 text-white rounded-xl font-bold hover:bg-rose-700 transition-all shadow-lg shadow-rose-200"
          >
            {t('delete')}
          </button>
        </div>
      </div>
    </Modal>
  );

  const calculateRevenue = (tenantId: string) => {
    const adminUser = allUsers.find(u => u.tenantId === tenantId && u.role === 'business_user' && !u.isStaff);
    if (adminUser?.subscription?.price) return adminUser.subscription.price;
    const plan = adminUser?.subscription?.plan || 'monthly';
    if (plan === 'daily') return 2;
    if (plan === 'weekly') return 10;
    if (plan === 'monthly') return 35;
    if (plan === '2months') return 65;
    if (plan === '3months') return 95;
    if (plan === 'yearly') return 350;
    return 0;
  };

  const totalRevenue = tenants.reduce((acc, tenant) => acc + calculateRevenue(tenant.id), 0);

  useEffect(() => {
    if (!newBusiness.startDate) return;
    const start = new Date(newBusiness.startDate);
    if (isNaN(start.getTime())) return;
    
    const end = new Date(start);
    const plan = newBusiness.subscriptionPlan;
    
    if (plan === 'daily') end.setDate(start.getDate() + 1);
    else if (plan === 'weekly') end.setDate(start.getDate() + 7);
    else if (plan === 'monthly') end.setMonth(start.getMonth() + 1);
    else if (plan === '2months') end.setMonth(start.getMonth() + 2);
    else if (plan === '3months') end.setMonth(start.getMonth() + 3);
    else if (plan === 'yearly') end.setFullYear(start.getFullYear() + 1);
    else if (plan === 'custom') end.setMonth(start.getMonth() + 1);
    
    const iso = isNaN(end.getTime()) ? new Date().toISOString() : end.toISOString();
    const datePart = iso.split('T')[0];
    
    setNewBusiness(prev => ({ ...prev, endDate: datePart, planExpiry: datePart }));
  }, [newBusiness.subscriptionPlan, newBusiness.startDate]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data: tenantsData } = await supabase
        .from('tenants')
        .select('*')
        .eq('manager_id', user.uid);
      
      const mappedTenants = (tenantsData || []).map(t => ({
        id: t.id,
        name: t.name,
        type: t.type,
        modules: t.modules,
        managerId: t.manager_id,
        subscriptionPlan: t.subscription_plan,
        planExpiry: t.plan_expiry,
        isLocked: t.is_locked,
        createdAt: t.created_at,
        logoUrl: t.logo_url,
        status: t.status,
        isMultiBranch: t.is_multi_branch,
        location: t.location,
        contact: t.contact,
        paymentNumbers: t.payment_numbers
      }));
      setTenants(mappedTenants as Tenant[]);

      // Fetch business users for these tenants to get subscription info
      if (tenantsData && tenantsData.length > 0) {
        const tenantIds = tenantsData.map(t => t.id);
        const { data: usersData } = await supabase
          .from('users')
          .select('*')
          .eq('role', 'business_user')
          .in('tenant_id', tenantIds);
        
        const mappedUsers = (usersData || []).map(u => ({
          id: u.id,
          uid: u.uid,
          email: u.email,
          displayName: u.display_name,
          role: u.role,
          tenantId: u.tenant_id,
          createdAt: u.created_at,
          username: u.username,
          password: u.password,
          phone: u.phone,
          photoURL: u.photo_url,
          isStaff: u.is_staff,
          staffRoles: u.staff_roles,
          subscription: u.subscription,
          isLocked: u.is_locked,
          isExpired: u.is_expired,
          planExpiry: u.plan_expiry,
          branchId: u.branch_id
        }));
        setAllUsers(mappedUsers as UserProfile[]);
      }
    } catch (error) {
      console.error("Error fetching manager data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [user.uid]);

  const handleRegisterBusiness = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setRegisterError(null);
    try {
      const trimmedUsername = newBusiness.adminUsername.trim();

      if (editingTenant) {
        // Find the current admin user for this tenant
        const currentAdmin = allUsers.find(u => u.tenantId === editingTenant.id && u.role === 'business_user' && !u.isStaff);

        // Only validate if username changed
        if (currentAdmin?.username !== trimmedUsername) {
          // 9-digit validation
          if (!is9DigitNumber(trimmedUsername)) {
            throw new Error(USERNAME_FORMAT_ERROR);
          }

          // Check for uniqueness
          const exists = await checkUsernameExists(trimmedUsername);
          if (exists) {
            throw new Error(USERNAME_EXISTS_ERROR);
          }
        }

        // Update existing tenant
        const { error: updateError } = await supabase.from('tenants').update({
          name: newBusiness.name,
          type: newBusiness.type,
          location: newBusiness.location,
          contact: newBusiness.contact,
          logo_url: newBusiness.logoUrl,
          payment_numbers: newBusiness.paymentNumbers,
          subscription_plan: newBusiness.subscriptionPlan,
          modules: newBusiness.modules,
          status: newBusiness.status,
          is_locked: newBusiness.isLocked,
          plan_expiry: safeIso(newBusiness.planExpiry)
        }).eq('id', editingTenant.id);
        if (updateError) throw updateError;

        // Update admin user credentials
        const adminUser = allUsers.find(u => u.tenantId === editingTenant.id && u.role === 'business_user' && !u.isStaff);
        if (adminUser) {
          const { error: userUpdateError } = await supabase.from('users').update({
            username: newBusiness.adminUsername,
            password: newBusiness.adminPassword,
            display_name: `${newBusiness.name} Admin`,
            subscription: {
              ...adminUser.subscription,
              plan: newBusiness.subscriptionPlan as any,
              startDate: safeIso(newBusiness.startDate),
              endDate: safeIso(newBusiness.endDate),
              price: (newBusiness.customPrice && !isNaN(parseFloat(newBusiness.customPrice))) ? parseFloat(newBusiness.customPrice) : null
            }
          }).eq('uid', adminUser.uid);
          if (userUpdateError) throw userUpdateError;
        }

        setIsEditModalOpen(false);
        setEditingTenant(null);
      } else {
        // 9-digit validation for new business
        if (!is9DigitNumber(trimmedUsername)) {
          throw new Error(USERNAME_FORMAT_ERROR);
        }

        // Check for uniqueness for new business
        const exists = await checkUsernameExists(trimmedUsername);
        if (exists) {
          throw new Error(USERNAME_EXISTS_ERROR);
        }

        // Create new tenant
        const tenantData = {
          name: newBusiness.name,
          type: newBusiness.type,
          manager_id: user.uid,
          location: newBusiness.location,
          contact: newBusiness.contact,
          logo_url: newBusiness.logoUrl,
          payment_numbers: newBusiness.paymentNumbers,
          modules: newBusiness.modules,
          subscription_plan: newBusiness.subscriptionPlan,
          is_locked: false,
          plan_expiry: safeIso(newBusiness.planExpiry),
          status: 'active',
          created_at: new Date().toISOString()
        };
        const { data: tenantRef, error: tenantError } = await supabase.from('tenants').insert(tenantData).select().single();
        if (tenantError) throw tenantError;
        if (!tenantRef) throw new Error("Failed to create tenant record");

        // 2. Create Business Admin User
        const adminUid = `user_${Date.now()}`;
        
        const adminData = {
          uid: adminUid,
          display_name: `${newBusiness.name.trim()} Admin`,
          email: `${newBusiness.adminUsername.trim()}@business.sahal`,
          username: newBusiness.adminUsername.trim(),
          password: newBusiness.adminPassword.trim(),
          role: 'business_user',
          tenant_id: tenantRef.id,
          created_at: new Date().toISOString(),
          subscription: {
            plan: newBusiness.subscriptionPlan as any,
            startDate: safeIso(newBusiness.startDate),
            endDate: safeIso(newBusiness.endDate),
            status: 'active',
            price: (newBusiness.customPrice && !isNaN(parseFloat(newBusiness.customPrice))) ? parseFloat(newBusiness.customPrice) : null
          }
        };
        const { error: adminInsertError } = await supabase.from('users').insert(adminData);
        if (adminInsertError) throw adminInsertError;
      }

      setIsRegisterModalOpen(false);
      setNewBusiness({
        name: '',
        type: 'retail',
        subscriptionPlan: 'monthly',
        customPrice: '',
        startDate: new Date().toISOString().split('T')[0],
        endDate: new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0],
        adminUsername: '',
        adminPassword: '',
        location: '',
        contact: '',
        status: 'active',
        isLocked: false,
        planExpiry: new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0],
        modules: getDefaultModulesForBusinessType('retail')
      });
      await fetchData();
    } catch (error: any) {
      console.error("Error saving business:", error);
      const errorMessage = error?.message || error?.details || error?.hint || JSON.stringify(error);
      setRegisterError(`Error saving business: ${errorMessage}`);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteBusiness = async (tenantId: string) => {
    openConfirm(t('delete'), t('delete_business_confirm'), async () => {
      try {
        setLoading(true);
        setStatusMessage(null);
        // 1. Delete all related data from all possible tables first
        const tables = [
          'inventory', 'sales', 'expenses', 'debts', 'customers', 
          'patients', 'visits', 'services', 'savings', 
          'investments', 'working_notes', 'daily_tasks', 'keeping_ideas', 
          'shareholders', 'staff', 'account_transactions',
          'stock_logs', 'utility_records', 'homes', 'accounts', 'utility_settings'
        ];

        // Perform deletions in parallel for efficiency
        await Promise.all(tables.map(table => supabase.from(table).delete().eq('tenant_id', tenantId)));

        // 2. Delete associated users for this tenant
        const { error: userError } = await supabase
          .from('users')
          .delete()
          .eq('tenant_id', tenantId);
          
        if (userError) throw userError;

        // 3. Delete the tenant itself
        const { error: tenantError } = await supabase
          .from('tenants')
          .delete()
          .eq('id', tenantId);

        if (tenantError) throw tenantError;
        
        setStatusMessage({ type: 'success', text: t('data_deleted_success') });
        await fetchData();
      } catch (error: any) {
        console.error("Error deleting business:", error);
        setStatusMessage({ type: 'error', text: `${t('error_occurred')}: ${error.message}` });
      } finally {
        setLoading(false);
      }
    });
  };

  const openEditModal = (tenant: Tenant) => {
    setEditingTenant(tenant);
    // Find the admin user for this tenant
    const adminUser = allUsers.find(u => u.tenantId === tenant.id && u.role === 'business_user' && !u.isStaff);
    setNewBusiness({
      name: tenant.name,
      type: tenant.type,
      subscriptionPlan: tenant.subscriptionPlan || 'monthly',
      customPrice: adminUser?.subscription?.price?.toString() || '',
      startDate: adminUser?.subscription?.startDate?.split('T')[0] || new Date().toISOString().split('T')[0],
      endDate: adminUser?.subscription?.endDate?.split('T')[0] || new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0],
      adminUsername: adminUser?.username || '',
      adminPassword: adminUser?.password || '',
      location: tenant.location || '',
      contact: tenant.contact || '',
      logoUrl: (tenant as any).logo_url || '',
      paymentNumbers: {
        evc: (tenant as any).payment_numbers?.evc || '',
        edahab: (tenant as any).payment_numbers?.edahab || '',
        zaad: (tenant as any).payment_numbers?.zaad || '',
        sahal: (tenant as any).payment_numbers?.sahal || '',
        bank: (tenant as any).payment_numbers?.bank || '',
        merchant: (tenant as any).payment_numbers?.merchant || ''
      },
      status: tenant.status || 'active',
      isLocked: tenant.isLocked || false,
      planExpiry: tenant.planExpiry?.split('T')[0] || new Date().toISOString().split('T')[0],
      modules: tenant.modules
    });
    setIsEditModalOpen(true);
  };

  const toggleModule = async (tenantId: string, moduleKey: string, currentValue: boolean) => {
    try {
      const tenant = tenants.find(t => t.id === tenantId);
      if (!tenant) return;

      const updatedModules = { ...tenant.modules, [moduleKey]: !currentValue };

      await supabase.from('tenants').update({
        modules: updatedModules
      }).eq('id', tenantId);

      setTenants(prev => prev.map(t => 
        t.id === tenantId 
          ? { ...t, modules: updatedModules }
          : t
      ));
    } catch (error) {
      console.error("Error toggling module:", error);
    }
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setProfileError(null);
    setProfileSuccess(null);

    try {
      if (profileData.password !== profileData.confirmPassword) {
        throw new Error(t('passwords_not_match'));
      }

      const { error } = await supabase
        .from('users')
        .update({
          display_name: profileData.displayName,
          phone: profileData.phone,
          password: profileData.password,
        })
        .eq('uid', user.uid);

      if (error) throw error;
      setProfileSuccess(t('profile_updated_successfully'));
    } catch (error: any) {
      console.error("Error updating profile:", error);
      setProfileError(error.message || "Failed to update profile");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-10">
      {activeTab === 'overview' && (
        <div className="space-y-10">
          {statusMessage && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`p-4 rounded-2xl flex items-center gap-3 text-sm font-medium border ${
                statusMessage.type === 'success' ? 'bg-emerald-50 border-emerald-100 text-emerald-600' : 'bg-rose-50 border-rose-100 text-rose-600'
              }`}
            >
              {statusMessage.type === 'success' ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
              {statusMessage.text}
            </motion.div>
          )}
        <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          <div className="sahal-card p-5 sm:p-8 bg-white border border-slate-100 shadow-sm flex flex-col justify-between min-h-[160px] sm:min-h-0">
            <div className="flex justify-between items-start mb-4">
              <div className="p-3 bg-indigo-600 text-white rounded-2xl shadow-lg shadow-indigo-100">
                <Building2 size={24} />
              </div>
            </div>
            <div>
              <h3 className="text-slate-400 text-[10px] sm:text-xs font-black uppercase tracking-widest mb-1">{t('total_business')}</h3>
              <p className="text-2xl sm:text-4xl font-display font-black text-slate-900 tracking-tighter">{tenants.length}</p>
            </div>
          </div>
          
          <div className="sahal-card p-5 sm:p-8 bg-white border border-slate-100 shadow-sm flex flex-col justify-between min-h-[160px] sm:min-h-0">
            <div className="flex justify-between items-start mb-4">
              <div className="p-3 bg-emerald-600 text-white rounded-2xl shadow-lg shadow-emerald-100">
                <CheckCircle2 size={24} />
              </div>
            </div>
            <div>
              <h3 className="text-slate-400 text-[10px] sm:text-xs font-black uppercase tracking-widest mb-1">{t('active_subscriptions')}</h3>
              <p className="text-2xl sm:text-4xl font-display font-black text-slate-900 tracking-tighter">
                {allUsers.filter(u => u.subscription?.status === 'active').length}
              </p>
            </div>
          </div>

          <div className="sahal-card p-5 sm:p-8 bg-white border border-slate-100 shadow-sm flex flex-col justify-between min-h-[160px] sm:min-h-0">
            <div className="flex justify-between items-start mb-4">
              <div className="p-3 bg-amber-500 text-white rounded-2xl shadow-lg shadow-amber-100">
                <Settings2 size={24} />
              </div>
            </div>
            <div>
              <h3 className="text-slate-400 text-[10px] sm:text-xs font-black uppercase tracking-widest mb-1">{t('total_modules_active')}</h3>
              <p className="text-2xl sm:text-4xl font-display font-black text-slate-900 tracking-tighter">
                {tenants.reduce((acc, t) => acc + Object.values(t.modules || {}).filter(Boolean).length, 0)}
              </p>
            </div>
          </div>

          <div className="sahal-card p-5 sm:p-8 bg-white border border-slate-100 shadow-sm flex flex-col justify-between min-h-[160px] sm:min-h-0">
            <div className="flex justify-between items-start mb-4">
              <div className="p-3 bg-emerald-600 text-white rounded-2xl shadow-lg shadow-emerald-100">
                <DollarSign size={24} />
              </div>
            </div>
            <div>
              <h3 className="text-slate-400 text-[10px] sm:text-xs font-black uppercase tracking-widest mb-1">{t('revenue_generated')}</h3>
              <p className="text-2xl sm:text-4xl font-display font-black text-emerald-600 tracking-tighter">
                ${totalRevenue}
              </p>
            </div>
          </div>
        </div>

        <div className="sahal-card overflow-hidden bg-white border border-slate-100 shadow-sm">
          <div className="p-8 border-b border-slate-100 flex justify-between items-center">
            <h3 className="text-xl font-display font-bold text-slate-900">{t('business_status')}</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/50">
                  <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('business')}</th>
                  <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('username')}</th>
                  <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('password')}</th>
                  <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('subscription_plan')}</th>
                  <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('revenue_generated')}</th>
                  <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('expiry')}</th>
                  <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('status')}</th>
                  <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('lock_status' as any) || 'Lock'}</th>
                  <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100 text-right">{t('actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {tenants.map((tenant) => {
                  const businessAdmin = allUsers.find(u => u.tenantId === tenant.id) || allUsers.find(u => u.uid === tenant.managerId);
                  const subscription = businessAdmin?.subscription;
                  const isExpired = subscription?.endDate ? new Date(subscription.endDate) < new Date() : false;

                  return (
                    <tr key={tenant.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-6">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center font-bold overflow-hidden">
                            {tenant.logo_url ? (
                              <img src={tenant.logo_url} alt="Logo" className="w-full h-full object-contain" />
                            ) : (
                              tenant.name.charAt(0)
                            )}
                          </div>
                          <div>
                            <p className="font-bold text-slate-900">{tenant.name}</p>
                            <p className="text-[10px] text-slate-400 uppercase">{tenant.type}</p>
                          </div>
                        </div>
                      </td>
                      <td className="p-6">
                        <p className="text-sm font-mono text-slate-600">{businessAdmin?.username || 'N/A'}</p>
                      </td>
                      <td className="p-6">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-mono text-slate-600">
                            {showBusinessPassword ? businessAdmin?.password : '••••••••'}
                          </p>
                          <button 
                            onClick={() => setShowBusinessPassword(!showBusinessPassword)}
                            className="text-slate-400 hover:text-slate-600 transition-colors"
                          >
                            {showBusinessPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                          </button>
                        </div>
                      </td>
                      <td className="p-6">
                        <span className="text-xs font-bold uppercase px-3 py-1.5 bg-slate-100 text-slate-600 rounded-lg">
                          {subscription?.plan || tenant.subscriptionPlan || 'N/A'}
                        </span>
                      </td>
                      <td className="p-6">
                        <p className="text-sm font-bold text-emerald-600">
                          ${calculateRevenue(tenant.id)}
                        </p>
                      </td>
                      <td className="p-6">
                        <p className="text-xs font-bold text-slate-600">
                          {subscription?.endDate ? new Date(subscription.endDate).toLocaleDateString() : t('not_found')}
                        </p>
                      </td>
                      <td className="p-6">
                        <span className={`text-[10px] font-bold uppercase px-2 py-1 rounded-md ${
                          isExpired ? 'bg-rose-50 text-rose-600' : 'bg-emerald-50 text-emerald-600'
                        }`}>
                          {isExpired ? t('expired') : t('active')}
                        </span>
                      </td>
                      <td className="p-6">
                        <span className={`text-[10px] font-bold uppercase px-2 py-1 rounded-md ${
                          tenant.isLocked ? 'bg-red-100 text-red-600' : 'bg-slate-100 text-slate-600'
                        }`}>
                          {tenant.isLocked ? t('locked' as any) || 'Locked' : t('unlocked' as any) || 'Unlocked'}
                        </span>
                      </td>
                      <td className="p-6 text-right">
                        <div className="flex items-center justify-end gap-3">
                          <button 
                            onClick={() => openEditModal(tenant)}
                            className="p-3 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all border border-transparent hover:border-indigo-100"
                            title={t('edit')}
                          >
                            <Edit2 size={20} />
                          </button>
                          <button 
                            onClick={() => handleDeleteBusiness(tenant.id)}
                            className="p-3 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all border border-transparent hover:border-rose-100"
                            title={t('delete')}
                          >
                            <Trash2 size={20} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    )}

      {activeTab === 'business' && (
        <div className="space-y-10">
        {statusMessage && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className={`p-4 rounded-2xl flex items-center gap-3 text-sm font-medium border ${
              statusMessage.type === 'success' ? 'bg-emerald-50 border-emerald-100 text-emerald-600' : 'bg-rose-50 border-rose-100 text-rose-600'
            }`}
          >
            {statusMessage.type === 'success' ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
            {statusMessage.text}
          </motion.div>
        )}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4">
          <div>
            <h1 className="text-4xl font-display font-bold tracking-tight text-slate-900">{t('business_portfolio')}</h1>
            <p className="text-slate-500 font-medium">{t('managing_tenants').replace('{count}', tenants.length.toString())}</p>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setIsRegisterModalOpen(true)}
              className="px-6 py-3 bg-slate-900 text-white rounded-xl font-bold text-sm hover:bg-slate-800 transition-all shadow-lg shadow-slate-200 flex items-center gap-2"
            >
              <Building2 size={18} />
              {t('register_new_business')}
            </button>
            <div className="flex bg-white p-1 rounded-xl border border-slate-200 shadow-sm h-[44px]">
              <button 
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded-lg transition-all ${viewMode === 'grid' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-400 hover:text-slate-600'}`}
              >
                <Grid size={18} />
              </button>
              <button 
                onClick={() => setViewMode('list')}
                className={`p-2 rounded-lg transition-all ${viewMode === 'list' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-400 hover:text-slate-600'}`}
              >
                <List size={18} />
              </button>
            </div>
          </div>
        </div>
        
        <div className={viewMode === 'grid' ? "grid grid-cols-1 xl:grid-cols-2 gap-8" : "space-y-6"}>
          {tenants.map((tenant) => (
            <motion.div 
              key={tenant.id}
              layout
              className="sahal-card overflow-hidden group"
            >
              <div className="p-8 border-b border-slate-100 flex justify-between items-start">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-400 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-all duration-300 overflow-hidden">
                    {tenant.logo_url ? (
                      <img src={tenant.logo_url} alt="Logo" className="w-full h-full object-contain p-2" />
                    ) : (
                      <Building2 size={28} />
                    )}
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-2xl text-slate-900">{tenant.name}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400 bg-slate-100 px-2 py-0.5 rounded">
                        {tenant.type}
                      </span>
                      <span className="text-[10px] font-bold uppercase tracking-widest bg-emerald-50 text-emerald-600 px-2 py-0.5 rounded">
                        ${calculateRevenue(tenant.id)}
                      </span>
                      <span className={`text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded ${
                        tenant.status === 'limited' ? 'bg-rose-50 text-rose-600' : 'bg-emerald-50 text-emerald-600'
                      }`}>
                        {tenant.status === 'limited' ? t('limited') : t('active')}
                      </span>
                      <span className="text-[10px] font-mono text-slate-300">ID: {tenant.id}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => openEditModal(tenant)}
                    className="flex items-center gap-2 px-4 py-2 bg-slate-50 text-slate-600 hover:bg-indigo-600 hover:text-white rounded-xl transition-all duration-300 border border-slate-100 font-bold text-xs"
                  >
                    <Edit2 size={16} />
                    <span>{t('edit')}</span>
                  </button>
                  <button 
                    onClick={() => handleDeleteBusiness(tenant.id)}
                    className="flex items-center gap-2 px-4 py-2 bg-slate-50 text-rose-600 hover:bg-rose-600 hover:text-white rounded-xl transition-all duration-300 border border-slate-100 font-bold text-xs"
                  >
                    <Trash2 size={16} />
                    <span>{t('delete')}</span>
                  </button>
                  <button className="p-2.5 bg-slate-50 text-slate-400 hover:bg-slate-900 hover:text-white rounded-xl transition-all duration-300 border border-slate-100">
                    <ExternalLink size={18} />
                  </button>
                </div>
              </div>

              <div className="p-8 bg-slate-50/30">
                <div className="flex items-center justify-between mb-6">
                  <p className="text-xs font-bold uppercase tracking-[0.15em] text-slate-400 flex items-center gap-2">
                    <Settings2 size={14} className="text-indigo-500" />
                    {t('module_configuration')}
                  </p>
                  <span className="text-[10px] font-medium text-slate-400 italic">{t('click_to_toggle')}</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  {(Object.entries(tenant.modules || {}) as [string, boolean][]).map(([key, enabled]) => (
                    <button
                      key={key}
                      onClick={() => toggleModule(tenant.id, key, enabled)}
                      className={`group/btn flex flex-col items-center justify-center p-5 rounded-2xl border-2 transition-all duration-300 ${
                        enabled 
                          ? 'bg-white border-indigo-600 text-indigo-600 shadow-lg shadow-indigo-50' 
                          : 'bg-white border-slate-100 text-slate-300 hover:border-slate-300 hover:text-slate-500'
                      }`}
                    >
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-3 transition-colors ${
                        enabled ? 'bg-indigo-600 text-white' : 'bg-slate-50 text-slate-300 group-hover/btn:bg-slate-100'
                      }`}>
                        {enabled ? <CheckCircle2 size={16} /> : <Circle size={16} />}
                      </div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-center">{t(key)}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="px-8 py-4 bg-white border-t border-slate-100 flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                  <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest">{t('system_online')}</span>
                </div>
                <span className="text-[10px] font-medium text-slate-300">{t('managed_by_you')}</span>
              </div>
            </motion.div>
          ))}
          {tenants.length === 0 && (
            <div className="col-span-full p-24 border-2 border-dashed border-slate-200 rounded-[2rem] text-center bg-white/50">
              <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Building2 size={40} className="text-slate-300" />
              </div>
              <h3 className="text-xl font-display font-bold text-slate-900 mb-2">{t('portfolio_empty')}</h3>
              <p className="text-slate-400 max-w-xs mx-auto">{t('no_tenants_assigned')}</p>
            </div>
          )}
        </div>
      </div>
    )}

      {activeTab === 'settings' && (
        <div className="max-w-4xl space-y-10">
        <div>
          <h1 className="text-4xl font-display font-bold tracking-tight text-slate-900">{t('account_settings')}</h1>
          <p className="text-slate-500 font-medium">{t('manage_your_account_details')}</p>
        </div>

        <div className="sahal-card p-8 bg-white border border-slate-100 shadow-sm">
          <form onSubmit={handleUpdateProfile} className="space-y-8">
            <div className="flex items-center gap-4 mb-8">
              <div className="w-16 h-16 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center text-2xl font-bold">
                {profileData.displayName?.[0]}
              </div>
              <div>
                <h3 className="font-display font-bold text-xl text-slate-900">{profileData.displayName}</h3>
                <p className="text-sm text-slate-400 capitalize">{user.role.replace('_', ' ')}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('display_name')}</label>
                <input 
                  type="text" 
                  required
                  value={profileData.displayName}
                  onChange={e => setProfileData({...profileData, displayName: e.target.value})}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('phone')}</label>
                <input 
                  type="text" 
                  value={profileData.phone}
                  onChange={e => setProfileData({...profileData, phone: e.target.value})}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-medium"
                />
              </div>

              <div className="relative">
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('password')}</label>
                <input 
                  type={showProfilePassword ? "text" : "password"}
                  required
                  value={profileData.password}
                  onChange={e => setProfileData({...profileData, password: e.target.value})}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-mono"
                />
                <button 
                  type="button"
                  onClick={() => setShowProfilePassword(!showProfilePassword)}
                  className="absolute right-4 top-[38px] text-slate-400 hover:text-slate-600 transition-colors"
                >
                  {showProfilePassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('confirm_password')}</label>
                <input 
                  type={showProfilePassword ? "text" : "password"}
                  required
                  value={profileData.confirmPassword}
                  onChange={e => setProfileData({...profileData, confirmPassword: e.target.value})}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-mono"
                />
              </div>
            </div>

            {(profileError || profileSuccess) && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`p-4 rounded-xl flex items-center gap-3 text-sm font-medium ${
                  profileError ? 'bg-rose-50 text-rose-600' : 'bg-emerald-50 text-emerald-600'
                }`}
              >
                {profileError ? <AlertCircle size={18} /> : <CheckCircle2 size={18} />}
                {profileError || profileSuccess}
              </motion.div>
            )}

            <div className="flex justify-end pt-4 border-t border-slate-100">
              <button
                type="submit"
                disabled={submitting}
                className="flex items-center gap-3 px-8 py-4 bg-slate-900 text-white rounded-2xl font-bold hover:bg-slate-800 transition-all shadow-lg shadow-slate-200 disabled:opacity-50"
              >
                {submitting ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <Save size={18} />
                )}
                <span>{t('save_changes')}</span>
              </button>
            </div>
          </form>
        </div>

        <div className="p-8 bg-amber-50 border border-amber-100 rounded-[2rem] flex items-start gap-4">
          <div className="w-12 h-12 bg-amber-100 text-amber-600 rounded-2xl flex items-center justify-center shrink-0">
            <Lock size={24} />
          </div>
          <div>
            <h4 className="font-bold text-amber-900 mb-1">{t('security_notice' as any) || 'Security Notice'}</h4>
            <p className="text-sm text-amber-700 leading-relaxed">
              {t('password_change_notice' as any) || 'Your password changes will be visible to the Super Admin for security monitoring purposes. Please ensure you use a strong, unique password.'}
            </p>
          </div>
        </div>
      </div>
    )}

      {activeTab !== 'overview' && activeTab !== 'business' && activeTab !== 'settings' && (
        <div className="flex flex-col items-center justify-center p-24 text-center">
          <div className="w-24 h-24 bg-slate-50 rounded-[2.5rem] flex items-center justify-center mb-8">
            <Settings2 size={48} className="text-slate-200" />
          </div>
          <h3 className="text-2xl font-display font-bold text-slate-900 mb-3">{t('module_under_construction')}</h3>
          <p className="text-slate-400 max-w-md">{t('onboarding_experience_desc')}</p>
        </div>
      )}

      {/* Common Modals */}
      <Modal 
        isOpen={isRegisterModalOpen || isEditModalOpen} 
        onClose={() => {
          setIsRegisterModalOpen(false);
          setIsEditModalOpen(false);
          setEditingTenant(null);
          setNewBusiness({
            name: '',
            type: 'retail',
            subscriptionPlan: 'monthly',
            customPrice: '',
            startDate: new Date().toISOString().split('T')[0],
            endDate: new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0],
            adminUsername: '',
            adminPassword: '',
            location: '',
            contact: '',
            status: 'active',
            isLocked: false,
            logoUrl: '',
            paymentNumbers: {
              evc: '',
              edahab: '',
              zaad: '',
              sahal: '',
              bank: '',
              merchant: ''
            },
            planExpiry: new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0],
            modules: getDefaultModulesForBusinessType('retail')
          });
        }}
        title={editingTenant ? t('edit_business') : t('register_new_business')}
        contentClassName="max-w-4xl"
      >
        <form onSubmit={handleRegisterBusiness} className="space-y-6">
          {registerError && (
            <div className="p-4 bg-red-50 text-red-600 rounded-xl text-sm font-medium">
              {registerError}
            </div>
          )}
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
            <div className="space-y-6">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em] mb-2">{t('business_name')}</label>
                <input 
                  required
                  type="text"
                  value={newBusiness.name}
                  onChange={(e) => setNewBusiness({...newBusiness, name: e.target.value})}
                  className="w-full px-4 py-3 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-900 placeholder:text-slate-300"
                  placeholder={t('business_name_placeholder')}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em] mb-2">{t('location')}</label>
                  <input 
                    type="text"
                    value={newBusiness.location}
                    onChange={(e) => setNewBusiness({...newBusiness, location: e.target.value})}
                    className="w-full px-4 py-3 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-900 placeholder:text-slate-300"
                    placeholder={t('location')}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em] mb-2">{t('contact')}</label>
                  <input 
                    type="text"
                    value={newBusiness.contact}
                    onChange={(e) => setNewBusiness({...newBusiness, contact: e.target.value})}
                    className="w-full px-4 py-3 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-900 placeholder:text-slate-300"
                    placeholder={t('contact')}
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em] mb-2">{t('business_type')}</label>
                <select 
                  required
                  value={newBusiness.type}
                  onChange={(e) => setNewBusiness({...newBusiness, type: e.target.value, modules: getDefaultModulesForBusinessType(e.target.value)})}
                  className="w-full px-4 py-3 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-900 appearance-none"
                  style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' fill=\'none\' viewBox=\'0 0 24 24\' stroke=\'currentColor\'%3E%3Cpath stroke-linecap=\'round\' stroke-linejoin=\'round\' stroke-width=\'2\' d=\'M19 9l-7 7-7-7\'/%3E%3C/svg%3E")', backgroundRepeat: 'no-repeat', backgroundPosition: 'right 1rem center', backgroundSize: '1.25rem' }}
                >
                  <option value="inventory">{t('type_inventory')}</option>
                  <option value="services">{t('type_services')}</option>
                  <option value="services_inventory">{t('type_services_inventory')}</option>
                  <option value="hospital">{t('type_hospital')}</option>
                  <option value="personal">{t('type_personal')}</option>
                  <option value="utility">{t('type_utility')}</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em] mb-2">{t('subscription_plan')}</label>
                <select 
                  value={newBusiness.subscriptionPlan}
                  onChange={(e) => setNewBusiness({...newBusiness, subscriptionPlan: e.target.value})}
                  className="w-full px-4 py-3 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-900 appearance-none"
                  style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' fill=\'none\' viewBox=\'0 0 24 24\' stroke=\'currentColor\'%3E%3Cpath stroke-linecap=\'round\' stroke-linejoin=\'round\' stroke-width=\'2\' d=\'M19 9l-7 7-7-7\'/%3E%3C/svg%3E")', backgroundRepeat: 'no-repeat', backgroundPosition: 'right 1rem center', backgroundSize: '1.25rem' }}
                >
                  <option value="daily">{t('daily_plan')}</option>
                  <option value="weekly">{t('weekly_plan')}</option>
                  <option value="monthly">{t('monthly_plan')}</option>
                  <option value="2months">{t('two_months_plan')}</option>
                  <option value="3months">{t('three_months_plan')}</option>
                  <option value="yearly">{t('yearly_plan')}</option>
                  <option value="custom">{t('custom_plan')}</option>
                </select>
              </div>

              {(newBusiness.subscriptionPlan === 'custom' || newBusiness.customPrice) && (
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em] mb-2">{t('custom_price')}</label>
                  <input 
                    type="number"
                    value={newBusiness.customPrice || ''}
                    onChange={(e) => setNewBusiness({...newBusiness, customPrice: e.target.value})}
                    className="w-full px-4 py-3 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-900 placeholder:text-slate-300"
                    placeholder="e.g. 50"
                  />
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em] mb-2">{t('start_date')}</label>
                  <input 
                    type="date"
                    value={newBusiness.startDate}
                    onChange={(e) => setNewBusiness({...newBusiness, startDate: e.target.value})}
                    className="w-full px-4 py-3 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em] mb-2">{t('end_date')}</label>
                  <input 
                    type="date"
                    value={newBusiness.planExpiry}
                    onChange={(e) => setNewBusiness({...newBusiness, planExpiry: e.target.value, endDate: e.target.value})}
                    className="w-full px-4 py-3 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-900"
                  />
                </div>
              </div>

              {editingTenant && (
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em] mb-2">{t('business_status')}</label>
                    <select 
                      value={newBusiness.status}
                      onChange={(e) => setNewBusiness({...newBusiness, status: e.target.value as any})}
                      className="w-full px-4 py-3 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-900 appearance-none"
                      style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' fill=\'none\' viewBox=\'0 0 24 24\' stroke=\'currentColor\'%3E%3Cpath stroke-linecap=\'round\' stroke-linejoin=\'round\' stroke-width=\'2\' d=\'M19 9l-7 7-7-7\'/%3E%3C/svg%3E")', backgroundRepeat: 'no-repeat', backgroundPosition: 'right 1rem center', backgroundSize: '1.25rem' }}
                    >
                      <option value="active">{t('active')}</option>
                      <option value="limited">{t('limited')}</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em] mb-2">{t('lock_status' as any) || 'Lock Status'}</label>
                    <select 
                      value={newBusiness.isLocked ? 'true' : 'false'}
                      onChange={(e) => setNewBusiness({...newBusiness, isLocked: e.target.value === 'true'})}
                      className="w-full px-4 py-3 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-900 appearance-none"
                      style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' fill=\'none\' viewBox=\'0 0 24 24\' stroke=\'currentColor\'%3E%3Cpath stroke-linecap=\'round\' stroke-linejoin=\'round\' stroke-width=\'2\' d=\'M19 9l-7 7-7-7\'/%3E%3C/svg%3E")', backgroundRepeat: 'no-repeat', backgroundPosition: 'right 1rem center', backgroundSize: '1.25rem' }}
                    >
                      <option value="false">{t('unlocked' as any) || 'Unlocked'}</option>
                      <option value="true">{t('locked' as any) || 'Locked'}</option>
                    </select>
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-6">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em] mb-4">{t('enabled_modules')}</label>
                <div className="grid grid-cols-2 lg:grid-cols-3 gap-2">
                  {Object.entries(newBusiness.modules).map(([key, enabled]) => (
                    <div
                      key={key}
                      onClick={() => setNewBusiness({
                        ...newBusiness,
                        modules: { ...newBusiness.modules, [key]: !enabled }
                      })}
                      className={`flex items-center gap-2 p-2 rounded-lg border transition-all cursor-pointer group ${
                        enabled ? 'bg-indigo-50/50 border-indigo-100' : 'bg-slate-50/50 border-transparent hover:border-slate-200'
                      }`}
                    >
                      <div className={`w-4 h-4 rounded flex items-center justify-center border transition-all ${
                        enabled 
                          ? 'bg-indigo-600 border-indigo-600 text-white' 
                          : 'bg-white border-slate-200 text-transparent group-hover:border-slate-300'
                      }`}>
                        <Check size={10} strokeWidth={4} />
                      </div>
                      <span className={`text-[10px] font-bold transition-colors ${enabled ? 'text-indigo-700' : 'text-slate-500'}`}>
                        {t(key)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-6 border-t border-slate-100">
                <h4 className="text-sm font-bold text-slate-900 mb-4">
                  {editingTenant ? t('edit_credentials') : t('initial_admin_account')}
                </h4>
                <div className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em] mb-2">{t('username')}</label>
                    <input 
                      required
                      type="text"
                      inputMode="numeric"
                      pattern="\d{9}"
                      maxLength={9}
                      value={newBusiness.adminUsername}
                      onChange={(e) => setNewBusiness({...newBusiness, adminUsername: e.target.value.replace(/\D/g, '')})}
                      className="w-full px-4 py-3 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-900 placeholder:text-slate-300"
                      placeholder="e.g. 615123456"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em] mb-2">{t('password')}</label>
                    <div className="relative">
                      <input 
                        required
                        type={showBusinessPassword ? "text" : "password"}
                        value={newBusiness.adminPassword}
                        onChange={(e) => setNewBusiness({...newBusiness, adminPassword: e.target.value})}
                        className="w-full px-4 py-3 bg-slate-50/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-900 placeholder:text-slate-300"
                        placeholder={t('password_placeholder')}
                      />
                      <button
                        type="button"
                        onClick={() => setShowBusinessPassword(!showBusinessPassword)}
                        className="absolute inset-y-0 right-0 pr-4 flex items-center text-slate-400 hover:text-slate-600 transition-colors"
                      >
                        {showBusinessPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-100">
            <button 
              disabled={submitting}
              type="submit"
              className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold shadow-xl shadow-slate-200 hover:bg-slate-800 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {submitting ? t('saving') : (editingTenant ? t('update_business') : t('register_business'))}
            </button>
          </div>
        </form>
      </Modal>
      <RenderConfirmModal />
    </div>
  );
}
