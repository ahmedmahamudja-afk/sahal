import React from 'react';
import { Calendar, ChevronLeft, ChevronRight } from 'lucide-react';
import { useLanguage } from './LanguageContext';

interface DateSelectorProps {
  selectedDate: Date;
  onChange: (date: Date) => void;
  mode?: 'day' | 'month' | 'year' | 'range';
  onModeChange?: (mode: 'day' | 'month' | 'year' | 'range') => void;
  startDate?: Date;
  endDate?: Date;
  onRangeChange?: (start: Date, end: Date) => void;
}

export default function DateSelector({ 
  selectedDate, 
  onChange, 
  mode = 'day', 
  onModeChange,
  startDate,
  endDate,
  onRangeChange
}: DateSelectorProps) {
  const { t, language } = useLanguage();

  const handlePrev = () => {
    if (!selectedDate) return;
    const newDate = new Date(selectedDate);
    if (mode === 'day') {
      newDate.setDate(newDate.getDate() - 1);
    } else if (mode === 'month') {
      newDate.setMonth(newDate.getMonth() - 1);
    } else if (mode === 'year') {
      newDate.setFullYear(newDate.getFullYear() - 1);
    }
    onChange(newDate);
  };

  const handleNext = () => {
    if (!selectedDate) return;
    const newDate = new Date(selectedDate);
    if (mode === 'day') {
      newDate.setDate(newDate.getDate() + 1);
    } else if (mode === 'month') {
      newDate.setMonth(newDate.getMonth() + 1);
    } else if (mode === 'year') {
      newDate.setFullYear(newDate.getFullYear() + 1);
    }
    onChange(newDate);
  };

  const formatDate = (date: Date) => {
    if (!date || isNaN(date.getTime())) return '';
    const locale = language === 'so' ? 'so-SO' : language;
    if (mode === 'day') {
      return date.toLocaleDateString(locale, { month: 'long', day: 'numeric', year: 'numeric' });
    } else if (mode === 'month') {
      return date.toLocaleDateString(locale, { month: 'long', year: 'numeric' });
    } else if (mode === 'year') {
      return date.toLocaleDateString(locale, { year: 'numeric' });
    }
    return '';
  };

  return (
    <div className="flex flex-col lg:flex-row items-center gap-4 bg-white p-2 rounded-2xl border border-slate-200 shadow-sm">
      {onModeChange && (
        <div className="flex bg-slate-100 p-1 rounded-xl flex-wrap justify-center">
          <button
            onClick={() => onModeChange('day')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
              mode === 'day' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            {t('day_label' as any) || 'Day'}
          </button>
          <button
            onClick={() => onModeChange('month')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
              mode === 'month' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            {t('month_label' as any) || 'Month'}
          </button>
          <button
            onClick={() => onModeChange('year')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
              mode === 'year' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            {t('year_label' as any) || 'Year'}
          </button>
          <button
            onClick={() => onModeChange('range')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
              mode === 'range' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            {t('range_label' as any) || 'Range'}
          </button>
        </div>
      )}
      
      {mode !== 'range' ? (
        <div className="flex items-center gap-2">
          <button 
            onClick={handlePrev}
            className="p-2 hover:bg-slate-50 rounded-xl text-slate-400 hover:text-indigo-600 transition-colors"
          >
            <ChevronLeft size={20} />
          </button>
          
          <div className="flex items-center gap-3 px-4 py-2 bg-slate-50 rounded-xl border border-slate-100 min-w-[180px] justify-center">
            <Calendar size={18} className="text-indigo-500" />
            <span className="text-sm font-bold text-slate-700">{formatDate(selectedDate)}</span>
          </div>

          <button 
            onClick={handleNext}
            className="p-2 hover:bg-slate-50 rounded-xl text-slate-400 hover:text-indigo-600 transition-colors"
          >
            <ChevronRight size={20} />
          </button>
        </div>
      ) : (
        <div className="flex flex-col sm:flex-row items-center gap-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-400 uppercase">{t('from' as any) || 'From'}</span>
            <input 
              type="date"
              value={startDate ? `${startDate.getFullYear()}-${String(startDate.getMonth() + 1).padStart(2, '0')}-${String(startDate.getDate()).padStart(2, '0')}` : ''}
              onChange={(e) => {
                const [y, m, d] = e.target.value.split('-').map(Number);
                const newDate = new Date(startDate || new Date());
                newDate.setFullYear(y);
                newDate.setMonth(m - 1);
                newDate.setDate(d);
                onRangeChange?.(newDate, endDate || new Date());
              }}
              className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            />
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-400 uppercase">{t('to' as any) || 'To'}</span>
            <input 
              type="date"
              value={endDate ? `${endDate.getFullYear()}-${String(endDate.getMonth() + 1).padStart(2, '0')}-${String(endDate.getDate()).padStart(2, '0')}` : ''}
              onChange={(e) => {
                const [y, m, d] = e.target.value.split('-').map(Number);
                const newDate = new Date(endDate || new Date());
                newDate.setFullYear(y);
                newDate.setMonth(m - 1);
                newDate.setDate(d);
                onRangeChange?.(startDate || new Date(), newDate);
              }}
              className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            />
          </div>
        </div>
      )}

      {mode !== 'range' && (
        <>
          <input 
            type={mode === 'day' ? 'date' : mode === 'month' ? 'month' : 'number'}
            value={selectedDate ? (
              mode === 'day' ? 
              `${selectedDate.getFullYear()}-${String(selectedDate.getMonth() + 1).padStart(2, '0')}-${String(selectedDate.getDate()).padStart(2, '0')}` : 
              mode === 'month' ? 
              `${selectedDate.getFullYear()}-${String(selectedDate.getMonth() + 1).padStart(2, '0')}` : 
              selectedDate.getFullYear()
            ) : ''}
            onChange={(e) => {
              if (!selectedDate) return;
              if (mode === 'year') {
                const newDate = new Date(selectedDate);
                newDate.setFullYear(parseInt(e.target.value));
                onChange(newDate);
              } else if (mode === 'month') {
                const [y, m] = e.target.value.split('-').map(Number);
                const newDate = new Date(selectedDate);
                newDate.setFullYear(y);
                newDate.setMonth(m - 1);
                onChange(newDate);
              } else {
                const [y, m, d] = e.target.value.split('-').map(Number);
                const newDate = new Date(selectedDate);
                newDate.setFullYear(y);
                newDate.setMonth(m - 1);
                newDate.setDate(d);
                onChange(newDate);
              }
            }}
            className="sr-only"
            id="hidden-date-picker"
          />
          <label 
            htmlFor="hidden-date-picker"
            className="cursor-pointer text-xs font-bold text-indigo-600 hover:text-indigo-700 px-3"
          >
            {t('select_date' as any) || 'Select'}
          </label>
        </>
      )}
    </div>
  );
}
