
import React, { useState, useRef, useEffect } from 'react';
import { useLanguage } from './LanguageContext';
import { Globe, ChevronDown } from 'lucide-react';

export function LanguageSelector() {
  const { language, setLanguage, t } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const languages = [
    { code: 'so', name: 'Somali', flag: '🇸🇴' },
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'ar', name: 'Arabic', flag: '🇸🇦' },
    { code: 'tr', name: 'Turkish', flag: '🇹🇷' },
    { code: 'zh', name: 'Chinese', flag: '🇨🇳' },
  ];

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative" ref={dropdownRef}>
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-all text-sm font-medium ${
          isOpen 
            ? 'bg-surface-main border-accent-main ring-4 ring-accent-soft text-ink' 
            : 'bg-surface-main/50 hover:bg-surface-main border-border-main text-ink-secondary'
        }`}
      >
        <Globe size={16} className={isOpen ? 'text-accent-main' : 'text-ink-tertiary'} />
        <span className="hidden sm:inline">{languages.find(l => l.code === language)?.name}</span>
        <span className="sm:hidden">{languages.find(l => l.code === language)?.flag}</span>
        <ChevronDown size={14} className={`transition-transform duration-300 hidden sm:block ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      
      <div className={`absolute top-full right-0 mt-2 w-48 bg-surface-main rounded-xl shadow-2xl border border-border-main transition-all z-50 overflow-hidden transform origin-top-right ${
        isOpen 
          ? 'opacity-100 visible scale-100 translate-y-0' 
          : 'opacity-0 invisible scale-95 -translate-y-2'
      }`}>
        <div className="p-2 bg-bg-sec border-b border-border-main">
          <p className="text-[10px] font-bold text-ink-tertiary uppercase tracking-widest px-2">{t('language')}</p>
        </div>
        <div className="p-1">
          {languages.map((lang) => (
            <button
              key={lang.code}
              onClick={() => {
                setLanguage(lang.code as any);
                setIsOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${
                language === lang.code 
                  ? 'bg-accent-soft text-accent-main font-bold' 
                  : 'text-ink-secondary hover:bg-bg-sec'
              }`}
            >
              <span className="text-lg leading-none">{lang.flag}</span>
              <span>{lang.name}</span>
              {language === lang.code && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-accent-main" />}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
