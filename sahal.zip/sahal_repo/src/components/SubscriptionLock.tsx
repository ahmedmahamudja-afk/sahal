import React from 'react';
import { Lock, CreditCard, Phone, LogOut } from 'lucide-react';
import { motion } from 'motion/react';
import { useLanguage } from './LanguageContext';

interface SubscriptionLockProps {
  onLogout: () => void;
  reason: 'expired' | 'locked';
  managerPhone?: string;
}

export const SubscriptionLock: React.FC<SubscriptionLockProps> = ({ onLogout, reason, managerPhone }) => {
  const { t } = useLanguage();

  const handleWhatsAppContact = () => {
    if (!managerPhone) return;
    const cleanPhone = managerPhone.replace(/\D/g, '');
    const message = encodeURIComponent(`Salaan, waxaan u baahanahay caawimaad ku saabsan akoonkayga SAHAL. (ID: ${reason})`);
    window.open(`https://wa.me/${cleanPhone}?text=${message}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-white flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-white rounded-3xl shadow-2xl shadow-slate-200/50 p-8 text-center border border-slate-100"
      >
        <div className="w-20 h-20 bg-red-50 rounded-2xl flex items-center justify-center mx-auto mb-8">
          <Lock size={40} className="text-red-500" />
        </div>

        <h2 className="text-3xl font-display font-bold text-slate-900 mb-4">
          {reason === 'expired' ? t('subscription_expired_title') : t('account_locked_title')}
        </h2>
        
        <p className="text-slate-500 mb-8 leading-relaxed">
          {reason === 'expired' 
            ? t('subscription_expired_lock_desc')
            : t('account_locked_desc')}
        </p>

        <div className="space-y-4">
          {reason === 'expired' && (
            <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-xl border border-slate-100 text-left">
              <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center shadow-sm">
                <CreditCard size={20} className="text-indigo-600" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">{t('payment_method')}</p>
                <p className="text-sm font-medium text-slate-700">EVC Plus / SAHAL / Zaad</p>
              </div>
            </div>
          )}

          <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-xl border border-slate-100 text-left">
            <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center shadow-sm">
              <Phone size={20} className="text-emerald-600" />
            </div>
            <div className="flex-1">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">{t('manager_contact')}</p>
              <p className="text-sm font-medium text-slate-700">{managerPhone || '+252 61XXXXXXX'}</p>
            </div>
            {managerPhone && (
              <button 
                onClick={handleWhatsAppContact}
                className="bg-emerald-500 text-white p-2 rounded-lg hover:bg-emerald-600 transition-colors shadow-sm"
                title={t('contact_whatsapp')}
              >
                <Phone size={16} />
              </button>
            )}
          </div>
        </div>

        <div className="mt-10 flex flex-col gap-3">
          <button 
            onClick={() => window.location.reload()}
            className="w-full bg-indigo-600 text-white py-4 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
          >
            {t('check_again')}
          </button>
          
          <button 
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-2 text-slate-500 hover:text-slate-700 py-2 font-medium transition-colors"
          >
            <LogOut size={18} />
            {t('logout_system')}
          </button>
        </div>
      </motion.div>
    </div>
  );
};
