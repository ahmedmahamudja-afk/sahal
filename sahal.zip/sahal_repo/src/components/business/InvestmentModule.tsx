import React, { useState, useEffect } from 'react';
import { supabase } from '../../supabase';
import { Investment, UserProfile } from '../../types';
import { Plus, Search, Edit2, Trash2, Activity, TrendingUp, ChevronRight, DollarSign, PieChart, AlertCircle, X, RefreshCw } from 'lucide-react';
import { useLanguage } from '../LanguageContext';
import Modal from '../Modal';
import { motion, AnimatePresence } from 'motion/react';

export default function InvestmentModule({ user }: { user: UserProfile }) {
  const { t } = useLanguage();
  const [investments, setInvestments] = useState<Investment[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingInvestment, setEditingInvestment] = useState<Investment | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [formData, setFormData] = useState({
    name: '',
    amount: 0,
    expectedReturn: 0,
    status: 'active' as 'active' | 'completed' | 'failed',
    paymentMethod: ''
  });

  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  const openConfirm = (title: string, message: string, onConfirm: () => void) => {
    setConfirmModal({
      isOpen: true,
      title,
      message,
      onConfirm: () => {
        onConfirm();
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const requiredAccounts = ['Cash', 'EVC', 'eDahab', 'ZAAD', 'SAHAL', 'Merchant', 'Bank Account'];

  const fetchInvestments = async () => {
    if (!user.tenantId) return;
    setLoading(true);
    try {
      let invQuery = supabase
        .from('investments')
        .select('*')
        .eq('tenant_id', user.tenantId);
      if (user.branchId) invQuery = invQuery.eq('branch_id', user.branchId);
      const { data: investmentsData } = await invQuery;
      setInvestments(investmentsData || []);

      let accQuery = supabase
        .from('accounts')
        .select('*')
        .eq('tenant_id', user.tenantId);
      if (user.branchId) accQuery = accQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
      const { data: accData } = await accQuery;
      setAccounts(accData || []);
    } catch (error) {
      console.error("Error fetching investments:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInvestments();
  }, [user.tenantId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.tenantId) return;
    setError(null);
    try {
      const investmentData = {
        name: formData.name,
        amount: formData.amount,
        expected_return: formData.expectedReturn,
        status: formData.status,
        payment_method: formData.paymentMethod,
        tenant_id: user.tenantId,
        branch_id: user.branchId || null,
        created_at: editingInvestment ? editingInvestment.createdAt : new Date().toISOString()
      };

      let investmentId = editingInvestment?.id;

      if (editingInvestment) {
        const { error: updateError } = await supabase.from('investments').update(investmentData).eq('id', editingInvestment.id);
        if (updateError) throw updateError;
      } else {
        const { data: newInv, error: insertError } = await supabase.from('investments').insert(investmentData).select().single();
        if (insertError) throw insertError;
        investmentId = newInv.id;
      }

      // Handle Account Balance and Transaction
      if (investmentId && formData.amount > 0 && formData.paymentMethod) {
        const { data: existingTrans } = await supabase
          .from('account_transactions')
          .select('id, amount, from_account_id')
          .eq('tenant_id', user.tenantId)
          .eq('branch_id', user.branchId || null)
          .eq('reference_id', investmentId)
          .eq('type', 'expense') // Investment is an outflow of cash
          .maybeSingle();

        if (!existingTrans && !editingInvestment) {
          // Find or create account
          let accQuery = supabase
            .from('accounts')
            .select('id, balance')
            .eq('tenant_id', user.tenantId)
            .eq('name', formData.paymentMethod);
          
          if (user.branchId) accQuery = accQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);

          let { data: accData } = await accQuery.maybeSingle();
            
          if (!accData) {
            const { data: newAcc, error: accCreateError } = await supabase
              .from('accounts')
              .insert({ 
                name: formData.paymentMethod, 
                balance: -formData.amount, 
                tenant_id: user.tenantId,
                branch_id: user.branchId || null
              })
              .select()
              .single();
            
            if (accCreateError) throw accCreateError;
            accData = newAcc;
          } else {
            const newBalance = (accData.balance || 0) - formData.amount;
            await supabase.from('accounts').update({ balance: newBalance }).eq('id', accData.id);
          }
          
          if (accData) {
            await supabase.from('account_transactions').insert({
              from_account_id: accData.id,
              type: 'expense',
              amount: formData.amount,
              description: `Investment: ${formData.name}`,
              tenant_id: user.tenantId,
              branch_id: user.branchId || null,
              reference_id: investmentId,
              created_at: new Date().toISOString()
            });
          }
        } else if (existingTrans && existingTrans.amount !== formData.amount) {
          // Update existing transaction and adjust account balance
          const diff = formData.amount - existingTrans.amount;
          
          await supabase.from('account_transactions').update({
            amount: formData.amount,
            description: `Investment: ${formData.name} (Updated)`
          }).eq('id', existingTrans.id);
          
          const { data: accData } = await supabase
            .from('accounts')
            .select('id, balance')
            .eq('id', existingTrans.from_account_id)
            .single();
            
          if (accData) {
            const newBalance = (accData.balance || 0) - diff;
            await supabase.from('accounts').update({ balance: newBalance }).eq('id', accData.id);
          }
        }
      }

      setIsModalOpen(false);
      setEditingInvestment(null);
      setFormData({ name: '', amount: 0, expectedReturn: 0, status: 'active', paymentMethod: '' });
      fetchInvestments();
    } catch (error: any) {
      console.error("Error saving investment:", error);
      setError(error.message || 'Error saving investment');
    }
  };

  const handleDelete = async (id: string) => {
    if (!user.tenantId) return;
    openConfirm(t('delete'), t('delete_confirm'), async () => {
      try {
        const { error } = await supabase.from('investments').delete().eq('id', id);
        if (error) throw error;
        fetchInvestments();
      } catch (error) {
        console.error("Error deleting investment:", error);
      }
    });
  };

  const openEdit = (i: Investment) => {
    setEditingInvestment(i);
    setFormData({
      name: i.name || '',
      amount: i.amount || 0,
      expectedReturn: i.expectedReturn || 0,
      status: i.status || 'active',
      paymentMethod: i.paymentMethod || ''
    });
    setIsModalOpen(true);
  };

  const totalInvested = investments.reduce((sum, i) => sum + (i.amount || 0), 0);
  const activeInvestments = investments.filter(i => i.status === 'active').length;
  const completedInvestments = investments.filter(i => i.status === 'completed').length;

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-3xl font-display font-bold text-slate-900">{t('investment')}</h2>
          <p className="text-slate-500">{t('manage_investments_desc' as any) || 'Track your business investments and returns.'}</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={fetchInvestments}
            disabled={loading}
            className={`p-3 bg-white text-slate-600 rounded-xl font-bold text-sm border border-slate-200 hover:bg-slate-50 transition-all flex items-center gap-2 ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
            title={t('refresh')}
          >
            <RefreshCw size={18} className={loading ? 'animate-spin' : ''} />
          </button>
          <button
            onClick={() => {
              setEditingInvestment(null);
              setFormData({ name: '', amount: 0, expectedReturn: 0, status: 'active' });
              setIsModalOpen(true);
            }}
            className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
          >
            <Plus size={20} />
            <span>{t('add_investment')}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="sahal-card p-6 bg-indigo-600 text-white">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-white/20 rounded-xl"><DollarSign size={24} /></div>
            <Activity size={20} className="text-indigo-200" />
          </div>
          <p className="text-indigo-100 text-xs font-bold uppercase tracking-wider mb-1">{t('total_invested' as any) || 'Total Invested'}</p>
          <h3 className="text-3xl font-display font-bold">${totalInvested.toLocaleString()}</h3>
        </div>
        <div className="sahal-card p-6">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl"><PieChart size={24} /></div>
            <span className="text-indigo-600 font-bold text-sm">{activeInvestments} {t('active_status')}</span>
          </div>
          <p className="text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">{t('active_investments' as any) || 'Active Investments'}</p>
          <h3 className="text-3xl font-display font-bold text-slate-900">{activeInvestments}</h3>
        </div>
        <div className="sahal-card p-6">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl"><TrendingUp size={24} /></div>
            <span className="text-emerald-600 font-bold text-sm">{completedInvestments} {t('completed_status')}</span>
          </div>
          <p className="text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">{t('completed_investments' as any) || 'Completed'}</p>
          <h3 className="text-3xl font-display font-bold text-slate-900">{completedInvestments}</h3>
        </div>
      </div>

      <div className="sahal-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-100">
                <th className="px-8 py-5 text-[10px] font-bold uppercase tracking-widest text-slate-400">{t('investment_name')}</th>
                <th className="px-8 py-5 text-[10px] font-bold uppercase tracking-widest text-slate-400">{t('amount')}</th>
                <th className="px-8 py-5 text-[10px] font-bold uppercase tracking-widest text-slate-400">{t('expected_return')}</th>
                <th className="px-8 py-5 text-[10px] font-bold uppercase tracking-widest text-slate-400">{t('status')}</th>
                <th className="px-8 py-5 text-[10px] font-bold uppercase tracking-widest text-slate-400 text-right">{t('actions')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {investments.map(i => (
                <tr key={i.id} className="group hover:bg-slate-50/50 transition-colors">
                  <td className="px-8 py-5">
                    <p className="font-bold text-slate-900">{i.name}</p>
                    <p className="text-[10px] text-slate-400 font-medium">{new Date(i.createdAt).toLocaleDateString()}</p>
                  </td>
                  <td className="px-8 py-5">
                    <p className="font-bold text-slate-900">${i.amount.toLocaleString()}</p>
                  </td>
                  <td className="px-8 py-5">
                    <p className="font-bold text-emerald-600">${(i.expectedReturn || 0).toLocaleString()}</p>
                  </td>
                  <td className="px-8 py-5">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest border ${
                      i.status === 'active' ? 'bg-indigo-50 text-indigo-600 border-indigo-100' :
                      i.status === 'completed' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' :
                      'bg-rose-50 text-rose-600 border-rose-100'
                    }`}>
                      {t(`${i.status}_status` as any)}
                    </span>
                  </td>
                  <td className="px-8 py-5 text-right">
                    <div className="flex justify-end gap-2 transition-opacity">
                      <button onClick={() => openEdit(i)} className="p-2 hover:bg-indigo-50 text-indigo-600 rounded-lg transition-colors">
                        <Edit2 size={16} />
                      </button>
                      <button onClick={() => handleDelete(i.id)} className="p-2 hover:bg-rose-50 text-rose-600 rounded-lg transition-colors">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {investments.length === 0 && (
            <div className="p-20 text-center">
              <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Activity size={32} className="text-slate-200" />
              </div>
              <p className="text-slate-400 font-medium italic">{t('no_data')}</p>
            </div>
          )}
        </div>
      </div>

      <Modal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        title={editingInvestment ? t('edit' as any) || 'Edit' : t('add_investment')}
        contentClassName="max-w-md"
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('investment_name')}</label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={e => setFormData({ ...formData, name: e.target.value })}
              className="sahal-input"
              placeholder={t('investment_name')}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('amount')}</label>
              <input
                type="number"
                required
                min="0"
                value={formData.amount}
                onChange={e => setFormData({ ...formData, amount: parseFloat(e.target.value) || 0 })}
                className="sahal-input"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('expected_return')}</label>
              <input
                type="number"
                required
                min="0"
                value={formData.expectedReturn}
                onChange={e => setFormData({ ...formData, expectedReturn: parseFloat(e.target.value) || 0 })}
                className="sahal-input"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('status')}</label>
            <select
              value={formData.status}
              onChange={e => setFormData({ ...formData, status: e.target.value as any })}
              className="sahal-input"
            >
              <option value="active">{t('active_status')}</option>
              <option value="completed">{t('completed_status')}</option>
              <option value="failed">{t('failed_status')}</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('payment_method' as any) || 'Payment Method'}</label>
            <select
              required
              value={formData.paymentMethod}
              onChange={e => setFormData({ ...formData, paymentMethod: e.target.value })}
              className="sahal-input"
            >
              <option value="" disabled>{t('select_account' as any) || 'Select Account'}</option>
              {accounts.sort((a, b) => a.name.localeCompare(b.name)).map(acc => (
                <option key={acc.id} value={acc.name}>
                  {acc.name} (${(acc.balance || 0).toLocaleString()})
                </option>
              ))}
            </select>
          </div>
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="flex-1 px-6 py-4 bg-slate-100 text-slate-600 rounded-2xl font-bold hover:bg-slate-200 transition-all"
            >
              {t('cancel')}
            </button>
            <button
              type="submit"
              className="flex-1 px-6 py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
            >
              {t('save')}
            </button>
          </div>
        </form>
      </Modal>
      
      {/* Confirm Modal */}
      <AnimatePresence>
        {confirmModal.isOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden p-6 space-y-6"
            >
              <div className="flex items-center gap-4 p-4 bg-rose-50 rounded-2xl text-rose-600">
                <Trash2 size={24} />
                <p className="text-sm font-medium">{confirmModal.message}</p>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
                  className="flex-1 py-3 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 transition-all"
                >
                  {t('cancel')}
                </button>
                <button
                  onClick={confirmModal.onConfirm}
                  className="flex-1 py-3 bg-rose-600 text-white rounded-xl font-bold hover:bg-rose-700 transition-all shadow-lg shadow-rose-100"
                >
                  {t('confirm')}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
