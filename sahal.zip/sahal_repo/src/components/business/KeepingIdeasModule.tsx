import React, { useState, useEffect } from 'react';
import { supabase } from '../../supabase';
import { KeepingIdea, UserProfile } from '../../types';
import { Plus, Search, Edit2, Trash2, Lightbulb, ChevronRight, Sparkles, RefreshCw } from 'lucide-react';
import { useLanguage } from '../LanguageContext';
import Modal from '../Modal';
import { motion, AnimatePresence } from 'motion/react';

export default function KeepingIdeasModule({ user }: { user: UserProfile }) {
  const { t } = useLanguage();
  const [ideas, setIdeas] = useState<KeepingIdea[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingIdea, setEditingIdea] = useState<KeepingIdea | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    description: ''
  });

  const fetchIdeas = async () => {
    if (!user.tenantId) return;
    setLoading(true);
    try {
      let query = supabase
        .from('keeping_ideas')
        .select('*')
        .eq('tenant_id', user.tenantId);
      
      if (user.branchId) {
        query = query.eq('branch_id', user.branchId);
      }
      
      const { data: ideasData } = await query;
      setIdeas(ideasData || []);
    } catch (error) {
      console.error("Error fetching ideas:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchIdeas();
  }, [user.tenantId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.tenantId) return;
    try {
      const ideaData = {
        title: formData.title,
        description: formData.description,
        tenant_id: user.tenantId,
        branch_id: user.branchId || null,
        created_at: editingIdea ? editingIdea.createdAt : new Date().toISOString()
      };

      if (editingIdea) {
        await supabase.from('keeping_ideas').update(ideaData).eq('id', editingIdea.id);
      } else {
        await supabase.from('keeping_ideas').insert(ideaData);
      }
      setIsModalOpen(false);
      setEditingIdea(null);
      setFormData({ title: '', description: '' });
      fetchIdeas();
    } catch (error) {
      console.error("Error saving idea:", error);
    }
  };

  const handleDelete = async (id: string) => {
    if (!user.tenantId || !window.confirm(t('delete_confirm'))) return;
    try {
      await supabase.from('keeping_ideas').delete().eq('id', id);
      fetchIdeas();
    } catch (error) {
      console.error("Error deleting idea:", error);
    }
  };

  const openEdit = (idea: KeepingIdea) => {
    setEditingIdea(idea);
    setFormData({
      title: idea.title || '',
      description: idea.description || ''
    });
    setIsModalOpen(true);
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-3xl font-display font-bold text-slate-900">{t('keeping_ideas')}</h2>
          <p className="text-slate-500">{t('manage_ideas_desc' as any) || 'Store and brainstorm your business ideas.'}</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={fetchIdeas}
            disabled={loading}
            className={`p-3 bg-white text-slate-600 rounded-xl font-bold text-sm border border-slate-200 hover:bg-slate-50 transition-all flex items-center gap-2 ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
            title={t('refresh')}
          >
            <RefreshCw size={18} className={loading ? 'animate-spin' : ''} />
          </button>
          <button
            onClick={() => {
              setEditingIdea(null);
              setFormData({ title: '', description: '' });
              setIsModalOpen(true);
            }}
            className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
          >
            <Plus size={20} />
            <span>{t('add_idea')}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {ideas.map(idea => (
          <motion.div
            layout
            key={idea.id}
            className="sahal-card p-8 group hover:border-indigo-200 transition-all flex flex-col h-full relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-50 rounded-full -translate-y-1/2 translate-x-1/2 group-hover:scale-110 transition-transform duration-500 opacity-50" />
            
            <div className="flex justify-between items-start mb-6 relative z-10">
              <div className="p-3 bg-indigo-600 text-white rounded-2xl shadow-lg shadow-indigo-100">
                <Lightbulb size={24} />
              </div>
              <div className="flex gap-2 transition-opacity">
                <button onClick={() => openEdit(idea)} className="p-2 hover:bg-indigo-50 text-indigo-600 rounded-lg transition-colors">
                  <Edit2 size={16} />
                </button>
                <button onClick={() => handleDelete(idea.id)} className="p-2 hover:bg-rose-50 text-rose-600 rounded-lg transition-colors">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
            
            <h4 className="text-xl font-display font-bold text-slate-900 mb-3 relative z-10">{idea.title}</h4>
            <p className="text-sm text-slate-500 line-clamp-6 mb-8 flex-1 relative z-10 leading-relaxed">{idea.description}</p>
            
            <div className="flex items-center gap-2 text-[10px] font-bold text-indigo-600 uppercase tracking-widest relative z-10">
              <Sparkles size={12} />
              <span>{t('new_idea' as any) || 'New Idea'}</span>
            </div>
          </motion.div>
        ))}
        {ideas.length === 0 && (
          <div className="col-span-full p-20 text-center sahal-card">
            <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Lightbulb size={32} className="text-slate-200" />
            </div>
            <p className="text-slate-400 font-medium italic">{t('no_data')}</p>
          </div>
        )}
      </div>

      <Modal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        title={editingIdea ? t('edit' as any) || 'Edit' : t('add_idea')}
        contentClassName="max-w-lg"
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('idea_title')}</label>
            <input
              type="text"
              required
              value={formData.title}
              onChange={e => setFormData({ ...formData, title: e.target.value })}
              className="sahal-input"
              placeholder={t('idea_title')}
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('idea_desc')}</label>
            <textarea
              required
              rows={6}
              value={formData.description}
              onChange={e => setFormData({ ...formData, description: e.target.value })}
              className="sahal-input resize-none"
              placeholder={t('idea_desc')}
            />
          </div>
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="flex-1 px-6 py-4 bg-slate-100 text-slate-600 rounded-2xl font-bold hover:bg-slate-200 transition-all"
            >
              {t('cancel')}
            </button>
            <button
              type="submit"
              className="flex-1 px-6 py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
            >
              {t('save')}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
