import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '../../supabase';
import { StaffMember, UserProfile, Tenant, Branch } from '../../types';
import { useLanguage } from '../LanguageContext';
import { UserPlus, Edit2, Trash2, Shield, Eye, EyeOff, Users, Briefcase, DollarSign, Phone, Calendar, Mail, MapPin, AlertCircle, RefreshCw, Building } from 'lucide-react';
import Modal from '../Modal';
import { motion, AnimatePresence } from 'motion/react';
import { is9DigitNumber, checkUsernameExists, USERNAME_FORMAT_ERROR, USERNAME_EXISTS_ERROR } from '../../lib/validation';

interface StaffModuleProps {
  user: UserProfile;
  tenant: Tenant;
}

export default function StaffModule({ user, tenant }: StaffModuleProps) {
  const { t } = useLanguage();
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [selectedBranchId, setSelectedBranchId] = useState<string>(user.branchId || '');
  const [loading, setLoading] = useState(true);
  
  // Modal & Form State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const modalContentRef = useRef<HTMLDivElement>(null);
  
  const [formData, setFormData] = useState({
    username: '', 
    password: '', 
    displayName: '', 
    photoURL: '', 
    roles: [] as string[],
    phone: '',
    position: '',
    salary: '',
    address: '',
    email: '',
    status: 'active',
    hireDate: new Date().toISOString().split('T')[0],
    createLogin: false,
    branchId: ''
  });

  const fetchData = async () => {
    if (!user.tenantId) return;
    try {
      setLoading(true);
      const activeBranchId = selectedBranchId || user.branchId;
      
      let staffQuery = supabase.from('staff').select('*').eq('tenant_id', user.tenantId);
      if (activeBranchId) staffQuery = staffQuery.eq('branch_id', activeBranchId);
      staffQuery = staffQuery.order('created_at', { ascending: false });

      let branchQuery = supabase.from('branches').select('*').eq('tenant_id', user.tenantId);

      const [staffRes, branchRes] = await Promise.all([
        staffQuery,
        tenant?.isMultiBranch ? branchQuery : Promise.resolve({ data: [] })
      ]);

      if (staffRes.error) throw staffRes.error;
      
      if (staffRes.data) {
        setStaff(staffRes.data.map(s => ({
          id: s.id,
          username: s.username,
          password: s.password,
          displayName: s.display_name,
          phone: s.phone,
          photoURL: s.photo_url,
          roles: s.roles || [],
          tenantId: s.tenant_id,
          branchId: s.branch_id,
          isLocked: s.is_locked,
          createdAt: s.created_at,
          position: s.position,
          salary: s.salary,
          address: s.address,
          email: s.email,
          status: s.status,
          hireDate: s.hire_date
        })));
      }

      if (branchRes.data) {
        setBranches(branchRes.data);
      }
    } catch (err) {
      console.error('Error fetching data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [user.tenantId, tenant?.isMultiBranch, selectedBranchId]);

  useEffect(() => {
    if (error && modalContentRef.current) {
      modalContentRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [error]);

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    console.log("handleSubmit triggered", formData);
    setError(null);
    
    if (!formData.displayName) {
      setError("Fadlan geli magaca shaqaalaha (Full Name is required)");
      return;
    }

    if (formData.createLogin) {
      const trimmedUsername = formData.username.trim();
      if (!trimmedUsername) {
        setError("Fadlan geli username-ka (Username is required for login)");
        return;
      }
      
      // 9-digit validation
      if (!is9DigitNumber(trimmedUsername)) {
        setError(USERNAME_FORMAT_ERROR);
        return;
      }

      // Check for uniqueness if username changed or new entry
      const currentStaff = staff.find(s => s.id === editingId);
      if (!editingId || currentStaff?.username !== trimmedUsername) {
        const exists = await checkUsernameExists(trimmedUsername);
        if (exists) {
          setError(USERNAME_EXISTS_ERROR);
          return;
        }
      }

      if (!formData.password && !editingId) {
        setError("Fadlan geli password-ka (Password is required for login)");
        return;
      }
    }

    console.log("Validation passed, setting submitting to true");
    setSubmitting(true);
    try {
      let finalPhotoURL = formData.photoURL;

      if (selectedFile) {
        setUploadingPhoto(true);
        console.log("Uploading photo...");
        const fileExt = selectedFile.name.split('.').pop();
        const fileName = `${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`;
        const filePath = `tenants/${user.tenantId}/${fileName}`;
        
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('staff-photos')
          .upload(filePath, selectedFile);
          
        if (uploadError) throw uploadError;
        
        const { data: urlData } = supabase.storage.from('staff-photos').getPublicUrl(uploadData.path);
        finalPhotoURL = urlData.publicUrl;
        console.log("Photo uploaded:", finalPhotoURL);
        setUploadingPhoto(false);
      }

      const dbPayload: any = {
        display_name: formData.displayName,
        username: formData.createLogin ? formData.username : null,
        photo_url: finalPhotoURL,
        roles: formData.createLogin ? formData.roles : [],
        phone: formData.phone,
        tenant_id: user.tenantId,
        branch_id: tenant?.isMultiBranch && formData.branchId ? formData.branchId : null,
        position: formData.position,
        salary: formData.salary ? parseFloat(formData.salary) : null,
        address: formData.address,
        email: formData.email,
        status: formData.status,
        hire_date: formData.hireDate || null
      };

      if (formData.createLogin && formData.password) {
        dbPayload.password = formData.password;
      }

      if (user.branchId) {
        dbPayload.branch_id = user.branchId;
      }

      if (editingId) {
        console.log("Updating existing staff:", editingId, dbPayload);
        const { error: updateError } = await supabase
          .from('staff')
          .update(dbPayload)
          .eq('id', editingId);
        if (updateError) throw updateError;
      } else {
        console.log("Inserting new staff:", dbPayload);
        const { error: insertError } = await supabase
          .from('staff')
          .insert([{
            ...dbPayload,
            created_at: new Date().toISOString()
          }]);
        if (insertError) throw insertError;
      }

      console.log("Successfully saved staff");
      setIsModalOpen(false);
      resetForm();
      fetchData();
    } catch (err: any) {
      console.error("Error saving staff:", err);
      setError("Cilad ayaa dhacday: " + (err.message || JSON.stringify(err)));
    } finally {
      console.log("Resetting submitting state");
      setSubmitting(false);
      setUploadingPhoto(false);
    }
  };

  const resetForm = () => {
    setEditingId(null);
    setSelectedFile(null);
    setFormData({ 
      username: '', 
      password: '', 
      displayName: '', 
      photoURL: '', 
      roles: [],
      phone: '',
      position: '',
      salary: '',
      address: '',
      email: '',
      status: 'active',
      hireDate: new Date().toISOString().split('T')[0],
      createLogin: false,
      branchId: user.branchId || ''
    });
    setShowPassword(false);
    setError(null);
  };

  const handleEdit = (s: StaffMember) => {
    setEditingId(s.id);
    setSelectedFile(null);
    setFormData({
      username: s.username || '',
      password: '', 
      displayName: s.displayName || '',
      photoURL: s.photoURL || '',
      roles: s.roles || [],
      phone: s.phone || '',
      position: s.position || '',
      salary: s.salary?.toString() || '',
      address: s.address || '',
      email: s.email || '',
      status: s.status || 'active',
      hireDate: s.hireDate ? new Date(s.hireDate).toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
      createLogin: !!s.username,
      branchId: s.branchId || ''
    });
    setIsModalOpen(true);
  };

  const handleDelete = async (id: string) => {
    setDeleteId(id);
  };

  const confirmDelete = async () => {
    if (!deleteId) return;
    try {
      setLoading(true);
      const { error } = await supabase.from('staff').delete().eq('id', deleteId);
      if (error) throw error;
      setDeleteId(null);
      fetchData();
    } catch (error: any) {
      console.error("Error deleting staff:", error);
      alert("Cilad ayaa dhacday: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleToggleLock = async (s: StaffMember) => {
    try {
      const { error } = await supabase
        .from('staff')
        .update({ is_locked: !s.isLocked })
        .eq('id', s.id);
      if (error) throw error;
      fetchData();
    } catch (error: any) {
      console.error("Error toggling lock:", error);
      alert("Cilad ayaa dhacday: " + error.message);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-display font-bold text-slate-900">{t('staff_management')}</h2>
          <p className="text-slate-500 mt-1">{t('staff_desc')}</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={fetchData}
            disabled={loading}
            className={`p-3 bg-white text-slate-600 rounded-xl font-bold text-sm border border-slate-200 hover:bg-slate-50 transition-all flex items-center gap-2 ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
            title={t('refresh')}
          >
            <RefreshCw size={18} className={loading ? 'animate-spin' : ''} />
          </button>
          <button 
            onClick={() => {
              resetForm();
              setIsModalOpen(true);
            }}
            className="bg-slate-900 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-slate-800 transition-all shadow-lg shadow-slate-200"
          >
            <UserPlus size={20} />
            {t('add_staff')}
          </button>
        </div>
      </div>

      <Modal 
        isOpen={isModalOpen} 
        onClose={() => {
          setIsModalOpen(false);
          resetForm();
        }} 
        title={editingId ? t('edit_staff') : t('add_staff')}
      >
        <form onSubmit={handleSubmit} noValidate className="space-y-12">
          <div ref={modalContentRef} className="scroll-mt-20">
            {error && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-rose-50 text-rose-600 p-6 rounded-2xl text-sm font-bold border border-rose-100 mb-8 flex items-center gap-3"
              >
                <AlertCircle size={20} />
                {error}
              </motion.div>
            )}
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {/* Left Column: Personal & Professional */}
              <div className="space-y-10">
                {/* Personal Info Section */}
                <div className="space-y-6">
                  <div className="flex items-center gap-3 pb-2 border-b border-slate-100">
                    <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
                      <Users size={18} />
                    </div>
                    <h4 className="text-sm font-black text-slate-900 uppercase tracking-widest">
                      {t('personal_info')}
                    </h4>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">{t('full_name')} *</label>
                      <input 
                        type="text"
                        value={formData.displayName}
                        onChange={(e) => setFormData({...formData, displayName: e.target.value})}
                        className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all font-bold text-slate-700"
                        placeholder={t('full_name_placeholder')}
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">{t('phone')}</label>
                        <div className="relative">
                          <Phone size={16} className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" />
                          <input 
                            type="text"
                            value={formData.phone}
                            onChange={(e) => setFormData({...formData, phone: e.target.value})}
                            className="w-full pl-12 pr-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all font-bold text-slate-700"
                            placeholder="61xxxxxxx"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">Email</label>
                        <div className="relative">
                          <Mail size={16} className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" />
                          <input 
                            type="email"
                            value={formData.email}
                            onChange={(e) => setFormData({...formData, email: e.target.value})}
                            className="w-full pl-12 pr-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all font-bold text-slate-700"
                            placeholder="email@tusaale.com"
                          />
                        </div>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">{t('address')}</label>
                      <div className="relative">
                        <MapPin size={16} className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input 
                          type="text"
                          value={formData.address}
                          onChange={(e) => setFormData({...formData, address: e.target.value})}
                          className="w-full pl-12 pr-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all font-bold text-slate-700"
                          placeholder="Hodan, Mogadishu"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4 px-1">{t('staff_photo')}</label>
                      <div className="flex items-center gap-6 p-6 bg-slate-50 rounded-[2rem] border border-dashed border-slate-200">
                        <div className="w-20 h-20 rounded-[1.5rem] bg-white overflow-hidden border-4 border-white shadow-xl shadow-slate-200/50 flex-shrink-0">
                          {(formData.photoURL || selectedFile) ? (
                            <img 
                              src={selectedFile ? URL.createObjectURL(selectedFile) : formData.photoURL} 
                              alt="Preview" 
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-slate-200 bg-slate-50">
                              <Users size={32} />
                            </div>
                          )}
                        </div>
                        <div className="flex-1 space-y-2">
                          <input 
                            type="file"
                            id="staff_photo_upload"
                            accept="image/*"
                            onChange={(e) => {
                              if (e.target.files && e.target.files[0]) {
                                setSelectedFile(e.target.files[0]);
                              }
                            }}
                            className="hidden"
                          />
                          <label 
                            htmlFor="staff_photo_upload"
                            className="inline-flex px-5 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-black text-slate-600 uppercase tracking-widest cursor-pointer hover:bg-slate-50 transition-colors shadow-sm"
                          >
                            {t('choose_photo')}
                          </label>
                          <p className="text-[10px] text-slate-400 font-medium">PNG, JPG qiyaas ahaan 1MB</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Professional Info Section */}
                <div className="space-y-6">
                  <div className="flex items-center gap-3 pb-2 border-b border-slate-100">
                    <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
                      <Briefcase size={18} />
                    </div>
                    <h4 className="text-sm font-black text-slate-900 uppercase tracking-widest">
                      {t('professional_info')}
                    </h4>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="col-span-2 sm:col-span-1">
                      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">{t('position')}</label>
                      <input 
                        type="text"
                        value={formData.position}
                        onChange={(e) => setFormData({...formData, position: e.target.value})}
                        className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all font-bold text-slate-700"
                        placeholder="Manager, Sales"
                      />
                    </div>
                    <div className="col-span-2 sm:col-span-1">
                      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">{t('salary')} ($)</label>
                      <div className="relative">
                        <DollarSign size={16} className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input 
                          type="number"
                          step="0.01"
                          value={formData.salary}
                          onChange={(e) => setFormData({...formData, salary: e.target.value})}
                          className="w-full pl-12 pr-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all font-bold text-slate-700"
                          placeholder="0.00"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">{t('hire_date')}</label>
                      <input 
                        type="date"
                        value={formData.hireDate}
                        onChange={(e) => setFormData({...formData, hireDate: e.target.value})}
                        className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all font-bold text-slate-700 uppercase"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">{t('staff_status')}</label>
                      <select 
                        value={formData.status}
                        onChange={(e) => setFormData({...formData, status: e.target.value as any})}
                        className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all font-bold text-slate-700 appearance-none bg-[url('data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' fill=\'none\' viewBox=\'0 0 24 24\' stroke=\'%2394A3B8\'%3E%3Cpath stroke-linecap=\'round\' stroke-linejoin=\'round\' stroke-width=\'2\' d=\'M19 9l-7 7-7-7\'/%3E%3C/svg%3E')] bg-[length:1.25rem] bg-[right_1.5rem_center] bg-no-repeat"
                      >
                        <option value="active">{t('active')}</option>
                        <option value="inactive">{t('inactive')}</option>
                        <option value="on_leave">{t('on_leave')}</option>
                      </select>
                    </div>
                      {tenant?.isMultiBranch && branches.length > 0 && (
                        <div>
                          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">{t('branch')} *</label>
                          <select 
                            value={formData.branchId}
                            onChange={(e) => setFormData({...formData, branchId: e.target.value})}
                            disabled={!!user.branchId}
                            className={`w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all font-bold text-slate-700 appearance-none bg-[url('data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' fill=\'none\' viewBox=\'0 0 24 24\' stroke=\'%2394A3B8\'%3E%3Cpath stroke-linecap=\'round\' stroke-linejoin=\'round\' stroke-width=\'2\' d=\'M19 9l-7 7-7-7\'/%3E%3C/svg%3E')] bg-[length:1.25rem] bg-[right_1.5rem_center] bg-no-repeat ${user.branchId ? 'opacity-60 cursor-not-allowed' : ''}`}
                          >
                            <option value="">{t('all_branches')}</option>
                            {branches.map(b => (
                              <option key={b.id} value={b.id}>{b.name}</option>
                            ))}
                          </select>
                        </div>
                      )}
                  </div>
                </div>
              </div>

              {/* Right Column: System Access */}
              <div className="space-y-10">
                <div className="space-y-6">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
                        <Shield size={18} />
                      </div>
                      <h4 className="text-sm font-black text-slate-900 uppercase tracking-widest">
                        {t('system_access')}
                      </h4>
                    </div>
                    <label className="flex items-center gap-3 cursor-pointer group">
                      <input 
                        type="checkbox"
                        checked={formData.createLogin}
                        onChange={(e) => setFormData({...formData, createLogin: e.target.checked})}
                        className="w-5 h-5 rounded-lg border-2 border-slate-200 text-indigo-600 focus:ring-indigo-500 transition-all cursor-pointer"
                      />
                      <span className="text-xs font-black text-slate-500 uppercase tracking-widest group-hover:text-indigo-600 transition-colors">{t('create_login_toggle')}</span>
                    </label>
                  </div>

                  <AnimatePresence>
                    {formData.createLogin && (
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        className="space-y-8"
                      >
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">{t('username')} *</label>
                            <input 
                              type="text"
                              inputMode="numeric"
                              pattern="\d{9}"
                              maxLength={9}
                              value={formData.username}
                              onChange={(e) => setFormData({...formData, username: e.target.value.replace(/\D/g, '')})}
                              className="w-full px-6 py-4 bg-indigo-50/30 border border-indigo-100 rounded-2xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all font-mono font-bold text-indigo-900"
                              placeholder="615123456"
                            />
                            <p className="text-[10px] text-indigo-400 mt-2 font-medium px-1">Username-ka waa inuu ahaadaa 9 lambar</p>
                          </div>
                          <div>
                            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">
                              {t('password')} {editingId ? '(' + t('optional') + ')' : '*'}
                            </label>
                            <div className="relative">
                              <input 
                                type={showPassword ? "text" : "password"}
                                value={formData.password}
                                onChange={(e) => setFormData({...formData, password: e.target.value})}
                                className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all font-bold text-slate-700"
                                placeholder={editingId ? '••••••••' : t('password_placeholder')}
                              />
                              <button
                                type="button"
                                onClick={() => setShowPassword(!showPassword)}
                                className="absolute inset-y-0 right-0 pr-5 flex items-center text-slate-300 hover:text-slate-500 transition-colors"
                              >
                                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                              </button>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-4">
                          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-1">{t('permissions')}</label>
                          <div className="grid grid-cols-1 gap-2.5 max-h-[400px] overflow-y-auto pr-2 sahal-scrollbar">
                            {/* Finance Management */}
                            <label className="flex items-center gap-4 p-4 bg-emerald-50/50 rounded-2xl border border-emerald-100/50 cursor-pointer hover:bg-emerald-50 transition-all group">
                              <input 
                                type="checkbox"
                                checked={(formData.roles || []).includes('finance')}
                                onChange={(e) => {
                                  const currentRoles = formData.roles || [];
                                  const roles = e.target.checked 
                                    ? [...currentRoles, 'finance']
                                    : currentRoles.filter(r => r !== 'finance');
                                  setFormData({...formData, roles});
                                }}
                                className="w-5 h-5 rounded-lg border-2 border-emerald-200 text-emerald-600 focus:ring-emerald-500 transition-all cursor-pointer"
                              />
                              <div className="flex-1">
                                <p className="text-sm font-black text-emerald-900 leading-none mb-1">{t('finance_management' as any) || 'Finance'}</p>
                                <p className="text-[10px] text-emerald-600/60 font-bold uppercase tracking-wider">{t('full_access_to_accounts')}</p>
                              </div>
                            </label>

                            {/* Staff Management */}
                            <label className="flex items-center gap-4 p-4 bg-indigo-50/50 rounded-2xl border border-indigo-100/50 cursor-pointer hover:bg-indigo-50 transition-all group">
                              <input 
                                type="checkbox"
                                checked={(formData.roles || []).includes('users')}
                                onChange={(e) => {
                                  const currentRoles = formData.roles || [];
                                  const roles = e.target.checked 
                                    ? [...currentRoles, 'users']
                                    : currentRoles.filter(r => r !== 'users');
                                  setFormData({...formData, roles});
                                }}
                                className="w-5 h-5 rounded-lg border-2 border-indigo-200 text-indigo-600 focus:ring-indigo-500 transition-all cursor-pointer"
                              />
                              <div className="flex-1">
                                <p className="text-sm font-black text-indigo-900 leading-none mb-1">{t('staff_management')}</p>
                                <p className="text-[10px] text-indigo-600/60 font-bold uppercase tracking-wider">{t('manage_staff_accounts')}</p>
                              </div>
                            </label>

                            {/* Tenant Modules */}
                            {Object.entries(tenant?.modules || {}).filter(([key, val]) => val && !['hospital', 'finance'].includes(key)).map(([key]) => (
                              <React.Fragment key={key}>
                                <label className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-200/50 cursor-pointer hover:bg-slate-100 transition-all group">
                                  <input 
                                    type="checkbox"
                                    checked={(formData.roles || []).includes(key)}
                                    onChange={(e) => {
                                      const currentRoles = formData.roles || [];
                                      const roles = e.target.checked 
                                        ? [...currentRoles, key]
                                        : currentRoles.filter(r => r !== key);
                                      setFormData({...formData, roles});
                                    }}
                                    className="w-5 h-5 rounded-lg border-2 border-slate-300 text-indigo-600 focus:ring-indigo-500 transition-all cursor-pointer"
                                  />
                                  <div className="flex-1">
                                    <p className="text-sm font-black text-slate-800 leading-none mb-1 capitalize">{t(`role_${key}` as any)}</p>
                                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{t('access_to_module')}</p>
                                  </div>
                                </label>
                                
                                {key === 'utility' && (
                                  <>
                                    {['utility_water', 'utility_electricity'].map(role => (
                                      <label key={role} className="flex items-center gap-4 p-4 ml-6 bg-slate-50/50 rounded-2xl border border-slate-200/50 cursor-pointer hover:bg-slate-50 transition-all group border-l-4 border-l-indigo-500">
                                        <input 
                                          type="checkbox"
                                          checked={(formData.roles || []).includes(role)}
                                          onChange={(e) => {
                                            const currentRoles = formData.roles || [];
                                            const roles = e.target.checked 
                                              ? [...currentRoles, role]
                                              : currentRoles.filter(r => r !== role);
                                            setFormData({...formData, roles});
                                          }}
                                          className="w-5 h-5 rounded-lg border-2 border-slate-300 text-indigo-600 focus:ring-indigo-500 transition-all cursor-pointer"
                                        />
                                        <div className="flex-1">
                                          <p className="text-xs font-black text-slate-800 leading-none mb-1 capitalize">{t(`role_${role}` as any)}</p>
                                        </div>
                                      </label>
                                    ))}
                                  </>
                                )}
                              </React.Fragment>
                            ))}

                            {/* Hospital Specific Roles */}
                            {tenant?.modules.hospital && (
                              <div className="space-y-2 pt-2">
                                <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest px-1">{t('hospital_module')}</p>
                                {['hospital_doctor', 'hospital_reception', 'hospital_pharmacy'].map((role) => (
                                  <label key={role} className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-200/50 cursor-pointer hover:bg-slate-100 transition-all group">
                                    <input 
                                      type="checkbox"
                                      checked={(formData.roles || []).includes(role)}
                                      onChange={(e) => {
                                        const currentRoles = formData.roles || [];
                                        const roles = e.target.checked 
                                          ? [...currentRoles, role]
                                          : currentRoles.filter(r => r !== role);
                                        setFormData({...formData, roles});
                                      }}
                                      className="w-5 h-5 rounded-lg border-2 border-slate-300 text-indigo-600 focus:ring-indigo-500 transition-all cursor-pointer"
                                    />
                                    <div className="flex-1">
                                      <p className="text-sm font-black text-slate-800 leading-none mb-1 capitalize">{t(`role_${role.replace('hospital_', '')}` as any)}</p>
                                    </div>
                                  </label>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </div>
          </div>

          <div className="sticky bottom-0 bg-white/80 backdrop-blur-xl pt-6 pb-2 border-t border-slate-100 z-10 flex gap-4">
            <button 
              type="button"
              onClick={() => {
                setIsModalOpen(false);
                resetForm();
              }}
              className="flex-1 px-8 py-5 rounded-2xl font-black text-sm uppercase tracking-widest text-slate-500 hover:bg-slate-100 transition-all"
            >
              {t('cancel')}
            </button>
            <button 
              disabled={submitting || uploadingPhoto}
              type="submit"
              className="flex-[2] bg-slate-900 text-white px-8 py-5 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-slate-800 transition-all disabled:opacity-50 shadow-2xl shadow-slate-200 flex items-center justify-center gap-3"
            >
              {uploadingPhoto ? (
                <>
                  <RefreshCw size={20} className="animate-spin" />
                  {t('uploading')}...
                </>
              ) : submitting ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  {editingId ? t('saving') : t('creating')}...
                </>
              ) : (
                <>
                  <UserPlus size={20} />
                  {editingId ? t('save_changes') : t('create_staff_account')}
                </>
              )}
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        title={t('confirm_delete' as any) || 'Confirm Delete'}
      >
        <div className="space-y-6">
          <div className="bg-rose-50 p-6 rounded-2xl border border-rose-100 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center flex-shrink-0">
              <Trash2 size={24} />
            </div>
            <div>
              <p className="font-bold text-slate-900">Ma hubtaa inaad tirtirto shaqaalahan?</p>
              <p className="text-sm text-slate-500 mt-1">Xogtan dib looma soo celin karo (This action cannot be undone).</p>
            </div>
          </div>
          <div className="flex gap-4">
            <button
              onClick={() => setDeleteId(null)}
              className="flex-1 px-6 py-4 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 transition-colors"
            >
              {t('cancel')}
            </button>
            <button
              disabled={loading}
              onClick={confirmDelete}
              className="flex-1 px-6 py-4 bg-rose-600 text-white rounded-xl font-bold hover:bg-rose-700 transition-colors shadow-lg shadow-rose-200 disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading && <RefreshCw size={18} className="animate-spin" />}
              {t('delete')}
            </button>
          </div>
        </div>
      </Modal>

      <div className="sahal-card overflow-hidden">
        <div className="p-8 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h3 className="font-display font-bold text-xl text-slate-900">{t('staff')}</h3>
            <p className="text-sm text-slate-400">{t('managing_tenants', { count: staff.length })}</p>
          </div>
          {tenant?.isMultiBranch && !user.branchId && (
            <select
              value={selectedBranchId}
              onChange={(e) => setSelectedBranchId(e.target.value)}
              className="w-full sm:w-auto px-5 py-2.5 bg-indigo-50 border border-indigo-100 text-indigo-700 rounded-xl font-bold hover:bg-indigo-100 transition-all shadow-sm outline-none cursor-pointer"
            >
              <option value="">{t('all_branches')}</option>
              {branches.map(b => (
                <option key={b.id} value={b.id}>{b.name}</option>
              ))}
            </select>
          )}
        </div>
        <div className="overflow-x-auto -mx-8 sm:mx-0">
          <table className="w-full text-left border-collapse min-w-[1000px]">
            <thead>
              <tr className="bg-slate-50/80 border-y border-slate-100">
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">{t('staff')}</th>
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">{t('position')} & {t('salary')}</th>
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">{t('contact')}</th>
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">{t('system_access')}</th>
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 text-right">{t('action')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {staff.map(s => (
                <tr key={s.id} className="hover:bg-indigo-50/30 transition-all group">
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-4">
                      <div className="relative">
                        <div className="w-14 h-14 rounded-2xl bg-slate-100 overflow-hidden border-2 border-white shadow-md ring-1 ring-slate-100 group-hover:ring-indigo-100 transition-all">
                          {s.photoURL ? (
                            <img src={s.photoURL} alt={s.displayName} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 text-slate-300">
                              <Users size={24} />
                            </div>
                          )}
                        </div>
                        <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white shadow-sm ${s.status === 'active' ? 'bg-emerald-500' : s.status === 'on_leave' ? 'bg-amber-500' : 'bg-slate-300'}`} />
                      </div>
                      <div>
                        <p className="font-bold text-slate-900 text-base leading-none mb-1.5">{s.displayName}</p>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-black text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md uppercase tracking-wider">
                            {t(s.status || 'active' as any)}
                          </span>
                          {tenant?.isMultiBranch && (
                            <span className="text-[10px] font-black text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md uppercase tracking-wider flex items-center gap-1">
                              <Building size={10} />
                              {s.branchId ? (branches.find(b => b.id === s.branchId)?.name || 'Unknown Branch') : t('all_branches')}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2">
                        <Briefcase size={14} className="text-slate-400" />
                        <p className="text-sm font-bold text-slate-700">{s.position || t('none')}</p>
                      </div>
                      {s.salary && (
                        <div className="flex items-center gap-2">
                          <DollarSign size={14} className="text-emerald-500" />
                          <span className="text-xs font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md">
                            ${s.salary.toLocaleString()}
                          </span>
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2">
                        <Phone size={14} className="text-slate-400" />
                        <p className="text-sm font-medium text-slate-600">{s.phone || t('none')}</p>
                      </div>
                      {s.hireDate && (
                        <div className="flex items-center gap-2">
                          <Calendar size={14} className="text-slate-400" />
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none">
                            {new Date(s.hireDate).toLocaleDateString()}
                          </p>
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    {s.username ? (
                      <div className="space-y-3">
                        <div className="flex items-center gap-4">
                          <div className="px-3 py-1.5 bg-slate-100 rounded-xl border border-slate-200">
                             <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5">{t('username')}</p>
                             <p className="text-xs font-mono font-bold text-slate-700">{s.username}</p>
                          </div>
                          <div className="px-3 py-1.5 bg-slate-100 rounded-xl border border-slate-200 relative group/pwd">
                             <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5">{t('password')}</p>
                             <div className="flex items-center gap-2">
                               <p className="text-xs font-mono font-bold text-slate-700">
                                 {showPassword ? s.password : '••••••••'}
                               </p>
                             </div>
                          </div>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {s.roles.map(role => (
                            <span key={role} className="px-2 py-0.5 bg-indigo-50 text-indigo-600 text-[10px] font-black rounded border border-indigo-100 uppercase tracking-wider">
                              {t(`role_${role.replace('hospital_', '')}` as any)}
                            </span>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 text-slate-300">
                        <Shield size={16} className="opacity-50" />
                        <span className="text-[10px] font-bold uppercase tracking-widest">{t('no_access')}</span>
                      </div>
                    )}
                  </td>
                  <td className="px-8 py-6 text-right">
                    <div className="flex justify-end gap-2 opacity-100 transition-all duration-300">
                      <button 
                        onClick={() => handleEdit(s)}
                        title={t('edit')}
                        className="p-2.5 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-indigo-600 hover:border-indigo-200 hover:bg-indigo-50 hover:shadow-lg hover:shadow-indigo-100 transition-all"
                      >
                        <Edit2 size={18} />
                      </button>
                      {s.username && (
                        <button 
                          onClick={() => handleToggleLock(s)}
                          title={s.isLocked ? t('unlock') : t('lock')}
                          className={`p-2.5 border rounded-xl transition-all shadow-sm ${s.isLocked ? 'bg-rose-50 border-rose-200 text-rose-600 shadow-rose-100' : 'bg-white border-slate-200 text-slate-400 hover:text-amber-600 hover:border-amber-200 hover:bg-amber-50 hover:shadow-lg hover:shadow-amber-100'}`}
                        >
                          <Shield size={18} />
                        </button>
                      )}
                      <button 
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          console.log("Delete staff clicked:", s.id);
                          handleDelete(s.id);
                        }}
                        title={t('delete')}
                        className="p-2.5 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-rose-600 hover:border-rose-200 hover:bg-rose-50 hover:shadow-lg hover:shadow-rose-100 transition-all"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {staff.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-8 py-12 text-center text-slate-500">
                    {t('no_staff_found')}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
