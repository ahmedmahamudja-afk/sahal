import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { supabase } from '../../supabase';
import { UserProfile } from '../../types';
import { Send, Bot, User, Loader2, Sparkles, AlertCircle, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../LanguageContext';

interface Message {
  role: 'user' | 'model';
  text: string;
}

export default function AIChatModule({ user }: { user: UserProfile }) {
  const { t } = useLanguage();
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: t('ai_welcome') }
  ]);
  const [input, setInput] = useState('');
  const [isThinking, setIsThinking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const fetchBusinessContext = async () => {
    if (!user.tenantId) return "";

    try {
      // Build queries conditionally
      const buildQuery = (table: string) => {
        let q = supabase.from(table).select('*').eq('tenant_id', user.tenantId);
        if (user.branchId) {
          if (['inventory', 'customers', 'accounts'].includes(table)) {
            q = q.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
          } else {
            q = q.eq('branch_id', user.branchId);
          }
        }
        return q;
      };

      // Fetch key data for context
      const [
        { data: inventory },
        { data: sales },
        { data: expenses },
        { data: debts }
      ] = await Promise.all([
        buildQuery('inventory').select('name, quantity, cost_price, price'),
        buildQuery('sales').select('total, paid_amount, created_at').limit(100),
        buildQuery('expenses').select('amount, category, description').limit(100),
        buildQuery('debts').select('amount, paid_amount, type')
      ]);

      const context = `
        Current Business State:
        - Inventory (top items): ${JSON.stringify(inventory?.slice(0, 20))}
        - Recent Sales History: ${JSON.stringify(sales?.slice(0, 20))}
        - Recent Expenses: ${JSON.stringify(expenses?.slice(0, 20))}
        - Business Debts Summary: ${JSON.stringify(debts)}
      `;
      return context;
    } catch (err) {
      console.error("Error fetching context:", err);
      return "Note: Occurred error when fetching some real-time business data.";
    }
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isThinking) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setIsThinking(true);
    setError(null);

    try {
      const businessContext = await fetchBusinessContext();
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      
      // Filter out empty messages and ensure we don't duplicate the last user message if we're prepending context
      const chatHistory = messages.slice(0, -1).map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));

      const modelName = "gemini-2.0-flash";

      const response = await ai.models.generateContent({
        model: modelName,
        contents: [
          ...chatHistory,
          { role: 'user', parts: [{ text: `CONTEXT:\n${businessContext}\n\nUSER MESSAGE: ${userMessage}` }] }
        ],
        config: {
          systemInstruction: "You are a professional business consultant and assistant named SAHAL AI. You can perform actions like adding inventory, recording sales, adding expenses, adding debts, and adding tasks. Speak in the language the user is using (Somali, English, Arabic, or Turkish). When performing actions, explain what you are doing. If you need more info for an action, ask for it. Keep answers structured and professional.",
          tools: [
            {
              functionDeclarations: [
                {
                  name: "add_inventory_item",
                  description: "Add a new item to the inventory",
                  parameters: {
                    type: Type.OBJECT,
                    properties: {
                      name: { type: Type.STRING, description: "Name of the item" },
                      quantity: { type: Type.NUMBER, description: "Initial quantity" },
                      cost_price: { type: Type.NUMBER, description: "Cost price per unit" },
                      selling_price: { type: Type.NUMBER, description: "Selling price per unit (Retail price)" },
                      sku: { type: Type.STRING, description: "Stock keeping unit (optional)" }
                    },
                    required: ["name", "quantity", "cost_price", "selling_price"]
                  }
                },
                {
                  name: "record_sale",
                  description: "Record a new sale",
                  parameters: {
                    type: Type.OBJECT,
                    properties: {
                      customer_name: { type: Type.STRING, description: "Name of the customer (optional)" },
                      items: { 
                        type: Type.ARRAY, 
                        items: {
                          type: Type.OBJECT,
                          properties: {
                            name: { type: Type.STRING },
                            quantity: { type: Type.NUMBER },
                            price: { type: Type.NUMBER }
                          }
                        }
                      },
                      total_amount: { type: Type.NUMBER, description: "Total sale amount" },
                      paid_amount: { type: Type.NUMBER, description: "Amount paid by customer" }
                    },
                    required: ["items", "total_amount", "paid_amount"]
                  }
                },
                {
                  name: "add_expense",
                  description: "Record a new business expense",
                  parameters: {
                    type: Type.OBJECT,
                    properties: {
                      category: { type: Type.STRING, description: "Category of expense (e.g., Rent, Salary, Utility, Marketing, Maintenance)" },
                      description: { type: Type.STRING, description: "Details of the expense" },
                      amount: { type: Type.NUMBER, description: "Amount spent" }
                    },
                    required: ["category", "amount"]
                  }
                },
                {
                  name: "add_debt",
                  description: "Record a new debt (money owed to or by the business)",
                  parameters: {
                    type: Type.OBJECT,
                    properties: {
                      customer_name: { type: Type.STRING, description: "Name of the person/business" },
                      amount: { type: Type.NUMBER, description: "Total debt amount" },
                      type: { type: Type.STRING, enum: ["customer", "business"], description: "customer means they owe us, business means we owe them" }
                    },
                    required: ["customer_name", "amount", "type"]
                  }
                },
                {
                  name: "add_daily_task",
                  description: "Add a new task to the daily to-do list",
                  parameters: {
                    type: Type.OBJECT,
                    properties: {
                      task: { type: Type.STRING, description: "The task description" }
                    },
                    required: ["task"]
                  }
                }
              ]
            }
          ]
        }
      });

      const functionCalls = response.functionCalls;

      if (functionCalls && functionCalls.length > 0) {
        const call = functionCalls[0];
        let actionResult = "";

        try {
          if (call.name === "add_inventory_item") {
            const args = call.args as any;
            const { error } = await supabase.from('inventory').insert([{
              name: args.name,
              quantity: args.quantity,
              cost_price: args.cost_price,
              price: args.selling_price, // Fixed mapping: selling_price -> price
              sku: args.sku || `SKU-${Date.now()}`,
              tenant_id: user.tenantId,
              branch_id: user.branchId
            }]);
            if (error) throw error;
            actionResult = t('ai_item_added');
          } else if (call.name === "record_sale") {
            const args = call.args as any;
            const { error } = await supabase.from('sales').insert([{
              customer_name: args.customer_name || 'Guest',
              items: args.items,
              total: args.total_amount, // Fixed mapping: total_amount -> total
              paid_amount: args.paid_amount,
              debt_amount: Math.max(0, args.total_amount - args.paid_amount),
              status: args.paid_amount >= args.total_amount ? 'paid' : (args.paid_amount > 0 ? 'partial' : 'debt'),
              tenant_id: user.tenantId,
              branch_id: user.branchId
            }]);
            if (error) throw error;
            actionResult = t('ai_sale_recorded');
          } else if (call.name === "add_expense") {
            const args = call.args as any;
            const { error } = await supabase.from('expenses').insert([{
              category: args.category,
              description: args.description || '',
              amount: args.amount,
              tenant_id: user.tenantId,
              branch_id: user.branchId,
              date: new Date().toISOString()
            }]);
            if (error) throw error;
            actionResult = t('ai_expense_added');
          } else if (call.name === "add_debt") {
            const args = call.args as any;
            const { error } = await supabase.from('debts').insert([{
              customer_name: args.customer_name,
              amount: args.amount,
              paid_amount: 0,
              type: args.type,
              status: 'unpaid',
              tenant_id: user.tenantId,
              branch_id: user.branchId
            }]);
            if (error) throw error;
            actionResult = t('ai_debt_added');
          } else if (call.name === "add_daily_task") {
            const args = call.args as any;
            const { error } = await supabase.from('daily_tasks').insert([{
              task: args.task,
              completed: false,
              tenant_id: user.tenantId,
              branch_id: user.branchId
            }]);
            if (error) throw error;
            actionResult = t('ai_task_added');
          }

          // Send the result back to AI to get a final confirmation message
          const finalResponse = await ai.models.generateContent({
            model: modelName,
            contents: [
              ...chatHistory,
              { role: 'user', parts: [{ text: `CONTEXT:\n${businessContext}\n\nUSER MESSAGE: ${userMessage}` }] },
              { role: 'model', parts: [{ functionCall: call }] },
              { role: 'user', parts: [{ functionResponse: { name: call.name, response: { content: actionResult } } }] }
            ]
          });
          
          setMessages(prev => [...prev, { role: 'model', text: finalResponse.text || t('ai_action_success') }]);
        } catch (err) {
          console.error("Action Error:", err);
          setMessages(prev => [...prev, { role: 'model', text: t('ai_action_error') }]);
        }
      } else {
        setMessages(prev => [...prev, { role: 'model', text: response.text || t('ai_error') }]);
      }
    } catch (err) {
      console.error("AI Error:", err);
      setError(t('ai_error'));
    } finally {
      setIsThinking(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto h-[calc(100vh-12rem)] flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-indigo-200">
            <Bot size={24} />
          </div>
          <div>
            <h2 className="text-2xl font-display font-bold text-slate-900">{t('ai_assistant')}</h2>
            <p className="text-sm text-slate-500">{t('ai_assistant_desc')}</p>
          </div>
        </div>
        <div className="hidden sm:flex items-center gap-2 px-4 py-2 bg-indigo-50 text-indigo-600 rounded-xl text-xs font-bold">
          <Sparkles size={14} />
          Powered by Gemini
        </div>
      </div>

      <div className="bg-blue-50 border border-blue-100 rounded-2xl p-4 mb-6 flex items-start gap-3">
        <Info size={20} className="text-blue-500 shrink-0 mt-0.5" />
        <p className="text-sm text-blue-700">{t('ai_context_info')}</p>
      </div>

      <div className="flex-1 bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden flex flex-col">
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <AnimatePresence initial={false}>
            {messages.map((msg, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`flex gap-3 max-w-[80%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                    msg.role === 'user' ? 'bg-slate-100 text-slate-600' : 'bg-indigo-100 text-indigo-600'
                  }`}>
                    {msg.role === 'user' ? <User size={16} /> : <Bot size={16} />}
                  </div>
                  <div className={`p-4 rounded-2xl text-sm leading-relaxed ${
                    msg.role === 'user' 
                      ? 'bg-indigo-600 text-white rounded-tr-none' 
                      : 'bg-slate-50 text-slate-700 rounded-tl-none border border-slate-100'
                  }`}>
                    {msg.text}
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
          {isThinking && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex justify-start"
            >
              <div className="flex gap-3 items-center text-slate-400 text-sm italic">
                <div className="w-8 h-8 rounded-lg bg-slate-50 flex items-center justify-center">
                  <Loader2 size={16} className="animate-spin" />
                </div>
                {t('ai_thinking')}
              </div>
            </motion.div>
          )}
          {error && (
            <div className="p-4 bg-rose-50 text-rose-600 rounded-xl text-sm font-bold flex items-center gap-2">
              <AlertCircle size={18} />
              {error}
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="p-6 bg-slate-50 border-t border-slate-100">
          <form onSubmit={handleSend} className="relative">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={t('ask_ai')}
              className="w-full pl-6 pr-16 py-4 bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-medium"
            />
            <button
              type="submit"
              disabled={!input.trim() || isThinking}
              className="absolute right-2 top-2 bottom-2 px-4 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all disabled:opacity-50 flex items-center justify-center"
            >
              <Send size={18} />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
