import React, { useState, useEffect } from 'react';
import { supabase } from '../../supabase';
import { UserProfile, Account, AccountTransaction, Tenant } from '../../types';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { 
  Wallet, 
  ArrowRightLeft, 
  Plus, 
  History, 
  TrendingUp, 
  TrendingDown, 
  DollarSign,
  AlertCircle,
  ArrowUpRight,
  ArrowDownLeft,
  RefreshCw,
  Package,
  CreditCard,
  FileDown,
  Calculator,
  Heart,
  Calendar,
  Search,
  ChevronDown,
  Table as TableIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../LanguageContext';
import Modal from '../Modal';

export default function FinanceModule({ user }: { user: UserProfile }) {
  const { t } = useLanguage();
  const [tenant, setTenant] = useState<Tenant | null>(null);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [branches, setBranches] = useState<any[]>([]);
  const [selectedBranchId, setSelectedBranchId] = useState<string>(user.branchId || '');
  const [transactions, setTransactions] = useState<AccountTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dateRange, setDateRange] = useState<{start: string, end: string}>({
    start: new Date().toISOString().split('T')[0],
    end: new Date().toISOString().split('T')[0]
  });
  const [rangeType, setRangeType] = useState<'today' | 'month' | '3months' | 'year' | 'custom'>('today');
  
  const [inventoryValue, setInventoryValue] = useState(0);
  const [receivables, setReceivables] = useState(0);
  const [payables, setPayables] = useState(0);
  const [customerCredits, setCustomerCredits] = useState(0);
  const [lastSync, setLastSync] = useState<Date>(new Date());
  
  const [transferData, setTransferData] = useState({
    fromAccountId: '',
    toAccountId: '',
    amount: '',
    description: ''
  });

  const getBase64ImageFromURL = (url: string): Promise<string> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.setAttribute('crossOrigin', 'anonymous');
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0);
        const dataURL = canvas.toDataURL('image/png');
        resolve(dataURL);
      };
      img.onerror = error => reject(error);
      img.src = url;
    });
  };

  const downloadPDF = async () => {
    const doc = new jsPDF();
    const businessName = tenant?.name || t('business_name_placeholder');
    const location = tenant?.location || '';
    const contact = tenant?.contact || '';
    
    // Header
    let yPos = 20;

    // Logo
    if (tenant?.logoUrl) {
      try {
        const base64 = await getBase64ImageFromURL(tenant.logoUrl);
        doc.addImage(base64, 'PNG', 165, 10, 30, 30);
      } catch (e) {
        console.warn('Could not load logo for Finance PDF:', e);
      }
    }
    
    doc.setFontSize(16);
    doc.setTextColor(37, 99, 235); // Blue-600
    doc.text(businessName, 14, yPos);
    yPos += 8;

    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139); // Slate-500
    if (location) {
      doc.text(location, 14, yPos);
      yPos += 5;
    }
    if (contact) {
      doc.text(contact, 14, yPos);
      yPos += 5;
    }
    
    yPos += 5;
    doc.setFontSize(14);
    doc.setTextColor(30, 41, 59);
    doc.text(`${t('finance_management' as any) || 'Financial Report'} (${new Date().toLocaleDateString()})`, 14, yPos);
    yPos += 10;

    // 1. Business Value Summary
    doc.setFontSize(12);
    doc.text(t('business_net_worth' as any) || 'Business Net Worth Summary', 14, yPos);
    yPos += 7;
    
    const summaryData = [
      [t('cash_balance' as any) || 'Physical Cash', `$${totalBalance.toLocaleString()}`],
      [t('stock_value' as any) || 'Stock Value', `$${inventoryValue.toLocaleString()}`],
      [t('receivables' as any) || 'Receivables', `$${receivables.toLocaleString()}`],
      [t('payables' as any) || 'Payables (Suppliers)', `-$${payables.toLocaleString()}`],
      [t('customer_credits' as any) || 'Customer Credits', `-$${customerCredits.toLocaleString()}`],
      [{ content: t('true_business_value' as any) || 'Net Business Worth', styles: { fontStyle: 'bold', fillColor: [241, 245, 249] } }, { content: `$${netWorth.toLocaleString()}`, styles: { fontStyle: 'bold', fillColor: [241, 245, 249] } }]
    ];

    autoTable(doc, {
      body: summaryData,
      startY: yPos,
      theme: 'grid',
      styles: { fontSize: 10, cellPadding: 4 },
      columnStyles: {
        0: { cellWidth: 100 },
        1: { cellWidth: 'auto', halign: 'right' }
      }
    });

    yPos = (doc as any).lastAutoTable.finalY + 15;

    // 2. Account Balances
    doc.setFontSize(12);
    doc.text(t('your_accounts' as any) || 'Account Balances', 14, yPos);
    yPos += 7;

    const accountRows = accounts.map(acc => [
      acc.name,
      `$${acc.balance.toLocaleString()}`
    ]);

    autoTable(doc, {
      head: [[t('account'), t('balance')]],
      body: accountRows,
      startY: yPos,
      theme: 'striped',
      headStyles: { fillColor: [37, 99, 235] },
      styles: { fontSize: 10, cellPadding: 4 },
      columnStyles: {
        0: { cellWidth: 100 },
        1: { cellWidth: 'auto', halign: 'right' }
      }
    });

    doc.save(`${businessName}_finance_report_${new Date().toLocaleDateString().replace(/\//g, '-')}.pdf`);
  };

  const downloadTransactionsPDF = async (filteredTrans: AccountTransaction[]) => {
    const doc = new jsPDF();
    const businessName = tenant?.name || t('business_name_placeholder');
    
    doc.setFontSize(16);
    doc.setTextColor(37, 99, 235);
    doc.text(`${businessName} - ${t('recent_transactions')}`, 14, 20);
    
    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139);
    doc.text(`${t('date')}: ${dateRange.start} - ${dateRange.end}`, 14, 28);
    
    const tableRows = filteredTrans.map(t => [
      new Date(t.createdAt).toLocaleString(),
      t.type,
      t.description,
      `${(t.type === 'sale' || t.type === 'equity' || (t.type === 'debt_payment' && t.toAccountId)) ? '+' : '-'}$${t.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}`
    ]);

    autoTable(doc, {
      head: [[t('date'), t('type'), t('description'), t('amount')]],
      body: tableRows,
      startY: 35,
      theme: 'grid',
      headStyles: { fillColor: [37, 99, 235] },
      styles: { fontSize: 9 }
    });

    doc.save(`${businessName}_transactions_${dateRange.start}_to_${dateRange.end}.pdf`);
  };

  const downloadTransactionsExcel = (filteredTrans: AccountTransaction[]) => {
    const businessName = tenant?.name || t('business_name_placeholder');
    const worksheetData = filteredTrans.map(t => ({
      Date: new Date(t.createdAt).toLocaleString(),
      Type: t.type.toUpperCase(),
      Description: t.description,
      Amount: (t.type === 'sale' || t.type === 'equity' || (t.type === 'debt_payment' && t.toAccountId)) ? t.amount : -t.amount
    }));

    const worksheet = XLSX.utils.json_to_sheet(worksheetData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Transactions");
    XLSX.writeFile(workbook, `${businessName}_transactions_${dateRange.start}_to_${dateRange.end}.xlsx`);
  };

  const setPredefinedRange = (type: 'today' | 'month' | '3months' | 'year') => {
    const end = new Date();
    const start = new Date();
    
    if (type === 'today') {
      // already set
    } else if (type === 'month') {
      start.setDate(1);
    } else if (type === '3months') {
      start.setMonth(start.getMonth() - 3);
    } else if (type === 'year') {
      start.setFullYear(start.getFullYear() - 1);
    }
    
    setDateRange({
      start: start.toISOString().split('T')[0],
      end: end.toISOString().split('T')[0]
    });
    setRangeType(type);
  };

  const fetchData = async (silent = false) => {
    if (!user.tenantId) return;
    try {
      if (!silent) setLoading(true);
      setError(null);
      
      const { data: tenantData } = await supabase.from('tenants').select('*').eq('id', user.tenantId).single();
      if (tenantData) {
        setTenant({
          ...tenantData,
          logoUrl: tenantData.logo_url,
          paymentNumbers: tenantData.payment_numbers,
          subscriptionPlan: tenantData.subscription_plan,
          planExpiry: tenantData.plan_expiry,
          isLocked: tenantData.is_locked,
          isMultiBranch: tenantData.is_multi_branch
        });
        if (tenantData.is_multi_branch) {
          const { data: branchData } = await supabase.from('branches').select('*').eq('tenant_id', user.tenantId);
          if (branchData) setBranches(branchData);
        }
      }

      const activeBranchId = selectedBranchId || user.branchId;
      
      // 1. Fetch Accounts
      let accQuery = supabase.from('accounts').select('*').eq('tenant_id', user.tenantId);
      if (activeBranchId) accQuery = accQuery.or(`branch_id.eq.${activeBranchId},branch_id.is.null`);

      const [
        { data: accDataRes, error: accError }
      ] = await Promise.all([
        accQuery
      ]);

      let accData = accDataRes;
      
      if (accError) {
        if (accError.code === '42P01') {
          setError('Table "accounts" does not exist. Please run the SQL setup script.');
          return;
        }
        throw accError;
      }

      // Consolidation and Duplicate Removal Logic
      const requiredAccounts = ['Cash', 'EVC', 'eDahab', 'ZAAD', 'SAHAL', 'Merchant', 'Bank Account'];
      const consolidationMap: Record<string, string> = {
        'CASH': 'Cash',
        'EVC Plus': 'EVC'
      };

      if (accData) {
        // 1. Handle explicit renames (CASH -> Cash, EVC Plus -> EVC)
        for (const [oldName, newName] of Object.entries(consolidationMap)) {
          const oldAccs = accData.filter(a => a.name === oldName);
          for (const oldAcc of oldAccs) {
            const targetAcc = accData.find(a => a.name === newName && a.id !== oldAcc.id);
            if (targetAcc) {
              // Merge balances
              const newBalance = (targetAcc.balance || 0) + (oldAcc.balance || 0);
              await supabase.from('accounts').update({ balance: newBalance }).eq('id', targetAcc.id);
              // Re-link transactions
              await supabase.from('account_transactions').update({ from_account_id: targetAcc.id }).eq('from_account_id', oldAcc.id);
              await supabase.from('account_transactions').update({ to_account_id: targetAcc.id }).eq('to_account_id', oldAcc.id);
              // Delete old
              await supabase.from('accounts').delete().eq('id', oldAcc.id);
              // Update local accData
              accData = accData.filter(a => a.id !== oldAcc.id);
              targetAcc.balance = newBalance;
            } else {
              // Just rename
              await supabase.from('accounts').update({ name: newName }).eq('id', oldAcc.id);
              oldAcc.name = newName;
            }
          }
        }

        // 2. Handle exact name duplicates (e.g., two "Cash" accounts)
        const nameGroups: Record<string, any[]> = {};
        accData.forEach(acc => {
          if (!nameGroups[acc.name]) nameGroups[acc.name] = [];
          nameGroups[acc.name].push(acc);
        });

        for (const name in nameGroups) {
          if (nameGroups[name].length > 1) {
            const [keep, ...others] = nameGroups[name];
            let totalBalanceValue = keep.balance || 0;
            for (const other of others) {
              totalBalanceValue += (other.balance || 0);
              await supabase.from('account_transactions').update({ from_account_id: keep.id }).eq('from_account_id', other.id);
              await supabase.from('account_transactions').update({ to_account_id: keep.id }).eq('to_account_id', other.id);
              await supabase.from('accounts').delete().eq('id', other.id);
              accData = accData.filter(a => a.id !== other.id);
            }
            await supabase.from('accounts').update({ balance: totalBalanceValue }).eq('id', keep.id);
            keep.balance = totalBalanceValue;
          }
        }
      }

      const existingNames = accData?.map(a => a.name) || [];
      const missingAccounts = requiredAccounts.filter(name => !existingNames.includes(name));

      if (missingAccounts.length > 0) {
        const activeBranchId = selectedBranchId || user.branchId;
        const newAccounts = missingAccounts.map(name => ({
          name,
          balance: 0,
          tenant_id: user.tenantId,
          branch_id: activeBranchId || null
        }));

        const { data: createdAccs, error: createError } = await supabase
          .from('accounts')
          .insert(newAccounts)
          .select();
        
        if (createError) throw createError;
        accData = [...(accData || []), ...(createdAccs || [])];
      }

      setAccounts(accData.map(a => ({
        id: a.id,
        name: a.name,
        balance: a.balance,
        tenantId: a.tenant_id,
        branchId: a.branch_id,
        createdAt: a.created_at
      })));

      // 2. Fetch Transactions
      const startDate = new Date(dateRange.start);
      startDate.setHours(0, 0, 0, 0);
      const endDate = new Date(dateRange.end);
      endDate.setHours(23, 59, 59, 999);

      let transQuery = supabase.from('account_transactions')
        .select('*')
        .eq('tenant_id', user.tenantId)
        .gte('created_at', startDate.toISOString())
        .lte('created_at', endDate.toISOString())
        .order('created_at', { ascending: false });
      
      if (activeBranchId) transQuery = transQuery.eq('branch_id', activeBranchId);

      const { data: transData, error: transError } = await transQuery;
      
      if (transError) throw transError;

      setTransactions(transData.map(t => ({
        id: t.id,
        fromAccountId: t.from_account_id,
        toAccountId: t.to_account_id,
        amount: t.amount,
        type: t.type,
        description: t.description,
        tenantId: t.tenant_id,
        branchId: t.branch_id,
        referenceId: t.reference_id,
        createdAt: t.created_at
      })));

      const buildFilteredQuery = (table: string) => {
        let q = supabase.from(table).select('*').eq('tenant_id', user.tenantId);
        if (activeBranchId) {
          if (table === 'inventory' || table === 'customers') {
            q = q.or(`branch_id.eq.${activeBranchId},branch_id.is.null`);
          } else {
            q = q.eq('branch_id', activeBranchId);
          }
        }
        return q;
      };

      // 3. Fetch Inventory Value
      const { data: invData } = await buildFilteredQuery('inventory').select('quantity, cost_price');
      
      const totalInv = invData?.reduce((sum, item) => sum + ((item.quantity || 0) * (item.cost_price || 0)), 0) || 0;
      setInventoryValue(totalInv);

      // 4. Fetch Debts (Receivables & Payables)
      const { data: debtData } = await buildFilteredQuery('debts')
        .select('amount, paid_amount, type')
        .eq('status', 'unpaid');
      
      let totalRec = 0;
      let totalPay = 0;
      
      debtData?.forEach(d => {
        const remaining = (d.amount || 0) - (d.paid_amount || 0);
        if (d.type === 'supplier' || d.type === 'business') {
          totalPay += remaining;
        } else {
          totalRec += remaining;
        }
      });
      
      setReceivables(totalRec);
      setPayables(totalPay);

      // 5. Fetch Customer Credit (Liability)
      const { data: custData } = await buildFilteredQuery('customers')
        .select('total_credit')
        .gt('total_credit', 0);
      
      const totalCredit = custData?.reduce((sum, c) => sum + (c.total_credit || 0), 0) || 0;
      setCustomerCredits(totalCredit);

      setLastSync(new Date());

    } catch (err: any) {
      console.error("Error fetching finance data:", err);
      setError(err.message || 'An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();

    // Real-time subscription for accounts and transactions
    const accountsChannel = supabase
      .channel('finance-updates')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'accounts', filter: `tenant_id=eq.${user.tenantId}` },
        () => fetchData(true)
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'account_transactions', filter: `tenant_id=eq.${user.tenantId}` },
        () => fetchData(true)
      )
      .subscribe();

    return () => {
      supabase.removeChannel(accountsChannel);
    };
  }, [user.tenantId, selectedBranchId, dateRange]);

  const handleTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.tenantId) return;
    if (transferData.fromAccountId === transferData.toAccountId) {
      alert('Source and destination accounts must be different');
      return;
    }

    const amount = parseFloat(transferData.amount);
    if (isNaN(amount) || amount <= 0) return;

    const fromAcc = accounts.find(a => a.id === transferData.fromAccountId);
    if (fromAcc && fromAcc.balance < amount) {
      if (!window.confirm('Insufficient balance in source account. Proceed anyway?')) return;
    }

    setSubmitting(true);
    try {
      const now = new Date().toISOString();
      
      // Optimistic Update
      setAccounts(prev => prev.map(acc => {
        if (acc.id === transferData.fromAccountId) return { ...acc, balance: acc.balance - amount };
        if (acc.id === transferData.toAccountId) return { ...acc, balance: acc.balance + amount };
        return acc;
      }));

      // 1. Update Source Account
      const { error: fromError } = await supabase
        .from('accounts')
        .update({ balance: (fromAcc?.balance || 0) - amount })
        .eq('id', transferData.fromAccountId);
      if (fromError) {
        fetchData(); // Rollback/Sync
        throw fromError;
      }

      // 2. Update Destination Account
      const toAcc = accounts.find(a => a.id === transferData.toAccountId);
      const { error: toError } = await supabase
        .from('accounts')
        .update({ balance: (toAcc?.balance || 0) + amount })
        .eq('id', transferData.toAccountId);
      if (toError) {
        fetchData(); // Rollback/Sync
        throw toError;
      }

      // 3. Create Transaction Record
      const { error: transError } = await supabase
        .from('account_transactions')
        .insert({
          from_account_id: transferData.fromAccountId,
          to_account_id: transferData.toAccountId,
          amount: amount,
          type: 'transfer',
          description: transferData.description || `Transfer from ${fromAcc?.name} to ${toAcc?.name}`,
          tenant_id: user.tenantId,
          branch_id: selectedBranchId || user.branchId || null,
          created_at: now
        });
      if (transError) {
        fetchData(); // Rollback/Sync
        throw transError;
      }

      setIsTransferModalOpen(false);
      setTransferData({ fromAccountId: '', toAccountId: '', amount: '', description: '' });
      // No need to manually call fetchData(true) here as real-time subscription will handle it
      // but we can do it after a short delay just in case
      setTimeout(() => fetchData(true), 500);
    } catch (err: any) {
      console.error("Error performing transfer:", err);
      alert(err.message || 'Error performing transfer');
    } finally {
      setSubmitting(false);
    }
  };

  const totalBalance = accounts.reduce((sum, a) => sum + a.balance, 0);
  const totalCashHoldings = totalBalance;
  const netWorth = totalBalance + inventoryValue + receivables - payables - customerCredits;
  const zakatAmount = netWorth > 0 ? netWorth * 0.025 : 0;

  if (loading) return <div className="p-8 text-center text-slate-500">{t('loading')}</div>;

  return (
    <div className="space-y-8 pb-12">
      {/* Header Section */}
      <div className="bg-surface-main p-8 rounded-[2.5rem] border border-border-main shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-accent-soft rounded-full -mr-32 -mt-32 opacity-50 blur-3xl" />
        <div className="relative z-10 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8">
          <div className="flex items-center gap-5">
            <div className="w-16 h-16 bg-accent-main rounded-2xl flex items-center justify-center text-white shadow-xl shadow-accent-soft">
              <DollarSign className="w-[var(--icon-lg)] h-[var(--icon-lg)]" />
            </div>
            <div>
              <h2 className="text-3xl font-display font-bold text-ink tracking-tight">
                {t('finance_management' as any) || 'Finance Management'}
              </h2>
              <div className="flex items-center gap-3 mt-1">
                <p className="text-ink-secondary font-medium">{t('finance_desc' as any) || 'Track your money across different accounts and perform transfers'}</p>
                <span className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-[10px] font-bold uppercase tracking-wider rounded-full border border-emerald-100 dark:border-emerald-900/30">
                  <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
                  Live Sync
                </span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            {tenant?.is_multi_branch && !user.branchId && (
              <select
                value={selectedBranchId}
                onChange={(e) => setSelectedBranchId(e.target.value)}
                className="w-full sm:w-auto px-5 py-3.5 bg-blue-50 border border-blue-100 text-blue-700 rounded-xl font-bold hover:bg-blue-100 transition-all shadow-sm outline-none cursor-pointer"
              >
                <option value="">{t('all_branches')}</option>
                {branches.map(b => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            )}
            <button 
              onClick={downloadPDF}
              className="bg-rose-600 text-white px-6 py-3.5 rounded-xl font-bold flex items-center gap-3 hover:bg-rose-700 transition-all shadow-lg shadow-rose-soft text-sm"
            >
              <FileDown className="w-[var(--icon-md)] h-[var(--icon-md)]" />
              {t('download_pdf')}
            </button>
            <button 
              onClick={() => fetchData(false)}
              disabled={loading}
              className="p-3 bg-surface-main border border-border-main text-ink-tertiary rounded-xl hover:bg-bg-sec transition-all shadow-sm flex items-center justify-center disabled:opacity-50"
              title={t('refresh')}
            >
              <RefreshCw className={`w-[var(--icon-md)] h-[var(--icon-md)] ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button 
              onClick={() => setIsTransferModalOpen(true)}
              className="bg-accent-main text-white px-6 py-3.5 rounded-xl font-bold flex items-center gap-3 hover:bg-accent-hover transition-all shadow-lg shadow-accent-soft text-sm"
            >
              <ArrowRightLeft className="w-[var(--icon-md)] h-[var(--icon-md)]" />
              {t('transfer_money' as any) || 'Transfer Money'}
            </button>
          </div>
        </div>
      </div>

      {error && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-center gap-3 text-rose-600"
        >
          <AlertCircle size={20} />
          <p className="text-sm font-bold">{error}</p>
        </motion.div>
      )}

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="p-8 bg-ink text-surface-main rounded-[2.5rem] border border-border-main shadow-xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform">
            <TrendingUp size={64} className="text-emerald-400" />
          </div>
          <div className="relative z-10">
            <h3 className="text-ink-tertiary text-[10px] font-bold uppercase tracking-[0.2em] mb-4">{t('true_business_value' as any) || 'True Business Value'}</h3>
            <p className="text-4xl font-display font-bold text-surface-main tracking-tight">${netWorth.toLocaleString()}</p>
            <div className="mt-6 pt-6 border-t border-surface-main/10 space-y-3">
              <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-wider">
                <span className="text-ink-tertiary">{t('cash_balance' as any) || 'Physical Cash'}</span>
                <span className="text-emerald-400">${totalBalance.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-wider">
                <span className="text-ink-tertiary">{t('stock_value' as any) || 'Stock'}</span>
                <span className="text-surface-main">${inventoryValue.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-wider">
                <span className="text-ink-tertiary">{t('receivables' as any) || 'Owed to us'}</span>
                <span className="text-emerald-400">${receivables.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-wider border-t border-surface-main/5 pt-2">
                <span className="text-ink-tertiary">{t('payables' as any) || 'We owe (Suppliers)'}</span>
                <span className="text-rose-400">-${payables.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-wider">
                <span className="text-ink-tertiary">{t('customer_credits' as any) || 'Customer Credits (Liability)'}</span>
                <span className="text-rose-400">-${customerCredits.toLocaleString()}</span>
              </div>
              <div className="pt-2 border-t border-surface-main/5 space-y-2">
                <div className="flex justify-between items-center text-[9px] font-bold uppercase tracking-widest text-ink-tertiary">
                  <span>{t('net_liquid_assets' as any) || 'Net Liquid Assets'}</span>
                  <span>${(totalBalance - customerCredits).toLocaleString()}</span>
                </div>
              </div>
            </div>
            <p className="text-[10px] text-ink-tertiary mt-4 italic text-center uppercase tracking-[0.1em]">{t('last_sync')}: {lastSync.toLocaleTimeString()}</p>
          </div>
        </div>

        <div className="p-8 bg-accent-main text-white rounded-[2.5rem] border border-accent-hover shadow-xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform">
            <Wallet size={64} />
          </div>
          <div className="relative z-10">
            <h3 className="text-accent-soft text-[10px] font-bold uppercase tracking-[0.2em] mb-4">{t('physical_cash_balance' as any) || 'Physical Cash Balance'}</h3>
            <p className="text-4xl font-display font-bold text-white tracking-tight">${totalBalance.toLocaleString()}</p>
            <div className="mt-8 p-4 bg-white/10 rounded-2xl border border-white/10">
              <p className="text-[10px] font-bold text-accent-soft uppercase tracking-widest mb-1">{t('customer_credits' as any) || 'Total Credits (Our Debt to Customers)'}</p>
              <p className="text-xl font-bold">${customerCredits.toLocaleString()}</p>
            </div>
          </div>
        </div>

        <div className="bg-surface-main p-8 rounded-[2.5rem] shadow-sm border border-border-main hover:shadow-md transition-all group">
          <div className="flex items-center justify-between mb-6">
            <div className="p-3 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-2xl group-hover:scale-110 transition-transform">
              <Package size={24} />
            </div>
          </div>
          <h3 className="text-ink-tertiary text-[10px] font-bold uppercase tracking-[0.2em] mb-2">{t('inventory_value' as any) || 'Inventory Value'}</h3>
          <p className="text-3xl font-display font-bold text-ink tracking-tight">${inventoryValue.toLocaleString()}</p>
          <p className="text-[10px] text-ink-secondary mt-4 font-medium leading-relaxed">{t('inventory_value_desc' as any) || 'Total value of all items in your stock based on cost price'}</p>
        </div>

        <div className="bg-surface-main p-8 rounded-[2.5rem] shadow-sm border border-border-main hover:shadow-md transition-all group">
          <div className="flex items-center justify-between mb-6">
            <div className="p-3 bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded-2xl group-hover:scale-110 transition-transform">
              <ArrowUpRight size={24} />
            </div>
          </div>
          <h3 className="text-ink-tertiary text-[10px] font-bold uppercase tracking-[0.2em] mb-2">{t('total_receivables' as any) || 'Total Receivables'}</h3>
          <p className="text-3xl font-display font-bold text-ink tracking-tight">${receivables.toLocaleString()}</p>
          <p className="text-[10px] text-ink-secondary mt-4 font-medium leading-relaxed">{t('receivables_desc' as any) || 'Money owed to your business by customers and partners'}</p>
        </div>
      </div>

      {/* Zakat Calculator */}
      <div className="bg-emerald-50 dark:bg-emerald-900/20 p-8 rounded-[2.5rem] border border-emerald-200 dark:border-emerald-800/30 shadow-sm relative overflow-hidden group">
        <div className="absolute -top-10 -right-10 opacity-5 group-hover:scale-110 transition-transform duration-500">
          <Heart size={200} className="text-emerald-600" />
        </div>
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
          <div className="flex items-center gap-5">
            <div className="w-16 h-16 bg-emerald-100 dark:bg-emerald-800/50 text-emerald-600 dark:text-emerald-400 rounded-2xl flex items-center justify-center">
              <Calculator className="w-[var(--icon-lg)] h-[var(--icon-lg)]" />
            </div>
            <div>
              <h3 className="text-emerald-800 dark:text-emerald-300 text-[10px] font-bold uppercase tracking-[0.2em] mb-1">
                {t('zakat_calculator' as any) || 'Zakat Calculator (2.5%)'}
              </h3>
              <p className="text-4xl font-display font-bold text-emerald-900 dark:text-emerald-100 tracking-tight">
                ${zakatAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
            </div>
          </div>
          <div className="md:max-w-md bg-white/50 dark:bg-black/20 p-4 rounded-2xl border border-emerald-100/50 dark:border-emerald-800/20">
            <p className="text-sm text-emerald-800/80 dark:text-emerald-300/80 font-medium leading-relaxed">
              The percentage of Nisab that is payable as Zakat is a quarter of one-tenth (2.5%) of the total money of ownership after one year.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
        {/* Accounts List */}
        <div className="xl:col-span-1 space-y-6">
          <div className="flex items-center justify-between px-2">
            <h3 className="text-xl font-display font-bold text-slate-900 flex items-center gap-3">
              <Wallet size={20} className="text-indigo-600" />
              {t('your_accounts' as any) || 'Your Accounts'}
            </h3>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{accounts.length} {t('accounts')}</span>
          </div>
          <div className="space-y-4">
            {accounts.filter(acc => acc.balance > 0).map(acc => (
              <motion.div 
                whileHover={{ y: -2 }}
                key={acc.id} 
                className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm hover:border-indigo-200 hover:shadow-md transition-all group cursor-pointer"
              >
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center text-slate-400 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
                      <CreditCard size={20} />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">{acc.name}</p>
                      <p className="text-[10px] font-medium text-slate-400 mt-1 uppercase tracking-wider">{t('last_updated' as any) || 'Updated'}: {new Date(acc.createdAt).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-display font-bold text-slate-900 tracking-tight">${acc.balance.toLocaleString()}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Recent Transactions */}
        <div className="xl:col-span-3 space-y-6">
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 px-2">
            <h3 className="text-xl font-display font-bold text-slate-900 flex items-center gap-3">
              <History size={24} className="text-indigo-600" />
              {t('recent_transactions' as any) || 'Recent Transactions'}
            </h3>
            
            <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
              {/* Range Presets */}
              <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200">
                {(['today', 'month', '3months', 'year'] as const).map((r) => (
                  <button
                    key={r}
                    onClick={() => setPredefinedRange(r)}
                    className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${
                      rangeType === r 
                        ? 'bg-white text-indigo-600 shadow-sm' 
                        : 'text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    {t(r as any) || r.replace('months', ' Months')}
                  </button>
                ))}
                <button
                  onClick={() => setRangeType('custom')}
                  className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${
                    rangeType === 'custom' 
                      ? 'bg-white text-indigo-600 shadow-sm' 
                      : 'text-slate-500 hover:text-slate-700'
                  }`}
                >
                  {t('custom' as any) || 'Custom'}
                </button>
              </div>

              {/* Custom Date Inputs */}
              {rangeType === 'custom' && (
                <div className="flex items-center gap-2 bg-white p-1 rounded-xl border border-slate-200 shadow-sm animate-in fade-in slide-in-from-left-2 transition-all">
                  <div className="relative">
                    <Calendar size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input 
                      type="date" 
                      value={dateRange.start}
                      onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
                      className="pl-8 pr-2 py-1.5 text-[10px] font-bold text-slate-600 outline-none border-none bg-transparent"
                    />
                  </div>
                  <span className="text-slate-300 font-bold">-</span>
                  <div className="relative">
                    <Calendar size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input 
                      type="date" 
                      value={dateRange.end}
                      onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
                      className="pl-8 pr-2 py-1.5 text-[10px] font-bold text-slate-600 outline-none border-none bg-transparent"
                    />
                  </div>
                </div>
              )}

              {/* Export Buttons */}
              <div className="flex items-center gap-2 ml-auto">
                <button 
                  onClick={() => downloadTransactionsPDF(transactions)}
                  disabled={transactions.length === 0}
                  className="flex items-center gap-2 px-4 py-2 bg-rose-600 text-white rounded-xl font-bold text-[10px] uppercase tracking-widest hover:bg-rose-700 transition-all shadow-lg shadow-rose-100 disabled:opacity-50 active:scale-95"
                >
                  <FileDown size={14} strokeWidth={3} />
                  PDF
                </button>
                <button 
                  onClick={() => downloadTransactionsExcel(transactions)}
                  disabled={transactions.length === 0}
                  className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-xl font-bold text-[10px] uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100 disabled:opacity-50 active:scale-95"
                >
                  <TableIcon size={14} strokeWidth={3} />
                  EXCEL
                </button>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50/50">
                    <th className="p-6 text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400 border-b border-slate-100">{t('date')}</th>
                    <th className="p-6 text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400 border-b border-slate-100">{t('type')}</th>
                    <th className="p-6 text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400 border-b border-slate-100">{t('description')}</th>
                    <th className="p-6 text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400 border-b border-slate-100 text-right">{t('amount')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {transactions.map((t) => {
                    const isTransfer = t.type === 'transfer';
                    
                    return (
                      <tr key={t.id} className="hover:bg-slate-50/80 transition-colors group">
                        <td className="p-6">
                          <div className="flex flex-col">
                            <span className="text-sm font-bold text-slate-900">{new Date(t.createdAt).toLocaleDateString()}</span>
                            <span className="text-[10px] font-medium text-slate-400 uppercase tracking-wider">{new Date(t.createdAt).toLocaleTimeString()}</span>
                          </div>
                        </td>
                        <td className="p-6">
                          <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest border ${
                            isTransfer ? 'bg-blue-50 text-blue-600 border-blue-100' :
                            t.type === 'sale' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' :
                            t.type === 'expense' ? 'bg-rose-50 text-rose-600 border-rose-100' :
                            t.type === 'equity' ? 'bg-indigo-50 text-indigo-600 border-indigo-100' :
                            t.type === 'debt_payment' ? 'bg-amber-50 text-amber-600 border-amber-100' :
                            'bg-slate-100 text-slate-600 border-slate-200'
                          }`}>
                            {t.type}
                          </span>
                        </td>
                        <td className="p-6">
                          <div className="flex flex-col">
                            <p className="text-sm font-bold text-slate-900 truncate max-w-[240px]">{t.description}</p>
                            <div className="flex items-center gap-2 mt-1">
                              {isTransfer ? (
                                <>
                                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{accounts.find(a => a.id === t.fromAccountId)?.name}</span>
                                  <ArrowRightLeft size={10} className="text-slate-300" />
                                  <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-wider">{accounts.find(a => a.id === t.toAccountId)?.name}</span>
                                </>
                              ) : (
                                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                                  {accounts.find(a => a.id === (t.fromAccountId || t.toAccountId))?.name || '-'}
                                </span>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="p-6 text-right">
                          <p className={`text-sm font-bold tracking-tight ${
                            (t.type === 'sale' || t.type === 'equity' || (t.type === 'debt_payment' && t.toAccountId) || (t.type === 'credit' && !t.fromAccountId)) ? 'text-emerald-600' :
                            (t.type === 'expense' || (t.type === 'debt_payment' && t.fromAccountId) || (t.type === 'credit' && t.fromAccountId)) ? 'text-rose-600' :
                            'text-slate-900'
                          }`}>
                            {(t.type === 'sale' || t.type === 'equity' || (t.type === 'debt_payment' && t.toAccountId) || (t.type === 'credit' && !t.fromAccountId)) ? '+' : 
                             (t.type === 'expense' || (t.type === 'debt_payment' && t.fromAccountId) || (t.type === 'credit' && t.fromAccountId)) ? '-' : ''}${t.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                          </p>
                        </td>
                      </tr>
                    );
                  })}
                  {transactions.length === 0 && (
                    <tr>
                      <td colSpan={4} className="p-20 text-center">
                        <div className="flex flex-col items-center gap-4">
                          <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-200">
                            <History size={32} />
                          </div>
                          <p className="text-slate-400 font-medium italic">{t('no_data')}</p>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Transfer Modal */}
      <Modal 
        isOpen={isTransferModalOpen} 
        onClose={() => setIsTransferModalOpen(false)} 
        title={t('transfer_money' as any) || 'Transfer Money'}
        contentClassName="max-w-lg"
      >
        <form onSubmit={handleTransfer} className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('from_account' as any) || 'From Account'}</label>
              <select 
                required
                value={transferData.fromAccountId}
                onChange={(e) => setTransferData({...transferData, fromAccountId: e.target.value})}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold"
              >
                <option value="">{t('select_account' as any) || 'Select Account'}</option>
                {accounts.filter(acc => acc.balance > 0).map(acc => (
                  <option key={acc.id} value={acc.id}>{acc.name} (${acc.balance})</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('to_account' as any) || 'To Account'}</label>
              <select 
                required
                value={transferData.toAccountId}
                onChange={(e) => setTransferData({...transferData, toAccountId: e.target.value})}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold"
              >
                <option value="">{t('select_account' as any) || 'Select Account'}</option>
                {accounts.map(acc => (
                  <option key={acc.id} value={acc.id}>{acc.name} (${acc.balance})</option>
                ))}
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('amount')}</label>
            <input 
              required
              type="number" 
              step="0.01"
              value={transferData.amount}
              onChange={(e) => setTransferData({...transferData, amount: e.target.value})}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('description')}</label>
            <input 
              type="text" 
              value={transferData.description}
              onChange={(e) => setTransferData({...transferData, description: e.target.value})}
              placeholder={t('transfer_desc_placeholder' as any) || 'e.g. Daily consolidation'}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold"
            />
          </div>
          <button 
            type="submit" 
            disabled={submitting}
            className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 disabled:opacity-50 flex items-center justify-center gap-2"
          >
            <ArrowRightLeft size={18} />
            {submitting ? t('processing') : t('confirm_transfer' as any) || 'Confirm Transfer'}
          </button>
        </form>
      </Modal>
    </div>
  );
}
