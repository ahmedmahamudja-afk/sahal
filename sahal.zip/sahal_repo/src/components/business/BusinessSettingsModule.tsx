import React, { useState, useEffect } from 'react';
import { supabase } from '../../supabase';
import { Tenant, UserProfile } from '../../types';
import { Building2, Save, AlertCircle, Upload, Trash2, RefreshCcw, Download, FileText, Table as TableIcon, Lock, Eye, EyeOff } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../LanguageContext';
import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';

export default function BusinessSettingsModule({ user }: { user: UserProfile }) {
  const { t } = useLanguage();
  const [tenant, setTenant] = useState<Tenant | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    type: 'retail',
    logoUrl: '',
    location: '',
    contact: '',
    isMultiBranch: false,
    paymentNumbers: {
      evc: '',
      edahab: '',
      zaad: '',
      sahal: '',
      bank: '',
      merchant: ''
    },
    utilitySettings: {
      waterRate: 0,
      electricityRate: 0
    }
  });

  // Password Change State
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [showPasswords, setShowPasswords] = useState({
    current: false,
    new: false,
    confirm: false
  });
  const [passwordSaving, setPasswordSaving] = useState(false);
  const [passwordMessage, setPasswordMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [exporting, setExporting] = useState<string | null>(null);
  const [importTable, setImportTable] = useState('inventory');
  const [importing, setImporting] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);

  useEffect(() => {
    const fetchTenant = async () => {
      if (!user.tenantId) {
        setLoading(false);
        return;
      }
      try {
        const { data: tenantData } = await supabase
          .from('tenants')
          .select('*')
          .eq('id', user.tenantId)
          .single();
        
        if (tenantData) {
          setTenant(tenantData);
          
          // Fetch Utility Settings
          const { data: utilitySettingsData } = await supabase
            .from('utility_settings')
            .select('*')
            .eq('tenant_id', user.tenantId)
            .single();
            
          let uSettings = { waterRate: 0, electricityRate: 0 };
          if (utilitySettingsData) {
            uSettings = {
              waterRate: utilitySettingsData.water_rate || 0,
              electricityRate: utilitySettingsData.electricity_rate || 0
            };
          }

          setFormData({ 
            name: tenantData.name, 
            type: tenantData.type, 
            logoUrl: tenantData.logo_url || '',
            location: tenantData.location || '',
            contact: tenantData.contact || '',
            isMultiBranch: tenantData.is_multi_branch || false,
            paymentNumbers: {
              evc: tenantData.payment_numbers?.evc || '',
              edahab: tenantData.payment_numbers?.edahab || '',
              zaad: tenantData.payment_numbers?.zaad || '',
              sahal: tenantData.payment_numbers?.sahal || '',
              bank: tenantData.payment_numbers?.bank || '',
              merchant: tenantData.payment_numbers?.merchant || ''
            },
            utilitySettings: uSettings
          });
        }
      } catch (error) {
        console.error("Error fetching business settings:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchTenant();
  }, [user.tenantId]);

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordMessage(null);

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      setPasswordMessage({ type: 'error', text: t('password_mismatch') });
      return;
    }

    if (passwordData.newPassword.length < 4) {
      setPasswordMessage({ type: 'error', text: 'Password-ka waa inuu ugu yaraan ka koobnaadaa 4 xaraf.' });
      return;
    }

    setPasswordSaving(true);
    try {
      const table = user.isStaff ? 'staff' : 'users';
      const idField = user.isStaff ? 'id' : 'uid';

      // Verify current password
      const { data: userData, error: fetchError } = await supabase
        .from(table)
        .select('password')
        .eq(idField, user.uid)
        .single();

      if (fetchError || !userData) throw new Error("User not found");

      if (userData.password !== passwordData.currentPassword) {
        setPasswordMessage({ type: 'error', text: t('incorrect_current_password') });
        setPasswordSaving(false);
        return;
      }

      // Update password
      const { error: updateError } = await supabase
        .from(table)
        .update({ password: passwordData.newPassword })
        .eq(idField, user.uid);

      if (updateError) throw updateError;

      setPasswordMessage({ type: 'success', text: t('password_changed_success') });
      setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
    } catch (error: any) {
      console.error("Error changing password:", error);
      setPasswordMessage({ type: 'error', text: t('error_occurred') });
    } finally {
      setPasswordSaving(false);
    }
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 1024 * 1024) { // 1MB limit
        alert(t('image_size_error'));
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, logoUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.tenantId) return;
    console.log("DEBUG: Saving business settings, formData:", formData);
    setSaving(true);
    setMessage(null);
    try {
      const { error } = await supabase
        .from('tenants')
        .update({
          name: formData.name,
          type: formData.type,
          logo_url: formData.logoUrl,
          location: formData.location,
          contact: formData.contact,
          is_multi_branch: formData.isMultiBranch,
          payment_numbers: formData.paymentNumbers
        })
        .eq('id', user.tenantId);

      if (error) throw error;

      // Update Utility Settings
      if (tenant?.modules?.utility_water || tenant?.modules?.utility_electricity) {
        const { data: existingSettings } = await supabase
          .from('utility_settings')
          .select('id')
          .eq('tenant_id', user.tenantId)
          .single();
          
        const utilitySettingsData = {
          water_rate: formData.utilitySettings.waterRate,
          electricity_rate: formData.utilitySettings.electricityRate,
          tenant_id: user.tenantId
        };
        
        if (!existingSettings) {
          await supabase.from('utility_settings').insert(utilitySettingsData);
        } else {
          await supabase.from('utility_settings').update(utilitySettingsData).eq('id', existingSettings.id);
        }
      }
      setMessage({ type: 'success', text: t('business_info_updated') });
    } catch (error) {
      console.error("Error updating business settings:", error);
      // @ts-ignore
      setMessage({ type: 'error', text: `${t('error_occurred')}: ${error?.message || 'Unknown error'}` });
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteAllData = async () => {
    if (!user.tenantId) return;
    setDeleting(true);
    setMessage(null);
    try {
      const tables = [
        'inventory', 'sales', 'expenses', 'debts', 'customers', 
        'patients', 'visits', 'services', 'savings', 
        'investments', 'working_notes', 'daily_tasks', 'keeping_ideas', 
        'shareholders', 'staff', 'account_transactions',
        'stock_logs', 'utility_records', 'homes'
      ];

      await Promise.all([
        ...tables.map(table => supabase.from(table).delete().eq('tenant_id', user.tenantId)),
        supabase.from('accounts').update({ balance: 0 }).eq('tenant_id', user.tenantId)
      ]);

      setMessage({ type: 'success', text: t('data_deleted_success') });
      setShowDeleteConfirm(false);
    } catch (error) {
      console.error("Error deleting data:", error);
      setMessage({ type: 'error', text: t('error_occurred') });
    } finally {
      setDeleting(false);
    }
  };

  const handleBackupData = async () => {
    if (!user.tenantId) return;
    try {
      const tables = [
        'inventory', 'sales', 'expenses', 'debts', 'customers', 
        'patients', 'visits', 'services', 'savings', 
        'investments', 'working_notes', 'daily_tasks', 'keeping_ideas', 
        'shareholders', 'staff', 'accounts', 'account_transactions',
        'stock_logs', 'utility_records', 'homes'
      ];

      const results = await Promise.all(tables.map(table => 
        supabase.from(table).select('*').eq('tenant_id', user.tenantId)
      ));

      const backupData: any = {};
      tables.forEach((table, index) => {
        backupData[table] = results[index].data;
      });

      const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `backup_${tenant.name}_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Error backing up data:", error);
      alert(t('error_occurred'));
    }
  };

  const handleRestoreData = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user.tenantId) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const backupData = JSON.parse(event.target?.result as string);
        setSaving(true);
        setMessage(null);

        for (const [table, rows] of Object.entries(backupData)) {
          if (Array.isArray(rows) && rows.length > 0) {
            // Clean rows to ensure they belong to this tenant and remove IDs to avoid conflicts if needed, 
            // or keep them if we want exact restoration. Here we keep them but ensure tenant_id matches.
            const cleanedRows = rows.map((row: any) => ({
              ...row,
              tenant_id: user.tenantId
            }));
            
            // Delete existing first to avoid unique constraint errors
            await supabase.from(table).delete().eq('tenant_id', user.tenantId);
            // Insert backup
            await supabase.from(table).insert(cleanedRows);
          }
        }

        setMessage({ type: 'success', text: t('business_info_updated') });
      } catch (error) {
        console.error("Error restoring data:", error);
        setMessage({ type: 'error', text: t('error_occurred') });
      } finally {
        setSaving(false);
      }
    };
    reader.readAsText(file);
  };

  const fetchAllData = async () => {
    if (!user.tenantId) return null;
    const tables = [
      'inventory', 'sales', 'expenses', 'debts', 'customers', 
      'patients', 'visits', 'services', 'savings', 
      'investments', 'working_notes', 'daily_tasks', 'keeping_ideas', 
      'shareholders', 'staff', 'accounts', 'account_transactions',
      'stock_logs', 'utility_records', 'homes'
    ];

    const results = await Promise.all(tables.map(table => 
      supabase.from(table).select('*').eq('tenant_id', user.tenantId)
    ));

    const data: any = {};
    tables.forEach((table, index) => {
      data[table] = results[index].data || [];
    });
    return data;
  };

  const handleExportExcel = async () => {
    setExporting('excel');
    try {
      const data = await fetchAllData();
      if (!data) return;

      const wb = XLSX.utils.book_new();

      Object.entries(data).forEach(([tableName, rows]: [string, any]) => {
        if (rows.length > 0) {
          const ws = XLSX.utils.json_to_sheet(rows);
          XLSX.utils.book_append_sheet(wb, ws, tableName.substring(0, 31));
        }
      });

      XLSX.writeFile(wb, `export_${tenant?.name}_${new Date().toISOString().split('T')[0]}.xlsx`);
    } catch (error) {
      console.error("Excel Export Error:", error);
      alert(t('error_occurred'));
    } finally {
      setExporting(null);
    }
  };

  const handleExportPDF = async () => {
    setExporting('pdf');
    try {
      const data = await fetchAllData();
      if (!data) return;

      const doc = new jsPDF();
      let yOffset = 20;

      doc.setFontSize(20);
      doc.text(`${tenant?.name} - Business Data Export`, 14, yOffset);
      yOffset += 10;
      doc.setFontSize(10);
      doc.text(`Generated on: ${new Date().toLocaleString()}`, 14, yOffset);
      yOffset += 15;

      const exportTables = ['inventory', 'sales', 'expenses', 'debts'];
      
      exportTables.forEach((tableName) => {
        const rows = data[tableName];
        if (rows && rows.length > 0) {
          if (yOffset > 250) {
            doc.addPage();
            yOffset = 20;
          }
          
          doc.setFontSize(14);
          doc.text(tableName.toUpperCase(), 14, yOffset);
          yOffset += 5;

          const headers = Object.keys(rows[0]).filter(k => !['id', 'tenant_id', 'branch_id', 'created_at'].includes(k));
          const body = rows.map((row: any) => headers.map(h => {
            const val = row[h];
            if (typeof val === 'object') return JSON.stringify(val);
            return String(val);
          }));

          autoTable(doc, {
            startY: yOffset,
            head: [headers],
            body: body,
            theme: 'striped',
            styles: { fontSize: 8 },
            margin: { top: 20 },
          });

          yOffset = (doc as any).lastAutoTable.finalY + 15;
        }
      });

      doc.save(`export_${tenant?.name}_${new Date().toISOString().split('T')[0]}.pdf`);
    } catch (error) {
      console.error("PDF Export Error:", error);
      alert(t('error_occurred'));
    } finally {
      setExporting(null);
    }
  };

  const handleBulkImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user.tenantId) return;

    setImporting(true);
    setMessage(null);
    setImportError(null);

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        // Fetch branches for name resolution
        const { data: branches } = await supabase
          .from('branches')
          .select('id, name')
          .eq('tenant_id', user.tenantId);
        
        const branchMap = new Map(branches?.map(b => [b.name.toLowerCase().trim(), b.id]) || []);

        const data = new Uint8Array(event.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);

        if (jsonData.length === 0) {
          throw new Error("File is empty or has no data rows");
        }

        // Define expected columns for each table to help with mapping and validation
        const tableSchemas: any = {
          inventory: ['name', 'sku', 'quantity', 'cost_price', 'price', 'min_stock', 'category', 'payment_method', 'expiry_date', 'branch_id'],
          customers: ['name', 'phone', 'total_debt', 'total_credit', 'offer_percentage', 'address', 'branch_id'],
          expenses: ['category', 'description', 'amount', 'date', 'payment_method', 'branch_id'],
          debts: ['customer_name', 'phone', 'amount', 'paid_amount', 'status', 'due_date', 'type', 'description', 'payment_method', 'branch_id'],
          services: ['name', 'description', 'price', 'branch_id'],
          staff: ['display_name', 'username', 'password', 'phone', 'position', 'salary', 'address', 'email', 'status', 'hire_date', 'branch_id']
        };

        const expectedColumns = tableSchemas[importTable] || [];

        // Map data to include tenant_id and normalize keys to lowercase to match DB columns
        const rowsToInsert = jsonData.map((row: any) => {
          const newRow: any = { 
            tenant_id: user.tenantId,
            branch_id: user.branchId || null
          };
          
          // Normalize keys: "Product Name" -> "name" if it matches our schema
          Object.keys(row).forEach(key => {
            const normalizedKey = key.toLowerCase().replace(/\s+/g, '_');
            
            // If the normalized key matches a DB column, use it
            if (expectedColumns.includes(normalizedKey)) {
              newRow[normalizedKey] = row[key];
            } else if (normalizedKey === 'branch' || normalizedKey === 'branch_name') {
               // Resolution logic below
            } else {
              // Fallback: if it's not in our schema but might be a direct match
              newRow[key.toLowerCase()] = row[key];
            }
          });

          // Resolve branch name if provided
          const branchName = row.branch || row.Branch || row.branch_name;
          if (branchName && branchMap.has(String(branchName).toLowerCase().trim())) {
            newRow.branch_id = branchMap.get(String(branchName).toLowerCase().trim());
          }

          // Special mappings for common mismatches
          if (importTable === 'inventory' && row.selling_price !== undefined) newRow.price = row.selling_price;
          if (importTable === 'inventory' && row.Price !== undefined) newRow.price = row.Price;
          if (importTable === 'staff' && row.name !== undefined) newRow.display_name = row.name;
          if (importTable === 'staff' && row.full_name !== undefined) newRow.display_name = row.full_name;
          if (importTable === 'debts' && row.name !== undefined) newRow.customer_name = row.name;

          return newRow;
        }).filter(row => {
          // Filter out rows that are essentially empty (only have tenant_id and branch_id)
          return Object.keys(row).length > 2;
        });

        if (rowsToInsert.length === 0) {
          throw new Error("No valid data rows found to import");
        }

        console.log(`DEBUG: Importing ${rowsToInsert.length} rows into ${importTable}`, rowsToInsert);

        // Handle financial impacts if payment_method is provided
        const financialImpacts: Record<string, number> = {};
        rowsToInsert.forEach(row => {
          if (row.payment_method) {
            let amount = 0;
            if (importTable === 'inventory') {
              amount = (parseFloat(row.quantity) || 0) * (parseFloat(row.cost_price) || 0);
            } else if (importTable === 'expenses') {
              amount = parseFloat(row.amount) || 0;
            } else if (importTable === 'debts') {
              amount = parseFloat(row.paid_amount) || 0;
            }
            
            if (amount > 0) {
              const method = row.payment_method.charAt(0).toUpperCase() + row.payment_method.slice(1).toLowerCase();
              financialImpacts[method] = (financialImpacts[method] || 0) + amount;
            }
          }
        });

        // Apply grouped financial impacts
        for (const [method, totalAmount] of Object.entries(financialImpacts)) {
          // Find or create account
          let accQuery = supabase
            .from('accounts')
            .select('*')
            .eq('tenant_id', user.tenantId)
            .eq('name', method);
          
          if (user.branchId) accQuery = accQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);

          let { data: accs } = await accQuery;
          let accData = accs?.[0];
          
          if (!accData) {
            const { data: newAcc } = await supabase
              .from('accounts')
              .insert({ 
                name: method, 
                balance: -totalAmount, 
                tenant_id: user.tenantId,
                branch_id: user.branchId || null
              })
              .select()
              .single();
            accData = newAcc;
          } else {
            await supabase
              .from('accounts')
              .update({ balance: accData.balance - totalAmount })
              .eq('id', accData.id);
          }

          // Log summarized Transaction
          if (accData) {
            await supabase.from('account_transactions').insert({
              from_account_id: accData.id,
              amount: totalAmount,
              type: 'expense',
              description: `Bulk Import: ${importTable.toUpperCase()} (${rowsToInsert.length} rows)`,
              tenant_id: user.tenantId,
              branch_id: user.branchId || null,
              created_at: new Date().toISOString()
            });
          }
        }

        // Clean rows for Supabase (remove internal logic columns like payment_method, category, expiry_date if not supported)
        const dbRowsToInsert = rowsToInsert.map(row => {
          const { payment_method, category, expiry_date, ...cleanRow } = row;
          return cleanRow;
        });

        const { error } = await supabase.from(importTable).insert(dbRowsToInsert);
        if (error) {
          console.error("Supabase Insert Error:", error);
          throw new Error(error.message);
        }

        setMessage({ type: 'success', text: t('import_success') });
      } catch (error: any) {
        console.error("Import Error:", error);
        setImportError(error.message || "Unknown error occurred during import");
        setMessage({ type: 'error', text: t('import_error') });
      } finally {
        setImporting(false);
        // Reset file input
        e.target.value = '';
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const downloadTemplate = () => {
    const templates: any = {
      inventory: [
        { name: 'Example Item', sku: 'SKU001', quantity: 10, cost_price: 5, price: 10, min_stock: 5, category: 'General', payment_method: 'Cash', expiry_date: '2025-12-31', branch: formData.isMultiBranch ? 'Branch Name' : undefined }
      ],
      customers: [
        { name: 'John Doe', phone: '123456789', total_debt: 0, total_credit: 0, offer_percentage: 0, address: 'Mogadishu', branch: formData.isMultiBranch ? 'Branch Name' : undefined }
      ],
      expenses: [
        { category: 'Rent', amount: 500, description: 'Monthly office rent', date: new Date().toISOString().split('T')[0], payment_method: 'Cash', branch: formData.isMultiBranch ? 'Branch Name' : undefined }
      ],
      debts: [
        { customer_name: 'Jane Smith', phone: '123456789', amount: 100, paid_amount: 0, status: 'unpaid', due_date: '', type: 'customer', description: 'Sample note', payment_method: 'Cash', branch: formData.isMultiBranch ? 'Branch Name' : undefined }
      ],
      services: [
        { name: 'Consultation', description: 'General consultation service', price: 50, branch: formData.isMultiBranch ? 'Branch Name' : undefined }
      ],
      staff: [
        { display_name: 'Staff Member', username: 'staff1', password: 'password123', phone: '123456789', position: 'Sales', salary: 500, address: 'Mogadishu', email: 'staff@example.com', status: 'active', hire_date: new Date().toISOString().split('T')[0], branch: formData.isMultiBranch ? 'Branch Name' : undefined }
      ]
    };

    const templateData = templates[importTable] || [{ name: 'Example' }];
    const ws = XLSX.utils.json_to_sheet(templateData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Template");
    XLSX.writeFile(wb, `${importTable}_template.xlsx`);
  };

  if (loading) return <div className="p-8 text-center text-slate-500">{t('loading')}</div>;

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-12 h-12 bg-indigo-100 rounded-2xl flex items-center justify-center text-indigo-600">
          <Lock size={24} />
        </div>
        <div>
          <h2 className="text-2xl font-display font-bold text-slate-900">{t('settings')}</h2>
          <p className="text-sm text-slate-500">{user.isStaff ? t('change_password') : t('business_settings_desc')}</p>
        </div>
      </div>

      {!user.isStaff && tenant && (
        <>
          <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
            <form onSubmit={handleSave} className="p-8 space-y-6">
          {message && (
            <div className={`p-4 rounded-xl text-sm font-bold flex items-center gap-2 ${message.type === 'success' ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
              <AlertCircle size={18} />
              {message.text}
            </div>
          )}
          
          <div className="flex flex-col sm:flex-row gap-6 items-start">
            <div className="w-full sm:w-1/3">
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('business_logo')}</label>
              <div className="relative group cursor-pointer">
                <div className="w-32 h-32 rounded-2xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center overflow-hidden bg-slate-50 hover:bg-slate-100 transition-colors">
                  {formData.logoUrl ? (
                    <img 
                      src={formData.logoUrl} 
                      alt="Logo" 
                      className="w-full h-full object-contain p-2" 
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="text-slate-400 flex flex-col items-center">
                      <Upload size={24} className="mb-2" />
                      <span className="text-xs font-bold">{t('choose_logo')}</span>
                    </div>
                  )}
                </div>
                <input 
                  type="file" 
                  accept="image/*" 
                  onChange={handleLogoUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
              </div>
              <p className="text-[10px] text-slate-400 mt-2">{t('max_image_size')}</p>
            </div>

            <div className="w-full sm:w-2/3 space-y-6">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('business_name')}</label>
                <input 
                  required
                  type="text" 
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold text-slate-900"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('location')}</label>
                  <input 
                    type="text" 
                    value={formData.location}
                    onChange={(e) => setFormData({...formData, location: e.target.value})}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('contact')}</label>
                  <input 
                    type="text" 
                    value={formData.contact}
                    onChange={(e) => setFormData({...formData, contact: e.target.value})}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('business_type')}</label>
                  <select 
                    required
                    value={formData.type}
                    onChange={(e) => setFormData({...formData, type: e.target.value})}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold text-slate-900 appearance-none"
                    style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' fill=\'none\' viewBox=\'0 0 24 24\' stroke=\'currentColor\'%3E%3Cpath stroke-linecap=\'round\' stroke-linejoin=\'round\' stroke-width=\'2\' d=\'M19 9l-7 7-7-7\'/%3E%3C/svg%3E")', backgroundRepeat: 'no-repeat', backgroundPosition: 'right 1rem center', backgroundSize: '1.25rem' }}
                  >
                    <option value="inventory">{t('type_inventory')}</option>
                    <option value="services">{t('type_services')}</option>
                    <option value="services_inventory">{t('type_services_inventory')}</option>
                    <option value="hospital">{t('type_hospital')}</option>
                    <option value="personal">{t('type_personal')}</option>
                    <option value="utility">{t('type_utility')}</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Structure</label>
                  <select 
                    value={formData.isMultiBranch ? 'multi' : 'single'}
                    onChange={(e) => setFormData({...formData, isMultiBranch: e.target.value === 'multi'})}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold text-slate-900 appearance-none"
                    style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' fill=\'none\' viewBox=\'0 0 24 24\' stroke=\'currentColor\'%3E%3Cpath stroke-linecap=\'round\' stroke-linejoin=\'round\' stroke-width=\'2\' d=\'M19 9l-7 7-7-7\'/%3E%3C/svg%3E")', backgroundRepeat: 'no-repeat', backgroundPosition: 'right 1rem center', backgroundSize: '1.25rem' }}
                  >
                    <option value="single">Single Branch</option>
                    <option value="multi">Multiple Branches</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-100 space-y-6">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">{t('payment_numbers')}</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('evc_number')}</label>
                <input 
                  type="text" 
                  value={formData.paymentNumbers.evc}
                  onChange={(e) => setFormData({
                    ...formData, 
                    paymentNumbers: { ...formData.paymentNumbers, evc: e.target.value }
                  })}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold text-slate-900"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('edahab_number')}</label>
                <input 
                  type="text" 
                  value={formData.paymentNumbers.edahab}
                  onChange={(e) => setFormData({
                    ...formData, 
                    paymentNumbers: { ...formData.paymentNumbers, edahab: e.target.value }
                  })}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold text-slate-900"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('zaad_number')}</label>
                <input 
                  type="text" 
                  value={formData.paymentNumbers.zaad}
                  onChange={(e) => setFormData({
                    ...formData, 
                    paymentNumbers: { ...formData.paymentNumbers, zaad: e.target.value }
                  })}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold text-slate-900"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('sahal_number')}</label>
                <input 
                  type="text" 
                  value={formData.paymentNumbers.sahal}
                  onChange={(e) => setFormData({
                    ...formData, 
                    paymentNumbers: { ...formData.paymentNumbers, sahal: e.target.value }
                  })}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold text-slate-900"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('merchant_number')}</label>
                <input 
                  type="text" 
                  value={formData.paymentNumbers.merchant}
                  onChange={(e) => setFormData({
                    ...formData, 
                    paymentNumbers: { ...formData.paymentNumbers, merchant: e.target.value }
                  })}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold text-slate-900"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('bank_number')}</label>
                <input 
                  type="text" 
                  value={formData.paymentNumbers.bank}
                  onChange={(e) => setFormData({
                    ...formData, 
                    paymentNumbers: { ...formData.paymentNumbers, bank: e.target.value }
                  })}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold text-slate-900"
                />
              </div>
            </div>
          </div>

          {tenant.modules.utility_water && (
            <div className="pt-6 border-t border-slate-100 space-y-6">
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">{t('utility_settings')} - Water</h3>
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Water Rate ($ per m³)</label>
                <input 
                  type="number" step="0.01"
                  value={formData.utilitySettings.waterRate}
                  onChange={(e) => setFormData({
                    ...formData, 
                    utilitySettings: { ...formData.utilitySettings, waterRate: parseFloat(e.target.value) || 0 }
                  })}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold text-slate-900"
                />
              </div>
            </div>
          )}

          {tenant.modules.utility_electricity && (
            <div className="pt-6 border-t border-slate-100 space-y-6">
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">{t('utility_settings')} - Electricity</h3>
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Electricity Rate ($ per kWh)</label>
                <input 
                  type="number" step="0.01"
                  value={formData.utilitySettings.electricityRate}
                  onChange={(e) => setFormData({
                    ...formData, 
                    utilitySettings: { ...formData.utilitySettings, electricityRate: parseFloat(e.target.value) || 0 }
                  })}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold text-slate-900"
                />
              </div>
            </div>
          )}

          <div className="pt-6 border-t border-slate-100">
            <button 
              type="submit" 
              disabled={saving}
              className="w-full sm:w-auto px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <Save size={18} />
              {saving ? t('saving') : t('save_changes')}
            </button>
          </div>
        </form>
      </div>

      <div className="bg-slate-50 rounded-2xl p-8 border border-slate-100">
        <h3 className="font-bold text-slate-900 mb-4">{t('active_modules')}</h3>
        <div className="flex flex-wrap gap-2">
          {Object.entries(tenant.modules || {}).map(([key, isActive]) => isActive && (
            <span key={key} className="px-3 py-1 bg-white border border-slate-200 text-slate-600 text-xs font-bold uppercase tracking-wider rounded-lg shadow-sm">
              {t(`role_${key}` as any)}
            </span>
          ))}
        </div>
        <p className="text-xs text-slate-400 mt-4">{t('contact_system_manager')}</p>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-8 space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center text-amber-600">
              <RefreshCcw size={20} />
            </div>
            <div>
              <h3 className="font-bold text-slate-900">{t('data_management')}</h3>
              <p className="text-xs text-slate-500">{t('data_management_desc')}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <button
              onClick={handleExportExcel}
              disabled={exporting !== null}
              className="flex items-center justify-center gap-2 px-6 py-3 bg-emerald-50 text-emerald-600 rounded-xl font-bold hover:bg-emerald-100 transition-all disabled:opacity-50"
            >
              <TableIcon size={18} />
              {exporting === 'excel' ? t('downloading') : t('export_excel')}
            </button>

            <button
              onClick={handleExportPDF}
              disabled={exporting !== null}
              className="flex items-center justify-center gap-2 px-6 py-3 bg-rose-50 text-rose-600 rounded-xl font-bold hover:bg-rose-100 transition-all disabled:opacity-50"
            >
              <FileText size={18} />
              {exporting === 'pdf' ? t('downloading') : t('export_pdf')}
            </button>

            <button
              onClick={handleBackupData}
              className="flex items-center justify-center gap-2 px-6 py-3 bg-slate-100 text-slate-700 rounded-xl font-bold hover:bg-slate-200 transition-all"
            >
              <Download size={18} />
              {t('backup_data')} (JSON)
            </button>

            <div className="relative">
              <button
                className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-indigo-50 text-indigo-600 rounded-xl font-bold hover:bg-indigo-100 transition-all"
              >
                <RefreshCcw size={18} />
                {t('restore_data')}
              </button>
              <input
                type="file"
                accept=".json"
                onChange={handleRestoreData}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
            </div>
          </div>

          <div className="pt-6 border-t border-slate-100">
            {!showDeleteConfirm ? (
              <button
                onClick={() => setShowDeleteConfirm(true)}
                className="flex items-center gap-2 text-rose-600 font-bold text-sm hover:text-rose-700 transition-colors"
              >
                <Trash2 size={18} />
                {t('delete_all_data')}
              </button>
            ) : (
              <div className="bg-rose-50 border border-rose-100 rounded-xl p-4 space-y-4">
                <p className="text-sm text-rose-700 font-medium">
                  {t('delete_data_confirm')}
                </p>
                <div className="flex gap-3">
                  <button
                    onClick={handleDeleteAllData}
                    disabled={deleting}
                    className="px-4 py-2 bg-rose-600 text-white rounded-lg text-sm font-bold hover:bg-rose-700 disabled:opacity-50"
                  >
                    {deleting ? t('loading') : t('delete_all_data')}
                  </button>
                  <button
                    onClick={() => setShowDeleteConfirm(false)}
                    className="px-4 py-2 bg-white border border-slate-200 text-slate-600 rounded-lg text-sm font-bold hover:bg-slate-50"
                  >
                    {t('cancel')}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-8 space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-100 rounded-xl flex items-center justify-center text-indigo-600">
              <Upload size={20} />
            </div>
            <div>
              <h3 className="font-bold text-slate-900">{t('bulk_import')}</h3>
              <p className="text-xs text-slate-500">{t('bulk_import_desc')}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('select_table')}</label>
              <select 
                value={importTable}
                onChange={(e) => setImportTable(e.target.value)}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold text-slate-900 appearance-none"
                style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' fill=\'none\' viewBox=\'0 0 24 24\' stroke=\'currentColor\'%3E%3Cpath stroke-linecap=\'round\' stroke-linejoin=\'round\' stroke-width=\'2\' d=\'M19 9l-7 7-7-7\'/%3E%3C/svg%3E")', backgroundRepeat: 'no-repeat', backgroundPosition: 'right 1rem center', backgroundSize: '1.25rem' }}
              >
                <option value="inventory">{t('inventory')}</option>
                <option value="customers">{t('customers')}</option>
                <option value="expenses">{t('expenses')}</option>
                <option value="debts">{t('debts')}</option>
                <option value="services">{t('services')}</option>
                <option value="staff">{t('staff')}</option>
              </select>
            </div>

            <div className="flex flex-col gap-2">
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">&nbsp;</label>
              <button
                onClick={downloadTemplate}
                className="flex items-center justify-center gap-2 px-6 py-3 bg-slate-100 text-slate-700 rounded-xl font-bold hover:bg-slate-200 transition-all"
              >
                <Download size={18} />
                {t('download_template')}
              </button>
            </div>
          </div>

          <div className="relative">
            {importError && (
              <div className="mb-4 p-4 bg-rose-50 border border-rose-100 rounded-xl text-rose-600 text-xs font-medium">
                <p className="font-bold mb-1">Cilad ayaa dhacday intii lagu guda jiray soo dejinta:</p>
                <p>{importError}</p>
              </div>
            )}
            <button
              disabled={importing}
              className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all disabled:opacity-50 shadow-lg shadow-indigo-100"
            >
              <Upload size={20} />
              {importing ? t('loading') : t('bulk_import')}
            </button>
            <input
              type="file"
              accept=".xlsx, .xls, .csv"
              onChange={handleBulkImport}
              disabled={importing}
              className="absolute inset-0 opacity-0 cursor-pointer"
            />
          </div>
        </div>
      </div>
    </>
  )}

  {/* Password Change Section - Visible to everyone */}
  <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
    <div className="p-8 space-y-6">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600">
          <Lock size={20} />
        </div>
        <div>
          <h3 className="font-bold text-slate-900">{t('change_password')}</h3>
          <p className="text-xs text-slate-500">Beddel ereygaaga sirta ah si aad u sugto amniga akoonkaaga.</p>
        </div>
      </div>

      <form onSubmit={handlePasswordChange} className="space-y-4">
        {passwordMessage && (
          <div className={`p-4 rounded-xl text-sm font-bold flex items-center gap-2 ${passwordMessage.type === 'success' ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
            <AlertCircle size={18} />
            {passwordMessage.text}
          </div>
        )}

        <div className="grid grid-cols-1 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('current_password')}</label>
            <div className="relative">
              <input 
                required
                type={showPasswords.current ? "text" : "password"}
                value={passwordData.currentPassword}
                onChange={(e) => setPasswordData({...passwordData, currentPassword: e.target.value})}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold text-slate-900"
                placeholder="••••••••"
              />
              <button
                type="button"
                onClick={() => setShowPasswords({...showPasswords, current: !showPasswords.current})}
                className="absolute inset-y-0 right-0 pr-4 flex items-center text-slate-400 hover:text-slate-600"
              >
                {showPasswords.current ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('new_password')}</label>
            <div className="relative">
              <input 
                required
                type={showPasswords.new ? "text" : "password"}
                value={passwordData.newPassword}
                onChange={(e) => setPasswordData({...passwordData, newPassword: e.target.value})}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold text-slate-900"
                placeholder="••••••••"
              />
              <button
                type="button"
                onClick={() => setShowPasswords({...showPasswords, new: !showPasswords.new})}
                className="absolute inset-y-0 right-0 pr-4 flex items-center text-slate-400 hover:text-slate-600"
              >
                {showPasswords.new ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('confirm_new_password')}</label>
            <div className="relative">
              <input 
                required
                type={showPasswords.confirm ? "text" : "password"}
                value={passwordData.confirmPassword}
                onChange={(e) => setPasswordData({...passwordData, confirmPassword: e.target.value})}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold text-slate-900"
                placeholder="••••••••"
              />
              <button
                type="button"
                onClick={() => setShowPasswords({...showPasswords, confirm: !showPasswords.confirm})}
                className="absolute inset-y-0 right-0 pr-4 flex items-center text-slate-400 hover:text-slate-600"
              >
                {showPasswords.confirm ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>
        </div>

        <button 
          type="submit" 
          disabled={passwordSaving}
          className="w-full sm:w-auto px-8 py-3 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-800 transition-all shadow-lg shadow-slate-200 disabled:opacity-50 flex items-center justify-center gap-2"
        >
          <Save size={18} />
          {passwordSaving ? t('saving') : t('change_password')}
        </button>
      </form>
    </div>
  </div>
</div>
  );
}
