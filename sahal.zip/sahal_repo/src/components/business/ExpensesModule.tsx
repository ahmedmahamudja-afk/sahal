import React, { useState, useEffect } from 'react';
import { supabase } from '../../supabase';
import { Expense, UserProfile, Tenant } from '../../types';
import { Receipt, Plus, Search, Trash2, Calendar, RefreshCw, FileDown, Table, Printer, AlertCircle, Edit2 } from 'lucide-react';
import { useLanguage } from '../LanguageContext';
import { filterByDate } from '../../lib/dateUtils';
import DateSelector from '../DateSelector';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import Modal from '../Modal';

export default function ExpensesModule({ user }: { user: UserProfile }) {
  const { t } = useLanguage();
  const [tenant, setTenant] = useState<Tenant | null>(null);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [branches, setBranches] = useState<any[]>([]);
  const [selectedBranchId, setSelectedBranchId] = useState<string>(user.branchId || '');
  const [accounts, setAccounts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [mode, setMode] = useState<'day' | 'month' | 'year' | 'range'>('day');
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  const openConfirm = (title: string, message: string, onConfirm: () => void) => {
    setConfirmModal({
      isOpen: true,
      title,
      message,
      onConfirm: () => {
        onConfirm();
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const RenderConfirmModal = () => (
    <Modal 
      isOpen={confirmModal.isOpen} 
      onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))} 
      title={confirmModal.title}
      contentClassName="max-w-sm"
    >
      <div className="space-y-6">
        <div className="flex items-center gap-4 p-4 bg-rose-50 rounded-2xl text-rose-600">
          <Trash2 size={24} />
          <p className="text-sm font-medium">{confirmModal.message}</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
            className="flex-1 px-4 py-2 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 transition-all"
          >
            {t('cancel')}
          </button>
          <button 
            onClick={confirmModal.onConfirm}
            className="flex-1 px-4 py-2 bg-rose-600 text-white rounded-xl font-bold hover:bg-rose-700 transition-all shadow-lg shadow-rose-200"
          >
            {t('delete')}
          </button>
        </div>
      </div>
    </Modal>
  );

  const getLocalDateString = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const [formData, setFormData] = useState({
    category: 'rent',
    description: '',
    amount: 0,
    date: getLocalDateString(new Date()),
    paymentMethod: '',
    status: 'paid' as 'paid' | 'pending',
    branchId: user.branchId || ''
  });

  const fetchExpenses = async () => {
    if (!user.tenantId) return;
    setLoading(true);
    try {
      const { data: tenantData } = await supabase
        .from('tenants')
        .select('*')
        .eq('id', user.tenantId)
        .single();
        
      if (tenantData) {
        setTenant(tenantData);
        if (tenantData.is_multi_branch) {
          const { data: branchData } = await supabase.from('branches').select('*').eq('tenant_id', user.tenantId);
          if (branchData) {
            setBranches(branchData);
            // Default form branch to first branch if user has none
            if (!user.branchId && branchData.length > 0 && !formData.branchId) {
              setFormData(prev => ({ ...prev, branchId: branchData[0].id }));
            }
          }
        }
      }
      
      const activeBranchId = selectedBranchId || user.branchId;
      let query = supabase.from('expenses').select('*').eq('tenant_id', user.tenantId);
      if (activeBranchId) {
          query = query.eq('branch_id', activeBranchId);
      }
      const { data: expData, error } = await query;
        
      let accQuery = supabase.from('accounts').select('*').eq('tenant_id', user.tenantId);
      if (activeBranchId) accQuery = accQuery.or(`branch_id.eq.${activeBranchId},branch_id.is.null`);
      const { data: accData } = await accQuery;

      if (accData) {
        setAccounts(accData);
      }
        
      console.log("Fetched expenses:", expData, "Error:", error);
        
      if (expData) {
        setExpenses(expData.map(e => ({
          id: e.id,
          category: e.category,
          description: e.description,
          amount: e.amount,
          date: e.date,
          tenantId: e.tenant_id,
          branchId: e.branch_id,
          createdAt: e.created_at,
          status: e.status || 'paid',
          approvalStatus: e.approval_status || 'approved'
        })));
      } else {
        setExpenses([]);
      }
    } catch (error) {
      console.error("Error fetching expenses:", error);
    } finally {
      setLoading(false);
    }
  };

  const [showReceipt, setShowReceipt] = useState(false);
  const [lastExpense, setLastExpense] = useState<any>(null);

  useEffect(() => {
    fetchExpenses();
    
    const channel = supabase
      .channel('expenses-channel')
      .on('postgres_changes', { 
        event: '*', 
        schema: 'public', 
        table: 'expenses',
        filter: `tenant_id=eq.${user.tenantId}` 
      }, (payload) => {
        console.log('Change received!', payload);
        fetchExpenses();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user.tenantId, selectedBranchId]);

  const [editingExpenseId, setEditingExpenseId] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.tenantId || submitting) return;
    setSubmitting(true);
    try {
      const activeBranchId = formData.branchId || user.branchId;
      const isStaff = user.role === 'staff';

      if (editingExpenseId) {
        // Find existing expense to check status
        const existingExp = expenses.find(e => e.id === editingExpenseId);
        const wasPending = existingExp?.status === 'pending';
        const isPaid = formData.status === 'paid';

        // Update existing expense
        const { error: updError } = await supabase.from('expenses').update({
          category: formData.category,
          description: formData.description,
          amount: formData.amount,
          date: formData.date,
          status: formData.status,
          branch_id: activeBranchId || null,
        }).eq('id', editingExpenseId);

        if (updError) throw updError;

        // If it was pending and is now paid, deduct from balance
        if (wasPending && isPaid && formData.amount > 0 && formData.paymentMethod && !isStaff) {
          // Re-use mark as paid logic or similar
          let accQuery = supabase
            .from('accounts')
            .select('*')
            .eq('tenant_id', user.tenantId)
            .eq('name', formData.paymentMethod);
          
          if (activeBranchId) accQuery = accQuery.or(`branch_id.eq.${activeBranchId},branch_id.is.null`);
          let { data: accData } = await accQuery.maybeSingle();
          
          if (accData) {
            await supabase
              .from('accounts')
              .update({ balance: accData.balance - formData.amount })
              .eq('id', accData.id);

            await supabase.from('account_transactions').insert({
              from_account_id: accData.id,
              amount: formData.amount,
              type: 'expense',
              description: `Expense (Paid via Edit): ${formData.description}`,
              tenant_id: user.tenantId,
              branch_id: activeBranchId || null,
              reference_id: editingExpenseId,
              created_at: new Date().toISOString()
            });
          }
        }
      } else {
        // Insert new expense
        const { data: expenseData, error: expError } = await supabase.from('expenses').insert({
          category: formData.category,
          description: formData.description,
          amount: formData.amount,
          date: formData.date,
          status: formData.status,
          approval_status: isStaff ? 'pending' : 'approved',
          tenant_id: user.tenantId,
          branch_id: activeBranchId || null,
          created_at: new Date().toISOString()
        }).select().single();
        
        if (expError) throw expError;

        // Update Account Balance ONLY if status is 'paid' AND not awaiting approval
        if (formData.amount > 0 && formData.status === 'paid' && formData.paymentMethod && !isStaff) {
          // Find or create account
          let accQuery = supabase
            .from('accounts')
            .select('*')
            .eq('tenant_id', user.tenantId)
            .eq('name', formData.paymentMethod);
          
          if (activeBranchId) accQuery = accQuery.or(`branch_id.eq.${activeBranchId},branch_id.is.null`);

          let { data: accData } = await accQuery.maybeSingle();
          
          if (!accData) {
            const { data: newAcc } = await supabase
              .from('accounts')
              .insert({ 
                name: formData.paymentMethod, 
                balance: -formData.amount, 
                tenant_id: user.tenantId,
                branch_id: activeBranchId || null
              })
              .select()
              .single();
            accData = newAcc;
          } else {
            await supabase
              .from('accounts')
              .update({ balance: accData.balance - formData.amount })
              .eq('id', accData.id);
          }

          // Log Transaction
          if (accData) {
            await supabase.from('account_transactions').insert({
              from_account_id: accData.id,
              amount: formData.amount,
              type: 'expense',
              description: `Expense: ${formData.description}`,
              tenant_id: user.tenantId,
              branch_id: activeBranchId || null,
              reference_id: expenseData.id,
              created_at: new Date().toISOString()
            });
          }
        }
      }
      
      setIsModalOpen(false);
      setEditingExpenseId(null);
      setFormData({ 
        category: 'rent', 
        description: '', 
        amount: 0, 
        date: getLocalDateString(new Date()), 
        paymentMethod: '', 
        status: 'paid',
        branchId: user.branchId || (branches.length > 0 ? branches[0].id : '')
      });
      fetchExpenses();
    } catch (error) {
      console.error("Error saving expense:", error);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!user.tenantId) return;
    openConfirm(t('delete'), t('delete_expense_confirm'), async () => {
      try {
        const { error } = await supabase.from('expenses').delete().eq('id', id);
        if (error) throw error;
        fetchExpenses();
      } catch (error) {
        console.error("Error deleting expense:", error);
      }
    });
  };

  const handleMarkAsPaid = async (expense: Expense, paymentMethod: string) => {
    if (!user.tenantId || submitting) return;
    setSubmitting(true);
    try {
      // 1. Update status to 'paid'
      const { error: updError } = await supabase
        .from('expenses')
        .update({ status: 'paid' })
        .eq('id', expense.id);
      
      if (updError) throw updError;

      // 2. Update Account Balance
      const activeBranchId = expense.branchId || user.branchId;
      let accQuery = supabase
        .from('accounts')
        .select('*')
        .eq('tenant_id', user.tenantId)
        .eq('name', paymentMethod);
      
      if (activeBranchId) accQuery = accQuery.or(`branch_id.eq.${activeBranchId},branch_id.is.null`);

      let { data: accData } = await accQuery.maybeSingle();
      
      if (!accData) {
        const { data: newAcc } = await supabase
          .from('accounts')
          .insert({ 
            name: paymentMethod, 
            balance: -expense.amount, 
            tenant_id: user.tenantId,
            branch_id: expense.branchId || null
          })
          .select()
          .single();
        accData = newAcc;
      } else {
        await supabase
          .from('accounts')
          .update({ balance: accData.balance - expense.amount })
          .eq('id', accData.id);
      }

      // 3. Log Transaction
      if (accData) {
        await supabase.from('account_transactions').insert({
          from_account_id: accData.id,
          amount: expense.amount,
          type: 'expense',
          description: `Expense (Paid): ${expense.description}`,
          tenant_id: user.tenantId,
          branch_id: activeBranchId || null,
          reference_id: expense.id,
          created_at: new Date().toISOString()
        });
      }

      fetchExpenses();
    } catch (error) {
      console.error("Error marking as paid:", error);
    } finally {
      setSubmitting(false);
      setPayingExpense(null);
    }
  };

  const [payingExpense, setPayingExpense] = useState<Expense | null>(null);
  const [payMethod, setPayMethod] = useState('');

  const handleApprove = async (id: string) => {
    if (!user.tenantId || user.role === 'staff') return;
    try {
      await supabase.from('expenses').update({ approval_status: 'approved' }).eq('id', id);
      fetchExpenses();
    } catch (error) {
      console.error("Error approving expense:", error);
    }
  };

  const handleReject = async (id: string) => {
    if (!user.tenantId || user.role === 'staff') return;
    try {
      await supabase.from('expenses').update({ approval_status: 'rejected' }).eq('id', id);
      fetchExpenses();
    } catch (error) {
      console.error("Error rejecting expense:", error);
    }
  };

  const filteredExpenses = expenses.filter(e => {
    const expDateStr = e.date ? e.date.substring(0, 10) : e.createdAt;
    return filterByDate(expDateStr, selectedDate, mode, startDate, endDate);
  }).sort((a, b) => new Date(b.date || b.createdAt).getTime() - new Date(a.date || a.createdAt).getTime());

  const downloadPDF = () => {
    let doc: any;
    try {
      doc = new jsPDF();
    } catch (e) {
      console.error("Error creating PDF:", e);
      return;
    }
    const businessName = tenant?.name || t('business_name_placeholder');
    const location = tenant?.location || '';
    const contact = tenant?.contact || '';
    
    // Header
    let yPos = 20;
    doc.setFontSize(20);
    doc.setTextColor(79, 70, 229); // Indigo-600
    doc.text(businessName, 14, yPos);
    yPos += 8;

    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139); // Slate-500
    if (location) {
      doc.text(location, 14, yPos);
      yPos += 5;
    }
    if (contact) {
      doc.text(contact, 14, yPos);
      yPos += 5;
    }
    
    yPos += 2;
    doc.setFontSize(12);
    const dateStr = mode === 'range' 
      ? `${startDate.toLocaleDateString()} - ${endDate.toLocaleDateString()}`
      : selectedDate.toLocaleDateString();
    doc.text(`${t('expenses_report')} (${dateStr})`, 14, yPos);
    yPos += 10;

    const tableColumn = [t('date'), t('expense_type'), t('description'), t('amount')];
    const tableRows: any[] = [];

    filteredExpenses.forEach(exp => {
      const rowData = [
        new Date(exp.date || exp.createdAt || '').toLocaleDateString(),
        t(exp.category as any),
        exp.description,
        `$${(exp.amount || 0).toFixed(2)}`
      ];
      tableRows.push(rowData);
    });

    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: yPos,
      theme: 'grid',
      styles: { fontSize: 8, cellPadding: 3 },
      headStyles: { fillColor: [79, 70, 229], textColor: [255, 255, 255], fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [248, 250, 252] }
    });

    doc.save(`${businessName}_expenses_report_${dateStr.replace(/\//g, '-')}.pdf`);
  };

  const downloadExcel = () => {
    const businessName = tenant?.name || t('business_name_placeholder');
    const location = tenant?.location || '';
    const contact = tenant?.contact || '';

    const dateStr = mode === 'range' 
      ? `${startDate.toLocaleDateString()} - ${endDate.toLocaleDateString()}`
      : selectedDate.toLocaleDateString();

    const fileNameDate = mode === 'range' 
      ? `${startDate.toLocaleDateString()}_to_${endDate.toLocaleDateString()}`
      : selectedDate.toLocaleDateString();

    // Create header rows
    const headerRows = [
      [businessName],
      [location],
      [contact],
      [`${t('expenses_report')} (${dateStr})`],
      [] // Empty row
    ];

    const dataRows = filteredExpenses.map(exp => [
      new Date(exp.date || exp.createdAt || '').toLocaleDateString(),
      t(exp.category as any),
      exp.description,
      exp.amount
    ]);

    const tableHeader = [t('date'), t('expense_type'), t('description'), t('amount')];
    
    const allRows = [...headerRows, tableHeader, ...dataRows];
    const worksheet = XLSX.utils.aoa_to_sheet(allRows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Expenses");
    
    XLSX.writeFile(workbook, `${businessName}_expenses_report_${fileNameDate.replace(/\//g, '-')}.xlsx`);
  };

  const totalExpenses = filteredExpenses.reduce((sum, exp) => sum + exp.amount, 0);
  const totalPending = filteredExpenses.filter(e => e.status === 'pending').reduce((sum, exp) => sum + exp.amount, 0);

  const uniqueCategories = React.useMemo(() => {
    const cats = expenses.map(e => e.category).filter(Boolean);
    return Array.from(new Set(cats));
  }, [expenses]);

  if (loading) return <div className="p-8 text-center text-slate-500">{t('loading')}</div>;

  console.log("Expenses state:", expenses);
  console.log("Filtered expenses:", filteredExpenses);

  return (
    <div className="space-y-6">
      <RenderConfirmModal />
      
      {/* Header Section */}
      <div className="bg-white p-4 sm:p-6 rounded-2xl border border-slate-100 shadow-sm space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600 shadow-inner">
              <Receipt size={24} />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-display font-bold text-slate-900 leading-tight">
                {t('expenses_record')}
              </h2>
              <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">
                {t('manage_business_expenses' as any) || 'Manage business expenses'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
            <button 
              onClick={() => setIsModalOpen(true)}
              className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-indigo-600 text-white px-5 py-2.5 rounded-xl text-sm font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 active:scale-95"
            >
              <Plus size={18} /> {t('record_expense')}
            </button>
            <button 
              onClick={fetchExpenses}
              disabled={loading}
              className={`flex items-center justify-center gap-2 bg-slate-50 text-slate-700 px-4 py-2.5 rounded-xl text-sm font-bold border border-slate-200 hover:bg-slate-100 transition-all ${loading ? 'opacity-50 cursor-not-allowed' : 'active:scale-95'}`}
            >
              <RefreshCw size={18} className={loading ? 'animate-spin' : ''} />
              <span className="hidden sm:inline">{loading ? t('refreshing') : t('refresh')}</span>
            </button>
          </div>
        </div>

        <div className="h-px bg-slate-100 w-full" />

        <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 w-full xl:w-auto">
            {tenant?.is_multi_branch && !user.branchId && (
              <select
                value={selectedBranchId}
                onChange={(e) => setSelectedBranchId(e.target.value)}
                className="w-full sm:w-auto px-5 py-2.5 bg-indigo-50 border border-indigo-100 text-indigo-700 rounded-xl font-bold hover:bg-indigo-100 transition-all shadow-sm outline-none cursor-pointer"
              >
                <option value="">{t('all_branches')}</option>
                {branches.map(b => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            )}
            <div className="w-full sm:w-auto px-4 py-2 rounded-xl text-sm font-bold flex items-center justify-center sm:justify-start gap-2 border bg-rose-50 text-rose-600 border-rose-100">
              <AlertCircle size={18} />
              <span className="whitespace-nowrap">
                {t('total_expenses' as any) || 'Total Expenses'}: 
                <span className="ml-1 text-lg">${(totalExpenses || 0).toFixed(2)}</span>
              </span>
            </div>
            <div className="w-full sm:w-auto px-4 py-2 rounded-xl text-sm font-bold flex items-center justify-center sm:justify-start gap-2 border bg-amber-50 text-amber-600 border-amber-100">
              <Calendar size={18} />
              <span className="whitespace-nowrap">
                {t('unpaid_expenses' as any) || 'Unpaid'}: 
                <span className="ml-1 text-lg">${(totalPending || 0).toFixed(2)}</span>
              </span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 w-full xl:w-auto">
            <div className="w-full sm:w-auto">
              <DateSelector 
                selectedDate={selectedDate} 
                onChange={setSelectedDate} 
                mode={mode} 
                onModeChange={setMode} 
                startDate={startDate}
                endDate={endDate}
                onRangeChange={(start, end) => {
                  setStartDate(start);
                  setEndDate(end);
                }}
              />
            </div>
            
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button 
                onClick={() => window.print()}
                disabled={filteredExpenses.length === 0}
                className="flex-1 sm:flex-none bg-slate-800 text-white p-2.5 rounded-xl text-sm font-bold shadow-lg shadow-slate-100 hover:bg-slate-900 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                title={t('print')}
              >
                <Printer size={18} />
                <span className="xl:hidden">{t('print')}</span>
              </button>
              <button 
                onClick={downloadPDF}
                disabled={filteredExpenses.length === 0}
                className="flex-1 sm:flex-none bg-emerald-600 text-white px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold shadow-lg shadow-emerald-50 hover:bg-emerald-700 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                title={t('download_pdf')}
              >
                <FileDown size={18} />
                <span>{t('download_pdf')}</span>
              </button>
              <button 
                onClick={downloadExcel}
                disabled={filteredExpenses.length === 0}
                className="flex-1 sm:flex-none bg-blue-600 text-white p-2.5 rounded-xl text-sm font-bold shadow-lg shadow-blue-50 hover:bg-blue-700 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                title={t('download_excel')}
              >
                <Table size={18} />
                <span className="xl:hidden">{t('download_excel')}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-3 w-full max-w-sm">
            <Search size={18} className="text-slate-400" />
            <input 
              type="text" 
              placeholder={t('search_expense')} 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-transparent border-none focus:outline-none text-sm w-full"
            />
          </div>
          <div className="text-sm font-bold text-slate-500">
            {t('total')}: <span className="text-rose-600">${(totalExpenses || 0).toFixed(2)}</span>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-bg-sec text-[10px] font-bold uppercase tracking-[0.2em] text-ink-tertiary border-b border-border-main">
              <tr>
                <th className="px-6 py-4">{t('date')} & {t('type')}</th>
                {tenant?.is_multi_branch && <th className="px-6 py-4">{t('branch')}</th>}
                <th className="px-6 py-4">{t('description')}</th>
                <th className="px-6 py-4 text-center">{t('approval_status')}</th>
                <th className="px-6 py-4 text-center">{t('payment_status')}</th>
                <th className="px-6 py-4 text-center">{t('amount')}</th>
                <th className="px-6 py-4 text-right">{t('actions')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border-main">
              {filteredExpenses.map(exp => (
                <tr key={exp.id} className={`hover:bg-bg-sec/50 transition-colors group border-b border-border-main last:border-0 ${exp.status === 'pending' || exp.approvalStatus === 'pending' ? 'bg-amber-50/20' : ''}`}>
                  <td className="px-6 py-5">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-1.5 text-xs font-black text-ink uppercase tracking-tight">
                        <Calendar size={12} className="text-accent-main opacity-60" />
                        {exp.date}
                      </div>
                      <span className="w-fit px-1.5 py-0.5 rounded bg-bg-sec text-[8px] font-black text-ink-tertiary uppercase tracking-tighter border border-border-main/50 shadow-sm">
                        {t(exp.category as any)}
                      </span>
                    </div>
                  </td>
                  {tenant?.is_multi_branch && (
                    <td className="px-6 py-5">
                      <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-lg">
                        {branches.find(b => b.id === exp.branchId)?.name || '-'}
                      </span>
                    </td>
                  )}
                  <td className="px-6 py-5">
                    <div className="max-w-[300px]">
                      <p className="text-sm font-bold text-ink leading-snug truncate group-hover:whitespace-normal group-hover:line-clamp-none line-clamp-1 transition-all">
                        {exp.description}
                      </p>
                      <div className="flex items-center gap-1 mt-1 opacity-40">
                        <span className="text-[8px] font-black uppercase tracking-widest">{t('id' as any) || 'ID'}: {exp.id.slice(0, 8)}</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-5 text-center">
                    <span className={`px-2 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest ${
                      exp.approvalStatus === 'pending' 
                        ? 'bg-amber-100 text-amber-700 border border-amber-200' 
                        : exp.approvalStatus === 'rejected'
                        ? 'bg-rose-100 text-rose-700 border border-rose-200'
                        : 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                    }`}>
                      {exp.approvalStatus === 'pending' ? t('awaiting_approval') : exp.approvalStatus === 'rejected' ? t('rejected') : t('approved')}
                    </span>
                  </td>
                  <td className="px-6 py-5 text-center">
                    <span className={`px-2 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest ${
                      exp.status === 'pending' 
                        ? 'bg-amber-100 text-amber-700 border border-amber-200' 
                        : 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                    }`}>
                      {exp.status === 'pending' ? t('pending') : t('paid')}
                    </span>
                  </td>
                  <td className="px-6 py-5 text-center">
                    <div className="flex flex-col items-center">
                      <span className="text-sm font-black text-rose-600 font-mono tracking-tighter">-${(exp.amount || 0).toLocaleString()}</span>
                      <span className="text-[8px] font-black text-ink-tertiary uppercase opacity-40 mt-0.5">
                        {exp.status === 'pending' ? t('not_paid' as any) || 'Not Paid' : `Paid via ${exp.paymentMethod || 'Cash'}`}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-5 text-right whitespace-nowrap">
                    <div className="flex justify-end gap-1 transition-all duration-300">
                      {user.role !== 'staff' && exp.approvalStatus === 'pending' && (
                        <>
                          <button 
                            onClick={() => handleApprove(exp.id)}
                            className="px-3 py-1 bg-emerald-600 text-white rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-sm shadow-emerald-100"
                          >
                            {t('approve')}
                          </button>
                          <button 
                            onClick={() => handleReject(exp.id)}
                            className="px-3 py-1 bg-rose-600 text-white rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-rose-700 transition-all shadow-sm shadow-rose-100"
                          >
                            {t('reject')}
                          </button>
                        </>
                      )}
                      {exp.status === 'pending' && exp.approvalStatus === 'approved' && (
                        <button 
                          onClick={() => setPayingExpense(exp)}
                          className="px-3 py-1 bg-amber-600 text-white rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-amber-700 transition-all shadow-sm shadow-amber-100"
                        >
                          {t('mark_as_paid')}
                        </button>
                      )}
                      <button 
                        onClick={() => {
                          setFormData({
                            category: exp.category,
                            description: exp.description,
                            amount: exp.amount,
                            date: exp.date || getLocalDateString(new Date()),
                            paymentMethod: '', // Method usually not editable for existing paid records
                            status: exp.status as 'paid' | 'pending',
                            branchId: exp.branchId || ''
                          });
                          setEditingExpenseId(exp.id);
                          setIsModalOpen(true);
                        }}
                        className="p-2 text-ink-tertiary hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all"
                        title={t('edit')}
                      >
                        <Edit2 size={16} strokeWidth={2.5} />
                      </button>
                      <button 
                        onClick={() => {
                          setLastExpense(exp);
                          setShowReceipt(true);
                        }}
                        className="p-2 text-ink-tertiary hover:text-accent-main hover:bg-accent-soft rounded-xl transition-all"
                        title={t('print')}
                      >
                        <Printer size={16} strokeWidth={2.5} />
                      </button>
                      <button 
                        onClick={() => handleDelete(exp.id)} 
                        className="p-2 text-ink-tertiary hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all"
                        title={t('delete')}
                      >
                        <Trash2 size={16} strokeWidth={2.5} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredExpenses.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-slate-400">
                    {t('no_expenses_found')}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && (
        <Modal 
          isOpen={isModalOpen} 
          onClose={() => {
            setIsModalOpen(false);
            setEditingExpenseId(null);
          }} 
          title={editingExpenseId ? t('edit_expense' as any) || 'Edit Expense' : t('record_expense')}
        >
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('expense_type')}</label>
              <input 
                required 
                type="text"
                value={formData.category} 
                onChange={e => setFormData({...formData, category: e.target.value})} 
                className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                placeholder={t('expense_type')}
                list="expense-category-suggestions"
              />
              <datalist id="expense-category-suggestions">
                {['rent', 'utilities', 'salary', 'supplies', 'maintenance', 'marketing', 'other_expense'].map(def => (
                  <option key={def} value={def}>{t(def as any)}</option>
                ))}
                {uniqueCategories.filter(c => !['rent', 'utilities', 'salary', 'supplies', 'maintenance', 'marketing', 'other_expense'].includes(c)).map(cat => (
                  <option key={cat} value={cat} />
                ))}
              </datalist>
            </div>
            {tenant?.is_multi_branch && (
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('branch')}</label>
                <select 
                  required 
                  value={formData.branchId} 
                  onChange={e => setFormData({...formData, branchId: e.target.value})} 
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 bg-white"
                >
                  <option value="" disabled>{t('select_branch')}</option>
                  {branches.map(b => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </select>
              </div>
            )}
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('description')}</label>
              <input required type="text" value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20" placeholder={t('expense_desc_placeholder')} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('amount')} ($)</label>
                <input required type="number" step="0.01" value={formData.amount} onChange={e => setFormData({...formData, amount: parseFloat(e.target.value) || 0})} className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20" />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('date')}</label>
                <input required type="date" value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20" />
              </div>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('payment_status')}</label>
              <div className="flex gap-4">
                <button
                  type="button"
                  onClick={() => setFormData({...formData, status: 'paid'})}
                  className={`flex-1 px-4 py-2 rounded-xl text-xs font-bold transition-all border ${
                    formData.status === 'paid' 
                      ? 'bg-emerald-600 text-white border-emerald-600 shadow-lg shadow-emerald-100' 
                      : 'bg-white text-slate-500 border-slate-200 hover:border-emerald-200'
                  }`}
                >
                  {t('paid')}
                </button>
                <button
                  type="button"
                  onClick={() => setFormData({...formData, status: 'pending'})}
                  className={`flex-1 px-4 py-2 rounded-xl text-xs font-bold transition-all border ${
                    formData.status === 'pending' 
                      ? 'bg-amber-600 text-white border-amber-600 shadow-lg shadow-amber-100' 
                      : 'bg-white text-slate-500 border-slate-200 hover:border-amber-200'
                  }`}
                >
                  {t('pending')}
                </button>
              </div>
            </div>
            {formData.status === 'paid' && (
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('payment_method')}</label>
                <select 
                  required 
                  value={formData.paymentMethod} 
                  onChange={e => setFormData({...formData, paymentMethod: e.target.value})} 
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 bg-white"
                >
                  <option value="" disabled>{t('select_account' as any) || 'Select Account'}</option>
                  {accounts.filter(acc => (acc.balance || 0) > 0).sort((a, b) => a.name.localeCompare(b.name)).map(acc => (
                    <option key={acc.id} value={acc.name}>
                      {acc.name}
                    </option>
                  ))}
                </select>
              </div>
            )}
            <div className="pt-4 flex gap-3">
              <button type="button" onClick={() => setIsModalOpen(false)} disabled={submitting} className="flex-1 px-4 py-2 border border-slate-200 text-slate-600 rounded-xl font-medium hover:bg-slate-50 disabled:opacity-50">{t('cancel')}</button>
              <button type="submit" disabled={submitting} className="flex-1 px-4 py-2 bg-indigo-600 text-white rounded-xl font-medium hover:bg-indigo-700 disabled:opacity-50">{submitting ? t('saving') || 'Saving...' : t('save_expense')}</button>
            </div>
          </form>
        </Modal>
      )}

      {/* Mark as Paid Modal */}
      {payingExpense && (
        <Modal
          isOpen={!!payingExpense}
          onClose={() => setPayingExpense(null)}
          title={t('mark_as_paid')}
          contentClassName="max-w-sm"
        >
          <div className="space-y-4">
            <div className="bg-amber-50 p-4 rounded-2xl border border-amber-100">
              <p className="text-xs font-bold text-amber-700 uppercase tracking-wider mb-1">{t('amount')}</p>
              <p className="text-2xl font-black text-amber-900">${(payingExpense.amount || 0).toLocaleString()}</p>
              <p className="text-[10px] text-amber-600 mt-2 font-medium">{payingExpense.description}</p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('payment_method')}</label>
              <select 
                required 
                value={payMethod} 
                onChange={e => setPayMethod(e.target.value)} 
                className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 bg-white"
              >
                <option value="" disabled>{t('select_account' as any) || 'Select Account'}</option>
                {accounts.filter(acc => (acc.balance || 0) > 0).sort((a, b) => a.name.localeCompare(b.name)).map(acc => (
                  <option key={acc.id} value={acc.name}>
                    {acc.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="pt-2 flex gap-3">
              <button 
                onClick={() => setPayingExpense(null)} 
                className="flex-1 px-4 py-3 border border-slate-200 text-slate-600 rounded-xl font-bold hover:bg-slate-50"
              >
                {t('cancel')}
              </button>
              <button 
                disabled={!payMethod || submitting}
                onClick={() => handleMarkAsPaid(payingExpense, payMethod)}
                className="flex-1 px-4 py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 disabled:opacity-50 shadow-lg shadow-emerald-100"
              >
                {submitting ? t('processing') : t('confirm')}
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Expense Receipt Modal */}
      {showReceipt && lastExpense && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden">
            <div className="p-8">
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center text-white mx-auto mb-4 shadow-lg shadow-indigo-200">
                  <Receipt size={32} />
                </div>
                <h3 className="text-xl font-bold text-slate-900">{t('expense_receipt' as any) || 'Expense Receipt'}</h3>
                <p className="text-slate-500 text-sm mt-1">{new Date(lastExpense.createdAt).toLocaleString()}</p>
              </div>

              <div className="space-y-4 mb-8">
                <div className="flex justify-between text-sm py-2 border-b border-slate-100">
                  <span className="text-slate-500">{t('expense_type')}:</span>
                  <span className="font-bold text-slate-900 uppercase">{t(lastExpense.category as any)}</span>
                </div>
                <div className="flex justify-between text-sm py-2 border-b border-slate-100">
                  <span className="text-slate-500">{t('description')}:</span>
                  <span className="font-bold text-slate-900">{lastExpense.description}</span>
                </div>
                <div className="flex justify-between text-lg py-4">
                  <span className="font-bold text-slate-900">{t('total_amount')}:</span>
                  <span className="font-bold text-indigo-600">${(lastExpense.amount || 0).toFixed(2)}</span>
                </div>
              </div>

              <div className="flex gap-3 print:hidden">
                <button 
                  onClick={() => setShowReceipt(false)} 
                  className="flex-1 px-4 py-3 border border-slate-200 text-slate-600 rounded-xl font-bold hover:bg-slate-50 transition-colors"
                >
                  {t('close')}
                </button>
                <button 
                  onClick={() => window.print()} 
                  className="flex-1 px-4 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200 flex items-center justify-center gap-2"
                >
                  <Printer size={18} />
                  {t('print')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
