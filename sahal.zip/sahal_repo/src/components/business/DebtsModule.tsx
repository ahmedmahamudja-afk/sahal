import React, { useState, useEffect } from 'react';
import { supabase } from '../../supabase';
import { Debt, UserProfile, Tenant } from '../../types';
import { Wallet, Search, CheckCircle2, Clock, AlertCircle, MessageCircle, Printer, Calendar, Plus, RefreshCw, FileDown, Table, Edit2, Trash2, Users } from 'lucide-react';
import { useLanguage } from '../LanguageContext';
import DateSelector from '../DateSelector';
import Modal from '../Modal';
import { filterByDate } from '../../lib/dateUtils';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';

export default function DebtsModule({ 
  user,
  initialSearch = '',
  onSearchCleared
}: { 
  user: UserProfile,
  initialSearch?: string,
  onSearchCleared?: () => void
}) {
  const { t } = useLanguage();
  const [tenant, setTenant] = useState<Tenant | null>(null);
  const [debts, setDebts] = useState<Debt[]>([]);
  const [branches, setBranches] = useState<any[]>([]);
  const [selectedBranchId, setSelectedBranchId] = useState<string>(user.branchId || '');
  const [utilityDebts, setUtilityDebts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAddDebtModalOpen, setIsAddDebtModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedDebt, setSelectedDebt] = useState<Debt | null>(null);
  const [editingDebt, setEditingDebt] = useState<Debt | null>(null);
  const [paymentAmount, setPaymentAmount] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState<string>('Cash');
  const [selectedAccountId, setSelectedAccountId] = useState<string>('');
  const [accounts, setAccounts] = useState<any[]>([]);
  const [affectAccount, setAffectAccount] = useState(false);
  
  const [newDebt, setNewDebt] = useState({ customerName: '', phone: '', amount: 0, dueDate: '', description: '' });
  const [editDebt, setEditDebt] = useState({ customerName: '', phone: '', amount: 0, dueDate: '', description: '' });
  
  const [showReceipt, setShowReceipt] = useState(false);
  const [lastPayment, setLastPayment] = useState<any>(null);

  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [mode, setMode] = useState<'day' | 'month' | 'year' | 'range' | 'all'>('all');
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());
  const [debtType, setDebtType] = useState<'customer' | 'business'>('customer');

  const fetchData = async () => {
    if (!user.tenantId) return;
    setLoading(true);
    try {
      const { data: tenantData } = await supabase
        .from('tenants')
        .select('*')
        .eq('id', user.tenantId)
        .single();
        
      if (tenantData) {
        setTenant({
          ...tenantData,
          logoUrl: tenantData.logo_url,
          paymentNumbers: tenantData.payment_numbers,
          subscriptionPlan: tenantData.subscription_plan,
          planExpiry: tenantData.plan_expiry,
          isLocked: tenantData.is_locked,
          isMultiBranch: tenantData.is_multi_branch
        });

        if (tenantData.is_multi_branch) {
          const { data: branchData } = await supabase.from('branches').select('*').eq('tenant_id', user.tenantId);
          if (branchData) setBranches(branchData);
        }
      }

      const activeBranchId = selectedBranchId || user.branchId;
      let query = supabase.from('debts').select('*').eq('tenant_id', user.tenantId);
      if (activeBranchId) {
          query = query.or(`branch_id.eq.${activeBranchId},branch_id.is.null`);
      }
      const { data: allDebts, error } = await query;
        
      if (allDebts) {
        const mappedDebts = allDebts.map(d => ({
          id: d.id,
          customerName: d.customer_name,
          phone: d.phone,
          amount: d.amount,
          paidAmount: d.paid_amount,
          status: d.status,
          tenantId: d.tenant_id,
          branchId: d.branch_id,
          createdAt: d.created_at,
          dueDate: d.due_date,
          type: d.type,
          description: d.description
        }));
        
        let accQuery = supabase.from('accounts').select('*').eq('tenant_id', user.tenantId);
        if (activeBranchId) accQuery = accQuery.or(`branch_id.eq.${activeBranchId},branch_id.is.null`);
        const { data: accData } = await accQuery;
        if (accData) {
          setAccounts(accData);
          if (accData.length > 0 && !selectedAccountId) {
            setSelectedAccountId(accData[0].id);
          }
        }
        
        // Fetch Utility Debts if it's customer debt type
        if (debtType === 'customer') {
          const activeBranchId = selectedBranchId || user.branchId;
          let utilityQuery = supabase
            .from('utility_records')
            .select('*')
            .eq('tenant_id', user.tenantId)
            .eq('is_paid', false);
          if (activeBranchId) utilityQuery = utilityQuery.eq('branch_id', activeBranchId);

          const { data: utilityData } = await utilityQuery;
            
          const unpaidUtility = (utilityData || []).map(r => ({
            id: r.id,
            customerName: `${r.home_number} - ${r.owner_name}`,
            phone: r.contact || '',
            amount: r.total_bill,
            paidAmount: 0,
            status: 'unpaid',
            createdAt: r.created_at,
            dueDate: '',
            type: 'customer',
            isUtility: true
          }));
          setUtilityDebts(unpaidUtility);
        } else {
          setUtilityDebts([]);
        }
        
        // Filter by type, default to customer if type is missing
        let initialDebts = mappedDebts.filter(d => (d.type || 'customer') === debtType);

        // Sync with CRM debts for 'customer' type
        if (debtType === 'customer') {
          let custQuery = supabase.from('customers').select('*').eq('tenant_id', user.tenantId).gt('total_debt', 0);
          if (activeBranchId) custQuery = custQuery.or(`branch_id.eq.${activeBranchId},branch_id.is.null`);
          const { data: customerData } = await custQuery;
          
          if (customerData) {
            const adjustmentDebts: any[] = [];
            customerData.forEach(cust => {
              const currentDebtsForCust = mappedDebts.filter(d => d.customerName === cust.name);
              const sumInTable = currentDebtsForCust.reduce((s, d) => s + (d.amount - d.paidAmount), 0);
              const diff = (cust.total_debt || 0) - sumInTable;
              
              if (diff > 0.05) { // Small tolerance for float errors
                adjustmentDebts.push({
                  id: `crm-sync-${cust.id}`,
                  customerName: cust.name,
                  phone: cust.phone || '',
                  amount: diff,
                  paidAmount: 0,
                  status: 'unpaid',
                  tenantId: user.tenantId,
                  branchId: cust.branch_id,
                  createdAt: cust.created_at || new Date().toISOString(),
                  dueDate: '',
                  type: 'customer',
                  description: 'CRM Balance Sync'
                });
              }
            });
            initialDebts = [...initialDebts, ...adjustmentDebts];
          }
        }
        
        setDebts(initialDebts);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    
    const channel = supabase
      .channel('debts-channel')
      .on('postgres_changes', { 
        event: '*', 
        schema: 'public', 
        table: 'debts',
        filter: `tenant_id=eq.${user.tenantId}` 
      }, (payload) => {
        console.log('Change received!', payload);
        fetchData();
      })
      .subscribe();

    const tenantChannel = supabase
      .channel('tenant_changes')
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'tenants', filter: `id=eq.${user.tenantId}` }, (payload) => {
        const tenantData = payload.new;
        if (tenantData) {
          setTenant({
            ...tenantData,
            logoUrl: tenantData.logo_url,
            paymentNumbers: tenantData.payment_numbers,
            subscriptionPlan: tenantData.subscription_plan,
            planExpiry: tenantData.plan_expiry,
            isLocked: tenantData.is_locked,
            isMultiBranch: tenantData.is_multi_branch
          });
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
      supabase.removeChannel(tenantChannel);
    };
  }, [user.tenantId, debtType, selectedBranchId]);

  useEffect(() => {
    if (initialSearch) {
      setSearchTerm(initialSearch);
      onSearchCleared?.();
    }
  }, [initialSearch]);

  const openConfirm = (title: string, message: string, onConfirm: () => void) => {
    setConfirmModal({
      isOpen: true,
      title,
      message,
      onConfirm: () => {
        onConfirm();
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const handleAddDebt = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.tenantId || submitting) return;
    setSubmitting(true);

    try {
      const activeBranchId = selectedBranchId || user.branchId;
      const { data: debtData, error: debtError } = await supabase.from('debts').insert({
        customer_name: newDebt.customerName,
        phone: newDebt.phone,
        amount: newDebt.amount,
        paid_amount: 0,
        status: 'unpaid',
        tenant_id: user.tenantId,
        branch_id: activeBranchId || null,
        created_at: new Date().toISOString(),
        due_date: newDebt.dueDate,
        type: debtType,
        description: newDebt.description
      }).select().single();

      if (debtError) throw debtError;

      // Handle Account Balance if requested
      if (affectAccount && selectedAccountId && newDebt.amount > 0) {
        const account = accounts.find(a => a.id === selectedAccountId);
        if (account) {
          // If we lend money to customer (customer debt), money LEAVES account
          // If we borrow money from supplier (business debt), money ENTERS account
          const amountChange = debtType === 'customer' ? -newDebt.amount : newDebt.amount;
          
          await supabase
            .from('accounts')
            .update({ balance: account.balance + amountChange })
            .eq('id', selectedAccountId);
            
          await supabase.from('account_transactions').insert({
            [amountChange > 0 ? 'to_account_id' : 'from_account_id']: selectedAccountId,
            amount: Math.abs(amountChange),
            type: debtType === 'customer' ? 'loan' : 'borrow',
            description: `${debtType === 'customer' ? 'Lent to' : 'Borrowed from'} ${newDebt.customerName}: ${newDebt.description}`,
            tenant_id: user.tenantId,
            branch_id: activeBranchId || null,
            reference_id: debtData.id,
            created_at: new Date().toISOString()
          });
        }
      }

      setMessage({ type: 'success', text: t('debt_added_success' as any) || 'Debt added successfully' });
      setTimeout(() => setMessage(null), 3000);
      setIsAddDebtModalOpen(false);
      setNewDebt({ customerName: '', phone: '', amount: 0, dueDate: '', description: '' });
      setAffectAccount(false);
      fetchData();
    } catch (error: any) {
      console.error("Error adding debt:", error);
      let errorMsg = error.message || t('error_adding_debt' as any);
      if (errorMsg.includes('description')) {
        errorMsg = "Database error: 'description' column missing. Please run the SQL setup script in your Supabase dashboard and reload the schema.";
      }
      setMessage({ type: 'error', text: errorMsg });
      setTimeout(() => setMessage(null), 7000);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteDebt = async (debt: any) => {
    openConfirm(t('confirm_delete'), t('confirm_delete_msg' as any) || 'Are you sure you want to delete this record?', async () => {
      if (!user.tenantId) return;
      try {
        let error;
        if (debt.isUtility) {
          const { error: err } = await supabase.from('utility_records').delete().eq('id', debt.id);
          error = err;
        } else {
          const { error: err } = await supabase.from('debts').delete().eq('id', debt.id);
          error = err;
        }
        
        if (error) throw error;
        
        setMessage({ type: 'success', text: t('delete_success' as any) || 'Deleted successfully' });
        setTimeout(() => setMessage(null), 3000);
        fetchData();
      } catch (error: any) {
        console.error("Error deleting debt:", error);
        setMessage({ type: 'error', text: error.message || t('error_saving' as any) });
        setTimeout(() => setMessage(null), 5000);
      }
    });
  };

  const handleUpdateDebt = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.tenantId || !editingDebt || submitting) return;
    setSubmitting(true);
    try {
      await supabase.from('debts').update({
        customer_name: editDebt.customerName,
        phone: editDebt.phone,
        amount: editDebt.amount,
        due_date: editDebt.dueDate,
        description: editDebt.description
      }).eq('id', editingDebt.id);
      
      setIsEditModalOpen(false);
      setEditingDebt(null);
      setEditDebt({ customerName: '', phone: '', amount: 0, dueDate: '', description: '' });
      fetchData();
    } catch (error: any) {
      console.error("Error updating debt:", error);
      let errorMsg = error.message || "Error updating debt";
      if (errorMsg.includes('description')) {
        errorMsg = "Database error: 'description' column missing. Please run the SQL setup script in your Supabase dashboard and reload the schema.";
      }
      setMessage({ type: 'error', text: errorMsg });
      setTimeout(() => setMessage(null), 7000);
    } finally {
      setSubmitting(false);
    }
  };

  const handlePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.tenantId || !selectedDebt || submitting) return;
    setSubmitting(true);
    
    const newPaidAmount = selectedDebt.paidAmount + paymentAmount;
    const overpayment = Math.max(0, newPaidAmount - selectedDebt.amount);
    const actualDebtPayment = Math.min(paymentAmount, Math.max(0, selectedDebt.amount - selectedDebt.paidAmount));
    const status = newPaidAmount >= selectedDebt.amount ? 'paid' : 'partial';

    try {
      const activeBranchId = selectedBranchId || user.branchId;
      // 1. Sync with customer record if it exists
      const isCustomerPayingUs = (selectedDebt.type || 'customer') === 'customer' || selectedDebt.isUtility;
      
      if (isCustomerPayingUs) {
        let custQuery = supabase
          .from('customers')
          .select('*')
          .eq('tenant_id', user.tenantId)
          .eq('name', selectedDebt.customerName);
        
        if (activeBranchId) custQuery = custQuery.or(`branch_id.eq.${activeBranchId},branch_id.is.null`);

        const { data: customerData } = await custQuery.maybeSingle();

        if (customerData) {
          await supabase
            .from('customers')
            .update({
              total_debt: Math.max(0, (customerData.total_debt || 0) - actualDebtPayment),
              total_credit: (customerData.total_credit || 0) + overpayment
            })
            .eq('id', customerData.id);
        }
      }

      // 2. Update Debt or Utility record
      if (selectedDebt.isUtility) {
        const { error: utilError } = await supabase.from('utility_records').update({
          is_paid: status === 'paid',
          paid_at: status === 'paid' ? new Date().toISOString() : null,
          collected_by: user.displayName,
          payment_method: paymentMethod
        }).eq('id', selectedDebt.id);
        if (utilError) throw utilError;
      } else if (!selectedDebt.id.toString().startsWith('crm-sync-')) {
        const { error: debtUpdateError } = await supabase.from('debts').update({
          paid_amount: newPaidAmount,
          status
        }).eq('id', selectedDebt.id);
        if (debtUpdateError) throw debtUpdateError;
      }

      // 3. Update Account Balance and Record Transaction
      if (paymentAmount > 0 && selectedAccountId) {
        const accData = accounts.find(a => a.id === selectedAccountId);
        if (accData) {
          const amountChange = isCustomerPayingUs ? paymentAmount : -paymentAmount;
          
          const { error: updateAccError } = await supabase
            .from('accounts')
            .update({ balance: accData.balance + amountChange })
            .eq('id', accData.id);
          if (updateAccError) throw updateAccError;

          // Record transaction
          const { error: transError } = await supabase.from('account_transactions').insert({
            [amountChange > 0 ? 'to_account_id' : 'from_account_id']: accData.id,
            amount: paymentAmount,
            type: 'debt_payment',
            description: `Debt payment ${isCustomerPayingUs ? 'from' : 'to'} ${selectedDebt.customerName}${overpayment > 0 ? ` (Includes ${overpayment} added to credit)` : ''}`,
            tenant_id: user.tenantId,
            branch_id: user.branchId || null,
            reference_id: selectedDebt.id,
            created_at: new Date().toISOString()
          });
          if (transError) throw transError;
        }
      }
      
      setLastPayment({
        customerName: selectedDebt.customerName,
        amountPaid: paymentAmount,
        remainingBalance: selectedDebt.amount - newPaidAmount,
        date: new Date().toISOString(),
        id: selectedDebt.id,
        paymentMethod: paymentMethod
      });
      
      setIsModalOpen(false);
      setSelectedDebt(null);
      setPaymentAmount(0);
      setShowReceipt(true);
      fetchData();
      setMessage({ type: 'success', text: t('payment_success') });
      setTimeout(() => setMessage(null), 3000);
    } catch (error: any) {
      console.error("Error recording payment:", error);
      setMessage({ type: 'error', text: t('error_saving' as any) || `Error: ${error.message || 'Failed to save payment'}` });
      setTimeout(() => setMessage(null), 5000);
    } finally {
      setSubmitting(false);
    }
  };

  const handleWhatsAppShare = (debt: Debt) => {
    const balance = debt.amount - debt.paidAmount;
    const businessName = tenant?.name || t('business_name_placeholder');
    
    let dueDateInfo = '';
    if (debt.dueDate) {
      dueDateInfo = t('due_date_info').replace('{date}', new Date(debt.dueDate).toLocaleDateString());
    }

    const message = t('whatsapp_debt_reminder')
      .replace('{customerName}', debt.customerName)
      .replace('{balance}', (balance || 0).toFixed(2))
      .replace('{businessName}', businessName)
      .replace('{dueDateInfo}', dueDateInfo);
    
    const cleanPhone = debt.phone.replace(/[^0-9]/g, '');
    const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  const filteredDebts = [...debts, ...utilityDebts].filter(debt => {
    const matchesSearch = (debt.customerName || '').toLowerCase().includes(searchTerm.toLowerCase()) || 
                         (debt.phone || '').includes(searchTerm);
    
    if (!matchesSearch) return false;
    
    if (mode === 'all') {
      // In 'all' mode, show everything, but we can prioritize unpaid
      return true;
    }

    return filterByDate(debt.createdAt, selectedDate, mode as any, startDate, endDate);
  }).sort((a, b) => {
    // Priority 1: Unpaid first
    const statusA = a.status === 'paid' ? 1 : 0;
    const statusB = b.status === 'paid' ? 1 : 0;
    if (statusA !== statusB) return statusA - statusB;
    
    // Priority 2: Newest first
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  const downloadPDF = () => {
    let doc: any;
    try {
      doc = new jsPDF();
    } catch (e) {
      console.error("Error creating PDF:", e);
      return;
    }
    const businessName = tenant?.name || t('business_name_placeholder');
    const location = tenant?.location || '';
    const contact = tenant?.contact || '';
    
    // Header
    let yPos = 20;
    doc.setFontSize(20);
    doc.setTextColor(79, 70, 229); // Indigo-600
    doc.text(businessName, 14, yPos);
    yPos += 8;

    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139); // Slate-500
    if (location) {
      doc.text(location, 14, yPos);
      yPos += 5;
    }
    if (contact) {
      doc.text(contact, 14, yPos);
      yPos += 5;
    }
    
    yPos += 2;
    doc.setFontSize(12);
    const dateStr = mode === 'range' 
      ? `${startDate.toLocaleDateString()} - ${endDate.toLocaleDateString()}`
      : selectedDate.toLocaleDateString();
    doc.text(`${t('debts_report')} (${dateStr})`, 14, yPos);
    yPos += 10;

    const tableColumn = [t('customer'), t('phone'), t('total_debt'), t('paid_amount'), t('balance'), t('date'), t('description')];
    const tableRows: any[] = [];

    filteredDebts.forEach(debt => {
      const rowData = [
        debt.customerName,
        debt.phone,
        `$${(debt.amount || 0).toFixed(2)}`,
        `$${(debt.paidAmount || 0).toFixed(2)}`,
        `$${((debt.amount || 0) - (debt.paidAmount || 0)).toFixed(2)}`,
        new Date(debt.createdAt || '').toLocaleDateString(),
        debt.description || ''
      ];
      tableRows.push(rowData);
    });

    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: yPos,
      theme: 'grid',
      styles: { fontSize: 8, cellPadding: 3 },
      headStyles: { fillColor: [79, 70, 229], textColor: [255, 255, 255], fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [248, 250, 252] }
    });

    doc.save(`${businessName}_debts_report_${dateStr.replace(/\//g, '-')}.pdf`);
  };

  const downloadExcel = () => {
    const businessName = tenant?.name || t('business_name_placeholder');
    const location = tenant?.location || '';
    const contact = tenant?.contact || '';

    const dateStr = mode === 'range' 
      ? `${startDate.toLocaleDateString()} - ${endDate.toLocaleDateString()}`
      : selectedDate.toLocaleDateString();

    const fileNameDate = mode === 'range' 
      ? `${startDate.toLocaleDateString()}_to_${endDate.toLocaleDateString()}`
      : selectedDate.toLocaleDateString();

    // Create header rows
    const headerRows = [
      [businessName],
      [location],
      [contact],
      [`${t('debts_report')} (${dateStr})`],
      [] // Empty row
    ];

    const dataRows = filteredDebts.map(debt => [
      debt.customerName,
      debt.phone,
      debt.amount,
      debt.paidAmount,
      (debt.amount || 0) - (debt.paidAmount || 0),
      new Date(debt.createdAt || '').toLocaleDateString(),
      debt.description || ''
    ]);

    const tableHeader = [t('customer'), t('phone'), t('total_debt'), t('paid_amount'), t('balance'), t('date'), t('description')];
    
    const allRows = [...headerRows, tableHeader, ...dataRows];
    const worksheet = XLSX.utils.aoa_to_sheet(allRows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Debts");
    
    XLSX.writeFile(workbook, `${businessName}_debts_report_${fileNameDate.replace(/\//g, '-')}.xlsx`);
  };

  const totalUnpaid = filteredDebts.reduce((sum, d) => sum + (d.amount - d.paidAmount), 0);

  if (loading) return <div className="p-8 text-center text-slate-500">{t('loading')}</div>;

  return (
    <div className="space-y-6">
      {/* Message Notification */}
      {message && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-[100] animate-in fade-in slide-in-from-top-4">
          <div className={`px-6 py-3 rounded-2xl shadow-xl flex items-center gap-3 border ${
            message.type === 'success' ? 'bg-emerald-50 border-emerald-100 text-emerald-600' : 'bg-rose-50 border-rose-100 text-rose-600'
          }`}>
            <div className={`p-1.5 rounded-lg ${message.type === 'success' ? 'bg-emerald-100' : 'bg-rose-100'}`}>
              <AlertCircle size={16} />
            </div>
            <p className="text-sm font-bold">{message.text}</p>
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      {confirmModal.isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden p-6 space-y-6">
            <div className="flex items-center gap-4 p-4 bg-rose-50 rounded-2xl text-rose-600">
              <Trash2 size={24} />
              <div>
                <h4 className="font-bold">{confirmModal.title}</h4>
                <p className="text-xs font-medium opacity-80">{confirmModal.message}</p>
              </div>
            </div>
            <div className="flex gap-3">
              <button 
                onClick={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
                className="flex-1 px-4 py-3 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 transition-all text-sm"
              >
                {t('cancel')}
              </button>
              <button 
                onClick={confirmModal.onConfirm}
                className="flex-1 px-4 py-3 bg-rose-600 text-white rounded-xl font-bold hover:bg-rose-700 transition-all shadow-lg shadow-rose-200 text-sm"
              >
                {t('delete')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header Section */}
      <div className="bg-white p-4 sm:p-6 rounded-2xl border border-slate-100 shadow-sm space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600 shadow-inner">
              <Wallet size={24} />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-display font-bold text-slate-900 leading-tight">
                {t('debt_management_title')}
              </h2>
              <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">
                {debtType === 'customer' ? t('customer_debts') : t('business_debts')}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
            <button 
              onClick={() => setIsAddDebtModalOpen(true)}
              className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-indigo-600 text-white px-5 py-2.5 rounded-xl text-sm font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 active:scale-95"
            >
              <Plus size={18} />
              {debtType === 'customer' ? t('add_debt') : t('add_business_debt')}
            </button>
            <button 
              onClick={fetchData}
              disabled={loading}
              className={`flex items-center justify-center gap-2 bg-slate-50 text-slate-700 px-4 py-2.5 rounded-xl text-sm font-bold border border-slate-200 hover:bg-slate-100 transition-all ${loading ? 'opacity-50 cursor-not-allowed' : 'active:scale-95'}`}
            >
              <RefreshCw size={18} className={loading ? 'animate-spin' : ''} />
              <span className="hidden sm:inline">{loading ? t('refreshing') : t('refresh')}</span>
            </button>
          </div>
        </div>

        <div className="h-px bg-slate-100 w-full" />

        <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 w-full xl:w-auto">
            {branches.length > 0 && !user.branchId && (
              <select
                value={selectedBranchId}
                onChange={(e) => setSelectedBranchId(e.target.value)}
                className="w-full sm:w-auto px-5 py-2.5 bg-indigo-50 border border-indigo-100 text-indigo-700 rounded-xl font-bold hover:bg-indigo-100 transition-all shadow-sm outline-none cursor-pointer"
              >
                <option value="">{t('all_branches')}</option>
                {branches.map(b => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            )}
            <div className="flex bg-slate-100 p-1 rounded-xl w-full sm:w-auto">
              <button
                onClick={() => setMode('all')}
                className={`flex-1 sm:flex-none px-4 py-2 rounded-lg text-xs font-bold transition-all ${mode === 'all' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
              >
                {t('all' as any) || 'All'}
              </button>
              <button
                onClick={() => setDebtType('customer')}
                className={`flex-1 sm:flex-none px-4 py-2 rounded-lg text-xs font-bold transition-all ${debtType === 'customer' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
              >
                {t('customer_debts')}
              </button>
              <button
                onClick={() => setDebtType('business')}
                className={`flex-1 sm:flex-none px-4 py-2 rounded-lg text-xs font-bold transition-all ${debtType === 'business' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
              >
                {t('business_debts')}
              </button>
            </div>

            <div className={`w-full sm:w-auto px-4 py-2 rounded-xl text-sm font-bold flex items-center justify-center sm:justify-start gap-2 border ${debtType === 'customer' ? 'bg-rose-50 text-rose-600 border-rose-100' : 'bg-amber-50 text-amber-600 border-amber-100'}`}>
              <AlertCircle size={18} />
              <span className="whitespace-nowrap">
                {debtType === 'customer' ? t('total_customer_debts') : t('total_business_debts')}: 
                <span className="ml-1 text-lg">${(totalUnpaid || 0).toFixed(2)}</span>
              </span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 w-full xl:w-auto">
            <div className="w-full sm:w-auto">
              <DateSelector 
                selectedDate={selectedDate} 
                onChange={setSelectedDate} 
                mode={mode} 
                onModeChange={setMode} 
                startDate={startDate}
                endDate={endDate}
                onRangeChange={(start, end) => {
                  setStartDate(start);
                  setEndDate(end);
                }}
              />
            </div>
            
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button 
                onClick={() => window.print()}
                disabled={filteredDebts.length === 0}
                className="flex-1 sm:flex-none bg-slate-800 text-white p-2.5 rounded-xl text-sm font-bold shadow-lg shadow-slate-100 hover:bg-slate-900 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                title={t('print')}
              >
                <Printer size={18} />
                <span className="xl:hidden">{t('print')}</span>
              </button>
              <button 
                onClick={downloadPDF}
                disabled={filteredDebts.length === 0}
                className="flex-1 sm:flex-none bg-emerald-600 text-white p-2.5 rounded-xl text-sm font-bold shadow-lg shadow-emerald-50 hover:bg-emerald-700 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                title={t('download_pdf')}
              >
                <FileDown size={18} />
                <span className="xl:hidden">{t('download_pdf')}</span>
              </button>
              <button 
                onClick={downloadExcel}
                disabled={filteredDebts.length === 0}
                className="flex-1 sm:flex-none bg-blue-600 text-white p-2.5 rounded-xl text-sm font-bold shadow-lg shadow-blue-50 hover:bg-blue-700 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                title={t('download_excel')}
              >
                <Table size={18} />
                <span className="xl:hidden">{t('download_excel')}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center gap-3 bg-slate-50/50">
          <Search size={18} className="text-slate-400" />
          <input 
            type="text" 
            placeholder={t('search_customer_placeholder')} 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-transparent border-none focus:outline-none text-sm w-full"
          />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-bg-sec text-xs font-bold uppercase tracking-[0.1em] text-ink-tertiary border-b border-border-main">
              <tr>
                <th className="px-6 py-5">{debtType === 'customer' ? t('customer_name') : t('supplier_name')}</th>
                <th className="px-6 py-5 text-center">{t('economics' as any) || 'Economics'}</th>
                <th className="px-6 py-5 text-center">{t('timeline' as any) || 'Timeline'}</th>
                <th className="px-6 py-5 text-center">{t('status')}</th>
                <th className="px-6 py-5 text-right">{t('actions')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border-main text-sm">
              {filteredDebts.map(debt => {
                const balance = debt.amount - debt.paidAmount;
                const isOverdue = debt.dueDate && new Date(debt.dueDate) < new Date() && debt.status !== 'paid';
                
                return (
                  <tr key={debt.id} className="hover:bg-bg-sec/50 transition-colors group border-b border-border-main last:border-0">
                    <td className="px-8 py-6">
                      <div className="flex flex-col">
                        <span className="font-black text-ink text-lg tracking-tight uppercase italic">{debt.customerName}</span>
                        {debt.description && (
                          <div className="text-xs font-bold text-ink-tertiary mt-2 opacity-60 italic max-w-[250px] whitespace-pre-wrap" title={debt.description}>
                            {debt.description}
                          </div>
                        )}
                        <div className="flex items-center gap-1.5 mt-2 font-mono text-xs text-ink-tertiary opacity-60">
                           <Users size={12} className="text-indigo-500" /> {debt.phone}
                        </div>
                        {debt.isUtility && (
                          <span className="mt-2 w-fit px-2 py-1 bg-indigo-600 text-white text-[10px] font-black rounded-lg uppercase tracking-wider shadow-sm">
                            {t('utility')}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div className="flex flex-col items-center gap-2">
                        <div className="flex items-center justify-between w-full min-w-[160px] text-xs font-bold text-ink-tertiary uppercase tracking-normal border-b border-border-main/10 pb-1">
                           <span>{t('total')}</span>
                           <span className="text-ink font-black text-sm">${(debt.amount || 0).toLocaleString()}</span>
                        </div>
                        <div className="flex items-center justify-between w-full min-w-[160px] text-xs font-bold text-ink-tertiary uppercase tracking-normal border-b border-border-main/10 pb-1">
                           <span className="text-emerald-600">{t('paid')}</span>
                           <span className="text-emerald-600 font-black text-sm">${(debt.paidAmount || 0).toLocaleString()}</span>
                        </div>
                        <div className="flex items-center justify-between w-full min-w-[160px] text-sm font-black uppercase tracking-normal pt-1">
                           <span className="text-rose-600">{t('balance')}</span>
                           <span className="text-rose-600 text-lg font-black font-mono bg-rose-50 px-2 py-0.5 rounded-lg border border-rose-100">${Math.abs(balance || 0).toLocaleString()}</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-6 text-center">
                       <div className="flex flex-col items-center gap-2">
                          <div className="flex items-center gap-1.5 text-xs font-bold text-ink-tertiary uppercase">
                             <Calendar size={14} className="text-indigo-500" />
                             {new Date(debt.createdAt).toLocaleDateString(undefined, { day: '2-digit', month: 'short', year: 'numeric' })}
                          </div>
                          <div className={`flex items-center gap-2 text-xs font-black uppercase tracking-wider px-3 py-1.5 rounded-xl border ${
                             isOverdue ? 'bg-rose-500 text-white border-rose-600 animate-pulse' : 'bg-bg-sec text-ink-tertiary border-border-main/50'
                          }`}>
                             {debt.dueDate ? new Date(debt.dueDate).toLocaleDateString(undefined, { day: '2-digit', month: 'short' }) : t('no_due_date')}
                             {isOverdue && <AlertCircle size={14} strokeWidth={3} />}
                          </div>
                       </div>
                    </td>
                    <td className="px-8 py-6 text-center">
                      <span className={`px-4 py-2 rounded-2xl text-xs font-black uppercase tracking-widest shadow-sm border ${
                        debt.status === 'paid' ? 'bg-emerald-500 text-white border-emerald-600' : 
                        debt.status === 'partial' ? 'bg-amber-500 text-white border-amber-600' : 
                        'bg-rose-500 text-white border-rose-600'
                      }`}>
                        {t(`${debt.status}_status` as any) || debt.status}
                      </span>
                    </td>
                    <td className="px-6 py-5 text-right whitespace-nowrap">
                      <div className="flex justify-end gap-1 transition-all duration-300">
                        <button 
                          onClick={() => {
                            setLastPayment({
                              customerName: debt.customerName,
                              amountPaid: debt.paidAmount,
                              remainingBalance: balance,
                              date: debt.createdAt,
                              id: debt.id,
                              paymentMethod: 'Statement'
                            });
                            setShowReceipt(true);
                          }}
                          className="p-2 text-ink-tertiary hover:text-accent-main hover:bg-accent-soft rounded-xl transition-all"
                          title={t('print')}
                        >
                          <Printer size={16} strokeWidth={2.5} />
                        </button>
                        
                        {debtType === 'customer' && (
                          <button 
                            onClick={() => handleWhatsAppShare(debt)}
                            className="p-2 text-ink-tertiary hover:text-emerald-600 hover:bg-emerald-50 rounded-xl transition-all"
                            title={t('send_whatsapp')}
                          >
                            <MessageCircle size={16} strokeWidth={2.5} />
                          </button>
                        )}

                        <button 
                          onClick={() => {
                            setEditingDebt(debt);
                            setEditDebt({ 
                              customerName: debt.customerName, 
                              phone: debt.phone, 
                              amount: debt.amount, 
                              dueDate: debt.dueDate || '',
                              description: debt.description || ''
                            });
                            setIsEditModalOpen(true);
                          }}
                          className="p-2 text-ink-tertiary hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all"
                          title={t('edit')}
                        >
                          <Edit2 size={16} strokeWidth={2.5} />
                        </button>

                        <button 
                          onClick={() => handleDeleteDebt(debt)}
                          className="p-2 text-ink-tertiary hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all"
                          title={t('delete')}
                        >
                          <Trash2 size={16} strokeWidth={2.5} />
                        </button>

                        {debt.status !== 'paid' && (
                          <button 
                            onClick={() => {
                              setSelectedDebt(debt);
                              setPaymentAmount(balance);
                              setIsModalOpen(true);
                            }} 
                            className="ml-2 px-5 py-2.5 bg-accent-main text-white hover:bg-accent-main/90 rounded-2xl text-xs font-black uppercase tracking-widest shadow-lg active:scale-95 transition-all"
                          >
                            {t('pay_status')}
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filteredDebts.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-ink-tertiary">
                    {t('no_debts_found')}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <Modal 
        isOpen={isModalOpen && !!selectedDebt} 
        onClose={() => setIsModalOpen(false)} 
        title={t('record_payment')}
      >
        {selectedDebt && (
          <form onSubmit={handlePayment} className="space-y-4">
            <div className="bg-slate-50 p-6 rounded-2xl space-y-3 mb-8 border border-slate-100 shadow-inner">
              <div className="flex justify-between text-sm sm:text-base">
                <span className="text-slate-500 font-medium">{debtType === 'customer' ? t('customer') : t('supplier_name')}</span>
                <span className="font-black text-slate-900">{selectedDebt.customerName}</span>
              </div>
              <div className="flex justify-between text-sm sm:text-base">
                <span className="text-slate-500 font-medium">{t('total_debt')}</span>
                <span className="font-bold text-slate-900">${(selectedDebt.amount || 0).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-base sm:text-lg pt-2 border-t border-slate-200">
                <span className="text-slate-500 font-bold">{t('balance')}</span>
                <span className="font-black text-rose-600">${((selectedDebt.amount || 0) - (selectedDebt.paidAmount || 0)).toFixed(2)}</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{t('amount_to_pay')}</label>
              <input 
                required 
                type="number" 
                step="0.01" 
                max={selectedDebt.amount - selectedDebt.paidAmount}
                value={paymentAmount} 
                onChange={e => setPaymentAmount(parseFloat(e.target.value) || 0)} 
                className="w-full px-6 py-4 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-indigo-500 text-2xl font-black text-indigo-600 bg-white shadow-sm" 
              />
            </div>
            
            <div>
              <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{t('payment_method')}</label>
              {accounts.length > 0 ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {accounts.filter(acc => debtType === 'customer' ? true : acc.balance > 0).map(acc => (
                    <button
                      key={acc.id}
                      type="button"
                      onClick={() => {
                        setPaymentMethod(acc.name);
                        setSelectedAccountId(acc.id);
                      }}
                      className={`px-4 py-3 rounded-xl text-sm font-bold transition-all border ${selectedAccountId === acc.id ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg' : 'bg-slate-50 text-slate-600 border-slate-100 hover:bg-slate-100'}`}
                    >
                      <div className="flex flex-col items-start">
                        <span>{acc.name}</span>
                      </div>
                    </button>
                  ))}
                </div>
              ) : (
                <div className="text-xs text-rose-500 font-bold p-3 bg-rose-50 rounded-xl border border-rose-100">
                  {t('no_accounts_found') || 'No accounts found. Please create an account in Transactions first.'}
                </div>
              )}
            </div>
            
            <div className="pt-4 flex gap-3">
              <button type="button" onClick={() => setIsModalOpen(false)} disabled={submitting} className="flex-1 px-4 py-3 border border-slate-200 text-slate-600 rounded-xl font-bold hover:bg-slate-50 transition-colors disabled:opacity-50">{t('cancel')}</button>
              <button type="submit" disabled={submitting} className="flex-1 px-4 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200 disabled:opacity-50">{submitting ? t('processing') || 'Processing...' : t('confirm_payment')}</button>
            </div>
          </form>
        )}
      </Modal>

      {isAddDebtModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <h3 className="text-lg font-bold text-slate-900">{debtType === 'customer' ? t('add_debt') : t('add_business_debt')}</h3>
              <button onClick={() => setIsAddDebtModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                &times;
              </button>
            </div>
            <form onSubmit={handleAddDebt} className="p-8 space-y-6">
              <div>
                <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{debtType === 'customer' ? t('customer_name') : t('supplier_name')}</label>
                <input required type="text" value={newDebt.customerName} onChange={e => setNewDebt({...newDebt, customerName: e.target.value})} className="w-full px-6 py-4 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-indigo-500 text-base font-bold shadow-sm" />
              </div>
              <div>
                <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{debtType === 'customer' ? t('phone_number') : t('supplier_phone')}</label>
                <input required type="text" value={newDebt.phone} onChange={e => setNewDebt({...newDebt, phone: e.target.value})} className="w-full px-6 py-4 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-indigo-500 text-base font-bold font-mono shadow-sm" />
              </div>
              <div>
                <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{t('amount')}</label>
                <input required type="number" step="0.01" value={newDebt.amount} onChange={e => setNewDebt({...newDebt, amount: parseFloat(e.target.value) || 0})} className="w-full px-6 py-4 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-indigo-500 text-xl font-black text-indigo-600 shadow-sm" />
              </div>
              <div>
                <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{t('due_date')}</label>
                <input type="date" value={newDebt.dueDate} onChange={e => setNewDebt({...newDebt, dueDate: e.target.value})} className="w-full px-6 py-4 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-indigo-500 text-base font-bold shadow-sm" />
              </div>

              <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100 space-y-5 shadow-inner">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-base font-black text-slate-900">{t('affect_account_balance' as any) || 'Affect Account Balance?'}</h4>
                    <p className="text-xs text-slate-500 font-medium italic mt-1">{debtType === 'customer' ? 'Deduct money from business account' : 'Add money to business account'}</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer" 
                      checked={affectAccount}
                      onChange={() => setAffectAccount(!affectAccount)}
                    />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:width-5 after:transition-all peer-checked:bg-indigo-600"></div>
                  </label>
                </div>

                {affectAccount && (
                  <div className="space-y-3 pt-2 border-t border-slate-200 animate-in fade-in slide-in-from-top-2">
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">{t('select_account')}</label>
                    {accounts.length > 0 ? (
                      <div className="grid grid-cols-2 gap-2">
                        {accounts.filter(acc => debtType === 'business' ? true : acc.balance > 0).map(acc => (
                          <button
                            key={acc.id}
                            type="button"
                            onClick={() => setSelectedAccountId(acc.id)}
                            className={`px-3 py-2 rounded-xl text-xs font-bold transition-all border ${selectedAccountId === acc.id ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm' : 'bg-white text-slate-600 border-slate-200 hover:border-indigo-300'}`}
                          >
                            <div className="flex flex-col items-center">
                              <span>{acc.name}</span>
                            </div>
                          </button>
                        ))}
                      </div>
                    ) : (
                      <div className="text-[10px] text-rose-500 font-bold p-2 bg-rose-50 rounded-lg">
                        {t('no_accounts_found') || 'No accounts found. Please create an account in Transactions first.'}
                      </div>
                    )}
                  </div>
                )}
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('description')}</label>
                <textarea 
                  value={newDebt.description} 
                  onChange={e => setNewDebt({...newDebt, description: e.target.value})} 
                  placeholder={t('description')}
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 min-h-[80px]"
                />
              </div>
              <div className="pt-4 flex gap-3">
                <button type="button" onClick={() => setIsAddDebtModalOpen(false)} disabled={submitting} className="flex-1 px-4 py-3 border border-slate-200 text-slate-600 rounded-xl font-bold hover:bg-slate-50 transition-colors disabled:opacity-50">{t('cancel')}</button>
                <button type="submit" disabled={submitting} className="flex-1 px-4 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200 disabled:opacity-50">{submitting ? t('saving') || 'Saving...' : (debtType === 'customer' ? t('add_debt') : t('add_business_debt'))}</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isEditModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <h3 className="text-lg font-bold text-slate-900">{t('edit_debt')}</h3>
              <button onClick={() => setIsEditModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                &times;
              </button>
            </div>
            <form onSubmit={handleUpdateDebt} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{debtType === 'customer' ? t('customer_name') : t('supplier_name')}</label>
                <input required type="text" value={editDebt.customerName} onChange={e => setEditDebt({...editDebt, customerName: e.target.value})} className="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20" />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{debtType === 'customer' ? t('phone_number') : t('supplier_phone')}</label>
                <input required type="text" value={editDebt.phone} onChange={e => setEditDebt({...editDebt, phone: e.target.value})} className="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20" />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('amount')}</label>
                <input required type="number" step="0.01" value={editDebt.amount} onChange={e => setEditDebt({...editDebt, amount: parseFloat(e.target.value) || 0})} className="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20" />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('due_date')}</label>
                <input type="date" value={editDebt.dueDate} onChange={e => setEditDebt({...editDebt, dueDate: e.target.value})} className="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20" />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('description')}</label>
                <textarea 
                  value={editDebt.description} 
                  onChange={e => setEditDebt({...editDebt, description: e.target.value})} 
                  placeholder={t('description')}
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 min-h-[80px]"
                />
              </div>
              <div className="pt-4 flex gap-3">
                <button type="button" onClick={() => setIsEditModalOpen(false)} disabled={submitting} className="flex-1 px-4 py-3 border border-slate-200 text-slate-600 rounded-xl font-bold hover:bg-slate-50 transition-colors disabled:opacity-50">{t('cancel')}</button>
                <button type="submit" disabled={submitting} className="flex-1 px-4 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200 disabled:opacity-50">{submitting ? t('saving') || 'Saving...' : t('save_changes')}</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Payment Receipt Modal */}
      {showReceipt && lastPayment && tenant && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm print:bg-white print:p-0">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden print:shadow-none print:w-full print:max-w-none">
            <div className="p-8 print:p-4">
              <div className="text-center mb-6">
                {tenant.logoUrl && (
                  <img src={tenant.logoUrl} alt="Logo" className="w-24 h-24 object-contain mx-auto mb-4" />
                )}
                <h2 className="text-2xl font-bold text-slate-900">{tenant.name}</h2>
                <p className="text-sm text-slate-500">{t('payment_receipt')}</p>
                <p className="text-xs text-slate-400 mt-1">{new Date(lastPayment.date).toLocaleString()}</p>
              </div>

              <div className="bg-slate-50 p-6 rounded-2xl mb-6 space-y-4">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">{t('customer')}:</span>
                  <span className="font-bold text-slate-900">{lastPayment.customerName}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">{t('amount_paid')}:</span>
                  <span className="font-bold text-emerald-600 text-lg">${(lastPayment.amountPaid || 0).toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm pt-2 border-t border-slate-200">
                  <span className="text-slate-500">{t('remaining_balance')}:</span>
                  <span className="font-bold text-slate-900">${(lastPayment.remainingBalance || 0).toFixed(2)}</span>
                </div>
              </div>

              <div className="text-center text-sm text-slate-500 mb-6">
                <p>{t('thank_you_payment')}</p>
              </div>

              {tenant?.paymentNumbers && typeof tenant.paymentNumbers === 'object' && (
                <div className="mb-6 p-4 bg-slate-50 rounded-xl border border-slate-100">
                  <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3 text-center">{t('payment_numbers')}</h4>
                  <div className="grid grid-cols-2 gap-3 text-[10px]">
                    {(tenant.paymentNumbers as any)?.evc && (
                      <div className="flex flex-col">
                        <span className="text-slate-400 font-bold uppercase tracking-tighter">EVC</span>
                        <span className="text-slate-900 font-mono font-bold">{(tenant.paymentNumbers as any).evc}</span>
                      </div>
                    )}
                    {(tenant.paymentNumbers as any)?.edahab && (
                      <div className="flex flex-col">
                        <span className="text-slate-400 font-bold uppercase tracking-tighter">eDahab</span>
                        <span className="text-slate-900 font-mono font-bold">{(tenant.paymentNumbers as any).edahab}</span>
                      </div>
                    )}
                    {(tenant.paymentNumbers as any)?.zaad && (
                      <div className="flex flex-col">
                        <span className="text-slate-400 font-bold uppercase tracking-tighter">ZAAD</span>
                        <span className="text-slate-900 font-mono font-bold">{(tenant.paymentNumbers as any).zaad}</span>
                      </div>
                    )}
                    {(tenant.paymentNumbers as any)?.sahal && (
                      <div className="flex flex-col">
                        <span className="text-slate-400 font-bold uppercase tracking-tighter">SAHAL</span>
                        <span className="text-slate-900 font-mono font-bold">{(tenant.paymentNumbers as any).sahal}</span>
                      </div>
                    )}
                    {(tenant.paymentNumbers as any)?.merchant && (
                      <div className="flex flex-col">
                        <span className="text-slate-400 font-bold uppercase tracking-tighter">MERCHANT</span>
                        <span className="text-slate-900 font-mono font-bold">{(tenant.paymentNumbers as any).merchant}</span>
                      </div>
                    )}
                    {(tenant.paymentNumbers as any)?.bank && (
                      <div className="flex flex-col col-span-2">
                        <span className="text-slate-400 font-bold uppercase tracking-tighter">BANK</span>
                        <span className="text-slate-900 font-mono font-bold">{(tenant.paymentNumbers as any).bank}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              <div className="flex flex-col gap-3 print:hidden">
                <div className="flex gap-3">
                  <button 
                    onClick={() => {
                      setShowReceipt(false);
                      setLastPayment(null);
                    }} 
                    className="flex-1 px-4 py-3 border border-slate-200 text-slate-600 rounded-xl font-bold hover:bg-slate-50 transition-colors"
                  >
                    {t('close')}
                  </button>
                  <button 
                    onClick={() => window.print()} 
                    className="flex-1 px-4 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200 flex items-center justify-center gap-2"
                  >
                    <Printer size={18} />
                    {t('print')}
                  </button>
                </div>
                <button 
                  onClick={() => {
                    const businessName = tenant?.name || t('business_name_placeholder');
                    const message = t('whatsapp_payment_confirmation')
                      .replace('{customerName}', lastPayment.customerName)
                      .replace('{amountPaid}', (lastPayment.amountPaid || 0).toFixed(2))
                      .replace('{businessName}', businessName)
                      .replace('{balance}', (lastPayment.remainingBalance || 0).toFixed(2));
                    window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
                  }}
                  className="w-full px-4 py-3 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-colors shadow-lg shadow-green-200 flex items-center justify-center gap-2"
                >
                  <MessageCircle size={18} />
                  {t('send_whatsapp')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
