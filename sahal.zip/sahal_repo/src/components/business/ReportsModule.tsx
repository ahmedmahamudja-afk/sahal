import React, { useState, useEffect } from 'react';
import { supabase } from '../../supabase';
import { Sale, Expense, UserProfile, Debt, InventoryItem, Tenant } from '../../types';
import { PieChart, TrendingUp, TrendingDown, Wallet, Receipt, ArrowUpRight, ArrowDownRight, CreditCard, Landmark, Calendar, RefreshCw, Package, BarChart3, FileDown, Table, Printer, RotateCcw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../LanguageContext';
import DateSelector from '../DateSelector';
import { filterByDate } from '../../lib/dateUtils';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';

export default function ReportsModule({ user }: { user: UserProfile }) {
  const { t } = useLanguage();
  const [tenant, setTenant] = useState<Tenant | null>(null);
  const [sales, setSales] = useState<Sale[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [debts, setDebts] = useState<Debt[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [utilityRecords, setUtilityRecords] = useState<any[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [branches, setBranches] = useState<any[]>([]);
  const [selectedBranchId, setSelectedBranchId] = useState<string>(user.branchId || '');
  const [loading, setLoading] = useState(true);
  
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [mode, setMode] = useState<'day' | 'month' | 'year' | 'range'>('day');
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());

  const getBase64ImageFromURL = (url: string): Promise<string> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.setAttribute('crossOrigin', 'anonymous');
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0);
        const dataURL = canvas.toDataURL('image/png');
        resolve(dataURL);
      };
      img.onerror = (error) => reject(error);
      img.src = url;
    });
  };

  const fetchReportsData = async () => {
    if (!user.tenantId) return;
    setLoading(true);
    try {
      const { data: tenantData } = await supabase
        .from('tenants')
        .select('*')
        .eq('id', user.tenantId)
        .single();
        
      if (tenantData) {
        setTenant(tenantData);
        if (tenantData.is_multi_branch) {
          const { data: branchData } = await supabase.from('branches').select('*').eq('tenant_id', user.tenantId);
          if (branchData) setBranches(branchData);
        }
      }

      const activeBranchId = selectedBranchId || user.branchId;
      
      let salesQuery = supabase.from('sales').select('*').eq('tenant_id', user.tenantId);
      if (activeBranchId) salesQuery = salesQuery.eq('branch_id', activeBranchId);
      const { data: salesData } = await salesQuery;
      if (salesData) {
        setSales(salesData.map(s => ({
          id: s.id,
          items: s.items,
          total: s.total,
          tax: s.tax,
          paidAmount: s.paid_amount,
          debtAmount: s.debt_amount,
          customerName: s.customer_name,
          status: s.status,
          paymentMethods: s.payment_methods,
          tenantId: s.tenant_id,
          branchId: s.branch_id,
          createdAt: s.created_at,
          debtId: s.debt_id,
          sellerName: s.seller_name,
          creditUsed: s.credit_used
        })));
      } else {
        setSales([]);
      }

      let expQuery = supabase.from('expenses').select('*').eq('tenant_id', user.tenantId);
      if (activeBranchId) expQuery = expQuery.eq('branch_id', activeBranchId);
      const { data: expData } = await expQuery;
      if (expData) {
        setExpenses(expData.map(e => ({
          id: e.id,
          category: e.category,
          description: e.description,
          amount: e.amount,
          date: e.date,
          tenantId: e.tenant_id,
          branchId: e.branch_id,
          createdAt: e.created_at
        })));
      } else {
        setExpenses([]);
      }

      let debtQuery = supabase.from('debts').select('*').eq('tenant_id', user.tenantId);
      if (activeBranchId) debtQuery = debtQuery.eq('branch_id', activeBranchId);
      const { data: debtData } = await debtQuery;
      if (debtData) {
        setDebts(debtData.map(d => ({
          id: d.id,
          customerName: d.customer_name,
          phone: d.phone,
          amount: d.amount,
          paidAmount: d.paid_amount,
          status: d.status,
          tenantId: d.tenant_id,
          branchId: d.branch_id,
          createdAt: d.created_at,
          dueDate: d.due_date,
          type: d.type,
          description: d.description
        })));
      } else {
        setDebts([]);
      }

      let invQuery = supabase.from('inventory').select('*').eq('tenant_id', user.tenantId);
      if (activeBranchId) invQuery = invQuery.or(`branch_id.eq.${activeBranchId},branch_id.is.null`);
      const { data: invData } = await invQuery;
      if (invData) {
        setInventory(invData.map(item => ({
          id: item.id,
          name: item.name,
          sku: item.sku,
          quantity: item.quantity,
          costPrice: item.cost_price,
          price: item.price,
          minStock: item.min_stock,
          imageUrl: item.image_url,
          tenantId: item.tenant_id,
          branchId: item.branch_id,
          createdAt: item.created_at
        })));
      } else {
        setInventory([]);
      }
      let utilQuery = supabase.from('utility_records').select('*').eq('tenant_id', user.tenantId);
      if (activeBranchId) utilQuery = utilQuery.eq('branch_id', activeBranchId);
      const { data: utilityData } = await utilQuery;
      if (utilityData) {
        setUtilityRecords(utilityData);
      } else {
        setUtilityRecords([]);
      }

      let custQuery = supabase.from('customers').select('*').eq('tenant_id', user.tenantId);
      if (activeBranchId) custQuery = custQuery.or(`branch_id.eq.${activeBranchId},branch_id.is.null`);
      const { data: custData } = await custQuery;
      if (custData) {
        setCustomers(custData);
      } else {
        setCustomers([]);
      }
    } catch (error) {
      console.error("Error fetching reports:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReportsData();
  }, [user.tenantId, selectedBranchId]);

  if (loading) return <div className="p-8 text-center text-slate-500">{t('loading')}</div>;

  const getLocalDateString = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  // Filter logic
  const filteredSales = sales.filter(s => filterByDate(s.createdAt, selectedDate, mode, startDate, endDate));
  const activeSales = filteredSales.filter(s => s.status !== 'returned');
  const returnedSales = filteredSales.filter(s => s.status === 'returned');

  const filteredExpenses = expenses.filter(e => filterByDate(e.date ? e.date.substring(0, 10) : e.createdAt || '', selectedDate, mode, startDate, endDate));

  // For debts, we filter by the date they were taken (createdAt)
  const filteredDebts = debts.filter(d => filterByDate(d.createdAt, selectedDate, mode, startDate, endDate));

  // Unified Accounting Logic
  const totalSalesVolume = activeSales.reduce((sum, s) => sum + (s.total || 0), 0);
  const totalRefunds = returnedSales.reduce((sum, s) => sum + (s.paidAmount || 0), 0);
  
  // Cash In: Paid Amount from all sales + Payments made on CUSTOMER debts
  const cashFromSales = activeSales.reduce((sum, s) => sum + (s.paidAmount || 0), 0);
  
  // Distinguish debt payments: customer paying us (In) vs us paying supplier (Out)
  const cashInFromDebts = filteredDebts.reduce((sum, d) => {
    if (d.type === 'business' || d.type === 'supplier') return sum;
    return sum + (d.paidAmount || 0);
  }, 0);
  
  const cashOutFromDebts = filteredDebts.reduce((sum, d) => {
    if (d.type === 'business' || d.type === 'supplier') {
      return sum + (d.paidAmount || 0);
    }
    return sum;
  }, 0);

  const filteredUtility = utilityRecords.filter(r => filterByDate(r.createdAt, selectedDate, mode, startDate, endDate));

  const utilityCollected = filteredUtility.filter(r => r.isPaid).reduce((sum, r) => sum + r.totalBill, 0);
  const utilityUnpaid = filteredUtility.filter(r => !r.isPaid).reduce((sum, r) => sum + r.totalBill, 0);
  const utilityPotential = utilityCollected + utilityUnpaid;

  const otherExpenses = filteredExpenses.reduce((sum, e) => sum + (e.amount || 0), 0);
  const totalExpenses = otherExpenses + cashOutFromDebts + utilityPotential + totalRefunds;
  
  const totalCashIn = cashFromSales + cashInFromDebts;
  const netCashFlow = totalCashIn - totalExpenses;

  // Net Profit Calculation (Sales - Cost of Goods Sold)
  const totalTaxCollected = activeSales.reduce((sum, sale) => sum + (sale.tax || 0), 0);
  const totalDiscountsGiven = activeSales.reduce((sum, sale) => {
    let rawSubtotal = sale.items.reduce((itemSum, item) => itemSum + (item.subtotal || 0), 0);
    const expectedTotal = rawSubtotal + (sale.tax || 0);
    const cartDiscount = expectedTotal - (sale.total || expectedTotal);
    return sum + (cartDiscount > 0 ? cartDiscount : 0);
  }, 0);

  const totalNetProfit = activeSales.reduce((sum, sale) => {
    let rawSubtotal = 0;
    const saleProfit = sale.items.reduce((itemSum, item) => {
      rawSubtotal += item.subtotal;
      const isProduct = item.type === 'product' || !item.type;
      if (isProduct) {
        const invItem = inventory.find(i => i.id === item.id);
        const cost = invItem?.costPrice || (item.costPrice || 0);
        return itemSum + ((item.price - cost) * (item.qty || item.quantity || 1));
      } else if (item.type === 'custom') {
        const cost = item.costPrice || 0;
        return itemSum + ((item.price - cost) * (item.qty || item.quantity || 1));
      }
      return itemSum + item.subtotal; // For services, profit is 100% for now
    }, 0);
    
    const cartDiscount = rawSubtotal + (sale.tax || 0) - (sale.total || rawSubtotal);
    const realProfit = saleProfit - (cartDiscount > 0 ? cartDiscount : 0);
    
    return sum + realProfit;
  }, 0);

  // Receivables (Money owed to the business)
  const totalOutstandingDebt = filteredDebts.reduce((sum, d) => sum + (d.amount - d.paidAmount), 0);
  const totalCustomerCredit = customers.reduce((sum, c) => sum + (c.total_credit || 0), 0);

  // Payment Method Breakdown
  const paymentMethodBreakdown = activeSales.reduce((acc, sale) => {
    if (sale.paymentMethods && Array.isArray(sale.paymentMethods)) {
      sale.paymentMethods.forEach(pm => {
        acc[pm.method] = (acc[pm.method] || 0) + pm.amount;
      });
    } else if (sale.status === 'paid') {
      // Fallback for older records
      const method = 'Cash';
      acc[method] = (acc[method] || 0) + (sale.paidAmount || sale.total);
    }
    return acc;
  }, {} as Record<string, number>);

  // Trend Calculations
  const getPreviousDateRange = () => {
    const prev = new Date(selectedDate);
    if (mode === 'day') {
      prev.setDate(prev.getDate() - 1);
    } else if (mode === 'month') {
      prev.setMonth(prev.getMonth() - 1);
    } else if (mode === 'year') {
      prev.setFullYear(prev.getFullYear() - 1);
    } else if (mode === 'range') {
      const diff = endDate.getTime() - startDate.getTime();
      const prevStart = new Date(startDate.getTime() - diff - 1);
      const prevEnd = new Date(startDate.getTime() - 1);
      return { start: prevStart, end: prevEnd };
    }
    return prev;
  };

  const previousData = getPreviousDateRange();

  const previousSales = sales.filter(s => {
    if (mode === 'range') {
      const { start, end } = previousData as { start: Date, end: Date };
      return filterByDate(s.createdAt, new Date(), 'range', start, end);
    }
    return filterByDate(s.createdAt, previousData as Date, mode);
  });

  const previousExpenses = expenses.filter(e => {
    if (mode === 'range') {
      const { start, end } = previousData as { start: Date, end: Date };
      return filterByDate(e.date ? e.date.substring(0, 10) : e.createdAt || '', new Date(), 'range', start, end);
    }
    return filterByDate(e.date ? e.date.substring(0, 10) : e.createdAt || '', previousData as Date, mode);
  });

  const previousDebts = debts.filter(d => {
    if (mode === 'range') {
      const { start, end } = previousData as { start: Date, end: Date };
      return filterByDate(d.createdAt, new Date(), 'range', start, end);
    }
    return filterByDate(d.createdAt, previousData as Date, mode);
  });

  const prevCashFromSales = previousSales.reduce((sum, s) => sum + (s.paidAmount || 0), 0);
  const prevCashInFromDebts = previousDebts.reduce((sum, d) => {
    if (d.type === 'business' || d.type === 'supplier') return sum;
    return sum + (d.paidAmount || 0);
  }, 0);
  const prevCashOutFromDebts = previousDebts.reduce((sum, d) => {
    if (d.type === 'business' || d.type === 'supplier') return sum + (d.paidAmount || 0);
    return sum;
  }, 0);

  const prevTotalCashIn = prevCashFromSales + prevCashInFromDebts;
  const prevTotalExpenses = previousExpenses.reduce((sum, e) => sum + (e.amount || 0), 0) + prevCashOutFromDebts;
  const prevTotalOutstanding = previousDebts.reduce((sum, d) => sum + ((d.amount || 0) - (d.paidAmount || 0)), 0);

  const TrendBadge = ({ current, previous, invert = false }: { current: number, previous: number, invert?: boolean }) => {
    const change = previous === 0 ? (current > 0 ? 100 : 0) : ((current - previous) / previous) * 100;
    const isPositive = change > 0;
    const isNeutral = change === 0;

    if (isNeutral) return null;

    const isGood = invert ? !isPositive : isPositive;
    const colorClass = isGood ? 'text-emerald-600 border-emerald-100' : 'text-rose-600 border-rose-100';

    return (
      <div className={`flex items-center gap-1 text-[10px] font-bold ${colorClass} bg-white/50 px-2 py-0.5 rounded-full border mt-2 w-fit`}>
        {isPositive ? <TrendingUp size={10} /> : <TrendingDown size={10} />}
        {Math.abs(change).toFixed(1)}%
        <span className="text-slate-400 font-normal ml-1 lowercase">{t('vs_previous')}</span>
      </div>
    );
  };

  // Group sales by date for a simple chart representation
  const salesByDate = activeSales.reduce((acc, sale) => {
    const date = new Date(sale.createdAt).toLocaleDateString();
    acc[date] = (acc[date] || 0) + sale.total;
    return acc;
  }, {} as Record<string, number>);

  const recentSales = Object.entries(salesByDate).slice(-7);

  // Product Performance Logic
  const productSales = activeSales.reduce((acc, sale) => {
    sale.items.forEach(item => {
      const isProduct = item.type === 'product' || !item.type;
      if (isProduct) {
        acc[item.id] = (acc[item.id] || 0) + (item.qty || item.quantity || 0);
      }
    });
    return acc;
  }, {} as Record<string, number>);

  const performanceData = inventory.map(item => ({
    id: item.id,
    name: item.name,
    unitsSold: productSales[item.id] || 0
  })).sort((a, b) => b.unitsSold - a.unitsSold);

  const topSelling = performanceData.slice(0, 5);
  const leastSelling = [...performanceData].reverse().slice(0, 5);

  const downloadPDF = async () => {
    let doc: any;
    try {
      doc = new jsPDF();
    } catch (e) {
      console.error("Error creating PDF:", e);
      return;
    }
    const businessName = tenant?.name || t('business_name_placeholder');
    const location = tenant?.location || '';
    const contact = tenant?.contact || '';
    
    // Header
    let yPos = 20;

    // Logo
    if (tenant?.logoUrl) {
      try {
        const base64 = await getBase64ImageFromURL(tenant.logoUrl);
        doc.addImage(base64, 'PNG', 165, 10, 30, 30);
      } catch (e) {
        console.warn('Could not load logo for PDF:', e);
      }
    }
    
    doc.setFontSize(16);
    doc.setTextColor(79, 70, 229); // Indigo-600
    doc.text(businessName, 14, yPos);
    yPos += 8;

    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139); // Slate-500
    if (location) {
      doc.text(location, 14, yPos);
      yPos += 5;
    }
    if (contact) {
      doc.text(contact, 14, yPos);
      yPos += 5;
    }
    
    yPos += 2;
    doc.setFontSize(12);
    const dateStr = mode === 'range' 
      ? `${startDate.toLocaleDateString()} - ${endDate.toLocaleDateString()}`
      : selectedDate.toLocaleDateString();
    doc.text(`${t('financial_report')} (${dateStr})`, 14, yPos);
    yPos += 10;

    // Daily Breakdown for Month/Range
    if (mode === 'month' || mode === 'range') {
      const dailyData: Record<string, { sales: number; expenses: number; refunds: number }> = {};

      activeSales.forEach(s => {
        const date = new Date(s.createdAt).toLocaleDateString();
        if (!dailyData[date]) dailyData[date] = { sales: 0, expenses: 0, refunds: 0 };
        dailyData[date].sales += (s.total || 0);
      });

      returnedSales.forEach(s => {
        const date = new Date(s.createdAt).toLocaleDateString();
        if (!dailyData[date]) dailyData[date] = { sales: 0, expenses: 0, refunds: 0 };
        dailyData[date].refunds += (s.paidAmount || 0);
      });

      filteredExpenses.forEach(e => {
        const dateString = e.date ? e.date.substring(0, 10) : (e.createdAt ? e.createdAt.substring(0, 10) : '');
        if (!dateString) return;
        const date = new Date(dateString).toLocaleDateString();
        if (!dailyData[date]) dailyData[date] = { sales: 0, expenses: 0, refunds: 0 };
        dailyData[date].expenses += (e.amount || 0);
      });

      const dailyBreakdown = Object.entries(dailyData)
        .sort((a, b) => new Date(a[0]).getTime() - new Date(b[0]).getTime())
        .map(([date, data]) => [
          date,
          `$${data.sales.toFixed(2)}`,
          `$${data.expenses.toFixed(2)}`,
          `$${data.refunds.toFixed(2)}`,
          `$${(data.sales - data.expenses - data.refunds).toFixed(2)}`
        ]);

      if (dailyBreakdown.length > 0) {
        doc.setFontSize(14);
        doc.setTextColor(30, 41, 59);
        doc.text(t('daily_breakdown' as any) || 'Daily Breakdown', 14, yPos);
        yPos += 5;

        autoTable(doc, {
          head: [[t('date' as any) || 'Date', t('sales'), t('expenses'), t('refunds'), t('net_cash_flow')]],
          body: dailyBreakdown,
          startY: yPos,
          theme: 'striped',
          styles: { fontSize: 8, cellPadding: 2 },
          headStyles: { fillColor: [100, 116, 139], textColor: [255, 255, 255] }
        });
        yPos = (doc as any).lastAutoTable.finalY + 15;
      }
    }

    doc.setFontSize(14);
    doc.setTextColor(30, 41, 59);
    doc.text(t('summary' as any) || 'Final Summary', 14, yPos);
    yPos += 5;

    const summaryData = [
      [t('total_sales_volume'), `$${totalSalesVolume.toFixed(2)}`],
      [t('total_refunds' as any) || 'Total Refunds', `$${totalRefunds.toFixed(2)}`],
      [t('total_customer_credit' as any) || 'Total Customer Credit', `$${totalCustomerCredit.toFixed(2)}`],
      [t('total_cash_in'), `$${totalCashIn.toFixed(2)}`],
      [t('total_expenses'), `$${totalExpenses.toFixed(2)}`],
      [t('tax_collected' as any) || 'Tax Collected', `$${totalTaxCollected.toFixed(2)}`],
      [t('discounts_given' as any) || 'Discounts Given', `$${totalDiscountsGiven.toFixed(2)}`],
      [t('net_cash_flow'), `$${netCashFlow.toFixed(2)}`],
      [t('total_net_profit'), `$${totalNetProfit.toFixed(2)}`],
      [t('total_outstanding_debt'), `$${totalOutstandingDebt.toFixed(2)}`]
    ];

    autoTable(doc, {
      head: [[t('metric'), t('value')]],
      body: summaryData,
      startY: yPos,
      theme: 'grid',
      styles: { fontSize: 10, cellPadding: 5 },
      headStyles: { fillColor: [79, 70, 229], textColor: [255, 255, 255], fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [248, 250, 252] }
    });

    // Payment Methods
    const paymentData = Object.entries(paymentMethodBreakdown).map(([method, amount]) => [method, `$${(amount as number).toFixed(2)}`]);
    if (paymentData.length > 0) {
      doc.text(t('payment_method_breakdown'), 14, (doc as any).lastAutoTable.finalY + 15);
      autoTable(doc, {
        head: [[t('payment_method'), t('amount')]],
        body: paymentData,
        startY: (doc as any).lastAutoTable.finalY + 20,
        theme: 'grid',
        styles: { fontSize: 10, cellPadding: 5 },
        headStyles: { fillColor: [79, 70, 229], textColor: [255, 255, 255], fontStyle: 'bold' }
      });
    }

    doc.save(`${businessName}_financial_report_${dateStr.replace(/\//g, '-')}.pdf`);
  };

  const downloadExcel = () => {
    const businessName = tenant?.name || t('business_name_placeholder');
    const location = tenant?.location || '';
    const contact = tenant?.contact || '';

    const dateStr = mode === 'range' 
      ? `${startDate.toLocaleDateString()}_to_${endDate.toLocaleDateString()}`
      : selectedDate.toLocaleDateString();

    const displayDateStr = mode === 'range' 
      ? `${startDate.toLocaleDateString()} - ${endDate.toLocaleDateString()}`
      : selectedDate.toLocaleDateString();

    // Create header rows
    const headerRows = [
      [businessName],
      [location],
      [contact],
      [`${t('financial_report')} (${displayDateStr})`],
      [] // Empty row
    ];

    const summaryDataAoA = [
      [t('metric'), t('value')],
      [t('total_sales_volume'), totalSalesVolume],
      [t('total_refunds' as any) || 'Total Refunds', totalRefunds],
      [t('total_customer_credit' as any) || 'Total Customer Credit', totalCustomerCredit],
      [t('total_cash_in'), totalCashIn],
      [t('total_expenses'), totalExpenses],
      [t('tax_collected' as any) || 'Tax Collected', totalTaxCollected],
      [t('discounts_given' as any) || 'Discounts Given', totalDiscountsGiven],
      [t('net_cash_flow'), netCashFlow],
      [t('total_net_profit'), totalNetProfit],
      [t('total_outstanding_debt'), totalOutstandingDebt]
    ];

    const allRows = [...headerRows, ...summaryDataAoA];
    const worksheet = XLSX.utils.aoa_to_sheet(allRows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Summary");
    
    XLSX.writeFile(workbook, `${businessName}_financial_report_${dateStr.replace(/\//g, '-')}.xlsx`);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header Section */}
      <div className="bg-surface-main p-8 rounded-[2.5rem] border border-border-main shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-accent-soft rounded-full -mr-32 -mt-32 opacity-50 blur-3xl" />
        <div className="relative z-10 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8">
          <div className="flex items-center gap-5">
            <div className="w-16 h-16 bg-accent-main rounded-2xl flex items-center justify-center text-white shadow-xl shadow-accent-soft">
              <PieChart className="w-[var(--icon-lg)] h-[var(--icon-lg)]" />
            </div>
            <div>
              <h2 className="text-3xl font-display font-bold text-ink tracking-tight">{t('financial_report')}</h2>
              <p className="text-ink-secondary font-medium mt-1">{t('financial_report_desc')}</p>
            </div>
          </div>
          
          <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
            {tenant?.is_multi_branch && !user.branchId && (
              <select
                value={selectedBranchId}
                onChange={(e) => setSelectedBranchId(e.target.value)}
                className="flex-1 sm:flex-none px-5 py-3 bg-indigo-50 border border-indigo-100 text-indigo-700 rounded-2xl font-bold hover:bg-indigo-100 transition-all shadow-sm outline-none cursor-pointer"
              >
                <option value="">{t('all_branches')}</option>
                {branches.map(b => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            )}
            <div className="bg-bg-sec p-1.5 rounded-2xl border border-border-main flex items-center gap-2">
              <DateSelector 
                selectedDate={selectedDate} 
                onChange={setSelectedDate} 
                mode={mode} 
                onModeChange={setMode} 
                startDate={startDate}
                endDate={endDate}
                onRangeChange={(start, end) => {
                  setStartDate(start);
                  setEndDate(end);
                }}
              />
            </div>
            <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
              <button 
                onClick={downloadPDF}
                className="flex-1 sm:flex-none bg-emerald-600 text-white px-6 py-3.5 rounded-xl font-bold shadow-lg shadow-emerald-500/20 hover:bg-emerald-700 transition-all flex items-center justify-center gap-2 text-sm"
              >
                <FileDown className="w-5 h-5" />
                <span>{t('download_pdf')}</span>
              </button>
              <button 
                onClick={downloadExcel}
                className="flex-1 sm:flex-none bg-blue-600 text-white px-6 py-3.5 rounded-xl font-bold shadow-lg shadow-blue-500/20 hover:bg-blue-700 transition-all flex items-center justify-center gap-2 text-sm"
              >
                <Table className="w-5 h-5" />
                <span>{t('download_excel')}</span>
              </button>
              <button 
                onClick={() => window.print()}
                disabled={loading}
                className="p-3.5 bg-surface-main border border-border-main text-ink-secondary rounded-xl hover:bg-bg-sec transition-all shadow-sm flex items-center justify-center"
                title={t('print')}
              >
                <Printer className="w-5 h-5" />
              </button>
              <button 
                onClick={fetchReportsData}
                disabled={loading}
                className="p-3.5 bg-surface-main border border-border-main text-ink-secondary rounded-xl hover:bg-bg-sec transition-all shadow-sm flex items-center justify-center"
                title={t('refresh')}
              >
                <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-surface-main p-8 rounded-3xl shadow-sm border border-border-subtle hover:shadow-md transition-all group">
          <div className="flex items-center justify-between mb-6">
            <div className="p-3 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 rounded-2xl group-hover:scale-110 transition-transform">
              <TrendingUp className="w-[var(--icon-md)] h-[var(--icon-md)]" />
            </div>
            <TrendBadge current={totalCashIn} previous={prevTotalCashIn} />
          </div>
          <h3 className="font-bold text-ink-tertiary uppercase tracking-widest text-[10px] mb-2">{t('cash_in')}</h3>
          <div className="text-3xl font-display font-bold text-ink tracking-tight">${(totalCashIn || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
          <p className="text-[10px] text-ink-tertiary mt-3 font-medium leading-relaxed">{t('cash_in_desc')}</p>
        </div>

        <div className="bg-surface-main p-8 rounded-3xl shadow-sm border border-border-subtle hover:shadow-md transition-all group">
          <div className="flex items-center justify-between mb-6">
            <div className="p-3 bg-rose-50 dark:bg-rose-500/10 text-rose-600 rounded-2xl group-hover:scale-110 transition-transform">
              <RotateCcw className="w-[var(--icon-md)] h-[var(--icon-md)]" />
            </div>
          </div>
          <h3 className="font-bold text-ink-tertiary uppercase tracking-widest text-[10px] mb-2">{t('total_refunds' as any) || 'Total Refunds'}</h3>
          <div className="text-3xl font-display font-bold text-rose-600 tracking-tight">${(totalRefunds || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
          <p className="text-[10px] text-ink-tertiary mt-3 font-medium leading-relaxed">{t('total_refunds_desc' as any) || 'Total money returned to customers'}</p>
        </div>

        <div className="bg-surface-main p-8 rounded-3xl shadow-sm border border-border-subtle hover:shadow-md transition-all group">
          <div className="flex items-center justify-between mb-6">
            <div className="p-3 bg-rose-50 dark:bg-rose-500/10 text-rose-600 rounded-2xl group-hover:scale-110 transition-transform">
              <Receipt className="w-[var(--icon-md)] h-[var(--icon-md)]" />
            </div>
            <TrendBadge current={totalExpenses} previous={prevTotalExpenses} invert={true} />
          </div>
          <h3 className="font-bold text-ink-tertiary uppercase tracking-widest text-[10px] mb-2">{t('cash_out')}</h3>
          <div className="text-3xl font-display font-bold text-ink tracking-tight">${(totalExpenses || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
          <p className="text-[10px] text-ink-tertiary mt-3 font-medium leading-relaxed">{t('cash_out_desc')}</p>
        </div>

        <div className="bg-surface-main p-8 rounded-3xl shadow-sm border border-border-subtle hover:shadow-md transition-all group">
          <div className="flex items-center justify-between mb-6">
            <div className="p-3 bg-amber-50 dark:bg-amber-500/10 text-amber-600 rounded-2xl group-hover:scale-110 transition-transform">
              <CreditCard className="w-[var(--icon-md)] h-[var(--icon-md)]" />
            </div>
            <TrendBadge current={totalOutstandingDebt} previous={prevTotalOutstanding} invert={true} />
          </div>
          <h3 className="font-bold text-ink-tertiary uppercase tracking-widest text-[10px] mb-2">{t('outstanding_debts')}</h3>
          <div className="text-3xl font-display font-bold text-rose-600 tracking-tight">${(totalOutstandingDebt || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
          <p className="text-[10px] text-ink-tertiary mt-3 font-medium leading-relaxed">{t('outstanding_debts_desc')}</p>
        </div>

        <div className="bg-surface-main p-8 rounded-3xl shadow-sm border border-border-subtle hover:shadow-md transition-all group">
          <div className="flex items-center justify-between mb-6">
            <div className="p-3 bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 rounded-2xl group-hover:scale-110 transition-transform">
              <Receipt className="w-[var(--icon-md)] h-[var(--icon-md)]" />
            </div>
          </div>
          <h3 className="font-bold text-ink-tertiary uppercase tracking-widest text-[10px] mb-2">{t('tax_collected' as any) || 'Tax Collected'}</h3>
          <div className="text-3xl font-display font-bold text-indigo-600 tracking-tight">${(totalTaxCollected || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
          <p className="text-[10px] text-ink-tertiary mt-3 font-medium leading-relaxed">{t('tax_collected_desc' as any) || 'Total tax collected on sales'}</p>
        </div>

        <div className="bg-surface-main p-8 rounded-3xl shadow-sm border border-border-subtle hover:shadow-md transition-all group">
          <div className="flex items-center justify-between mb-6">
            <div className="p-3 bg-rose-50 dark:bg-rose-500/10 text-rose-600 rounded-2xl group-hover:scale-110 transition-transform">
              <TrendingUp className="w-[var(--icon-md)] h-[var(--icon-md)]" />
            </div>
          </div>
          <h3 className="font-bold text-ink-tertiary uppercase tracking-widest text-[10px] mb-2">{t('discounts_given' as any) || 'Discounts Given'}</h3>
          <div className="text-3xl font-display font-bold text-rose-600 tracking-tight">${(totalDiscountsGiven || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
          <p className="text-[10px] text-ink-tertiary mt-3 font-medium leading-relaxed">{t('discounts_given_desc' as any) || 'Total discounts applied to sales'}</p>
        </div>

        <div className="bg-ink p-8 rounded-3xl shadow-xl text-white relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform">
            <Landmark className="w-16 h-16" />
          </div>
          <div className="relative z-10">
            <div className="flex items-center gap-4 mb-6">
              <div className="p-3 bg-white/10 text-indigo-300 rounded-2xl">
                <Wallet className="w-[var(--icon-md)] h-[var(--icon-md)]" />
              </div>
            </div>
            <h3 className="font-bold text-slate-400 uppercase tracking-widest text-[10px] mb-2">{t('net_cash')}</h3>
            <div className="text-3xl font-display font-bold text-white tracking-tight">${(netCashFlow || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
            <p className="text-[10px] text-indigo-300 mt-3 font-medium leading-relaxed">{t('net_cash_desc')}</p>
          </div>
        </div>
      </div>

      {/* Secondary Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-accent-main p-8 rounded-[2.5rem] shadow-xl text-white relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-12 opacity-10 group-hover:scale-110 transition-transform">
            <TrendingUp size={120} />
          </div>
          <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="text-center md:text-left">
              <div className="flex items-center justify-center md:justify-start gap-4 mb-4">
                <div className="p-3 bg-white/10 text-emerald-300 rounded-2xl">
                  <BarChart3 className="w-[var(--icon-md)] h-[var(--icon-md)]" />
                </div>
                <h3 className="font-bold text-slate-300 uppercase tracking-widest text-xs">{t('net_profit')}</h3>
              </div>
              <div className="text-5xl font-display font-bold text-white tracking-tighter mb-2">
                ${(totalNetProfit || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
              <p className="text-sm text-emerald-300 font-medium">{t('expected_profit')}</p>
            </div>
            <div className="bg-white/10 backdrop-blur-md p-6 rounded-3xl border border-white/10 w-full md:w-auto">
              <div className="text-center">
                <p className="text-[10px] font-bold text-slate-300 uppercase tracking-[0.2em] mb-2">{t('total_sales_volume')}</p>
                <p className="text-2xl font-display font-bold text-white">${(totalSalesVolume || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-surface-main p-8 rounded-[2.5rem] shadow-sm border border-border-subtle flex flex-col justify-center">
          <h3 className="font-bold text-ink mb-6 flex items-center gap-2">
            <CreditCard className="w-[var(--icon-md)] h-[var(--icon-md)] text-accent-main" />
            {t('payment_methods')}
          </h3>
          <div className="space-y-4">
            {Object.keys(paymentMethodBreakdown).length > 0 ? Object.entries(paymentMethodBreakdown).map(([method, amount]) => (
              <div key={method} className="flex items-center justify-between p-4 bg-bg-sec rounded-2xl hover:bg-bg-soft transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-surface-main shadow-sm flex items-center justify-center text-accent-main">
                    <CreditCard className="w-[var(--icon-sm)] h-[var(--icon-sm)]" />
                  </div>
                  <div className="text-sm font-bold text-ink">{method}</div>
                </div>
                <div className="text-sm font-bold text-accent-main">${(amount as number || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
              </div>
            )) : (
              <div className="text-center text-ink-tertiary py-8 italic">{t('no_data')}</div>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Sales Trend */}
        <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-8">
            <h3 className="font-bold text-slate-900 text-lg">{t('sales_trend')}</h3>
            <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
              <BarChart3 size={20} />
            </div>
          </div>
          <div className="space-y-6">
            {recentSales.length > 0 ? recentSales.map(([date, amount]) => (
              <div key={date} className="group">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-slate-500">{date}</span>
                  <span className="text-xs font-bold text-slate-900">${((amount as number) || 0).toLocaleString()}</span>
                </div>
                <div className="h-2.5 bg-slate-50 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min(((amount as number) / (Math.max(...recentSales.map(s => s[1] as number)) || 1)) * 100, 100)}%` }}
                    className="h-full bg-indigo-500 rounded-full group-hover:bg-indigo-600 transition-colors" 
                  />
                </div>
              </div>
            )) : (
              <div className="text-center text-slate-400 py-12 italic">{t('no_sales_data')}</div>
            )}
          </div>
        </div>

        {/* Expense Breakdown */}
        <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-8">
            <h3 className="font-bold text-slate-900 text-lg">{t('recent_expenses')}</h3>
            <div className="w-10 h-10 bg-rose-50 text-rose-600 rounded-xl flex items-center justify-center">
              <Receipt size={20} />
            </div>
          </div>
          <div className="space-y-4">
            {expenses.length > 0 ? expenses.slice(0, 6).map(exp => (
              <div key={exp.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl hover:bg-slate-100 transition-colors group">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-white shadow-sm flex items-center justify-center text-slate-400 group-hover:text-rose-500 transition-colors">
                    <Receipt size={20} />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-slate-900">{t(exp.category as any)}</div>
                    <div className="text-[10px] font-medium text-slate-400 uppercase tracking-wider">{new Date(exp.createdAt).toLocaleDateString()}</div>
                  </div>
                </div>
                <div className="text-sm font-bold text-rose-600">-${(exp.amount || 0).toLocaleString()}</div>
              </div>
            )) : (
              <div className="text-center text-slate-400 py-12 italic">{t('no_expenses_found')}</div>
            )}
          </div>
        </div>
      </div>

      {/* Product Performance Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center">
                <TrendingUp size={20} />
              </div>
              <h3 className="font-bold text-slate-900 text-lg">{t('top_selling')}</h3>
            </div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest bg-slate-50 px-3 py-1 rounded-full">{t('best_sellers')}</span>
          </div>
          <div className="space-y-4">
            {topSelling.length > 0 ? topSelling.map((item, index) => (
              <div key={item.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl hover:bg-emerald-50 transition-colors group">
                <div className="flex items-center gap-4">
                  <div className="relative">
                    <div className="w-12 h-12 rounded-xl bg-white shadow-sm flex items-center justify-center text-indigo-500 group-hover:scale-110 transition-transform">
                      <Package size={20} />
                    </div>
                    <div className="absolute -top-2 -right-2 w-6 h-6 bg-emerald-500 text-white rounded-full flex items-center justify-center text-[10px] font-black border-2 border-white shadow-sm">
                      #{index + 1}
                    </div>
                  </div>
                  <div className="text-sm font-bold text-slate-900">{item.name}</div>
                </div>
                <div className="text-xs font-bold text-emerald-600 bg-emerald-100/50 px-3 py-1 rounded-full">{item.unitsSold} {t('units_sold')}</div>
              </div>
            )) : (
              <div className="text-center text-slate-400 py-12 italic">{t('no_data')}</div>
            )}
          </div>
        </div>

        <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-rose-50 text-rose-600 rounded-xl flex items-center justify-center">
                <TrendingDown size={20} />
              </div>
              <h3 className="font-bold text-slate-900 text-lg">{t('least_selling')}</h3>
            </div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest bg-slate-50 px-3 py-1 rounded-full">{t('slow_movers')}</span>
          </div>
          <div className="space-y-4">
            {leastSelling.length > 0 ? leastSelling.map((item, index) => (
              <div key={item.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl hover:bg-rose-50 transition-colors group">
                <div className="flex items-center gap-4">
                  <div className="relative">
                    <div className="w-12 h-12 rounded-xl bg-white shadow-sm flex items-center justify-center text-slate-400 group-hover:scale-110 transition-transform">
                      <Package size={20} />
                    </div>
                    <div className="absolute -top-2 -right-2 w-6 h-6 bg-rose-500 text-white rounded-full flex items-center justify-center text-[10px] font-black border-2 border-white shadow-sm">
                      #{index + 1}
                    </div>
                  </div>
                  <div className="text-sm font-bold text-slate-900">{item.name}</div>
                </div>
                <div className="text-xs font-bold text-slate-500 bg-slate-200/50 px-3 py-1 rounded-full">{item.unitsSold} {t('units_sold')}</div>
              </div>
            )) : (
              <div className="text-center text-slate-400 py-12 italic">{t('no_data')}</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
