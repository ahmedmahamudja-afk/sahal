import React, { useState, useEffect } from 'react';
import { supabase } from '../../supabase';
import { UserProfile, Customer, Tenant, Account, Branch } from '../../types';
import { Users, Plus, Edit2, Trash2, Tag, DollarSign, RefreshCw, FileDown, Table, ArrowUpRight, ArrowDownRight, Landmark, ArrowRightLeft } from 'lucide-react';
import { useLanguage } from '../LanguageContext';
import { motion, AnimatePresence } from 'motion/react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import Modal from '../Modal';

export default function CRMModule({ user }: { user: UserProfile }) {
  const { t } = useLanguage();
  const [tenant, setTenant] = useState<Tenant | null>(null);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [selectedBranchId, setSelectedBranchId] = useState<string>(user.branchId || '');
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const submittingRef = React.useRef(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isBulkModalOpen, setIsBulkModalOpen] = useState(false);
  const [isCreditModalOpen, setIsCreditModalOpen] = useState(false);
  const [isDeleteCreditModalOpen, setIsDeleteCreditModalOpen] = useState(false);
  const [isTransferBranchModalOpen, setIsTransferBranchModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [customerToDelete, setCustomerToDelete] = useState<Customer | null>(null);
  const [deleteAction, setDeleteAction] = useState({ type: 'refund' as 'refund' | 'forfeit', accountId: '' });
  const [formData, setFormData] = useState({ name: '', phone: '', offerPercentage: '', branchId: user.branchId || '' });
  const [creditData, setCreditData] = useState({ type: 'deposit' as 'deposit' | 'refund', amount: '', accountId: '', note: '' });
  const [targetBranchId, setTargetBranchId] = useState('');
  const [bulkOffer, setBulkOffer] = useState('');

  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  const openConfirm = (title: string, message: string, onConfirm: () => void) => {
    setConfirmModal({
      isOpen: true,
      title,
      message,
      onConfirm: () => {
        onConfirm();
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const RenderConfirmModal = () => (
    confirmModal.isOpen ? (
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
        <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden p-6 space-y-6">
          <div className="flex items-center gap-4 p-4 bg-rose-50 rounded-2xl text-rose-600">
            <Trash2 size={24} />
            <p className="text-sm font-medium">{confirmModal.message}</p>
          </div>
          <div className="flex gap-3">
            <button 
              onClick={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
              className="flex-1 px-4 py-2 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 transition-all"
            >
              {t('cancel')}
            </button>
            <button 
              onClick={confirmModal.onConfirm}
              className="flex-1 px-4 py-2 bg-rose-600 text-white rounded-xl font-bold hover:bg-rose-700 transition-all shadow-lg shadow-rose-200"
            >
              {t('delete')}
            </button>
          </div>
        </div>
      </div>
    ) : null
  );

  const fetchData = async () => {
    if (!user.tenantId) return;
    setLoading(true);
    try {
      const { data: tenantData } = await supabase
        .from('tenants')
        .select('*')
        .eq('id', user.tenantId)
        .single();
        
      if (tenantData) {
        setTenant(tenantData);
      }

      if (tenantData?.is_multi_branch) {
        const { data: branchData } = await supabase
          .from('branches')
          .select('*')
          .eq('tenant_id', user.tenantId);
        if (branchData) setBranches(branchData);
      }
      
      let custQuery = supabase.from('customers').select('*').eq('tenant_id', user.tenantId);
      const effectiveBranchId = selectedBranchId || user.branchId;
      if (effectiveBranchId) {
        custQuery = custQuery.or(`branch_id.eq.${effectiveBranchId},branch_id.is.null`);
      }
      const { data: customerData } = await custQuery;
        
      if (customerData) {
        setCustomers(customerData.map(c => ({
          id: c.id,
          name: c.name,
          phone: c.phone,
          tenantId: c.tenant_id,
          branchId: c.branch_id,
          createdAt: c.created_at,
          totalDebt: c.total_debt,
          totalCredit: c.total_credit,
          offerPercentage: c.offer_percentage
        })));
      } else {
        setCustomers([]);
      }

      let accQuery = supabase.from('accounts').select('*').eq('tenant_id', user.tenantId);
      if (effectiveBranchId) {
        accQuery = accQuery.or(`branch_id.eq.${effectiveBranchId},branch_id.is.null`);
      }
      const { data: accData } = await accQuery;
      
      if (accData) {
        setAccounts(accData.map(a => ({
          id: a.id,
          name: a.name,
          balance: a.balance,
          tenantId: a.tenant_id,
          branchId: a.branch_id,
          createdAt: a.created_at
        })));
      }
    } catch (error) {
      console.error("Error fetching customers:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [user.tenantId, selectedBranchId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.tenantId || submitting) return;
    setSubmitting(true);

    try {
      const activeBranchId = selectedBranchId || user.branchId;
      const customerData: any = {
        name: formData.name,
        phone: formData.phone,
        offer_percentage: parseFloat(formData.offerPercentage) || 0,
        total_credit: editingCustomer ? editingCustomer.totalCredit : 0,
        tenant_id: user.tenantId,
        branch_id: formData.branchId || null,
        total_debt: editingCustomer ? editingCustomer.totalDebt : 0,
        created_at: editingCustomer ? editingCustomer.createdAt : new Date().toISOString()
      };

      if (editingCustomer) {
        await supabase.from('customers').update(customerData).eq('id', editingCustomer.id);
      } else {
        await supabase.from('customers').insert(customerData);
      }

      setIsModalOpen(false);
      setEditingCustomer(null);
      setFormData({ name: '', phone: '', offerPercentage: '', branchId: user.branchId || '' });
      fetchData();
    } catch (error) {
      console.error("Error saving customer:", error);
    } finally {
      setSubmitting(false);
    }
  };

  const handleBulkOffer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.tenantId || submitting) return;
    setSubmitting(true);

    try {
      const activeBranchId = selectedBranchId || user.branchId;
      const offer = parseFloat(bulkOffer) || 0;
      let query = supabase
        .from('customers')
        .update({ offer_percentage: offer })
        .eq('tenant_id', user.tenantId);
      
      if (activeBranchId) query = query.eq('branch_id', activeBranchId);

      await query;
        
      setIsBulkModalOpen(false);
      setBulkOffer('');
      fetchData();
    } catch (error) {
      console.error("Error applying bulk offer:", error);
    } finally {
      setSubmitting(false);
    }
  };

  const handleCreditSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.tenantId || submitting || submittingRef.current || !editingCustomer) return;
    const amount = parseFloat(creditData.amount) || 0;
    if (amount <= 0 || !creditData.accountId) return;

    submittingRef.current = true;
    setSubmitting(true);
    try {
      const selectedAccount = accounts.find(a => a.id === creditData.accountId);
      if (!selectedAccount) throw new Error("Account not found");

      // 1. Fetch latest customer credit
      const { data: latestCust } = await supabase
        .from('customers')
        .select('total_credit')
        .eq('id', editingCustomer.id)
        .single();
      
      const currentCredit = latestCust?.total_credit || 0;
      const newCustomerCredit = creditData.type === 'deposit' 
        ? currentCredit + amount
        : currentCredit - amount;
      
      if (newCustomerCredit < 0 && creditData.type === 'refund') {
        alert(t('refund_exceeds_credit' as any) || "Refund amount exceeds available credit");
        setSubmitting(false);
        return;
      }

      // 2. Update Customer Total Credit
      const { error: custError } = await supabase
        .from('customers')
        .update({ total_credit: newCustomerCredit })
        .eq('id', editingCustomer.id);
      
      if (custError) throw custError;

      // 3. Update Account balance
      const { data: latestAcc } = await supabase
        .from('accounts')
        .select('balance')
        .eq('id', selectedAccount.id)
        .single();
      
      const currentAccBalance = latestAcc?.balance || 0;
      const newAccountBalance = creditData.type === 'deposit'
        ? currentAccBalance + amount
        : currentAccBalance - amount;

      const { error: accError } = await supabase
        .from('accounts')
        .update({ balance: newAccountBalance })
        .eq('id', selectedAccount.id);
      
      if (accError) throw accError;

      // 4. Record Transaction
      const activeBranchId = selectedBranchId || user.branchId;
      const { error: transError } = await supabase.from('account_transactions').insert({
        tenant_id: user.tenantId,
        branch_id: activeBranchId || null,
        [creditData.type === 'deposit' ? 'to_account_id' : 'from_account_id']: selectedAccount.id,
        amount: amount,
        type: 'credit',
        description: `${creditData.type === 'deposit' ? 'Deposit' : 'Refund'} for credit: ${editingCustomer.name}. ${creditData.note}`,
        created_at: new Date().toISOString()
      });
      
      if (transError) throw transError;

      setIsCreditModalOpen(false);
      setEditingCustomer(null);
      setCreditData({ type: 'deposit', amount: '', accountId: '', note: '' });
      fetchData();
      alert(t('success_msg'));
    } catch (error: any) {
      console.error("Error managing credit:", error);
      alert(error.message || t('error_occurred'));
    } finally {
      setSubmitting(false);
      submittingRef.current = false;
    }
  };

  const handleTransferBranch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.tenantId || !editingCustomer || !targetBranchId || submitting) return;
    setSubmitting(true);
    try {
      const { error } = await supabase
        .from('customers')
        .update({ branch_id: targetBranchId })
        .eq('id', editingCustomer.id);
      
      if (error) throw error;
      
      setIsTransferBranchModalOpen(false);
      setEditingCustomer(null);
      setTargetBranchId('');
      fetchData();
      alert(t('transfer_success'));
    } catch (error) {
      console.error("Error transferring customer branch:", error);
      alert(t('error_occurred'));
    } finally {
      setSubmitting(false);
    }
  };

  const deleteCustomer = async (id: string) => {
    if (!user.tenantId) return;
    const customer = customers.find(c => c.id === id);
    if (!customer) return;

    // If customer has credit, we must ask how to handle it
    if ((customer.totalCredit || 0) > 0) {
      setCustomerToDelete(customer);
      setDeleteAction({ type: 'refund', accountId: '' });
      setIsDeleteCreditModalOpen(true);
      return;
    }

    // Normal delete for 0 credit
    openConfirm(t('delete'), t('delete_confirm'), async () => {
      await supabase.from('customers').delete().eq('id', id);
      fetchData();
    });
  };

  const processDeleteWithCredit = async () => {
    if (!user.tenantId || !customerToDelete || submitting) return;
    
    setSubmitting(true);
    try {
      if (deleteAction.type === 'refund') {
        if (!deleteAction.accountId) {
          alert("Please select an account for refund");
          setSubmitting(false);
          return;
        }
        const selectedAccount = accounts.find(a => a.id === deleteAction.accountId);
        if (selectedAccount) {
          // 1. Update Account balance (Decrease)
          const { error: accError } = await supabase
            .from('accounts')
            .update({ balance: selectedAccount.balance - customerToDelete.totalCredit })
            .eq('id', selectedAccount.id);
          
          if (accError) throw accError;

          // 2. Record Transaction
          const activeBranchId = selectedBranchId || user.branchId;
          const { error: transError } = await supabase.from('account_transactions').insert({
            tenant_id: user.tenantId,
            branch_id: activeBranchId || null,
            from_account_id: selectedAccount.id,
            amount: customerToDelete.totalCredit,
            type: 'expense',
            description: `Refund credit upon customer deletion: ${customerToDelete.name}`,
            created_at: new Date().toISOString()
          });
          if (transError) throw transError;
        }
      } else if (deleteAction.type === 'forfeit') {
        // Record gain as debt/credit adjustment transaction if desired, or just log
        const activeBranchId = selectedBranchId || user.branchId;
        const { error: transError } = await supabase.from('account_transactions').insert({
          tenant_id: user.tenantId,
          branch_id: activeBranchId || null,
          amount: customerToDelete.totalCredit,
          type: 'equity',
          description: `Credit forfeited upon customer deletion: ${customerToDelete.name}`,
          created_at: new Date().toISOString()
        });
        if (transError) throw transError;
      }

      // Finally, delete the customer
      const { error: delError } = await supabase.from('customers').delete().eq('id', customerToDelete.id);
      if (delError) throw delError;
      
      setIsDeleteCreditModalOpen(false);
      setCustomerToDelete(null);
      fetchData();
      alert(t('success_msg'));
    } catch (error: any) {
      console.error("Error deleting customer with credit:", error);
      alert(error.message || t('error_occurred'));
    } finally {
      setSubmitting(false);
    }
  };

  const downloadPDF = () => {
    let doc: any;
    try {
      doc = new jsPDF();
    } catch (e) {
      console.error("Error creating PDF:", e);
      return;
    }
    const businessName = tenant?.name || t('business_name_placeholder');
    const location = tenant?.location || '';
    const contact = tenant?.contact || '';
    
    // Header
    let yPos = 20;
    doc.setFontSize(20);
    doc.setTextColor(79, 70, 229); // Indigo-600
    doc.text(businessName, 14, yPos);
    yPos += 8;

    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139); // Slate-500
    if (location) {
      doc.text(location, 14, yPos);
      yPos += 5;
    }
    if (contact) {
      doc.text(contact, 14, yPos);
      yPos += 5;
    }
    
    yPos += 2;
    doc.setFontSize(12);
    doc.text(`${t('crm_report')} (${new Date().toLocaleDateString()})`, 14, yPos);
    yPos += 10;

    const tableColumn = [t('patient_name'), t('phone'), t('offer_percentage'), t('date')];
    const tableRows: any[] = [];

    customers.forEach(customer => {
      const rowData = [
        customer.name,
        customer.phone,
        `${customer.offerPercentage || 0}%`,
        new Date(customer.createdAt || '').toLocaleDateString()
      ];
      tableRows.push(rowData);
    });

    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: yPos,
      theme: 'grid',
      styles: { fontSize: 8, cellPadding: 3 },
      headStyles: { fillColor: [79, 70, 229], textColor: [255, 255, 255], fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [248, 250, 252] }
    });

    doc.save(`${businessName}_crm_report_${new Date().toLocaleDateString().replace(/\//g, '-')}.pdf`);
  };

  const downloadExcel = () => {
    const businessName = tenant?.name || t('business_name_placeholder');
    const location = tenant?.location || '';
    const contact = tenant?.contact || '';

    // Create header rows
    const headerRows = [
      [businessName],
      [location],
      [contact],
      [`${t('crm_report')} (${new Date().toLocaleDateString()})`],
      [] // Empty row
    ];

    const dataRows = customers.map(customer => [
      customer.name,
      customer.phone,
      `${customer.offerPercentage || 0}%`,
      new Date(customer.createdAt || '').toLocaleDateString()
    ]);

    const tableHeader = [t('patient_name'), t('phone'), t('offer_percentage'), t('date')];
    
    const allRows = [...headerRows, tableHeader, ...dataRows];
    const worksheet = XLSX.utils.aoa_to_sheet(allRows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Customers");
    XLSX.writeFile(workbook, `${businessName}_crm_report_${new Date().toLocaleDateString().replace(/\//g, '-')}.xlsx`);
  };

  if (loading) return <div className="p-8 text-center text-ink-secondary">{t('loading')}</div>;

  return (
    <div className="space-y-8 pb-12">
      <RenderConfirmModal />
      
      {/* Header Section */}
      <div className="bg-surface-main p-8 rounded-[2.5rem] border border-border-main shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-50 dark:bg-indigo-900/10 rounded-full -mr-32 -mt-32 blur-3xl opacity-50" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-emerald-50 dark:bg-emerald-950/10 rounded-full -ml-24 -mb-24 blur-2xl opacity-50" />
        
        <div className="relative flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-1">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-100 dark:shadow-none">
                <Users className="text-white" size={24} />
              </div>
              <h2 className="text-3xl font-display font-bold text-ink tracking-tight">
                {t('crm_customers')}
              </h2>
            </div>
            <p className="text-ink-secondary font-medium ml-15">{t('manage_customer_relationships')}</p>
          </div>

          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
            <button 
              onClick={() => {
                setEditingCustomer(null);
                setFormData({ name: '', phone: '', offerPercentage: '' });
                setIsModalOpen(true);
              }}
              className="flex-1 md:flex-none px-6 py-3.5 bg-indigo-600 text-white rounded-2xl font-bold shadow-lg shadow-indigo-100 dark:shadow-none hover:bg-indigo-700 hover:-translate-y-0.5 transition-all flex items-center justify-center gap-2"
            >
              <Plus size={20} />
              {t('add_customer')}
            </button>
            <button 
              onClick={() => setIsBulkModalOpen(true)}
              className="flex-1 md:flex-none px-6 py-3.5 bg-bg-sec text-emerald-600 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/30 rounded-2xl font-bold hover:bg-emerald-50 dark:hover:bg-emerald-950/30 transition-all flex items-center justify-center gap-2"
            >
              <Tag size={20} />
              {t('apply_bulk_offer')}
            </button>
          </div>
        </div>

        <div className="h-px bg-border-main w-full my-8" />

        <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-6">
          <div className="flex flex-wrap items-center gap-3 w-full xl:w-auto">
            {tenant?.is_multi_branch && !user.branchId && (
              <select
                value={selectedBranchId}
                onChange={(e) => setSelectedBranchId(e.target.value)}
                className="flex-1 sm:flex-none px-5 py-3 bg-indigo-50 border border-indigo-100 text-indigo-700 rounded-2xl font-bold hover:bg-indigo-100 transition-all shadow-sm outline-none cursor-pointer"
              >
                <option value="">{t('all_branches')}</option>
                {branches.map(b => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            )}
            <button 
              onClick={downloadPDF}
              disabled={customers.length === 0}
              className="flex-1 sm:flex-none px-5 py-3 bg-surface-main border border-border-main text-ink-secondary rounded-2xl font-bold hover:bg-bg-sec transition-all flex items-center justify-center gap-2 disabled:opacity-50 shadow-sm"
            >
              <FileDown size={18} className="text-red-500" />
              {t('download_pdf')}
            </button>
            <button 
              onClick={downloadExcel}
              disabled={customers.length === 0}
              className="flex-1 sm:flex-none px-5 py-3 bg-surface-main border border-border-main text-ink-secondary rounded-2xl font-bold hover:bg-bg-sec transition-all flex items-center justify-center gap-2 disabled:opacity-50 shadow-sm"
            >
              <Table size={18} className="text-emerald-500" />
              {t('download_excel')}
            </button>
            <button 
              onClick={fetchData}
              disabled={loading}
              className="flex-1 sm:flex-none px-5 py-3 bg-surface-main border border-border-main text-ink-secondary rounded-2xl font-bold hover:bg-bg-sec transition-all flex items-center justify-center gap-2 shadow-sm"
            >
              <RefreshCw size={18} className={`text-indigo-600 ${loading ? 'animate-spin' : ''}`} />
              {loading ? t('refreshing') : t('refresh')}
            </button>
          </div>
        </div>
      </div>

      {/* Customers Table */}
      <div className="bg-surface-main rounded-[2.5rem] border border-border-main shadow-sm overflow-hidden">
        <div className="overflow-x-auto custom-scrollbar">
          <table className="w-full text-left border-collapse">
            <thead className="bg-bg-sec text-xs font-bold uppercase tracking-[0.1em] text-ink-tertiary border-b border-border-main">
              <tr>
                <th className="px-8 py-5">{t('customer_name')}</th>
                <th className="px-8 py-5">{t('phone')}</th>
                {tenant?.is_multi_branch && <th className="px-8 py-5">{t('branch')}</th>}
                <th className="px-8 py-5 text-center">{t('balances' as any) || 'Balances'}</th>
                <th className="px-8 py-5 text-center">{t('offer_percentage')}</th>
                <th className="px-8 py-5 text-right">{t('actions')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border-main text-sm">
              {[...customers].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map(customer => (
                <tr key={customer.id} className="group hover:bg-bg-sec/50 transition-colors">
                  <td className="px-8 py-6">
                    <div className="flex flex-col">
                      <span className="font-black text-ink text-lg tracking-tight group-hover:text-accent-main transition-colors uppercase italic">{customer.name}</span>
                      <div className="flex items-center gap-2 opacity-60 mt-1.5">
                        <span className="text-[10px] font-black uppercase tracking-widest bg-bg-sec px-2 py-0.5 rounded border border-border-main/50">{t('id' as any) || 'ID'}: {customer.id.slice(0, 8)}</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-6 font-mono font-bold text-ink-secondary">
                    <div className="flex items-center gap-3">
                       <div className="w-10 h-10 rounded-xl bg-bg-sec border-2 border-border-main/50 flex items-center justify-center text-indigo-500 shadow-inner">
                         <Users size={16} strokeWidth={3} />
                       </div>
                       <span className="text-base">{customer.phone}</span>
                    </div>
                  </td>
                  {tenant?.is_multi_branch && (
                    <td className="px-8 py-6">
                      <span className="px-3 py-1 bg-slate-100 text-slate-600 rounded-lg text-xs font-bold">
                        {branches.find(b => b.id === customer.branchId)?.name || t('no_branch')}
                      </span>
                    </td>
                  )}
                  <td className="px-8 py-6">
                    <div className="flex flex-col items-center gap-2">
                       <div className="flex items-center gap-3 w-full max-w-[140px] justify-between">
                         <span className="text-[10px] font-black text-ink-tertiary uppercase opacity-50 tracking-wider">Debt</span>
                         <span className="text-sm font-black text-rose-600 bg-rose-50 px-2 py-0.5 rounded-lg border border-rose-100">${(customer.totalDebt || 0).toLocaleString()}</span>
                       </div>
                       <div className="flex items-center gap-3 w-full max-w-[140px] justify-between">
                         <span className="text-[10px] font-black text-ink-tertiary uppercase opacity-50 tracking-wider">Credit</span>
                         <span className="text-sm font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-100">${(customer.totalCredit || 0).toLocaleString()}</span>
                       </div>
                    </div>
                  </td>
                  <td className="px-8 py-6 text-center">
                    <div className="inline-flex items-center px-4 py-2 rounded-xl bg-accent-soft text-accent-main border-2 border-accent-main/20 shadow-sm group-hover:scale-110 transition-transform">
                      <span className="text-sm font-black tracking-tighter">{customer.offerPercentage || 0}%</span>
                      <Tag size={12} className="ml-1.5 opacity-60" strokeWidth={3} />
                    </div>
                  </td>
                  <td className="px-8 py-6 text-right whitespace-nowrap">
                    <div className="flex items-center justify-end gap-2 transition-all duration-300">
                      <button 
                        onClick={() => {
                          setEditingCustomer(customer);
                          setTargetBranchId(customer.branchId || '');
                          setIsTransferBranchModalOpen(true);
                        }}
                        className="p-3 text-amber-600 hover:bg-amber-50 rounded-2xl transition-all shadow-sm active:scale-95"
                        title={t('transfer_branch')}
                      >
                        <ArrowRightLeft size={20} strokeWidth={2.5} />
                      </button>
                      <button 
                        onClick={() => {
                          setEditingCustomer(customer);
                          setCreditData({ type: 'deposit', amount: '', accountId: '', note: '' });
                          setIsCreditModalOpen(true);
                        }}
                        className="p-3 text-emerald-600 hover:bg-emerald-50 rounded-2xl transition-all shadow-sm active:scale-95"
                        title={t('manage_credit' as any) || 'Manage Credit'}
                      >
                        <DollarSign size={20} strokeWidth={2.5} />
                      </button>
                      <button 
                        onClick={() => { 
                          setEditingCustomer(customer); 
                          setFormData({ 
                            name: customer.name || '', 
                            phone: customer.phone || '', 
                            offerPercentage: customer.offerPercentage?.toString() || '',
                            branchId: customer.branchId || ''
                          }); 
                          setIsModalOpen(true); 
                        }} 
                        className="p-3 text-blue-600 hover:bg-blue-50 rounded-2xl transition-all shadow-sm active:scale-95"
                        title={t('edit')}
                      >
                        <Edit2 size={20} strokeWidth={2.5} />
                      </button>
                      <button 
                        onClick={() => deleteCustomer(customer.id)} 
                        className="p-3 text-rose-600 hover:bg-rose-50 rounded-2xl transition-all shadow-sm active:scale-95"
                        title={t('delete')}
                      >
                        <Trash2 size={20} strokeWidth={2.5} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {customers.length === 0 && (
          <div className="p-24 text-center">
            <div className="w-24 h-24 bg-bg-sec border border-border-main rounded-[2.5rem] flex items-center justify-center mx-auto mb-6">
              <Users size={40} className="text-ink-tertiary/20" />
            </div>
            <h3 className="text-xl font-display font-bold text-ink mb-2">{t('no_customers' as any) || 'No Customers Found'}</h3>
            <p className="text-ink-secondary max-w-sm mx-auto">{t('no_customers_desc' as any) || 'Add your first customer to start tracking relationships and credit.'}</p>
          </div>
        )}
      </div>

      {isModalOpen && (
        <Modal 
          isOpen={isModalOpen} 
          onClose={() => setIsModalOpen(false)} 
          title={editingCustomer ? t('edit_customer') : t('add_customer')}
        >
          <form onSubmit={handleSubmit} className="p-8 space-y-6">
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{t('customer_name')}</label>
                <input 
                  type="text" 
                  value={formData.name} 
                  onChange={e => setFormData({...formData, name: e.target.value})} 
                  className="w-full px-6 py-4 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-indigo-500 text-base font-bold shadow-sm" 
                  required 
                />
              </div>
              <div>
                <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{t('phone')}</label>
                <input 
                  type="text" 
                  value={formData.phone} 
                  onChange={e => setFormData({...formData, phone: e.target.value})} 
                  className="w-full px-6 py-4 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-indigo-500 font-mono text-base font-bold shadow-sm" 
                  required 
                />
              </div>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{t('offer_percentage')}</label>
                  <input 
                    type="number" 
                    value={formData.offerPercentage} 
                    onChange={e => setFormData({...formData, offerPercentage: e.target.value})} 
                    className="w-full px-6 py-4 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-indigo-500 text-base font-black shadow-sm" 
                  />
                </div>
              </div>
              {tenant?.is_multi_branch && (
                <div>
                  <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{t('branch')}</label>
                  <select 
                    value={formData.branchId} 
                    onChange={e => setFormData({...formData, branchId: e.target.value})} 
                    className="w-full px-6 py-4 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-indigo-500 text-base font-bold shadow-sm bg-white"
                  >
                    <option value="">{t('select_branch')}</option>
                    {branches.map(b => (
                      <option key={b.id} value={b.id}>{b.name}</option>
                    ))}
                  </select>
                </div>
              )}
            </div>
            <div className="flex gap-4 pt-6">
              <button type="button" onClick={() => setIsModalOpen(false)} disabled={submitting} className="flex-1 px-6 py-4 border-2 border-slate-200 text-slate-600 rounded-2xl font-black uppercase tracking-widest hover:bg-slate-50 transition-all disabled:opacity-50">{t('cancel')}</button>
              <button type="submit" disabled={submitting} className="flex-1 px-6 py-4 bg-indigo-600 text-white rounded-2xl font-black uppercase tracking-widest hover:bg-indigo-700 shadow-lg shadow-indigo-100 transition-all disabled:opacity-50 active:scale-95">{submitting ? t('saving') || 'Saving...' : t('save')}</button>
            </div>
          </form>
        </Modal>
      )}

      {isTransferBranchModalOpen && (
        <Modal 
          isOpen={isTransferBranchModalOpen} 
          onClose={() => {
            setIsTransferBranchModalOpen(false);
            setEditingCustomer(null);
          }} 
          title={`${t('transfer_branch')}: ${editingCustomer?.name}`}
        >
          <form onSubmit={handleTransferBranch} className="p-8 space-y-6">
            <div>
              <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{t('select_target_branch')}</label>
              <select 
                value={targetBranchId} 
                onChange={e => setTargetBranchId(e.target.value)} 
                className="w-full px-6 py-4 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-amber-500 text-base font-bold shadow-sm bg-white"
                required
              >
                <option value="" disabled>{t('select_branch')}</option>
                {branches.map(b => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
              <p className="mt-4 text-xs text-slate-500 bg-slate-50 p-4 rounded-xl border border-slate-100">
                {t('transfer_branch_desc' as any) || 'Moving a customer to another branch will update their visibility to that branch. Their debt and credit history remains unchanged.'}
              </p>
            </div>
            <div className="flex gap-4 pt-6">
              <button type="button" onClick={() => setIsTransferBranchModalOpen(false)} disabled={submitting} className="flex-1 px-6 py-4 border-2 border-slate-200 text-slate-600 rounded-2xl font-black uppercase tracking-widest hover:bg-slate-50 transition-all disabled:opacity-50">{t('cancel')}</button>
              <button type="submit" disabled={submitting || !targetBranchId} className="flex-1 px-6 py-4 bg-amber-600 text-white rounded-2xl font-black uppercase tracking-widest hover:bg-amber-700 shadow-lg shadow-amber-100 transition-all disabled:opacity-50 active:scale-95">{submitting ? t('processing') : t('confirm_transfer')}</button>
            </div>
          </form>
        </Modal>
      )}

      {isBulkModalOpen && (
        <Modal 
          isOpen={isBulkModalOpen} 
          onClose={() => setIsBulkModalOpen(false)} 
          title={t('apply_bulk_offer')}
        >
          <form onSubmit={handleBulkOffer} className="space-y-5">
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('offer_percentage')} (%)</label>
              <input 
                type="number" 
                value={bulkOffer} 
                onChange={e => setBulkOffer(e.target.value)} 
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-medium" 
                required 
              />
            </div>
            <div className="flex gap-3 pt-4">
              <button type="button" onClick={() => setIsBulkModalOpen(false)} disabled={submitting} className="flex-1 px-4 py-3.5 border border-slate-200 text-slate-600 rounded-xl font-bold hover:bg-slate-50 transition-all disabled:opacity-50">{t('cancel')}</button>
              <button type="submit" disabled={submitting} className="flex-1 px-4 py-3.5 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 shadow-lg shadow-emerald-100 transition-all disabled:opacity-50">{submitting ? t('saving') || 'Saving...' : t('save')}</button>
            </div>
          </form>
        </Modal>
      )}

      {isCreditModalOpen && (
        <Modal 
          isOpen={isCreditModalOpen} 
          onClose={() => setIsCreditModalOpen(false)} 
          title={`${t('manage_credit' as any) || 'Manage Credit'}: ${editingCustomer?.name}`}
        >
          <form onSubmit={handleCreditSubmit} className="space-y-6">
            <div className="flex bg-slate-100 p-1.5 rounded-2xl">
              <button 
                type="button" 
                onClick={() => setCreditData({...creditData, type: 'deposit'})}
                className={`flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold transition-all ${creditData.type === 'deposit' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
              >
                <ArrowUpRight size={18} />
                {t('deposit' as any) || 'Deposit'}
              </button>
              <button 
                type="button"
                onClick={() => setCreditData({...creditData, type: 'refund'})}
                className={`flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold transition-all ${creditData.type === 'refund' ? 'bg-white text-rose-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
              >
                <ArrowDownRight size={18} />
                {t('refund' as any) || 'Refund'}
              </button>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">{t('current_credit' as any) || 'Current Credit'}</span>
              <span className="text-xl font-black text-slate-900">${(editingCustomer?.totalCredit || 0).toFixed(2)}</span>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('amount')}</label>
                <input 
                  type="number" 
                  step="0.01"
                  value={creditData.amount} 
                  onChange={e => setCreditData({...creditData, amount: e.target.value})} 
                  placeholder="0.00"
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-display text-lg font-bold" 
                  required 
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('select_account' as any) || 'Select Account'}</label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {accounts.filter(acc => creditData.type === 'deposit' || acc.balance > 0).map(acc => (
                    <button
                      key={acc.id}
                      type="button"
                      onClick={() => setCreditData({...creditData, accountId: acc.id})}
                      className={`p-3 rounded-xl border transition-all text-left ${creditData.accountId === acc.id ? 'bg-indigo-600 border-indigo-600 text-white' : 'bg-white border-slate-200 text-slate-600 hover:border-indigo-300'}`}
                    >
                      <Landmark size={14} className="mb-2 opacity-60" />
                      <div className="text-xs font-bold truncate leading-tight">{acc.name}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('note' as any) || 'Note'}</label>
                <textarea 
                  value={creditData.note} 
                  onChange={e => setCreditData({...creditData, note: e.target.value})} 
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-medium min-h-[80px]"
                  placeholder={t('note_placeholder' as any) || 'Optional note about this transaction...'}
                />
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <button 
                type="button" 
                onClick={() => setIsCreditModalOpen(false)} 
                disabled={submitting} 
                className="flex-1 px-4 py-3.5 border border-slate-200 text-slate-600 rounded-xl font-bold hover:bg-slate-50 transition-all disabled:opacity-50"
              >
                {t('cancel')}
              </button>
              <button 
                type="submit" 
                disabled={submitting || !creditData.accountId || !creditData.amount} 
                className={`flex-1 px-4 py-3.5 rounded-xl font-bold transition-all shadow-lg disabled:opacity-50 ${creditData.type === 'deposit' ? 'bg-emerald-600 text-white shadow-emerald-100 hover:bg-emerald-700' : 'bg-indigo-600 text-white shadow-indigo-100 hover:bg-indigo-700'}`}
              >
                {submitting ? t('saving') : (creditData.type === 'deposit' ? (t('process_deposit' as any) || 'Process Deposit') : (t('process_refund' as any) || 'Process Refund'))}
              </button>
            </div>
          </form>
        </Modal>
      )}

      {isDeleteCreditModalOpen && (
        <Modal 
          isOpen={isDeleteCreditModalOpen} 
          onClose={() => setIsDeleteCreditModalOpen(false)} 
          title={t('customer_has_credit' as any) || 'Customer has Credit Balance'}
        >
          <div className="space-y-6">
            <div className="p-6 bg-amber-50 border border-amber-200 rounded-3xl text-center">
              <p className="text-sm font-bold text-amber-800 mb-2">{t('balance_deletion_warning' as any) || 'This customer still has an active credit balance:'}</p>
              <h4 className="text-3xl font-black text-amber-600">${(customerToDelete?.totalCredit || 0).toFixed(2)}</h4>
              <p className="text-xs text-amber-700/60 mt-3">{t('choose_how_to_handle' as any) || 'How would you like to handle this money before deleting the profile?'}</p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button 
                onClick={() => setDeleteAction({...deleteAction, type: 'refund'})}
                className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 ${deleteAction.type === 'refund' ? 'border-indigo-600 bg-indigo-50 text-indigo-700' : 'border-slate-100 bg-slate-50 text-slate-500 hover:border-slate-200'}`}
              >
                <ArrowDownRight size={20} />
                <span className="text-xs font-bold">{t('refund_to_account' as any) || 'Refund to Account'}</span>
              </button>
              <button 
                onClick={() => setDeleteAction({...deleteAction, type: 'forfeit'})}
                className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 ${deleteAction.type === 'forfeit' ? 'border-emerald-600 bg-emerald-50 text-emerald-700' : 'border-slate-100 bg-slate-50 text-slate-500 hover:border-slate-200'}`}
              >
                <RefreshCw size={20} />
                <span className="text-xs font-bold">{t('forfeit_credit' as any) || 'Forfeit Credit (Gain)'}</span>
              </button>
            </div>

            <AnimatePresence>
              {deleteAction.type === 'refund' && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="space-y-3"
                >
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">{t('select_refund_account' as any) || 'Select Source Account'}</label>
                  <div className="grid grid-cols-2 gap-2">
                    {accounts.filter(acc => acc.balance > 0).map(acc => (
                      <button
                        key={acc.id}
                        type="button"
                        onClick={() => setDeleteAction({...deleteAction, accountId: acc.id})}
                        className={`p-3 rounded-xl border text-left transition-all ${deleteAction.accountId === acc.id ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm' : 'bg-white border-slate-200 text-slate-600'}`}
                      >
                        <div className="text-[10px] font-bold truncate">{acc.name}</div>
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="flex gap-3 pt-4 border-t border-slate-100">
              <button 
                onClick={() => setIsDeleteCreditModalOpen(false)} 
                className="flex-1 px-4 py-3.5 border border-slate-200 text-slate-600 rounded-xl font-bold hover:bg-slate-50 transition-all font-display"
              >
                {t('cancel')}
              </button>
              <button 
                onClick={processDeleteWithCredit}
                disabled={submitting || (deleteAction.type === 'refund' && !deleteAction.accountId)}
                className="flex-1 px-4 py-3.5 bg-rose-600 text-white rounded-xl font-bold hover:bg-rose-700 shadow-lg shadow-rose-100 transition-all font-display disabled:opacity-50"
              >
                {submitting ? t('processing') : t('confirm_deletion' as any) || 'Confirm Deletion'}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
