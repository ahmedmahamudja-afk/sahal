import React, { useState, useEffect } from 'react';
import { supabase } from '../../supabase';
import { Patient, UserProfile, PatientVisit, PrescriptionItem, InventoryItem, StaffMember } from '../../types';
import { 
  Users, 
  UserPlus, 
  Search, 
  Trash2, 
  Activity, 
  ClipboardList, 
  Stethoscope, 
  Pill, 
  Receipt, 
  ArrowRight,
  Plus,
  X,
  CheckCircle2,
  Clock,
  Wallet,
  RefreshCw,
  Calendar,
  ShoppingCart,
  Edit2,
  History
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../LanguageContext';
import Modal from '../Modal';

type HospitalTab = 'dashboard' | 'patients' | 'doctor' | 'pharmacy';

export default function HospitalModule({ user, navigateToSales }: { user: UserProfile, navigateToSales: (prescription: PrescriptionItem[], total: number, patientName?: string, patientPhone?: string, visitId?: string) => void }) {
  const { t } = useLanguage();
  const isManager = user.role === 'business_user' && !user.isStaff;
  
  const getAvailableTabs = (): HospitalTab[] => {
    if (isManager) return ['dashboard', 'patients', 'doctor', 'pharmacy'];
    
    const tabs: HospitalTab[] = [];
    if (user.staffRoles?.includes('hospital_reception')) tabs.push('patients');
    if (user.staffRoles?.includes('hospital_doctor')) tabs.push('doctor');
    if (user.staffRoles?.includes('hospital_pharmacy')) tabs.push('pharmacy');
    
    return tabs;
  };

  const availableTabs = getAvailableTabs();
  const [activeTab, setActiveTab] = useState<HospitalTab>(availableTabs[0] || 'patients');
  const [patients, setPatients] = useState<Patient[]>([]);
  const [visits, setVisits] = useState<PatientVisit[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Modal States
  const [isAddPatientModalOpen, setIsAddPatientModalOpen] = useState(false);
  const [editingPatientId, setEditingPatientId] = useState<string | null>(null);
  const [isStartVisitModalOpen, setIsStartVisitModalOpen] = useState<Patient | null>(null);
  const [isConsultModalOpen, setIsConsultModalOpen] = useState<PatientVisit | null>(null);
  const [isAccountsModalOpen, setIsAccountsModalOpen] = useState<{ visit: PatientVisit, type: 'consultation' | 'pharmacy' | 'full' } | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<string>('Cash');
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState<Patient | null>(null);

  // Form States
  const [newPatient, setNewPatient] = useState<{name: string, age: string, phone: string, insuranceProvider: string, type: 'outpatient' | 'inpatient'}>({ name: '', age: '', phone: '', insuranceProvider: '', type: 'outpatient' });
  const [registrationFee, setRegistrationFee] = useState('0');
  const [consultationFee, setConsultationFee] = useState('10');
  const [selectedDoctor, setSelectedDoctor] = useState<{ id: string, name: string, phone?: string } | null>(null);
  const [diagnosis, setDiagnosis] = useState('');
  const [prescription, setPrescription] = useState<PrescriptionItem[]>([]);
  const [newPrescriptionItem, setNewPrescriptionItem] = useState({ medicineName: '', dosage: '', quantity: NaN, price: 0 });

  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [lastUpdated, setLastUpdated] = useState<string>(new Date().toLocaleTimeString());
  const [isSaving, setIsSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);

  // Confirmation Modal State
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  const openConfirm = (title: string, message: string, onConfirm: () => void) => {
    setConfirmModal({
      isOpen: true,
      title,
      message,
      onConfirm: () => {
        onConfirm();
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const RenderConfirmModal = () => (
    confirmModal.isOpen ? (
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
        <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden p-6 space-y-6">
          <div className="flex items-center gap-4 p-4 bg-rose-50 rounded-2xl text-rose-600">
            <Trash2 size={24} />
            <p className="text-sm font-medium">{confirmModal.message}</p>
          </div>
          <div className="flex gap-3">
            <button 
              onClick={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
              className="flex-1 px-4 py-2 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 transition-all"
            >
              {t('cancel')}
            </button>
            <button 
              onClick={confirmModal.onConfirm}
              className="flex-1 px-4 py-2 bg-rose-600 text-white rounded-xl font-bold hover:bg-rose-700 transition-all shadow-lg shadow-rose-200"
            >
              {t('delete')}
            </button>
          </div>
        </div>
      </div>
    ) : null
  );

  const fetchData = async () => {
    if (!user.tenantId) return;
    try {
      let patientsQuery = supabase.from('patients').select('*').eq('tenant_id', user.tenantId);
      if (user.branchId) patientsQuery = patientsQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
      
      let visitsQuery = supabase.from('visits').select('*').eq('tenant_id', user.tenantId).order('created_at', { ascending: false });
      if (user.branchId) visitsQuery = visitsQuery.eq('branch_id', user.branchId);
      
      let invQuery = supabase.from('inventory').select('*').eq('tenant_id', user.tenantId);
      if (user.branchId) invQuery = invQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
      
      let staffQuery = supabase.from('staff').select('*').eq('tenant_id', user.tenantId);
      if (user.branchId) staffQuery = staffQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
      
      let accQuery = supabase.from('accounts').select('*').eq('tenant_id', user.tenantId);
      if (user.branchId) accQuery = accQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);

      const [
        { data: patientsData },
        { data: visitsData },
        { data: invData },
        { data: staffData },
        { data: accData }
      ] = await Promise.all([
        patientsQuery,
        visitsQuery,
        invQuery,
        staffQuery,
        accQuery
      ]);

      setAccounts(accData || []);

      setPatients(patientsData?.map(p => ({
        id: p.id,
        name: p.name,
        age: p.age,
        phone: p.phone,
        insuranceProvider: p.insurance_provider,
        type: p.type || 'outpatient',
        tenantId: p.tenant_id,
        branchId: p.branch_id,
        createdAt: p.created_at
      })) || []);
      setVisits(visitsData?.map(v => ({
        id: v.id,
        patientId: v.patient_id,
        patientName: v.patient_name,
        patientAge: v.patient_age,
        doctorId: v.doctor_id,
        doctorName: v.doctor_name,
        doctorPhone: v.doctor_phone,
        status: v.status,
        registrationFee: v.registration_fee,
        consultationFee: v.consultation_fee,
        diagnosis: v.diagnosis,
        prescription: v.prescription,
        totalBill: v.total_bill,
        paidAmount: v.paid_amount,
        consultationPaid: v.consultation_paid,
        pharmacyPaid: v.pharmacy_paid,
        dispensed: v.dispensed,
        tenantId: v.tenant_id,
        branchId: v.branch_id,
        createdAt: v.created_at
      })) || []);
      if (invData) {
        setInventory(invData.map(item => ({
          id: item.id,
          name: item.name,
          sku: item.sku,
          quantity: item.quantity,
          costPrice: item.cost_price,
          price: item.price,
          minStock: item.min_stock,
          imageUrl: item.image_url,
          tenantId: item.tenant_id,
          branchId: item.branch_id,
          createdAt: item.created_at
        })));
      } else {
        setInventory([]);
      }
      setStaff(staffData?.map(s => ({
        id: s.id,
        username: s.username,
        password: s.password,
        displayName: s.display_name,
        phone: s.phone,
        photoURL: s.photo_url,
        roles: s.roles || [],
        tenantId: s.tenant_id,
        branchId: s.branch_id,
        isLocked: s.is_locked,
        createdAt: s.created_at,
        position: s.position,
        department: s.department,
        salary: s.salary,
        status: s.status,
        hireDate: s.hire_date
      })) || []);
      setLastUpdated(new Date().toLocaleTimeString());
    } catch (error) {
      console.error("Error fetching hospital data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!user.tenantId) return;

    const patientsChannel = supabase
      .channel('hospital_patients')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'patients', filter: `tenant_id=eq.${user.tenantId}` }, fetchData)
      .subscribe();

    const visitsChannel = supabase
      .channel('hospital_visits')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'visits', filter: `tenant_id=eq.${user.tenantId}` }, fetchData)
      .subscribe();

    const invChannel = supabase
      .channel('hospital_inventory')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'inventory', filter: `tenant_id=eq.${user.tenantId}` }, fetchData)
      .subscribe();

    const staffChannel = supabase
      .channel('hospital_staff')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'staff', filter: `tenant_id=eq.${user.tenantId}` }, fetchData)
      .subscribe();

    const accountsChannel = supabase
      .channel('hospital_accounts')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'accounts', filter: `tenant_id=eq.${user.tenantId}` }, fetchData)
      .subscribe();

    fetchData();

    return () => {
      supabase.removeChannel(patientsChannel);
      supabase.removeChannel(visitsChannel);
      supabase.removeChannel(invChannel);
      supabase.removeChannel(staffChannel);
      supabase.removeChannel(accountsChannel);
    };
  }, [user.tenantId, refreshTrigger]);

  const handleRefresh = async () => {
    setLoading(true);
    if (!user.tenantId) {
      setLoading(false);
      return;
    }
    setRefreshTrigger(prev => prev + 1);
  };

  const doctors = staff.filter(s => s.roles?.includes('hospital_doctor'));

  const handleAddPatient = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.tenantId) return;
    setIsSaving(true);
    setSaveError(null);
    try {
      if (editingPatientId) {
        const { error: updateError } = await supabase.from('patients').update({
          name: newPatient.name,
          age: newPatient.age,
          phone: newPatient.phone,
          insurance_provider: newPatient.insuranceProvider,
          type: newPatient.type,
          updated_at: new Date().toISOString()
        }).eq('id', editingPatientId);
        if (updateError) {
          if (updateError.message.includes('column "type" of relation "patients" does not exist')) {
            alert('Please run the following SQL in your Supabase SQL Editor to enable Patient Types:\n\nALTER TABLE patients ADD COLUMN type TEXT DEFAULT \'outpatient\';');
            return;
          }
          throw updateError;
        }
      } else {
        const { data: patientRef, error: patientError } = await supabase.from('patients').insert({
          name: newPatient.name,
          age: newPatient.age,
          phone: newPatient.phone,
          insurance_provider: newPatient.insuranceProvider,
          type: newPatient.type,
          tenant_id: user.tenantId,
          branch_id: user.branchId || null,
          created_at: new Date().toISOString()
        }).select().single();
        
        if (patientError) {
          console.error("Patient insert error:", patientError);
          if (patientError.message.includes('column "type" of relation "patients" does not exist') || patientError.code === '42703') {
            alert('Please run the following SQL in your Supabase SQL Editor to enable Patient Types:\n\nALTER TABLE patients ADD COLUMN type TEXT DEFAULT \'outpatient\';');
            return;
          }
          throw patientError;
        }

        // If doctor is selected, start visit immediately
        if (selectedDoctor && patientRef) {
          const regFee = parseFloat(registrationFee) || 0;
          const consFee = parseFloat(consultationFee) || 0;
          const isFree = (regFee + consFee) === 0;

          const { error: visitError } = await supabase.from('visits').insert({
            patient_id: patientRef.id,
            patient_name: newPatient.name,
            patient_age: newPatient.age,
            doctor_id: selectedDoctor.id,
            doctor_name: selectedDoctor.name,
            doctor_phone: selectedDoctor.phone || '',
            status: isFree ? 'doctor' : 'reception',
            registration_fee: regFee,
            consultation_fee: consFee,
            consultation_paid: isFree,
            tenant_id: user.tenantId,
            branch_id: user.branchId || null,
            created_at: new Date().toISOString()
          });
          if (visitError) {
             console.error("Visit insert error:", visitError);
             throw visitError;
          }
          setActiveTab(isFree ? 'doctor' : 'patients');
        }
      }

      setIsAddPatientModalOpen(false);
      setEditingPatientId(null);
      setNewPatient({ name: '', age: '', phone: '', insuranceProvider: '', type: 'outpatient' });
      setSelectedDoctor(null);
      setRegistrationFee('0');
      setConsultationFee('10');
    } catch (error: any) {
      console.error("Error adding/updating patient:", error);
      setSaveError(error.message || "Cilad ayaa dhacday markii la keydinayay bukaanka");
      alert("Cilad: " + (error.message || "Lama keydin karo xogta"));
    } finally {
      setIsSaving(false);
    }
  };

  const handleEditPatient = (patient: Patient) => {
    setEditingPatientId(patient.id);
    setNewPatient({
      name: patient.name || '',
      age: patient.age || '',
      phone: patient.phone || '',
      insuranceProvider: patient.insuranceProvider || '',
      type: patient.type || 'outpatient'
    });
    setIsAddPatientModalOpen(true);
  };

  const handleDeletePatient = async (patientId: string) => {
    if (!user.tenantId) return;
    openConfirm(t('delete'), t('delete_patient_confirm'), async () => {
      try {
        const { error } = await supabase.from('patients').delete().eq('id', patientId);
        if (error) throw error;
        fetchData();
      } catch (error) {
        console.error("Error deleting patient:", error);
      }
    });
  };

  const handleDeleteVisit = async (visitId: string) => {
    if (!user.tenantId) return;
    openConfirm(t('delete'), t('delete_confirm'), async () => {
      try {
        const { error } = await supabase.from('visits').delete().eq('id', visitId);
        if (error) throw error;
        fetchData();
      } catch (error) {
        console.error("Error deleting visit:", error);
      }
    });
  };

  const handleStartVisit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.tenantId || !isStartVisitModalOpen || !selectedDoctor) return;
    try {
      const regFee = parseFloat(registrationFee) || 0;
      const consFee = parseFloat(consultationFee) || 0;
      const isFree = (regFee + consFee) === 0;

      const { error: visitError } = await supabase.from('visits').insert({
        patient_id: isStartVisitModalOpen.id,
        patient_name: isStartVisitModalOpen.name,
        patient_age: isStartVisitModalOpen.age,
        doctor_id: selectedDoctor.id,
        doctor_name: selectedDoctor.name,
        doctor_phone: selectedDoctor.phone || '',
        status: isFree ? 'doctor' : 'reception',
        registration_fee: regFee,
        consultation_fee: consFee,
        consultation_paid: isFree,
        tenant_id: user.tenantId,
        branch_id: user.branchId || null,
        created_at: new Date().toISOString()
      });
      if (visitError) {
        console.error("Visit insert error:", visitError);
        throw visitError;
      }
      setIsStartVisitModalOpen(null);
      setSelectedDoctor(null);
      setRegistrationFee('5');
      setConsultationFee('10');
      fetchData();
      setActiveTab(isFree ? 'doctor' : 'patients');
    } catch (error) {
      console.error("Error starting visit:", error);
    } finally {
      setIsSaving(false);
    }
  };

  const handleForwardToDoctor = async (visit: PatientVisit) => {
    try {
      const isFree = (visit.consultationFee || 0) === 0;
      const { error } = await supabase.from('visits').update({ 
        status: 'doctor',
        consultation_paid: isFree || visit.consultationPaid
      }).eq('id', visit.id);
      if (error) throw error;
      fetchData();
    } catch (error) {
      console.error("Error forwarding to doctor:", error);
    }
  };

  const handleSaveConsultation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.tenantId || !isConsultModalOpen || isSaving) return;
    setIsSaving(true);
    try {
      let finalPrescription = [...prescription];
      if (newPrescriptionItem.medicineName) {
        const invItem = inventory.find(i => i.name === newPrescriptionItem.medicineName);
        const qty = isNaN(newPrescriptionItem.quantity) ? 1 : newPrescriptionItem.quantity;
        finalPrescription.push({ 
          ...newPrescriptionItem, 
          quantity: qty, 
          medicineId: invItem?.id || `med-${Math.random().toString(36).substr(2, 9)}` 
        });
      }

      let nextStatus = 'accounts';
      if (finalPrescription.length > 0) {
        nextStatus = 'pharmacy';
      }

      await supabase.from('visits').update({
        diagnosis,
        prescription: finalPrescription,
        status: nextStatus
      }).eq('id', isConsultModalOpen.id);
      setIsConsultModalOpen(null);
      setDiagnosis('');
      setPrescription([]);
      setNewPrescriptionItem({ medicineName: '', dosage: '', quantity: NaN, price: 0 });
      fetchData();
      setActiveTab(nextStatus as HospitalTab);
    } catch (error) {
      console.error("Error saving consultation:", error);
    } finally {
      setIsSaving(false);
    }
  };

  useEffect(() => {
    if (isConsultModalOpen) {
      setDiagnosis(isConsultModalOpen.diagnosis || '');
      setPrescription(isConsultModalOpen.prescription || []);
    } else {
      setDiagnosis('');
      setPrescription([]);
    }
  }, [isConsultModalOpen]);

  const handlePayment = async (visit: PatientVisit, type: 'consultation' | 'pharmacy' | 'full') => {
    if (!user.tenantId || isSaving) return;
    setIsSaving(true);
    
    const serviceItems = [];
    let serviceTotal = 0;

    if (type === 'consultation' || type === 'full') {
      if (visit.consultationFee && visit.consultationFee > 0) {
        serviceItems.push({
          id: 'consultation',
          name: t('consultation_fee_short'),
          price: visit.consultationFee,
          quantity: 1,
          subtotal: visit.consultationFee
        });
        serviceTotal += visit.consultationFee;
      }
    }

    if (type === 'pharmacy' || type === 'full') {
      if (visit.prescription && visit.prescription.length > 0) {
        for (const item of visit.prescription) {
          serviceItems.push({
            id: item.medicineId,
            name: item.medicineName,
            price: item.price,
            quantity: item.quantity,
            subtotal: item.price * item.quantity
          });
          serviceTotal += item.price * item.quantity;
        }
      }
    }

    if (serviceItems.length === 0) return;

    try {
      const { data: saleData, error: saleError } = await supabase.from('sales').insert({
        items: serviceItems,
        total: serviceTotal,
        tax: 0,
        paid_amount: serviceTotal,
        debt_amount: 0,
        customer_name: visit.patientName,
        status: 'paid',
        payment_methods: [{ method: paymentMethod, amount: serviceTotal }],
        tenant_id: user.tenantId,
        branch_id: user.branchId || null,
        seller_name: user.displayName || user.username || 'System',
        created_at: new Date().toISOString()
      }).select().single();

      if (saleError) throw saleError;

      // Update Account Balance
      if (serviceTotal > 0) {
        let accQuery = supabase
          .from('accounts')
          .select('*')
          .eq('tenant_id', user.tenantId)
          .eq('name', paymentMethod);
        
        if (user.branchId) accQuery = accQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);

        let { data: accData } = await accQuery.maybeSingle();
        
        if (!accData) {
          const { data: newAcc } = await supabase
            .from('accounts')
            .insert({ 
              name: paymentMethod, 
              balance: serviceTotal, 
              tenant_id: user.tenantId,
              branch_id: user.branchId || null
            })
            .select()
            .single();
          accData = newAcc;
        } else {
          await supabase
            .from('accounts')
            .update({ balance: accData.balance + serviceTotal })
            .eq('id', accData.id);
        }

        if (accData) {
          await supabase.from('account_transactions').insert({
            to_account_id: accData.id,
            amount: serviceTotal,
            type: 'sale',
            description: `Hospital payment from ${visit.patientName}`,
            tenant_id: user.tenantId,
            branch_id: user.branchId || null,
            reference_id: saleData.id,
            created_at: new Date().toISOString()
          });
        }
      }

      const updates: any = {
        paid_amount: (visit.paidAmount || 0) + serviceTotal
      };

      if (type === 'consultation') {
        updates.consultation_paid = true;
      }
      if (type === 'pharmacy') updates.pharmacy_paid = true;
      
      const isConsultPaid = type === 'consultation' || visit.consultationPaid;
      const hasPrescription = visit.prescription && visit.prescription.length > 0;
      const isPharmPaid = type === 'pharmacy' || visit.pharmacyPaid || (visit.status !== 'pharmacy' && !hasPrescription);

      if (isConsultPaid && isPharmPaid && visit.status !== 'reception') {
        updates.status = 'completed';
        updates.total_bill = (visit.consultationFee || 0) + (visit.prescription?.reduce((sum, item) => sum + (item.price * item.quantity), 0) || 0);
      }

      if (type === 'pharmacy' || type === 'full') {
        if (visit.prescription && visit.prescription.length > 0 && !visit.dispensed) {
          for (const item of visit.prescription) {
            if (!item.medicineId.startsWith('manual_')) {
              const invItem = inventory.find(i => i.id === item.medicineId);
              if (invItem) {
                const newQty = Math.max(0, invItem.quantity - item.quantity);
                await supabase.from('inventory').update({
                  quantity: newQty
                }).eq('id', item.medicineId);
              }
            }
          }
          updates.dispensed = true;
        }
      }

      await supabase.from('visits').update(updates).eq('id', visit.id);
      setIsAccountsModalOpen(null);
      fetchData();
    } catch (error) {
      console.error("Error processing payment:", error);
    } finally {
      setIsSaving(false);
    }
  };

  const addPrescriptionItem = () => {
    if (!newPrescriptionItem.medicineName) return;
    
    const invItem = inventory.find(i => i.name === newPrescriptionItem.medicineName);
    const qty = isNaN(newPrescriptionItem.quantity) ? 1 : newPrescriptionItem.quantity;
    
    setPrescription([...prescription, { 
      ...newPrescriptionItem, 
      quantity: qty, 
      medicineId: invItem?.id || `med-${Math.random().toString(36).substr(2, 9)}` 
    }]);
    setNewPrescriptionItem({ medicineName: '', dosage: '', quantity: NaN, price: 0 });
  };

  const removePrescriptionItem = (index: number) => {
    setPrescription(prescription.filter((_, i) => i !== index));
  };

  const filteredPatients = React.useMemo(() => patients.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || p.phone.includes(searchTerm);
    const isOutpatient = p.type === 'outpatient';
    const hasVisit = visits.some(v => v.patientId === p.id);
    
    // Hide outpatients from the records list once they have been registered and sent to doctor/reception
    if (isOutpatient && hasVisit) {
      return false;
    }
    
    return matchesSearch;
  }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()), [patients, searchTerm, visits]);

  const visitsByStatus = React.useMemo(() => {
    const statuses = ['reception', 'doctor', 'pharmacy', 'completed', 'accounts'];
    const mapping: Record<string, PatientVisit[]> = {};
    
    statuses.forEach(status => {
      let filtered = visits.filter(v => v.status === status);
      if (status === 'reception') {
        filtered = visits.filter(v => {
          const total = (v.consultationFee || 0);
          const isFree = total === 0;
          if (isFree) return false;
          return v.status === 'reception' || (!v.consultationPaid && v.status !== 'completed');
        });
      }
      if (status === 'pharmacy') {
        filtered = visits.filter(v => (v.status === 'pharmacy' || v.status === 'accounts') && v.status !== 'completed');
      }
      if (status === 'doctor' && !isManager && user.uid && user.staffRoles?.includes('hospital_doctor')) {
        filtered = filtered.filter(v => v.doctorId === user.uid);
      }
      mapping[status] = filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    });
    
    return mapping;
  }, [visits, isManager, user.uid, user.staffRoles]);

  const getVisitsByStatus = (status: string) => visitsByStatus[status] || [];

  const TabButton = ({ id, label, icon: Icon, count }: { id: HospitalTab, label: string, icon: any, count?: number }) => (
    <button
      onClick={() => setActiveTab(id)}
      role="tab"
      aria-selected={activeTab === id}
      aria-controls={`${id}-panel`}
      className={`flex items-center gap-2 px-4 sm:px-6 py-4 border-b-2 transition-all font-bold text-xs sm:text-sm whitespace-nowrap active:scale-95 ${
        activeTab === id 
          ? 'border-indigo-600 text-indigo-600 bg-indigo-50/30' 
          : 'border-transparent text-slate-400 hover:text-slate-600 hover:bg-slate-50'
      }`}
    >
      <Icon size={18} className={activeTab === id ? 'text-indigo-600' : 'text-slate-400'} />
      <span className="hidden sm:inline">{label}</span>
      {count !== undefined && count > 0 && (
        <span className={`ml-1 px-2 py-0.5 rounded-full text-[10px] ${
          activeTab === id ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-500'
        }`}>
          {count}
        </span>
      )}
    </button>
  );

  return (
    <div className="space-y-6">
      <RenderConfirmModal />
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-3xl font-display font-bold text-slate-900 tracking-tight uppercase">{t('hospital_name')}</h2>
          <p className="text-sm text-slate-500 font-medium">{t('hospital_desc')}</p>
        </div>
        <div className="flex flex-wrap gap-3">
          <div className="relative group">
            <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-hover:text-indigo-500 transition-colors" size={18} />
            <input 
              type="date" 
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="pl-10 pr-4 py-3 bg-white text-slate-600 rounded-xl font-bold text-sm border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all hover:border-indigo-200 cursor-pointer"
            />
          </div>
          <div className="flex flex-col items-end">
            <button 
              onClick={handleRefresh}
              disabled={loading}
              className={`p-3 bg-white text-slate-600 rounded-xl font-bold text-sm border border-slate-200 hover:bg-slate-50 transition-all flex items-center justify-center ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
              title={t('refresh')}
            >
              <RefreshCw size={18} className={loading ? 'animate-spin' : ''} />
            </button>
            <p className="text-[10px] text-slate-400 mt-1 font-medium">
              {t('last_updated') || 'Last updated'}: {lastUpdated}
            </p>
          </div>
                {(isManager || user.staffRoles?.includes('hospital_reception')) && (
                  <button 
                    onClick={() => {
                      setEditingPatientId(null);
                      setNewPatient({ name: '', age: '', phone: '', insuranceProvider: '', type: 'outpatient' });
                      setIsAddPatientModalOpen(true);
                    }}
                    className="px-6 py-3 bg-indigo-600 text-white rounded-xl font-bold text-sm hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 flex items-center gap-2"
                  >
                    <UserPlus size={18} />
                    {t('add_patient')}
                  </button>
                )}
              </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-x-auto">
        <div className="flex min-w-max" role="tablist" aria-label="Hospital Navigation">
          {availableTabs.includes('dashboard') && <TabButton id="dashboard" label={t('dashboard')} icon={Activity} />}
          {availableTabs.includes('patients') && <TabButton id="patients" label={t('reception')} icon={ClipboardList} />}
          {availableTabs.includes('doctor') && <TabButton id="doctor" label={t('doctor')} icon={Stethoscope} count={getVisitsByStatus('doctor').length} />}
          {availableTabs.includes('pharmacy') && <TabButton id="pharmacy" label={t('status_pharmacy')} icon={Pill} count={getVisitsByStatus('pharmacy').length} />}
        </div>
      </div>

      {availableTabs.length === 0 && (
        <div className="bg-[var(--surface)] p-12 rounded-2xl border border-[var(--border)] text-center transition-colors duration-300">
          <Clock size={48} className="mx-auto text-slate-200 dark:text-slate-700 mb-4" />
          <h3 className="text-xl font-bold text-[var(--ink)] mb-2">{t('no_permission')}</h3>
          <p className="text-slate-500">{t('contact_manager')}</p>
        </div>
      )}

      {/* Tab Content */}
      <div className="min-h-[400px]">
        {activeTab === 'dashboard' && isManager && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-[var(--surface)] p-6 rounded-2xl border border-[var(--border)] shadow-sm transition-colors duration-300">
              <div className="w-12 h-12 bg-indigo-50 dark:bg-indigo-900/20 rounded-xl flex items-center justify-center text-indigo-600 mb-4">
                <Users size={24} />
              </div>
              <p className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-1">{t('patient_records')}</p>
              <h3 className="text-3xl font-display font-bold text-[var(--ink)]">{patients.length}</h3>
            </div>
            <div className="bg-[var(--surface)] p-6 rounded-2xl border border-[var(--border)] shadow-sm transition-colors duration-300">
              <div className="w-12 h-12 bg-blue-50 dark:bg-blue-900/20 rounded-xl flex items-center justify-center text-blue-600 mb-4">
                <Clock size={24} />
              </div>
              <p className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-1">{t('waiting_list')}</p>
              <h3 className="text-3xl font-display font-bold text-[var(--ink)]">{getVisitsByStatus('doctor').length + getVisitsByStatus('pharmacy').length}</h3>
            </div>
            <div className="bg-[var(--surface)] p-6 rounded-2xl border border-[var(--border)] shadow-sm transition-colors duration-300">
              <div className="w-12 h-12 bg-emerald-50 dark:bg-emerald-900/20 rounded-xl flex items-center justify-center text-emerald-600 mb-4">
                <CheckCircle2 size={24} />
              </div>
              <p className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-1">{t('today_visits')}</p>
              <h3 className="text-3xl font-display font-bold text-[var(--ink)]">{visits.filter(v => v.createdAt.startsWith(selectedDate)).length}</h3>
            </div>
            <div className="bg-[var(--surface)] p-6 rounded-2xl border border-[var(--border)] shadow-sm transition-colors duration-300">
              <div className="w-12 h-12 bg-amber-50 dark:bg-amber-950/20 rounded-xl flex items-center justify-center text-amber-600 mb-4">
                <Wallet size={24} />
              </div>
              <p className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-1">{t('today_revenue')}</p>
              <h3 className="text-3xl font-display font-bold text-[var(--ink)]">
                ${visits
                  .filter(v => v.createdAt.startsWith(selectedDate) && v.status === 'completed')
                  .reduce((sum, v) => sum + (v.paidAmount || 0), 0)
                  .toFixed(2)}
              </h3>
            </div>
          </div>
        )}
        {availableTabs.length > 0 && activeTab === 'patients' && availableTabs.includes('patients') && (
          <div className="space-y-6">
            {/* Active Reception Queue */}
      {getVisitsByStatus('reception').length > 0 && (
        <div className="mb-8">
          <h3 className="text-sm font-bold text-slate-900 mb-4 flex items-center gap-2">
            <Clock className="text-amber-500" size={18} />
            {t('waiting_for_payment') || 'Bukaanada Sugaya Lacag-bixinta'}
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {getVisitsByStatus('reception').map(visit => (
              <div key={visit.id} className="bg-[var(--surface)] p-5 rounded-2xl shadow-sm border border-[var(--border)] hover:shadow-md transition-all duration-300">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h4 className="font-bold text-[var(--ink)]">{visit.patientName}</h4>
                    <p className="text-xs text-slate-500">{visit.patientAge} {t('years_old')}</p>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <div className="flex gap-1">
                      <button 
                        onClick={() => handleDeleteVisit(visit.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                        title={t('delete')}
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                    {(visit.consultationFee || 0) === 0 ? (
                    <span className="px-2 py-1 bg-slate-100 text-slate-600 rounded text-[10px] font-bold uppercase tracking-wider">
                      FREE / BILAASH
                    </span>
                  ) : visit.consultationPaid ? (
                    <span className="px-2 py-1 bg-emerald-50 text-emerald-600 rounded text-[10px] font-bold uppercase tracking-wider">
                      {t('paid') || 'Waa la bixiyay'}
                    </span>
                  ) : (
                    <span className="px-2 py-1 bg-amber-50 text-amber-600 rounded text-[10px] font-bold uppercase tracking-wider">
                      {t('unpaid') || 'Lama bixin'}
                    </span>
                  )}
                  </div>
                </div>
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400">{t('consultation_fee') || 'Consultation'}:</span>
                    <span className="font-bold text-[var(--ink)]">${visit.consultationFee?.toFixed(2)}</span>
                  </div>
                  <div className="pt-2 border-t border-[var(--border)] flex justify-between text-sm transition-colors duration-300">
                    <span className="font-bold text-[var(--ink)]">{t('total')}:</span>
                    <span className="font-bold text-indigo-600">${(visit.consultationFee || 0).toFixed(2)}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  {(visit.consultationFee || 0) > 0 && !visit.consultationPaid && (
                    <button 
                      onClick={() => setIsAccountsModalOpen({ visit, type: 'consultation' })}
                      className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold text-sm hover:bg-indigo-700 transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-100"
                    >
                      <Wallet size={16} />
                      {t('collect_payment')}
                    </button>
                  )}
                  {visit.status === 'reception' && (
                    <button 
                      onClick={() => handleForwardToDoctor(visit)}
                      className="flex-1 py-3 bg-emerald-600 text-white rounded-xl font-bold text-sm hover:bg-emerald-700 transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-100"
                    >
                      <ArrowRight size={16} />
                      {t('send_to_doctor')}
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
              <div className="p-6 border-b border-slate-100">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input 
                      type="text"
                      placeholder={t('search_patient')}
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all text-sm"
                    />
                  </div>
                  <button 
                    onClick={() => {
                      setEditingPatientId(null);
                      setNewPatient({ name: '', age: '', phone: '', insuranceProvider: '', type: 'outpatient' });
                      setIsAddPatientModalOpen(true);
                    }}
                    className="flex items-center justify-center gap-2 px-6 py-2.5 bg-indigo-600 text-white rounded-xl font-bold text-xs uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
                  >
                    <UserPlus size={18} /> {t('add_patient')}
                  </button>
                </div>
              </div>
              <div className="overflow-x-auto hidden md:block">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50/50">
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('patient_name')}</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('phone')}</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('insurance')}</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right">{t('action')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {filteredPatients.map((patient) => (
                      <tr key={patient.id} className="hover:bg-slate-50/50 transition-colors group">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600 font-bold text-xs group-hover:scale-110 transition-transform">
                              {patient.name?.[0]}
                            </div>
                            <span className="text-sm font-bold text-slate-900">{patient.name}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-sm text-slate-600 font-mono">{patient.phone}</td>
                        <td className="px-6 py-4">
                          <span className={`px-2 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider ${patient.insuranceProvider ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>
                            {patient.insuranceProvider || t('none')}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex items-center justify-end gap-2 transition-opacity">
                            <button 
                              onClick={() => handleEditPatient(patient)}
                              className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-white rounded-lg shadow-sm transition-all"
                              title={t('edit')}
                            >
                                <Edit2 size={16} />
                            </button>
                            <button 
                              onClick={() => handleDeletePatient(patient.id)}
                              className="p-2 text-slate-400 hover:text-rose-600 hover:bg-white rounded-lg shadow-sm transition-all"
                              title={t('delete')}
                            >
                                <Trash2 size={16} />
                            </button>
                            <button 
                              onClick={() => setIsHistoryModalOpen(patient)}
                              className="p-2 text-slate-400 hover:text-blue-600 hover:bg-white rounded-lg shadow-sm transition-all"
                              title={t('history')}
                            >
                                <History size={16} />
                            </button>
                            <button 
                              onClick={() => setIsStartVisitModalOpen(patient)}
                              className="px-4 py-2 bg-indigo-600 text-white rounded-xl font-bold text-[10px] uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 flex items-center gap-2"
                            >
                              <ArrowRight size={14} />
                              {t('start_visit')}
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Mobile List View */}
              <div className="md:hidden divide-y divide-slate-100">
                {filteredPatients.map((patient) => (
                  <div key={patient.id} className="p-4 active:bg-slate-50 transition-all">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-600 font-black text-sm">
                          {patient.name?.[0]}
                        </div>
                        <div>
                          <h4 className="font-bold text-slate-900 text-sm leading-tight">{patient.name}</h4>
                          <p className="text-[10px] text-slate-400 font-mono tracking-tight">{patient.phone}</p>
                        </div>
                      </div>
                      <div className="flex gap-1.5">
                        <button onClick={() => handleEditPatient(patient)} className="p-2 text-slate-400 bg-slate-50 rounded-lg"><Edit2 size={14} /></button>
                        <button onClick={() => handleDeletePatient(patient.id)} className="p-2 text-slate-400 bg-slate-50 hover:text-rose-600 rounded-lg"><Trash2 size={14} /></button>
                        <button onClick={() => setIsHistoryModalOpen(patient)} className="p-2 text-slate-400 bg-slate-50 rounded-lg"><History size={14} /></button>
                      </div>
                    </div>
                    <button 
                      onClick={() => setIsStartVisitModalOpen(patient)}
                      className="w-full py-3 bg-indigo-600 text-white rounded-xl font-black text-xs uppercase tracking-[0.2em] shadow-lg shadow-indigo-200 active:scale-95 transition-all flex items-center justify-center gap-2"
                    >
                      <Plus size={16} />
                      {t('start_visit')}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'doctor' && availableTabs.includes('doctor') && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {getVisitsByStatus('doctor').map(visit => (
              <div key={visit.id} className="bg-[var(--surface)] p-6 rounded-2xl border border-[var(--border)] shadow-sm hover:shadow-md transition-all relative">
                <div className="flex justify-between items-start mb-4">
                  <div className="w-12 h-12 bg-blue-50 dark:bg-blue-900/20 rounded-xl flex items-center justify-center text-blue-600">
                    <Stethoscope size={24} />
                  </div>
                  <div className="flex flex-col items-end">
                    <div className="flex gap-1 mb-2">
                      <button 
                        onClick={() => setIsConsultModalOpen(visit)}
                        className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                        title={t('edit')}
                      >
                        <ClipboardList size={14} />
                      </button>
                      <button 
                        onClick={() => handleDeleteVisit(visit.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                        title={t('delete')}
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                    <span className="px-2 py-1 bg-blue-50 text-blue-600 text-[10px] font-bold uppercase rounded-lg block mb-1">{t('waiting_status')}</span>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">{visit.doctorName}</span>
                    {visit.doctorPhone && (
                      <span className="text-[9px] text-slate-400 block">{visit.doctorPhone}</span>
                    )}
                  </div>
                </div>
                <div className="flex justify-between items-end mb-4">
                  <div>
                    <h4 className="text-lg font-bold text-slate-900 mb-1">{visit.patientName}</h4>
                    <p className="text-xs text-slate-400">{t('age')}: {visit.patientAge}</p>
                    {visit.consultationFee && (
                      <p className="text-[10px] text-blue-600 font-bold mt-1">{t('consultation_fee_short')}: ${visit.consultationFee}</p>
                    )}
                  </div>
                  <p className="text-[10px] font-bold text-slate-400">{new Date(visit.createdAt).toLocaleTimeString()}</p>
                </div>
                <button 
                  onClick={() => setIsConsultModalOpen(visit)}
                  className="w-full py-3 bg-slate-900 text-white rounded-xl font-bold text-sm hover:bg-slate-800 transition-all flex items-center justify-center gap-2"
                >
                  <Activity size={16} />
                  {t('consultation')}
                </button>
              </div>
            ))}
            {getVisitsByStatus('doctor').length === 0 && (
              <div className="col-span-full py-20 text-center bg-white rounded-2xl border border-dashed border-slate-200">
                <Stethoscope size={48} className="mx-auto text-slate-200 mb-4" />
                <p className="text-slate-400 font-medium italic">{t('no_waiting_patients')}</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'pharmacy' && availableTabs.includes('pharmacy') && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {getVisitsByStatus('pharmacy').map(visit => (
              <div key={visit.id} className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-all relative">
                <div className="flex justify-between items-start mb-4">
                  <div className="w-12 h-12 bg-emerald-50 rounded-xl flex items-center justify-center text-emerald-600">
                    <Pill size={24} />
                  </div>
                  <div className="flex flex-col items-end">
                    <div className="flex gap-1 mb-2">
                      <button 
                        onClick={() => setIsConsultModalOpen(visit)}
                        className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                        title={t('edit')}
                      >
                        <ClipboardList size={14} />
                      </button>
                      <button 
                        onClick={() => handleDeleteVisit(visit.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                        title={t('delete')}
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                    <span className="px-2 py-1 bg-emerald-50 text-emerald-600 text-[10px] font-bold uppercase rounded-lg">{t('medicine')}</span>
                  </div>
                </div>
                <div className="flex justify-between items-end mb-4">
                  <div>
                    <h4 className="text-lg font-bold text-slate-900 mb-1">{visit.patientName}</h4>
                    <p className="text-xs text-slate-400">{t('age')}: {visit.patientAge}</p>
                    {visit.doctorName && (
                      <div className="mt-1">
                        <p className="text-[10px] text-emerald-600 font-medium">{t('doctor_prefix')} {visit.doctorName}</p>
                        {visit.doctorPhone && (
                          <p className="text-[9px] text-slate-400">{visit.doctorPhone}</p>
                        )}
                      </div>
                    )}
                  </div>
                  <p className="text-[10px] font-bold text-slate-400">{new Date(visit.createdAt).toLocaleTimeString()}</p>
                </div>
                <div className="space-y-2 mb-6">
                  {visit.prescription?.map((item, i) => (
                    <div key={i} className="flex justify-between text-xs font-medium text-slate-600 bg-slate-50 p-2 rounded-lg">
                      <span>{item.medicineName} ({item.dosage})</span>
                      <div className="text-right">
                        <span className="font-bold block">x{item.quantity}</span>
                        <span className="text-[10px] text-emerald-600">${((item.price || 0) * (item.quantity || 0)).toFixed(2)}</span>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="pt-4 border-t border-slate-100 flex justify-between items-center mb-6">
                  <span className="text-sm font-bold text-slate-900">{t('total_amount')}</span>
                  <span className="text-lg font-bold text-emerald-600">
                    ${((visit.prescription?.reduce((sum, item) => sum + ((item.price || 0) * (item.quantity || 0)), 0) || 0)).toFixed(2)}
                  </span>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => setIsAccountsModalOpen({ visit, type: 'pharmacy' })}
                    className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold text-sm hover:bg-indigo-700 transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-100"
                  >
                    <Wallet size={16} />
                    {t('collect_payment')}
                  </button>
                  <button 
                    onClick={async () => {
                      if (!user.tenantId) return;
                      try {
                        console.log("Adding visit to cart:", visit);
                        const total = visit.prescription?.reduce((sum, item) => sum + ((item.price || 0) * (item.quantity || 0)), 0) || 0;
                        
                        const { error: updateError } = await supabase.from('visits').update({
                          status: 'completed',
                          dispensed: true,
                          pharmacy_paid: false
                        }).eq('id', visit.id);
                        
                        if (updateError) throw updateError;
                        
                        fetchData();
                        const patient = patients.find(p => p.id === visit.patientId);
                        navigateToSales(visit.prescription || [], total, visit.patientName, patient?.phone, visit.id);
                      } catch (error) {
                        console.error("Error adding to cart:", error);
                      }
                    }}
                    className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold text-sm hover:bg-indigo-700 transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-100"
                  >
                    <CheckCircle2 size={16} />
                    Done
                  </button>
                </div>
              </div>
            ))}
            {getVisitsByStatus('pharmacy').length === 0 && (
              <div className="col-span-full py-20 text-center bg-white rounded-2xl border border-dashed border-slate-200">
                <Pill size={48} className="mx-auto text-slate-200 mb-4" />
                <p className="text-slate-400 font-medium italic">{t('no_waiting_prescriptions')}</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Modals */}
      {/* Add Patient Modal */}
      <Modal 
        isOpen={isAddPatientModalOpen} 
        onClose={() => { setIsAddPatientModalOpen(false); setEditingPatientId(null); }} 
        title={editingPatientId ? t('edit_patient') : t('register_patient')}
      >
        <form onSubmit={handleAddPatient} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('patient_type_label') || 'Patient Type'}</label>
            <div className="grid grid-cols-2 gap-3 mb-2">
              <button
                type="button"
                onClick={() => setNewPatient({ ...newPatient, type: 'outpatient' })}
                className={`py-3 px-4 rounded-xl font-bold border-2 transition-all ${newPatient.type === 'outpatient' ? 'border-indigo-600 bg-indigo-50 text-indigo-600' : 'border-slate-200 bg-white text-slate-500 hover:border-slate-300'}`}
              >
                {t('outpatient') || 'Outpatient'}
              </button>
              <button
                type="button"
                onClick={() => setNewPatient({ ...newPatient, type: 'inpatient' })}
                className={`py-3 px-4 rounded-xl font-bold border-2 transition-all ${newPatient.type === 'inpatient' ? 'border-indigo-600 bg-indigo-50 text-indigo-600' : 'border-slate-200 bg-white text-slate-500 hover:border-slate-300'}`}
              >
                {t('inpatient') || 'Inpatient'}
              </button>
            </div>
          </div>
          <input required type="text" value={newPatient.name} onChange={(e) => setNewPatient({...newPatient, name: e.target.value})} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl" placeholder={t('patient_name_placeholder')} />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <input required type="number" value={newPatient.age} onChange={(e) => setNewPatient({...newPatient, age: e.target.value})} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl" placeholder={t('age_placeholder')} />
            <input required type="tel" value={newPatient.phone} onChange={(e) => setNewPatient({...newPatient, phone: e.target.value})} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl" placeholder={t('phone_placeholder')} />
          </div>
          <input type="text" value={newPatient.insuranceProvider} onChange={(e) => setNewPatient({...newPatient, insuranceProvider: e.target.value})} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl" placeholder={t('insurance_placeholder')} />
          
          {!editingPatientId && (
            <>
              <div className="grid grid-cols-1 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('consultation_fee_label')}</label>
                  <input required type="number" value={consultationFee} onChange={(e) => setConsultationFee(e.target.value)} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold" />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100">
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('assign_doctor_label')}</label>
                <select 
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl"
                  onChange={(e) => {
                    const dr = doctors.find(d => d.id === e.target.value);
                    if (dr) setSelectedDoctor({ id: dr.id, name: dr.displayName, phone: dr.phone });
                    else setSelectedDoctor(null);
                  }}
                >
                  <option value="">{t('select_doctor_placeholder')}</option>
                  {doctors.map(dr => (
                    <option key={dr.id} value={dr.id}>{dr.displayName}</option>
                  ))}
                </select>
                {doctors.length === 0 && (
                  <p className="text-[10px] text-amber-600 mt-1 font-medium">
                    {t('no_doctors_found_warning') || 'Fadlan hubi in shaqaaluhu leeyihiin doorka "hospital_doctor"'}
                  </p>
                )}
              </div>
            </>
          )}

          <button 
            type="submit" 
            disabled={isSaving}
            className={`w-full py-3 bg-indigo-600 text-white rounded-xl font-bold ${isSaving ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            {isSaving ? t('saving') : (editingPatientId ? t('update') : t('save'))}
          </button>
          {saveError && (
            <p className="text-red-500 text-sm text-center mt-2">{saveError}</p>
          )}
        </form>
      </Modal>

      {/* Start Visit Modal */}
      <Modal 
        isOpen={!!isStartVisitModalOpen} 
        onClose={() => setIsStartVisitModalOpen(null)} 
        title={t('start_visit_title')}
      >
        {isStartVisitModalOpen && (
          <form onSubmit={handleStartVisit} className="space-y-4">
            <p className="text-sm text-slate-500 mb-4">{isStartVisitModalOpen.name}</p>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('select_doctor')}</label>
              <select 
                required 
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl"
                onChange={(e) => {
                  const dr = doctors.find(d => d.id === e.target.value);
                  if (dr) setSelectedDoctor({ id: dr.id, name: dr.displayName, phone: dr.phone });
                }}
              >
                <option value="">{t('select_doctor_placeholder')}</option>
                {doctors.map(dr => (
                  <option key={dr.id} value={dr.id}>{dr.displayName}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('consultation_fee_label')}</label>
              <input required type="number" value={consultationFee} onChange={(e) => setConsultationFee(e.target.value)} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold" />
            </div>
            <button type="submit" disabled={isSaving} className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold disabled:opacity-50">{isSaving ? t('saving') : t('send_to_doctor')}</button>
          </form>
        )}
      </Modal>

      {/* Consult Modal */}
      <Modal 
        isOpen={!!isConsultModalOpen} 
        onClose={() => setIsConsultModalOpen(null)} 
        title={t('consultation_title')}
      >
        {isConsultModalOpen && (
          <form onSubmit={handleSaveConsultation} className="space-y-6">
            <p className="text-sm text-slate-500 mb-4">{isConsultModalOpen.patientName}</p>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('diagnosis_label')}</label>
              <textarea required value={diagnosis} onChange={(e) => setDiagnosis(e.target.value)} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl h-24" placeholder={t('diagnosis_placeholder')} />
            </div>
            
            <div className="space-y-4">
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest">{t('prescription_label')}</label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">{t('medicine_name')}</label>
                  <select 
                    value={newPrescriptionItem.medicineName} 
                    onChange={(e) => {
                      const name = e.target.value;
                      const invItem = inventory.find(i => i.name === name);
                      if (invItem) {
                        setNewPrescriptionItem({
                          ...newPrescriptionItem, 
                          medicineName: name,
                          price: invItem.price
                        });
                      } else {
                        setNewPrescriptionItem({
                          ...newPrescriptionItem,
                          medicineName: '',
                          price: 0
                        });
                      }
                    }} 
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm" 
                  >
                    <option value="">{t('select_medicine_placeholder')}</option>
                    {inventory.map(item => (
                      <option key={item.id} value={item.name}>
                        {item.name} ({item.quantity} {t('remaining')})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">{t('dosage')}</label>
                  <input type="text" placeholder={t('dosage_placeholder')} value={newPrescriptionItem.dosage} onChange={(e) => setNewPrescriptionItem({...newPrescriptionItem, dosage: e.target.value})} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm" />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">{t('quantity')}</label>
                  <input type="number" placeholder={t('qty_placeholder')} value={isNaN(newPrescriptionItem.quantity) ? '' : newPrescriptionItem.quantity} onChange={(e) => setNewPrescriptionItem({...newPrescriptionItem, quantity: e.target.value === '' ? 0 : parseInt(e.target.value) || 0})} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm" />
                </div>
              </div>
              <button type="button" onClick={addPrescriptionItem} className="w-full py-2 border-2 border-dashed border-slate-200 text-slate-400 rounded-xl font-bold text-xs hover:border-indigo-200 hover:text-indigo-600 transition-all flex items-center justify-center gap-2">
                <Plus size={14} /> {t('add_medicine_btn')}
              </button>

              <div className="space-y-2">
                {prescription.map((item, i) => (
                  <div key={i} className="flex justify-between items-center p-3 bg-indigo-50 rounded-xl">
                    <div className="text-xs">
                      <p className="font-bold text-indigo-900">{item.medicineName}</p>
                      <p className="text-indigo-600">{item.dosage} - {t('quantity')}: {item.quantity}</p>
                    </div>
                    <button type="button" onClick={() => removePrescriptionItem(i)} className="text-rose-500 p-1"><X size={14} /></button>
                  </div>
                ))}
              </div>
            </div>

            <button type="submit" disabled={isSaving} className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold shadow-lg shadow-indigo-100 disabled:opacity-50">{isSaving ? t('saving') : t('save_send_pharmacy')}</button>
          </form>
        )}
      </Modal>

      {/* Accounts Modal */}
      <Modal 
        isOpen={!!isAccountsModalOpen} 
        onClose={() => setIsAccountsModalOpen(null)} 
        title={t('payment_summary')}
      >
        {isAccountsModalOpen && (
          <div className="space-y-4">
            <p className="text-sm text-slate-500">{isAccountsModalOpen.visit.patientName} - {isAccountsModalOpen.type === 'consultation' ? t('consultation') : isAccountsModalOpen.type === 'pharmacy' ? t('add_cart') : t('full_payment')}</p>
            <div className="space-y-2">
              {(isAccountsModalOpen.type === 'consultation' || isAccountsModalOpen.type === 'full') && (
                <>
                  {isAccountsModalOpen.visit.consultationFee && (
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-500">{t('consultation_fee_short')} ({t('doctor_prefix')} {isAccountsModalOpen.visit.doctorName}):</span>
                      <span className="font-bold">${(isAccountsModalOpen.visit.consultationFee || 0).toFixed(2)}</span>
                    </div>
                  )}
                </>
              )}
              {(isAccountsModalOpen.type === 'pharmacy' || isAccountsModalOpen.type === 'full') && (
                isAccountsModalOpen.visit.prescription?.map((item, i) => (
                  <div key={`rx_${i}`} className="flex justify-between text-sm">
                    <span className="text-slate-500">{item.medicineName} (x{item.quantity}):</span>
                    <span className="font-bold">${((item.price || 0) * (item.quantity || 0)).toFixed(2)}</span>
                  </div>
                ))
              )}
            </div>
            <div className="pt-4 border-t border-slate-100 flex justify-between items-center">
              <span className="text-lg font-display font-bold text-slate-900">{t('total_amount')}</span>
              <span className="text-2xl font-display font-bold text-indigo-600">
                ${(
                  ((isAccountsModalOpen.type === 'consultation' || isAccountsModalOpen.type === 'full') ? (isAccountsModalOpen.visit.consultationFee || 0) : 0) +
                  ((isAccountsModalOpen.type === 'pharmacy' || isAccountsModalOpen.type === 'full') ? (isAccountsModalOpen.visit.prescription?.reduce((sum, item) => sum + ((item.price || 0) * (item.quantity || 0)), 0) || 0) : 0)
                ).toFixed(2)}
              </span>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">{t('payment_method')}</label>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                {[...new Set(['Cash', 'EVC', 'ZAAD', 'eDahab', 'SAHAL', 'Bank Account', 'Merchant', ...accounts.map(a => a.name)])].map((method) => (
                  <button
                    key={method}
                    onClick={() => setPaymentMethod(method)}
                    className={`py-3 px-2 rounded-xl text-[10px] font-bold border transition-all ${
                      paymentMethod === method 
                        ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg' 
                        : 'bg-white border-slate-200 text-slate-500 hover:border-slate-300'
                    }`}
                  >
                    {method}
                  </button>
                ))}
              </div>
            </div>

            <button onClick={() => handlePayment(isAccountsModalOpen.visit, isAccountsModalOpen.type)} disabled={isSaving} className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold shadow-lg shadow-emerald-100 mt-4 disabled:opacity-50">
              {isSaving ? t('processing') || 'Processing...' : t('confirm_payment_btn')}
            </button>
          </div>
        )}
      </Modal>

      {/* History Modal */}
      <Modal 
        isOpen={!!isHistoryModalOpen} 
        onClose={() => setIsHistoryModalOpen(null)} 
        title={t('patient_history')}
      >
        {isHistoryModalOpen && (
          <div className="space-y-4">
            <p className="text-sm text-slate-500 mb-4">{isHistoryModalOpen.name}</p>
            {visits.filter(v => v.patientId === isHistoryModalOpen.id).length === 0 ? (
              <div className="text-center py-12">
                <Clock size={48} className="mx-auto text-slate-200 mb-4" />
                <p className="text-slate-400 italic">{t('no_history')}</p>
              </div>
            ) : (
              visits.filter(v => v.patientId === isHistoryModalOpen.id).map(visit => (
                <div key={visit.id} className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">{new Date(visit.createdAt).toLocaleDateString()}</span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${visit.status === 'completed' ? 'bg-emerald-100 text-emerald-600' : 'bg-blue-100 text-blue-600'}`}>
                      {t(`status_${visit.status}` as any)}
                    </span>
                  </div>
                  <p className="text-sm font-bold text-slate-900 mb-1">{t('diagnosis')}: {visit.diagnosis || t('none')}</p>
                  {visit.prescription && visit.prescription.length > 0 && (
                    <div className="mt-2 pt-2 border-t border-slate-200">
                      <p className="text-[10px] font-bold text-slate-400 uppercase mb-1">{t('medicine')}:</p>
                      <div className="flex flex-wrap gap-2">
                        {visit.prescription.map((p, i) => (
                          <span key={i} className="px-2 py-1 bg-white border border-slate-200 rounded-lg text-xs text-slate-600">
                            {p.medicineName} ({p.dosage})
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}
