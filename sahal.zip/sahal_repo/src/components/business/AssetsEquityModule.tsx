import React, { useState, useEffect } from 'react';
import { supabase } from '../../supabase';
import { UserProfile, Shareholder } from '../../types';
import { Users, DollarSign, TrendingUp, Plus, Trash2, Edit2, Save, X, AlertCircle, RefreshCw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../LanguageContext';
import Modal from '../Modal';

export default function AssetsEquityModule({ user }: { user: UserProfile }) {
  const { t } = useLanguage();
  const [shareholders, setShareholders] = useState<Shareholder[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [businessMetrics, setBusinessMetrics] = useState({
    cash: 0,
    inventoryValue: 0,
    receivables: 0,
    payables: 0,
    totalExpenses: 0,
    totalValue: 0,
    totalProfit: 0
  });
  
  const [formData, setFormData] = useState({
    name: '',
    initialInvestment: '',
    currentValue: '',
    sharePercentage: '',
    paymentMethod: ''
  });

  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  const openConfirm = (title: string, message: string, onConfirm: () => void) => {
    setConfirmModal({
      isOpen: true,
      title,
      message,
      onConfirm: () => {
        onConfirm();
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const RenderConfirmModal = () => (
    <Modal 
      isOpen={confirmModal.isOpen} 
      onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))} 
      title={confirmModal.title}
      contentClassName="max-w-sm"
    >
      <div className="space-y-6">
        <div className="flex items-center gap-4 p-4 bg-rose-50 rounded-2xl text-rose-600">
          <Trash2 size={24} />
          <p className="text-sm font-medium">{confirmModal.message}</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
            className="flex-1 px-4 py-2 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 transition-all"
          >
            {t('cancel')}
          </button>
          <button 
            onClick={confirmModal.onConfirm}
            className="flex-1 px-4 py-2 bg-rose-600 text-white rounded-xl font-bold hover:bg-rose-700 transition-all shadow-lg shadow-rose-200"
          >
            {t('delete')}
          </button>
        </div>
      </div>
    </Modal>
  );

  const fetchData = async () => {
    if (!user.tenantId) return;
    try {
      setLoading(true);
      setError(null);
      
      // 1. Fetch Shareholders
      let shQuery = supabase
        .from('shareholders')
        .select('*')
        .eq('tenant_id', user.tenantId);
      if (user.branchId) shQuery = shQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
      const { data: shData, error: fetchError } = await shQuery;
      
      if (fetchError) {
        if (fetchError.code === '42P01') {
          setError('Table "shareholders" does not exist. Please run the SQL setup script.');
        } else {
          setError(fetchError.message);
        }
        return;
      }

      const buildQuery = (table: string) => {
        let q = supabase.from(table).select('*').eq('tenant_id', user.tenantId);
        if (user.branchId) {
          if (['inventory', 'accounts', 'customers'].includes(table)) {
            q = q.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
          } else {
            q = q.eq('branch_id', user.branchId);
          }
        }
        return q;
      };

      const [invRes, accountsRes, debtsRes, expRes, salesRes, custRes] = await Promise.all([
        buildQuery('inventory'),
        buildQuery('accounts'),
        buildQuery('debts'),
        buildQuery('expenses'),
        buildQuery('sales'),
        buildQuery('customers')
      ]);

      const inventoryItems = invRes.data || [];
      const inventoryValue = inventoryItems.reduce((sum, item) => sum + ((item.quantity || 0) * (item.cost_price || 0)), 0);
      const physicalCash = (accountsRes.data || []).reduce((sum, a) => sum + (a.balance || 0), 0);
      const customerCredits = (custRes.data || []).reduce((sum, c) => sum + (c.total_credit || 0), 0);
      const totalCashHoldings = physicalCash;
      const totalExpenses = (expRes.data || []).reduce((sum, e) => sum + (e.amount || 0), 0);
      
      const receivables = (debtsRes.data || [])
        .filter(d => d.type === 'customer')
        .reduce((sum, d) => sum + (d.amount - d.paid_amount), 0);
        
      const payables = (debtsRes.data || [])
        .filter(d => d.type === 'business' || d.type === 'supplier')
        .reduce((sum, d) => sum + (d.amount - d.paid_amount), 0);

      // Calculate Total Net Profit
      const sales = salesRes.data || [];
      const totalProfit = sales.filter(s => s.status !== 'returned').reduce((sum, sale) => {
        let rawSubtotal = 0;
        const saleProfit = (sale.items || []).reduce((itemSum: number, item: any) => {
          rawSubtotal += (item.subtotal || 0);
          if (item.type === 'product') {
            const invItem = inventoryItems.find(i => i.id === item.id);
            const cost = invItem?.cost_price || 0;
            return itemSum + ((item.price - cost) * (item.qty || 1));
          }
          return itemSum + (item.subtotal || 0); // For services, profit is 100% for now
        }, 0);
        
        const cartDiscount = rawSubtotal + (sale.tax || 0) - (sale.total || rawSubtotal);
        const realProfit = saleProfit - (cartDiscount > 0 ? cartDiscount : 0);
        
        return sum + realProfit;
      }, 0);

      const totalValue = physicalCash + inventoryValue + receivables - payables - customerCredits;

      setBusinessMetrics({
        cash: totalCashHoldings,
        inventoryValue,
        receivables,
        payables,
        totalExpenses,
        totalValue,
        totalProfit
      });

      if (shData) {
        setShareholders(shData.map(s => ({
          id: s.id,
          name: s.name,
          initialInvestment: s.initial_investment,
          currentValue: (totalValue * (s.share_percentage / 100)), // Dynamic calculation
          sharePercentage: s.share_percentage,
          paymentMethod: s.payment_method,
          tenantId: s.tenant_id,
          createdAt: s.created_at
        })));
      }
    } catch (err: any) {
      console.error("Error fetching shareholders:", err);
      setError(err.message || 'An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [user.tenantId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.tenantId) return;
    setSubmitting(true);
    try {
      const data = {
        name: formData.name,
        initial_investment: parseFloat(formData.initialInvestment) || 0,
        share_percentage: parseFloat(formData.sharePercentage) || 0,
        payment_method: formData.paymentMethod,
        tenant_id: user.tenantId,
        branch_id: user.branchId || null
      };

      let shareholderId = editingId;

      if (editingId) {
        const { error: updateError } = await supabase.from('shareholders').update(data).eq('id', editingId);
        if (updateError) throw updateError;
      } else {
        const { data: newSH, error: insertError } = await supabase
          .from('shareholders')
          .insert({ ...data, created_at: new Date().toISOString() })
          .select()
          .single();
        if (insertError) throw insertError;
        shareholderId = newSH.id;
      }

      // Handle Account Balance and Transaction
      if (shareholderId && data.initial_investment > 0 && data.payment_method) {
        // Check if a transaction already exists for this shareholder's initial investment
        const { data: existingTrans } = await supabase
          .from('account_transactions')
          .select('id, amount, to_account_id')
          .eq('tenant_id', user.tenantId)
          .eq('branch_id', user.branchId || null)
          .eq('reference_id', shareholderId)
          .eq('type', 'equity')
          .maybeSingle();

        if (!existingTrans) {
          // Find or create account
          let accQuery = supabase
            .from('accounts')
            .select('id, balance')
            .eq('tenant_id', user.tenantId)
            .eq('name', data.payment_method);
          
          if (user.branchId) accQuery = accQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);

          let { data: accData } = await accQuery.maybeSingle();
            
          if (!accData) {
            const { data: newAcc, error: accCreateError } = await supabase
              .from('accounts')
              .insert({ 
                name: data.payment_method, 
                balance: data.initial_investment, 
                tenant_id: user.tenantId,
                branch_id: user.branchId || null
              })
              .select()
              .single();
            
            if (accCreateError) throw accCreateError;
            accData = newAcc;
          } else {
            const newBalance = (accData.balance || 0) + data.initial_investment;
            await supabase.from('accounts').update({ balance: newBalance }).eq('id', accData.id);
          }
          
          if (accData) {
            await supabase.from('account_transactions').insert({
              to_account_id: accData.id,
              type: 'equity',
              amount: data.initial_investment,
              description: `Investment from shareholder: ${data.name}`,
              tenant_id: user.tenantId,
              branch_id: user.branchId || null,
              reference_id: shareholderId,
              created_at: new Date().toISOString()
            });
          }
        } else if (existingTrans.amount !== data.initial_investment) {
          // Update existing transaction and adjust account balance
          const diff = data.initial_investment - existingTrans.amount;
          
          // Update transaction
          await supabase.from('account_transactions').update({
            amount: data.initial_investment,
            description: `Investment from shareholder: ${data.name} (Updated)`
          }).eq('id', existingTrans.id);
          
          // Update account balance
          const { data: accData } = await supabase
            .from('accounts')
            .select('id, balance')
            .eq('id', existingTrans.to_account_id)
            .single();
            
          if (accData) {
            const newBalance = (accData.balance || 0) + diff;
            await supabase.from('accounts').update({ balance: newBalance }).eq('id', accData.id);
          }
        }
      }

      setIsModalOpen(false);
      setEditingId(null);
      setFormData({ name: '', initialInvestment: '', currentValue: '', sharePercentage: '', paymentMethod: '' });
      fetchData();
    } catch (err: any) {
      console.error("Error saving shareholder:", err);
      alert(err.message || 'Error saving shareholder');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    openConfirm(
      t('delete_confirm'),
      t('delete_confirm_desc' as any) || 'Ma hubtaa inaad tirtirto xogtan?',
      async () => {
        try {
          const { error } = await supabase.from('shareholders').delete().eq('id', id);
          if (error) throw error;
          fetchData();
        } catch (error: any) {
          console.error("Error deleting shareholder:", error);
          setError(error.message || 'Error deleting shareholder');
        }
      }
    );
  };

  const handleEdit = (s: Shareholder) => {
    setEditingId(s.id);
    setFormData({
      name: s.name,
      initialInvestment: s.initialInvestment.toString(),
      currentValue: '',
      sharePercentage: s.sharePercentage.toString(),
      paymentMethod: s.paymentMethod || ''
    });
    setIsModalOpen(true);
  };

  const totalInitial = shareholders.reduce((sum, s) => sum + s.initialInvestment, 0);
  const totalCurrent = shareholders.reduce((sum, s) => sum + s.currentValue, 0);
  const totalGrowth = totalCurrent - totalInitial;
  const growthPercentage = totalInitial > 0 ? (totalGrowth / totalInitial) * 100 : 0;

  if (loading) return <div className="p-8 text-center text-slate-500">{t('loading')}</div>;

  return (
    <div className="space-y-8">
      <RenderConfirmModal />
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-display font-bold text-slate-900">{t('assets_equity')}</h2>
          <p className="text-slate-500 mt-1">{t('shareholders_desc' as any) || 'Manage business ownership and equity'}</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={fetchData}
            disabled={loading}
            className={`p-3 bg-white text-slate-600 rounded-xl font-bold text-sm border border-slate-200 hover:bg-slate-50 transition-all flex items-center gap-2 ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
            title={t('refresh')}
          >
            <RefreshCw size={18} className={loading ? 'animate-spin' : ''} />
          </button>
          <button 
            onClick={() => {
              setEditingId(null);
              setFormData({ name: '', initialInvestment: '', currentValue: '', sharePercentage: '', paymentMethod: '' });
              setIsModalOpen(true);
            }}
            className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200"
          >
            <Plus size={20} />
            {t('add_shareholder')}
          </button>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-center gap-3 text-rose-600">
          <AlertCircle size={20} />
          <p className="text-sm font-medium">{error}</p>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        <div className="sahal-card p-6 bg-white">
          <h3 className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-1">{t('total_assets')}</h3>
          <p className="text-xl font-display font-bold text-slate-900">${(businessMetrics.cash + businessMetrics.inventoryValue + businessMetrics.receivables).toLocaleString()}</p>
        </div>

        <div className="sahal-card p-6 bg-white">
          <h3 className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-1">{t('initial_investment')}</h3>
          <p className="text-xl font-display font-bold text-slate-900">${totalInitial.toLocaleString()}</p>
        </div>

        <div className="sahal-card p-6 bg-white">
          <h3 className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-1">{t('inventory_value' as any) || 'Inventory'}</h3>
          <p className="text-xl font-display font-bold text-slate-900">${businessMetrics.inventoryValue.toLocaleString()}</p>
        </div>

        <div className="sahal-card p-6 bg-white">
          <h3 className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-1">{t('total_cash_holdings' as any) || 'Physical Cash holdings'}</h3>
          <p className={`text-xl font-display font-bold ${businessMetrics.cash >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
            ${businessMetrics.cash.toLocaleString()}
          </p>
        </div>

        <div className="sahal-card p-6 bg-white">
          <h3 className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-1">{t('total_expenses')}</h3>
          <p className="text-xl font-display font-bold text-rose-600">${businessMetrics.totalExpenses.toLocaleString()}</p>
        </div>

        <div className="sahal-card p-6 bg-white">
          <h3 className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-1">{t('total_net_profit' as any) || 'Total Profit'}</h3>
          <p className={`text-xl font-display font-bold ${businessMetrics.totalProfit >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
            ${businessMetrics.totalProfit.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </p>
        </div>

        <div className="sahal-card p-6 bg-indigo-600 text-white md:col-span-1 lg:col-span-2 flex flex-col justify-center">
          <h3 className="text-indigo-200 text-[10px] font-bold uppercase tracking-widest mb-1">{t('total_equity')}</h3>
          <p className="text-xl font-display font-bold">${businessMetrics.totalValue.toLocaleString()}</p>
        </div>
      </div>

      <div className="sahal-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50">
                <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('owner_name')}</th>
                <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('initial_investment')}</th>
                <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('current_value')}</th>
                <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('share_percentage')}</th>
                <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('growth')}</th>
                <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100 text-right">{t('action')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {shareholders.map((s) => {
                const growth = s.currentValue - s.initialInvestment;
                return (
                  <tr key={s.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-6">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                          {s.name[0]}
                        </div>
                        <p className="font-bold text-slate-900">{s.name}</p>
                      </div>
                    </td>
                    <td className="p-6 font-medium text-slate-600">${s.initialInvestment.toLocaleString()}</td>
                    <td className="p-6 font-bold text-slate-900">${s.currentValue.toLocaleString()}</td>
                    <td className="p-6">
                      <span className="px-3 py-1 bg-slate-100 text-slate-600 rounded-full text-xs font-bold">
                        {s.sharePercentage}%
                      </span>
                    </td>
                    <td className="p-6">
                      <span className={`font-bold ${growth >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {growth >= 0 ? '+' : ''}${growth.toLocaleString()}
                      </span>
                    </td>
                    <td className="p-6 text-right">
                      <div className="flex justify-end gap-2">
                        <button 
                          onClick={() => handleEdit(s)}
                          className="p-2 text-slate-400 hover:text-indigo-600 transition-colors"
                        >
                          <Edit2 size={18} />
                        </button>
                        <button 
                          onClick={() => handleDelete(s.id)}
                          className="p-2 text-slate-400 hover:text-rose-600 transition-colors"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {shareholders.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-12 text-center text-slate-400 italic">
                    {t('no_data')}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <Modal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        title={editingId ? t('edit') : t('add_shareholder')}
        contentClassName="max-w-lg"
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('owner_name')}</label>
            <input 
              required
              type="text" 
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold"
            />
          </div>
          <div className="grid grid-cols-1 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('initial_investment')}</label>
              <input 
                required
                type="number" 
                value={formData.initialInvestment}
                onChange={(e) => setFormData({...formData, initialInvestment: e.target.value})}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('share_percentage')} (%)</label>
            <input 
              required
              type="number" 
              step="0.01"
              value={formData.sharePercentage}
              onChange={(e) => setFormData({...formData, sharePercentage: e.target.value})}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('payment_method' as any) || 'Payment Method'}</label>
            <select
              required
              value={formData.paymentMethod}
              onChange={(e) => setFormData({...formData, paymentMethod: e.target.value})}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold"
            >
              <option value="">{t('select_payment_method' as any) || 'Select Payment Method'}</option>
              <option value="Cash">{t('cash')}</option>
              <option value="Bank Account">{t('bank_account')}</option>
              <option value="EVC">{t('evc')}</option>
              <option value="eDahab">{t('edahab')}</option>
              <option value="ZAAD">{t('zaad')}</option>
              <option value="SAHAL">{t('sahal')}</option>
            </select>
          </div>
          <button 
            type="submit" 
            disabled={submitting}
            className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 disabled:opacity-50 flex items-center justify-center gap-2"
          >
            <Save size={18} />
            {submitting ? t('saving') : t('save')}
          </button>
        </form>
      </Modal>
    </div>
  );
}
