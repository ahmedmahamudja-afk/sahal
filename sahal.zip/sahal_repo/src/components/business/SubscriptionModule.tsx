import React from 'react';
import { UserProfile } from '../../types';
import { 
  CreditCard, 
  AlertCircle,
  MessageCircle
} from 'lucide-react';
import { useLanguage } from '../LanguageContext';

interface SubscriptionModuleProps {
  user: UserProfile;
  managerPhone?: string;
}

export default function SubscriptionModule({ user, managerPhone }: SubscriptionModuleProps) {
  const { t } = useLanguage();

  const getDaysRemaining = () => {
    const endDateStr = user.subscription?.endDate || user.planExpiry;
    if (!endDateStr) return 0;
    const end = new Date(endDateStr);
    const now = new Date();
    const diff = end.getTime() - now.getTime();
    return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
  };

  const daysRemaining = getDaysRemaining();
  const isExpired = daysRemaining <= 0;
  
  const endDateToDisplay = user.subscription?.endDate || user.planExpiry;
  const startDateToDisplay = user.subscription?.startDate;

  const handleWhatsAppContact = () => {
    if (!managerPhone) return;
    const cleanPhone = managerPhone.replace(/\D/g, '');
    const message = encodeURIComponent(`Salaan, waxaan u baahanahay caawimaad ku saabsan akoonkayga SAHAL. (Subscription Alert)`);
    window.open(`https://wa.me/${cleanPhone}?text=${message}`, '_blank');
  };

  return (
    <div className="space-y-12 pb-20">
      <header>
        <h2 className="text-4xl font-display font-bold text-slate-900 tracking-tight">{t('subscription_management')}</h2>
        <p className="text-slate-400 font-medium">{t('subscription_management_desc')}</p>
      </header>

      {/* Current Status */}
      <div className="p-8 bg-slate-900 text-white relative overflow-hidden rounded-2xl shadow-lg border border-slate-800">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
        <div className="relative z-10">
          <div className="flex justify-between items-start mb-8">
            <div>
              <span className="px-3 py-1 bg-white/10 text-white/80 text-[10px] font-bold uppercase tracking-widest rounded-full border border-white/10">
                {t('current_plan')}
              </span>
              <h3 className="text-3xl font-display font-bold mt-3 capitalize">
                {user.subscription?.plan ? t(user.subscription.plan as any) : t('none')} {t('plan')}
              </h3>
            </div>
            <div className="p-3 bg-white/10 rounded-2xl border border-white/10">
              <CreditCard size={24} />
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-8 mb-8">
            <div>
              <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest mb-1">{t('status')}</p>
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${isExpired ? 'bg-red-500' : 'bg-emerald-500'}`} />
                <p className="font-bold">{isExpired ? t('expired') : t('active')}</p>
              </div>
            </div>
            <div>
              <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest mb-1">{t('start_date')}</p>
              <p className="font-bold">
                {startDateToDisplay 
                  ? new Date(startDateToDisplay).toLocaleDateString() 
                  : 'N/A'}
              </p>
            </div>
            <div>
              <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest mb-1">{t('expires_on')}</p>
              <p className="font-bold">
                {endDateToDisplay 
                  ? new Date(endDateToDisplay).toLocaleDateString() 
                  : 'N/A'}
              </p>
            </div>
            <div className="col-span-2 sm:col-span-1">
              <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest mb-1">{t('days_remaining')}</p>
              <p className={`text-2xl font-display font-bold ${daysRemaining < 5 ? 'text-amber-400' : 'text-white'}`}>
                {daysRemaining} {t('days')}
              </p>
            </div>
          </div>

          {(isExpired || daysRemaining <= 5) && (
            <div className={`flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-2xl border ${
              isExpired 
                ? 'bg-red-500/20 border-red-500/30 text-red-200' 
                : 'bg-amber-500/20 border-amber-500/30 text-amber-200'
            }`}>
              <div className="flex items-center gap-3">
                <AlertCircle size={20} className="shrink-0" />
                <p className="text-sm font-medium">
                  {isExpired ? t('subscription_expired_msg') : t('subscription_expiring_soon_msg')}
                </p>
              </div>
              <button 
                onClick={handleWhatsAppContact}
                className="flex items-center gap-2 px-4 py-2 bg-[#25D366] hover:bg-[#128C7E] text-white rounded-xl font-bold transition-colors shrink-0"
              >
                <MessageCircle size={18} />
                {managerPhone ? `WhatsApp: ${managerPhone}` : t('contact_admin_whatsapp')}
              </button>
            </div>
          )}
        </div>
      </div>

    </div>
  );
}
