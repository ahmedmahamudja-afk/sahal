import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '../../supabase';
import { offlineSync } from '../../lib/offline';
import { logStockChange } from '../../services/stockService';
import { InventoryItem, UserProfile, Sale, Tenant, Customer, Service, PrescriptionItem, Account, Branch } from '../../types';
import { ShoppingCart, Plus, Minus, Trash2, CreditCard, User, Tag, Printer, MessageCircle, History, LayoutGrid, Search, Clock, RotateCcw, RefreshCw, Briefcase, Package as PackageIcon, FileDown, Archive, Save as SaveIcon, Edit2, X, ChevronDown, ChevronUp, CheckCircle2, Phone, Landmark, Wallet, TrendingUp, AlertTriangle, ArrowDownRight, DollarSign, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';

import { useLanguage } from '../LanguageContext';
import DateSelector from '../DateSelector';
import Modal from '../Modal';

export default function SalesModule({ user, pendingPrescription, setPendingPrescription }: { user: UserProfile, pendingPrescription: { items: PrescriptionItem[], total: number, patientName?: string, patientPhone?: string, visitId?: string } | null, setPendingPrescription: (p: any) => void }) {
  const { t, language } = useLanguage();
  const [tenant, setTenant] = useState<Tenant | null>(null);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [allSales, setAllSales] = useState<Sale[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [selectedBranchFilter, setSelectedBranchFilter] = useState<string>(user.branchId || 'All');
  const [selectedSalesBranchId, setSelectedSalesBranchId] = useState<string>('');
  const [cart, setCart] = useState<{ item: any; qty: number; type: 'product' | 'service' | 'custom' }[]>([]);

  const getBase64ImageFromURL = (url: string): Promise<string> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.setAttribute('crossOrigin', 'anonymous');
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0);
        const dataURL = canvas.toDataURL('image/png');
        resolve(dataURL);
      };
      img.onerror = (error) => reject(error);
      img.src = url;
    });
  };
  const [currentVisitId, setCurrentVisitId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [salesSearchTerm, setSalesSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState<'products' | 'services' | 'custom'>('products');
  const [productCategoryFilter, setProductCategoryFilter] = useState<string>('All');
  const [serviceCategoryFilter, setServiceCategoryFilter] = useState<string>('All');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [isDebt, setIsDebt] = useState(false);
  const [debtDescription, setDebtDescription] = useState('');
  const [manualDebt, setManualDebt] = useState(0);
  const [taxPercentage, setTaxPercentage] = useState<number | ''>('');
  const [manualDiscount, setManualDiscount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const processingRef = React.useRef(false);
  
  const [customItemName, setCustomItemName] = useState('');
  const [customItemPrice, setCustomItemPrice] = useState('');
  const [customItemCostPrice, setCustomItemCostPrice] = useState('');
  const [customItemQty, setCustomItemQty] = useState('1');
  const [customItemCostAccountId, setCustomItemCostAccountId] = useState('');
  const [customItemIsDebt, setCustomItemIsDebt] = useState(false);
  const [customItemSupplierName, setCustomItemSupplierName] = useState('');
  const [customItemSupplierPhone, setCustomItemSupplierPhone] = useState('');
  
  const [showReceipt, setShowReceipt] = useState(false);
  const [lastSale, setLastSale] = useState<any>(null);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const [activeView, setActiveView] = useState<'pos' | 'history'>('pos');
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [mode, setMode] = useState<'day' | 'month' | 'year' | 'range'>('day');
  const [showOnlyDebt, setShowOnlyDebt] = useState(false);
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());

  // New state for quick customer registration
  const [registerCustomer, setRegisterCustomer] = useState(false);
  const [paymentMethods, setPaymentMethods] = useState<{ method: string; amount: number }[]>([{ method: 'Cash', amount: 0 }]);
  const [useCredit, setUseCredit] = useState(false);
  const [availableCredit, setAvailableCredit] = useState(0);
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);

  const [returnModal, setReturnModal] = useState<{
    isOpen: boolean;
    sale: Sale | null;
  }>({
    isOpen: false,
    sale: null,
  });

  const [accounts, setAccounts] = useState<Account[]>([]);
  const [selectedRefundAccountId, setSelectedRefundAccountId] = useState<string>('');
  const [creditAccountId, setCreditAccountId] = useState<string>('');

  const [savedCarts, setSavedCarts] = useState<{ id: string; name: string; items: any[]; createdAt: string }[]>([]);
  const [showSavedCarts, setShowSavedCarts] = useState(false);
  const [holdCartName, setHoldCartName] = useState('');
  const [showHoldModal, setShowHoldModal] = useState(false);
  const [showMobileCart, setShowMobileCart] = useState(false);
  const [editingSaleId, setEditingSaleId] = useState<string | null>(null);

  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  const openConfirm = (title: string, message: string, onConfirm: () => void) => {
    setConfirmModal({
      isOpen: true,
      title,
      message,
      onConfirm: () => {
        onConfirm();
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const RenderConfirmModal = () => (
    confirmModal.isOpen ? (
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-bg-main/60 backdrop-blur-sm">
        <div className="bg-surface-main rounded-2xl shadow-xl w-full max-w-sm overflow-hidden p-6 space-y-6 border border-border-main">
          <div className="flex items-center gap-4 p-4 bg-rose-50 dark:bg-rose-500/10 rounded-2xl text-rose-600 dark:text-rose-400">
            <RotateCcw className="w-[var(--icon-md)] h-[var(--icon-md)]" />
            <p className="text-sm font-medium">{confirmModal.message}</p>
          </div>
          <div className="flex gap-3">
            <button 
              onClick={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
              className="flex-1 px-4 py-2 bg-bg-sec text-ink-secondary rounded-xl font-bold hover:bg-border-main transition-all"
            >
              {t('cancel')}
            </button>
            <button 
              onClick={confirmModal.onConfirm}
              className="flex-1 px-4 py-2 bg-rose-600 text-white rounded-xl font-bold hover:bg-rose-700 transition-all shadow-lg shadow-rose-200 dark:shadow-none"
            >
              {t('confirm')}
            </button>
          </div>
        </div>
      </div>
    ) : null
  );

  const RenderReturnModal = () => (
    returnModal.isOpen && returnModal.sale ? (
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-bg-main/60 backdrop-blur-sm">
        <div className="bg-surface-main rounded-2xl shadow-xl w-full max-w-md overflow-hidden p-6 space-y-6 border border-border-main">
          <div className="flex items-center gap-4 p-4 bg-amber-50 dark:bg-amber-500/10 rounded-2xl text-amber-600 dark:text-amber-400">
            <RotateCcw className="w-[var(--icon-md)] h-[var(--icon-md)]" />
            <div>
              <p className="text-sm font-bold">{t('return_item_confirm_with_choice')}</p>
              <p className="text-xs opacity-80">{t('return_item_confirm')}</p>
            </div>
          </div>
          
          <div className="space-y-3">
            <label className="block text-xs font-bold text-ink-tertiary uppercase tracking-wider">{t('return_refund_type')}</label>
            
            {/* Account Selector for Refund */}
            <div className="p-4 bg-bg-sec rounded-xl border border-border-main space-y-3">
              <label className="block text-xs font-bold text-ink-tertiary uppercase tracking-widest">{t('select_refund_account' as any) || 'Select Refund Account'}</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-ink-tertiary">
                  <Wallet size={14} />
                </div>
                <select 
                  value={selectedRefundAccountId}
                  onChange={(e) => setSelectedRefundAccountId(e.target.value)}
                  className="w-full pl-9 pr-4 py-2.5 bg-surface-main border border-border-main rounded-xl focus:outline-none focus:ring-2 focus:ring-accent-main/20 transition-all font-bold text-ink text-sm appearance-none"
                >
                  {accounts.filter(acc => (acc.balance || 0) > 0).map(acc => (
                    <option key={acc.id} value={acc.id}>
                      {acc.name}
                    </option>
                  ))}
                  {accounts.length === 0 && <option value="">{t('no_accounts_available')}</option>}
                </select>
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-ink-tertiary">
                  <ChevronDown size={14} />
                </div>
              </div>
              {accounts.length === 0 && (
                <p className="text-xs text-rose-500 font-medium">{t('please_create_account_first')}</p>
              )}
            </div>

            <div className="grid grid-cols-1 gap-3 pt-2">
              <button 
                onClick={() => processReturn(returnModal.sale!, 'cash')}
                disabled={accounts.length === 0}
                className="flex items-center justify-between p-4 border border-border-main rounded-xl hover:bg-bg-sec transition-all text-left group disabled:opacity-50"
              >
                <div>
                  <p className="font-bold text-ink">{t('refund_cash')}</p>
                  <p className="text-xs text-ink-secondary">{t('refund_cash_desc') || 'Return money to customer in cash'}</p>
                </div>
                <div className="w-8 h-8 rounded-full bg-bg-sec flex items-center justify-center group-hover:bg-accent-soft group-hover:text-accent-main transition-colors">
                  <CreditCard className="w-[var(--icon-md)] h-[var(--icon-md)]" />
                </div>
              </button>
              
              <button 
                onClick={() => processReturn(returnModal.sale!, 'credit')}
                className="flex items-center justify-between p-4 border border-emerald-200 dark:border-emerald-800 bg-emerald-50/30 dark:bg-emerald-500/10 rounded-xl hover:bg-emerald-50 dark:hover:bg-emerald-500/20 transition-all text-left group"
              >
                <div>
                  <p className="font-bold text-emerald-700 dark:text-emerald-400">{t('add_to_credit')}</p>
                  <p className="text-xs text-emerald-600/70 dark:text-emerald-500/50">{t('add_to_credit_desc') || 'Store refund amount as customer credit'}</p>
                </div>
                <div className="w-8 h-8 rounded-full bg-emerald-100 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center group-hover:bg-emerald-200 dark:group-hover:bg-emerald-500/30 transition-colors">
                  <Tag className="w-[var(--icon-md)] h-[var(--icon-md)]" />
                </div>
              </button>
            </div>
          </div>
          
          <div className="flex gap-3 pt-2">
            <button 
              onClick={() => setReturnModal({ isOpen: false, sale: null })}
              className="flex-1 px-4 py-2 bg-bg-sec text-ink-secondary rounded-xl font-bold hover:bg-border-main transition-all"
            >
              {t('cancel')}
            </button>
          </div>
        </div>
      </div>
    ) : null
  );

  const fetchData = async () => {
    if (!user.tenantId) return;
    setLoading(true);
    try {
      const { data: tenantData } = await supabase
        .from('tenants')
        .select('*')
        .eq('id', user.tenantId)
        .single();
        
      if (tenantData) {
        const tenantInfo: Tenant = {
          ...tenantData,
          logoUrl: tenantData.logo_url,
          paymentNumbers: tenantData.payment_numbers,
          subscriptionPlan: tenantData.subscription_plan,
          planExpiry: tenantData.plan_expiry,
          isLocked: tenantData.is_locked,
          isMultiBranch: tenantData.is_multi_branch
        };
        setTenant(tenantInfo);
        
        // If service-only business, default to services category
        if (tenantInfo.type === 'services') {
          setActiveCategory('services');
        }

        if (tenantInfo.isMultiBranch) {
          const { data: branchesData } = await supabase.from('branches').select('*').eq('tenant_id', user.tenantId);
          if (branchesData) {
            setBranches(branchesData);
            if (user.branchId) {
              setSelectedSalesBranchId(user.branchId);
            } else if (branchesData.length > 0) {
              setSelectedSalesBranchId(branchesData[0].id);
            }
          }
        }
        
        let invQuery = supabase.from('inventory').select('*').eq('tenant_id', user.tenantId);
        if (user.branchId) invQuery = invQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
        const { data: invData } = await invQuery;
        if (invData) {
          setInventory(invData.map(item => ({
            id: item.id,
            name: item.name,
            sku: item.sku,
            quantity: item.quantity,
            costPrice: item.cost_price,
            price: item.price,
            minStock: item.min_stock,
            category: item.category,
            imageUrl: item.image_url || (item as any).imageUrl,
            tenantId: item.tenant_id,
            branchId: item.branch_id,
            createdAt: item.created_at,
            offerPrice: item.offer_price,
            discountPercentage: item.discount_percentage
          })));
        } else {
          setInventory([]);
        }
        
        let servQuery = supabase.from('services').select('*').eq('tenant_id', user.tenantId);
        if (user.branchId) servQuery = servQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
        const { data: servData } = await servQuery;
        if (servData) {
          setServices(servData.map(s => ({
            id: s.id,
            name: s.name,
            description: s.description,
            price: s.price,
            category: s.category,
            tenantId: s.tenant_id,
            branchId: s.branch_id,
            createdAt: s.created_at,
            imageUrl: s.image_url || (s as any).imageUrl,
            offerPrice: s.offer_price,
            discountPercentage: s.discount_percentage
          })));
        } else {
          setServices([]);
        }
        
        let salesQuery = supabase.from('sales').select('*').eq('tenant_id', user.tenantId).order('created_at', { ascending: false });
        if (user.branchId) salesQuery = salesQuery.eq('branch_id', user.branchId);
        const { data: salesData } = await salesQuery;
        setAllSales((salesData || []).map(s => {
          const items = s.items || [];
          const calcSubtotal = items.reduce((sum: number, i: any) => sum + (i.subtotal || 0), 0) || 0;
          const calcDiscount = Math.max(0, (calcSubtotal + (s.tax || 0)) - (s.total || 0));
          
          return {
            id: s.id,
            items: items,
            total: s.total,
            tax: s.tax,
            subtotal: calcSubtotal,
            discount: calcDiscount,
            paidAmount: s.paid_amount,
            debtAmount: s.debt_amount,
            customerName: s.customer_name,
            status: s.status,
            paymentMethods: s.payment_methods,
            tenantId: s.tenant_id,
            branchId: s.branch_id,
            createdAt: s.created_at,
            debtId: s.debt_id,
            sellerName: s.seller_name,
            creditUsed: s.credit_used,
            isEdited: s.is_edited
          };
        }));
        
        let custQuery = supabase.from('customers').select('*').eq('tenant_id', user.tenantId);
        if (user.branchId) custQuery = custQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
        const { data: custData } = await custQuery;
        if (custData) {
          setCustomers(custData.map(c => ({
            id: c.id,
            name: c.name,
            phone: c.phone,
            tenantId: c.tenant_id,
            branchId: c.branch_id,
            createdAt: c.created_at,
            totalDebt: c.total_debt,
            totalCredit: c.total_credit,
            offerPercentage: c.offer_percentage
          })));
        } else {
          setCustomers([]);
        }

        const { data: accData } = await supabase.from('accounts').select('*').eq('tenant_id', user.tenantId);
        let accQuery = supabase.from('accounts').select('*').eq('tenant_id', user.tenantId);
        if (user.branchId) accQuery = accQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
        const { data: accountsData } = await accQuery;

        if (accountsData) {
          setAccounts(accountsData);
          if (accountsData.length > 0) {
            if (!selectedRefundAccountId) setSelectedRefundAccountId(accountsData[0].id);
            if (!creditAccountId) {
              const creditAcc = accountsData.find(a => a.name.toLowerCase().includes('credit'));
              setCreditAccountId(creditAcc ? creditAcc.id : accountsData[0].id);
            }
          }
        }

        const { data: cartsData, error: cartsError } = await supabase.from('working_notes')
          .select('*')
          .eq('tenant_id', user.tenantId)
          .like('title', '[CART]%')
          .order('created_at', { ascending: false });
        
        let cartsQuery = supabase.from('working_notes')
          .select('*')
          .eq('tenant_id', user.tenantId)
          .like('title', '[CART]%');
        if (user.branchId) cartsQuery = cartsQuery.eq('branch_id', user.branchId);
        cartsQuery = cartsQuery.order('created_at', { ascending: false });

        const { data: cartsDataRes, error: notesError } = await cartsQuery;
        
        if (notesError) {
          console.error("Error fetching carts:", notesError);
        }

        if (cartsDataRes) {
          const parsedCarts = cartsDataRes.map(c => {
            try {
              const parsed = JSON.parse(c.content);
              return { ...parsed, dbId: c.id };
            } catch (e) {
              console.error("Error parsing cart JSON:", e);
              return null;
            }
          }).filter((c): c is any => c !== null);
          setSavedCarts(parsedCarts);
        } else {
          setSavedCarts([]);
        }
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();

    const tenantChannel = supabase
      .channel('tenant_changes')
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'tenants', filter: `id=eq.${user.tenantId}` }, (payload) => {
        const tenantData = payload.new;
        if (tenantData) {
          setTenant({
            ...tenantData,
            logoUrl: tenantData.logo_url,
            paymentNumbers: tenantData.payment_numbers,
            subscriptionPlan: tenantData.subscription_plan,
            planExpiry: tenantData.plan_expiry,
            isLocked: tenantData.is_locked,
            isMultiBranch: tenantData.is_multi_branch
          });
        }
      })
      .subscribe();

    const cartsChannel = supabase
      .channel('carts_changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'working_notes', filter: `tenant_id=eq.${user.tenantId}` }, () => {
        fetchData();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(tenantChannel);
      supabase.removeChannel(cartsChannel);
    };
  }, [user.tenantId]);

  const saveCartsToStorage = async (carts: any[]) => {
    // Only used conceptually now, see handleHoldCart and handleDeleteSavedCart directly
  };

  const handleHoldCart = async () => {
    if (cart.length === 0 || !user.tenantId || processing) return;
    setProcessing(true);
    const newCart = {
      id: Math.random().toString(36).substr(2, 9),
      name: holdCartName || customerName || `${t('cart')} ${savedCarts.length + 1}`,
      items: [...cart],
      customerName,
      customerPhone,
      customerId: selectedCustomerId,
      createdAt: new Date().toISOString()
    };
    
    try {
      const { error: insertError } = await supabase.from('working_notes').insert({
        title: `[CART] ${newCart.name}`,
        content: JSON.stringify(newCart),
        tenant_id: user.tenantId
      });
      
      if (insertError) throw insertError;
      
      setCart([]);
      setCustomerName('');
      setCustomerPhone('');
      setSelectedCustomerId(null);
      setAvailableCredit(0);
      setHoldCartName('');
      setShowHoldModal(false);
      setCurrentVisitId(null);
      setMessage({ type: 'success', text: t('cart_held_success') });
      setTimeout(() => setMessage(null), 3000);
      await fetchData();
    } catch (e: any) {
      console.error('Error holding cart:', e);
      setMessage({ type: 'error', text: e.message || 'Error saving cart' });
      setTimeout(() => setMessage(null), 5000);
    } finally {
      setProcessing(false);
    }
  };

  const handleEditSale = (sale: Sale) => {
    openConfirm(t('edit_sale'), t('edit_sale_confirm'), async () => {
      // Load items into cart
      const newCart = sale.items.map((item: any) => {
        const invItem = inventory.find(i => i.id === item.id);
        const servItem = services.find(s => s.id === item.id);
        return {
          item: invItem || servItem || { id: item.id, name: item.name, price: item.price },
          qty: item.qty,
          type: item.type || (invItem ? 'product' : (servItem ? 'service' : 'custom'))
        };
      });
      setCart(newCart);
      
      // Load customer info
      const customer = customers.find(c => c.name === sale.customerName);
      if (customer) {
        setCustomerName(customer.name);
        setCustomerPhone(customer.phone);
        setSelectedCustomerId(customer.id);
        setAvailableCredit(customer.totalCredit || 0);
      } else {
        setCustomerName(sale.customerName === t('regular_customer') ? '' : sale.customerName);
        setCustomerPhone('');
        setSelectedCustomerId(null);
        setAvailableCredit(0);
      }
      
      setTaxPercentage(sale.tax ? parseFloat(((sale.tax / sale.total) * 100).toFixed(2)) : '');
      setManualDiscount(0); // Reset manual discount as it's calculated
      
      if (sale.status === 'debt' || sale.status === 'partial') {
        setIsDebt(true);
        setManualDebt(sale.debtAmount || 0);
        
        // Fetch debt description if exists
        if (sale.debtId) {
          try {
            const { data: debtData } = await supabase
              .from('debts')
              .select('description')
              .eq('id', sale.debtId)
              .single();
            if (debtData) setDebtDescription(debtData.description || '');
          } catch (e) {
            console.error("Error fetching debt description:", e);
          }
        }
      } else {
        setIsDebt(false);
        setManualDebt(0);
        setDebtDescription('');
      }
      
      setPaymentMethods(sale.paymentMethods || [{ method: 'Cash', amount: 0 }]);
      setUseCredit(sale.creditUsed > 0);
      
      setEditingSaleId(sale.id);
      setActiveView('pos');
      setMessage({ type: 'success', text: t('edit_sale') });
      setTimeout(() => setMessage(null), 3000);
    });
  };
  const handleResumeCart = async (savedCart: any) => {
    const resume = async () => {
      setCart(savedCart.items);
      if (savedCart.customerName) setCustomerName(savedCart.customerName);
      if (savedCart.customerPhone) setCustomerPhone(savedCart.customerPhone);
      if (savedCart.customerId) {
        setSelectedCustomerId(savedCart.customerId);
        const customer = customers.find(c => c.id === savedCart.customerId);
        if (customer) setAvailableCredit(customer.totalCredit || 0);
      } else {
        setSelectedCustomerId(null);
        setAvailableCredit(0);
      }
      
      if (savedCart.dbId) {
        await supabase.from('working_notes').delete().eq('id', savedCart.dbId);
        fetchData();
      }
      setShowSavedCarts(false);
    };

    if (cart.length > 0) {
      openConfirm(t('resume_cart'), t('resume_cart_confirm' as any) || 'This will replace your current cart. Continue?', resume);
    } else {
      resume();
    }
  };

  const handleDeleteSavedCart = async (id: string, dbId?: string) => {
    if (dbId) {
      await supabase.from('working_notes').delete().eq('id', dbId);
      fetchData();
    } else {
      // Fallback if dbId is missing
      const cart = savedCarts.find(c => c.id === id);
      if (cart && cart.dbId) {
        await supabase.from('working_notes').delete().eq('id', cart.dbId);
        fetchData();
      }
    }
  };

  const handleQuickPay = async (savedCart: any) => {
    if (!user.tenantId || processing) return;

    // Check stock availability
    const outOfStockItems = savedCart.items.filter((c: any) => {
      if (c.type !== 'product') return false;
      const invItem = inventory.find(i => i.id === c.item.id);
      if (!invItem) return true;
      return c.qty > invItem.quantity;
    });

    if (outOfStockItems.length > 0) {
      const itemNames = outOfStockItems.map((c: any) => c.item.name).join(', ');
      setMessage({ type: 'error', text: `${t('out_of_stock_alert')}: ${itemNames}` });
      setTimeout(() => setMessage(null), 3000);
      return;
    }

    setProcessing(true);
    try {
      const now = new Date().toISOString();
      const cartTotal = savedCart.items.reduce((sum: number, c: any) => sum + (c.item.price * c.qty), 0);
      
      const saleData = {
        items: savedCart.items.map((c: any) => ({
          id: c.item.id,
          name: c.item.name,
          price: c.item.price,
          costPrice: (c.item as any).costPrice,
          costAccountId: (c.item as any).costAccountId,
          isDebt: (c.item as any).isDebt,
          supplierName: (c.item as any).supplierName,
          supplierPhone: (c.item as any).supplierPhone,
          qty: c.qty,
          subtotal: c.item.price * c.qty,
          type: c.type
        })),
        total: cartTotal,
        tax: 0,
        paid_amount: cartTotal,
        debt_amount: 0,
        customer_name: savedCart.name || t('regular_customer'),
        status: 'paid',
        payment_methods: [{ method: 'Cash', amount: cartTotal }],
        tenant_id: user.tenantId,
        branch_id: selectedSalesBranchId || user.branchId || null,
        created_at: now,
        seller_name: user.displayName || user.username || 'System'
      };

      const saleResponse = await offlineSync.perform('sales', 'insert', saleData);
      const saleResult = saleResponse.data;
      if (saleResponse.error) throw saleResponse.error;

      // Update Account Balance
      if (!saleResponse.offline) {
        let accQuery = supabase.from('accounts').select('*').eq('tenant_id', user.tenantId);
        if (user.branchId) accQuery = accQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
        let { data: accData } = await accQuery.eq('name', 'Cash').maybeSingle();
        
        if (!accData) {
          const { data: newAcc } = await supabase
            .from('accounts')
            .insert({ 
              name: 'Cash', 
              balance: cartTotal, 
              tenant_id: user.tenantId,
              branch_id: selectedSalesBranchId || user.branchId || null
            })
            .select()
            .single();
          accData = newAcc;
        } else {
          await supabase
            .from('accounts')
            .update({ balance: accData.balance + cartTotal })
            .eq('id', accData.id);
        }
        
        if (accData) {
          await supabase.from('account_transactions').insert({
            to_account_id: accData.id,
            amount: cartTotal,
            type: 'sale',
            description: `Sale #${saleResult?.id || 'offline'} - ${savedCart.name || t('regular_customer')}`,
            tenant_id: user.tenantId,
            branch_id: selectedSalesBranchId || user.branchId || null,
            created_at: now
          });
        }
      } else {
        // Handle local balance or just notify
        setMessage({ type: 'success', text: 'Sale saved offline. It will sync when connection returns.' });
      }

      // Update inventory
      for (const c of savedCart.items) {
        if (c.type === 'product') {
          const item = inventory.find(i => i.id === c.item.id);
          if (item) {
            await supabase.from('inventory').update({ quantity: item.quantity - c.qty }).eq('id', c.item.id);
            await logStockChange(user.tenantId, c.item.id, c.item.name, -c.qty, 'sale', user.branchId);
          }
        }
      }

      // Handle Custom Items costs & debts
      const customItemCosts = saleData.items
        .filter(item => item.type === 'custom' && (item as any).costPrice > 0 && !(item as any).isDebt)
        .reduce((acc: Record<string, number>, item: any) => {
          const accountId = item.costAccountId || 'default';
          acc[accountId] = (acc[accountId] || 0) + (item.costPrice * item.qty);
          return acc;
        }, {});

      for (const [accountId, amount] of Object.entries(customItemCosts) as [string, number][]) {
        if (amount > 0) {
          const { data: expData } = await supabase.from('expenses').insert({
            category: 'supplies',
            description: `Cost of Custom Item(s) for Sale ${saleResult.id}`,
            amount: amount,
            date: now,
            tenant_id: user.tenantId,
            branch_id: selectedSalesBranchId || user.branchId || null,
            created_at: now
          }).select().single();

          let accQuery = supabase.from('accounts').select('*').eq('tenant_id', user.tenantId);
          if (accountId === 'default' || !accountId) {
             accQuery = accQuery.eq('name', 'Cash');
          } else if (accountId.length > 30) {
             accQuery = accQuery.eq('id', accountId);
          } else {
             accQuery = accQuery.eq('name', accountId);
          }
          let { data: expAcc } = await accQuery.maybeSingle();

          if (expAcc) {
            await supabase.from('accounts').update({ balance: expAcc.balance - amount }).eq('id', expAcc.id);
            if (expData) {
              await supabase.from('account_transactions').insert({
                from_account_id: expAcc.id,
                amount: amount,
                type: 'expense',
                description: `Cost of Custom Item(s) out-of-pocket for Quick Pay Sale ${saleResult.id}`,
                tenant_id: user.tenantId,
                branch_id: selectedSalesBranchId || user.branchId || null,
                reference_id: expData.id,
                created_at: now
              });
            }
          }
        }
      }

      const customItemDebts = saleData.items
        .filter(item => item.type === 'custom' && (item as any).costPrice > 0 && (item as any).isDebt);
      for (const d of customItemDebts) {
        const item = d as any;
        const totalCost = item.costPrice * item.qty;
        await supabase.from('debts').insert({
          customer_name: item.supplierName || 'Unknown Supplier',
          phone: item.supplierPhone || '',
          amount: totalCost,
          paid_amount: 0,
          status: 'unpaid',
          tenant_id: user.tenantId,
          branch_id: selectedSalesBranchId || user.branchId || null,
          created_at: now,
          type: 'business',
          description: `Debt for custom item "${item.name}" in sale ${saleResult.id}`
        });
      }

      if (savedCart.dbId) {
        await supabase.from('working_notes').delete().eq('id', savedCart.dbId);
      }
      setMessage({ type: 'success', text: t('payment_success') });
      setTimeout(() => setMessage(null), 3000);
      fetchData();
    } catch (error) {
      console.error("Quick pay error:", error);
      setMessage({ type: 'error', text: 'Error processing payment' });
    } finally {
      setProcessing(false);
    }
  };

  const handlePayAll = async () => {
    if (savedCarts.length === 0 || !user.tenantId || processing) return;

    // Check stock for ALL items in ALL carts first
    const allItemsToBuy: Record<string, number> = {};
    savedCarts.forEach(sc => {
      sc.items.forEach((item: any) => {
        if (item.type === 'product') {
          allItemsToBuy[item.item.id] = (allItemsToBuy[item.item.id] || 0) + item.qty;
        }
      });
    });

    const outOfStockNames: string[] = [];
    Object.entries(allItemsToBuy).forEach(([id, neededQty]) => {
      const invItem = inventory.find(i => i.id === id);
      if (!invItem || neededQty > invItem.quantity) {
        const name = inventory.find(i => i.id === id)?.name || id;
        outOfStockNames.push(name);
      }
    });

    if (outOfStockNames.length > 0) {
      setMessage({ type: 'error', text: `${t('out_of_stock_alert')}: ${outOfStockNames.join(', ')}` });
      setTimeout(() => setMessage(null), 3000);
      return;
    }

    setProcessing(true);
    try {
      for (const sc of savedCarts) {
        const now = new Date().toISOString();
        
        const itemsWithDiscounts = sc.items.map((c: any) => {
          let price = c.item.price;
          if (c.type === 'product') {
            const item = c.item as InventoryItem;
            if (item.offerPrice && item.offerPrice > 0) {
              price = item.offerPrice;
            } else if (item.discountPercentage && item.discountPercentage > 0) {
              price = item.price * (1 - item.discountPercentage / 100);
            }
          }
          return {
            id: c.item.id,
            name: c.item.name,
            price: price,
            costPrice: (c.item as any).costPrice,
            costAccountId: (c.item as any).costAccountId,
            isDebt: (c.item as any).isDebt,
            supplierName: (c.item as any).supplierName,
            supplierPhone: (c.item as any).supplierPhone,
            qty: c.qty,
            subtotal: price * c.qty,
            type: c.type
          };
        });

        const subtotal = itemsWithDiscounts.reduce((sum: number, c: any) => sum + c.subtotal, 0);
        const selectedCustomer = customers.find(c => c.name === sc.name);
        const autoDiscount = (selectedCustomer?.offerPercentage || 0) * subtotal / 100;
        const cartTotal = subtotal - autoDiscount;
        
        const saleData = {
          items: itemsWithDiscounts,
          total: cartTotal,
          tax: 0,
          paid_amount: cartTotal,
          debt_amount: 0,
          customer_name: sc.name || t('regular_customer'),
          status: 'paid',
          payment_methods: [{ method: 'Cash', amount: cartTotal }],
          tenant_id: user.tenantId,
          branch_id: selectedSalesBranchId || user.branchId || null,
          created_at: now,
          seller_name: user.displayName || user.username || 'System'
        };

        const { data: saleResult, error: saleError } = await supabase.from('sales').insert(saleData).select().single();
        if (saleError) throw saleError;

        // Update Account Balance
        let accQuery = supabase
          .from('accounts')
          .select('*')
          .eq('tenant_id', user.tenantId)
          .eq('name', 'Cash');
        
        if (user.branchId) accQuery = accQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
        
        let { data: accData } = await accQuery.maybeSingle();
        
        if (!accData) {
          const { data: newAcc } = await supabase
            .from('accounts')
            .insert({ 
              name: 'Cash', 
              balance: cartTotal, 
              tenant_id: user.tenantId,
              branch_id: selectedSalesBranchId || user.branchId || null
            })
            .select()
            .single();
          accData = newAcc;
        } else {
          await supabase
            .from('accounts')
            .update({ balance: accData.balance + cartTotal })
            .eq('id', accData.id);
        }
        
        if (accData) {
          await supabase.from('account_transactions').insert({
            to_account_id: accData.id,
            amount: cartTotal,
            type: 'sale',
            description: `Bulk payment sale: ${saleResult.id}`,
            tenant_id: user.tenantId,
            branch_id: selectedSalesBranchId || user.branchId || null,
            reference_id: saleResult.id,
            created_at: now
          });
        }

        // Update inventory
        for (const c of sc.items) {
          if (c.type === 'product') {
            const item = inventory.find(i => i.id === c.item.id);
            if (item) {
              await supabase.from('inventory').update({ quantity: item.quantity - c.qty }).eq('id', c.item.id);
              await logStockChange(user.tenantId, c.item.id, c.item.name, -c.qty, 'sale', user.branchId);
            }
          }
        }
        // Handle Custom Items costs & debts
        const customItemCosts = saleData.items
          .filter(item => item.type === 'custom' && (item as any).costPrice > 0 && !(item as any).isDebt)
          .reduce((acc: Record<string, number>, item: any) => {
            const accountId = item.costAccountId || 'default';
            acc[accountId] = (acc[accountId] || 0) + (item.costPrice * item.qty);
            return acc;
          }, {});

        for (const [accountId, amount] of Object.entries(customItemCosts) as [string, number][]) {
          if (amount > 0) {
            const { data: expData } = await supabase.from('expenses').insert({
              category: 'supplies',
              description: `Cost of Custom Item(s) for Bulk Sale ${saleResult.id}`,
              amount: amount,
              date: now,
              tenant_id: user.tenantId,
              branch_id: selectedSalesBranchId || user.branchId || null,
              created_at: now
            }).select().single();

            let accQuery = supabase.from('accounts').select('*').eq('tenant_id', user.tenantId);
            if (accountId === 'default' || !accountId) {
               accQuery = accQuery.eq('name', 'Cash');
            } else if (accountId.length > 30) {
               accQuery = accQuery.eq('id', accountId);
            } else {
               accQuery = accQuery.eq('name', accountId);
            }
            let { data: expAcc } = await accQuery.maybeSingle();

            if (expAcc) {
              await supabase.from('accounts').update({ balance: expAcc.balance - amount }).eq('id', expAcc.id);
              if (expData) {
                await supabase.from('account_transactions').insert({
                  from_account_id: expAcc.id,
                  amount: amount,
                  type: 'expense',
                  description: `Cost of Custom Item(s) out-of-pocket for Bulk Sale ${saleResult.id}`,
                  tenant_id: user.tenantId,
                  reference_id: expData.id,
                  created_at: now
                });
              }
            }
          }
        }

        const customItemDebts = saleData.items
          .filter(item => item.type === 'custom' && (item as any).costPrice > 0 && (item as any).isDebt);
        for (const d of customItemDebts) {
          const item = d as any;
          const totalCost = item.costPrice * item.qty;
          await supabase.from('debts').insert({
            customer_name: item.supplierName || 'Unknown Supplier',
            phone: item.supplierPhone || '',
            amount: totalCost,
            paid_amount: 0,
            status: 'unpaid',
            tenant_id: user.tenantId,
            branch_id: selectedSalesBranchId || user.branchId || null,
            created_at: now,
            type: 'business',
            description: `Debt for custom item "${item.name}" in sale ${saleResult.id}`
          });
        }
      }

      for (const sc of savedCarts) {
        if (sc.dbId) {
          await supabase.from('working_notes').delete().eq('id', sc.dbId);
        }
      }
      setMessage({ type: 'success', text: t('bulk_payment_success') });
      setTimeout(() => setMessage(null), 3000);
      fetchData();
    } catch (error) {
      console.error("Pay all error:", error);
      setMessage({ type: 'error', text: 'Error processing bulk payment' });
    } finally {
      setProcessing(false);
    }
  };

  useEffect(() => {
    if (pendingPrescription && !loading) {
      console.log("Processing pendingPrescription in SalesModule:", pendingPrescription);
      
      const newCart = pendingPrescription.items.map(item => {
        // Try to find the item in current inventory to get full details
        const invItem = inventory.find(i => i.id === item.medicineId || i.name === item.medicineName);
        
        const displayName = item.dosage ? `${item.medicineName} (${item.dosage})` : item.medicineName;
        
        return {
          item: invItem || { 
            id: item.medicineId || `med-${Math.random().toString(36).substr(2, 9)}`, 
            name: displayName, 
            price: item.price,
            category: 'Medicine',
            sku: 'MED-' + (item.medicineId ? item.medicineId.slice(0, 4) : 'NEW'),
            quantity: 999 
          },
          qty: item.quantity,
          type: 'product' as const
        };
      });
      
      if (newCart.length > 0) {
        setCart(newCart);
        if (pendingPrescription.patientName) setCustomerName(pendingPrescription.patientName);
        if (pendingPrescription.patientPhone) setCustomerPhone(pendingPrescription.patientPhone);
        if (pendingPrescription.visitId) setCurrentVisitId(pendingPrescription.visitId);
        
        // Clear the pending state in the parent to prevent re-processing
        setPendingPrescription(null);
      } else {
        console.warn("New cart is empty, clearing pendingPrescription anyway to avoid loop.");
        setPendingPrescription(null);
      }
    }
  }, [pendingPrescription, loading, inventory, setPendingPrescription]);

  const addToCart = (item: InventoryItem | Service, type: 'product' | 'service') => {
    const existing = cart.find(c => c.item.id === item.id && c.type === type);
    if (existing) {
      setCart(cart.map(c => (c.item.id === item.id && c.type === type) ? { ...c, qty: c.qty + 1 } : c));
    } else {
      setCart([...cart, { item, qty: 1, type }]);
    }
  };

  const updateQty = (id: string, type: 'product' | 'service' | 'custom', delta: number) => {
    setCart(cart.map(c => {
      if (c.item.id === id && c.type === type) {
        let newQty;
        
        // Use 0.1 increments when quantity is 1 or less
        if (delta === -1) {
          if (c.qty <= 1 && c.qty > 0.1) {
            newQty = Math.round((c.qty - 0.1) * 100) / 100;
          } else {
            newQty = Math.max(0.1, c.qty - 1);
          }
        } else {
          if (c.qty < 1) {
            newQty = Math.round((c.qty + 0.1) * 100) / 100;
          } else {
            newQty = c.qty + 1;
          }
        }

        if (newQty > 0) {
          return { ...c, qty: newQty };
        }
      }
      return c;
    }));
  };

  const setQty = (id: string, type: 'product' | 'service' | 'custom', value: number) => {
    setCart(cart.map(c => {
      if (c.item.id === id && c.type === type) {
        if (value > 0) {
          return { ...c, qty: value };
        }
      }
      return c;
    }));
  };

  const removeFromCart = (id: string, type: 'product' | 'service' | 'custom') => {
    setCart(cart.filter(c => !(c.item.id === id && c.type === type)));
  };

  const addCustomToCart = () => {
    if (!customItemName || !customItemPrice) return;
    const price = parseFloat(customItemPrice);
    if (isNaN(price)) return;
    
    const costPrice = customItemCostPrice ? parseFloat(customItemCostPrice) : 0;
    const qty = parseInt(customItemQty) || 1;

    if (costPrice > 0 && !customItemCostAccountId && !customItemIsDebt) {
      setMessage({ type: 'error', text: t('select_account_for_cost' as any) || 'Please select an account for the purchase cost.' });
      return;
    }

    if (customItemIsDebt && !customItemSupplierName) {
      setMessage({ type: 'error', text: t('enter_supplier_name' as any) || 'Please enter supplier name for debt.' });
      return;
    }

    const newItem = {
      id: `custom-${Date.now()}`,
      name: customItemName,
      price: price,
      costPrice: costPrice,
      costAccountId: customItemCostAccountId,
      isDebt: customItemIsDebt,
      supplierName: customItemSupplierName,
      supplierPhone: customItemSupplierPhone
    };

    setCart([...cart, { item: newItem, qty: qty, type: 'custom' }]);
    setCustomItemName('');
    setCustomItemPrice('');
    setCustomItemCostPrice('');
    setCustomItemQty('1');
    setCustomItemCostAccountId('');
    setCustomItemIsDebt(false);
    setCustomItemSupplierName('');
    setCustomItemSupplierPhone('');
  };

  const subtotal = cart.reduce((sum, c) => {
    let price = c.item.price;
    if (c.type === 'product' || c.type === 'service') {
      const item = c.item as any;
      const offerPrice = item.offerPrice || item.offer_price;
      const discountPercentage = item.discountPercentage || item.discount_percentage;
      
      if (offerPrice && offerPrice > 0) {
        price = offerPrice;
      } else if (discountPercentage && discountPercentage > 0) {
        price = item.price * (1 - discountPercentage / 100);
      }
    }
    return sum + (price * c.qty);
  }, 0);

  // Remove auto-calculation useEffect to allow user to manually control tax, maintaining it across sales
  useEffect(() => {
    // If tenant has default tax and percentage hasn't been touched, we could set it, 
    // but the user wants to avoid forced reculculations.
  }, []);

  const parsedTaxPercentage = typeof taxPercentage === 'number' ? taxPercentage : 0;
  const computedTaxAmount = subtotal * (parsedTaxPercentage / 100);
  const total = subtotal + computedTaxAmount;
  const selectedCustomer = customers.find(c => c.id === selectedCustomerId || c.name === customerName);
  const autoDiscount = (selectedCustomer?.offerPercentage || 0) * subtotal / 100;
  const finalTotal = total - autoDiscount - manualDiscount;
  const creditUsed = useCredit ? Math.min(finalTotal, availableCredit) : 0;
  const remainingToPay = Math.max(0, finalTotal - creditUsed);

  useEffect(() => {
    setPaymentMethods(prev => {
      // If debt is checked and we have a single method, force it to 0
      if (isDebt && prev.length === 1) {
        return [{ ...prev[0], amount: 0 }];
      }
      // Otherwise use the default calculation logic for single method
      if (prev.length === 1) {
        return [{ ...prev[0], amount: Math.max(0, remainingToPay - manualDebt) }];
      }
      return prev;
    });
  }, [remainingToPay, manualDebt, isDebt]);

  // Handle toggling isDebt - if turned on, we might want to clear other methods if user intends all-debt
  const toggleDebt = (checked: boolean) => {
    setIsDebt(checked);
    if (checked) {
      // Optional: reset to single payment method if user checks debt to make it easier
      setPaymentMethods([{ method: 'Cash', amount: 0 }]);
    }
  };

  const handleCheckout = async () => {
    if (cart.length === 0 || !user.tenantId || processing || processingRef.current) return;

    processingRef.current = true;
    setProcessing(true);

    const oldSaleForValidation = editingSaleId ? allSales.find(s => s.id === editingSaleId) : null;
    const outOfStockItems = cart.filter(c => {
      if (c.type !== 'product') return false;
      const invItem = inventory.find(i => i.id === c.item.id);
      if (!invItem) return true;
      const oldQty = oldSaleForValidation ? (oldSaleForValidation.items.find(i => i.id === c.item.id)?.qty || 0) : 0;
      const totalAvailable = invItem.quantity + oldQty;
      return c.qty > totalAvailable;
    });

    if (outOfStockItems.length > 0) {
      const itemNames = outOfStockItems.map(c => c.item.name).join(', ');
      setMessage({ type: 'error', text: `${t('out_of_stock_alert')}: ${itemNames}` });
      setTimeout(() => setMessage(null), 3000);
      setProcessing(false);
      processingRef.current = false;
      return;
    }

    const paidAmount = paymentMethods.reduce((sum, pm) => sum + pm.amount, 0);
    const isActuallyDebt = isDebt || (paidAmount < remainingToPay - 0.01);

    if (isActuallyDebt && !customerName) {
      setMessage({ type: 'error', text: t('customer_info_required_debt') });
      setTimeout(() => setMessage(null), 3000);
      setProcessing(false);
      processingRef.current = false;
      return;
    }

    // Nudge for customer selection if it's a debt sale
    if (isActuallyDebt && !selectedCustomerId) {
      setMessage({ type: 'error', text: t('select_customer_for_debt' as any) || 'You must select an existing CRM customer to register debt.' });
      setTimeout(() => setMessage(null), 3000);
      setProcessing(false);
      processingRef.current = false;
      return;
    }

    try {
      const now = new Date().toISOString();
      const overpayment = Math.max(0, paidAmount - remainingToPay);
      const actualPaidForSale = Math.min(paidAmount, remainingToPay);
      const debtAmount = isActuallyDebt ? Math.max(0, remainingToPay - paidAmount) : 0;

      // If editing, we need to revert the old sale's inventory and account balances first
      if (editingSaleId) {
        const oldSale = allSales.find(s => s.id === editingSaleId);
        if (oldSale) {
          for (const item of oldSale.items) {
            if (item.type === 'product') {
              const invItem = inventory.find(i => i.id === item.id);
              if (invItem) {
                await supabase
                  .from('inventory')
                  .update({ quantity: invItem.quantity + item.qty })
                  .eq('id', item.id);
                await logStockChange(user.tenantId, item.id, item.name, item.qty, 'edit_revert', user.branchId);
              }
            }
          }
          
          // Revert Account Balances for old sale
          if (oldSale.paymentMethods) {
            for (const pm of oldSale.paymentMethods) {
              let accQuery = supabase
                .from('accounts')
                .select('*')
                .eq('tenant_id', user.tenantId)
                .eq('name', pm.method);
              
              if (user.branchId) accQuery = accQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
              
              const { data: accData } = await accQuery.maybeSingle();
              
              if (accData) {
                await supabase
                  .from('accounts')
                  .update({ balance: accData.balance - pm.amount })
                  .eq('id', accData.id);
                
                // Log Reversal Transaction
                await supabase.from('account_transactions').insert({
                  from_account_id: accData.id,
                  amount: pm.amount,
                  type: 'adjustment',
                  description: `Reversal of sale ${oldSale.id} due to edit`,
                  tenant_id: user.tenantId,
                  branch_id: user.branchId || null,
                  reference_id: oldSale.id,
                  created_at: now
                });
              }
            }
          }
          
          // If old sale had debt, delete it
          if (oldSale.debtId) {
            await supabase.from('debts').delete().eq('id', oldSale.debtId);
          }
          
          // If old sale used credit, return it
          if (oldSale.creditUsed && oldSale.creditUsed > 0) {
            const customer = customers.find(c => c.name === oldSale.customerName);
            if (customer) {
              await supabase
                .from('customers')
                .update({ total_credit: (customer.totalCredit || 0) + oldSale.creditUsed })
                .eq('id', customer.id);
            }
          }

          // Reverse any old custom item cost expenses
          const oldCustomItemCosts = oldSale.items
            .filter((item: any) => item.type === 'custom' && (item as any).costPrice > 0)
            .reduce((acc: Record<string, number>, item: any) => {
              const accountId = item.costAccountId || 'default';
              acc[accountId] = (acc[accountId] || 0) + (item.costPrice * item.qty);
              return acc;
            }, {});

          for (const [accountId, amount] of Object.entries(oldCustomItemCosts) as [string, number][]) {
            if (amount > 0) {
              let accQuery = supabase.from('accounts').select('*').eq('tenant_id', user.tenantId);
              if (accountId === 'default') {
                 const deductAccName = oldSale.paymentMethods?.find((pm: any) => pm.amount > 0)?.method || 'Cash';
                 accQuery = accQuery.eq('name', deductAccName);
              } else {
                 accQuery = accQuery.eq('id', accountId);
              }
              let { data: expAcc } = await accQuery.maybeSingle();

              if (expAcc) {
                 await supabase.from('accounts').update({ balance: expAcc.balance + amount }).eq('id', expAcc.id);
                 await supabase.from('account_transactions').insert({
                    to_account_id: expAcc.id,
                    amount: amount,
                    type: 'adjustment',
                    description: `Reversal of Custom Item(s) cost for edited Sale ${oldSale.id}`,
                    tenant_id: user.tenantId,
                    reference_id: oldSale.id,
                    created_at: now
                 });
                 await supabase.from('expenses').insert({
                    category: 'supplies',
                    description: `Edit Reversal: Cost of Custom Item(s) for Sale ${oldSale.id}`,
                    amount: -amount,
                    date: now,
                    tenant_id: user.tenantId,
                    branch_id: selectedSalesBranchId || user.branchId || null,
                    created_at: now
                 });
              }
            }
          }
        }
      }

      // 1. Prepare Debt Record if applicable
      let debtId = null;
      if (isActuallyDebt && debtAmount > 0) {
        const { data: debtData, error: debtError } = await supabase
          .from('debts')
          .insert({
            customer_name: customerName,
            phone: customerPhone || 'N/A',
            amount: debtAmount,
            paid_amount: 0,
            status: 'unpaid',
            tenant_id: user.tenantId,
            branch_id: selectedSalesBranchId || user.branchId || null,
            created_at: now,
            type: 'customer',
            description: debtDescription || 'POS Sale'
          })
          .select()
          .single();
        
        if (debtError) throw debtError;
        debtId = debtData.id;

        // 2. Register customer if new
        if (!selectedCustomerId && customerName) {
          const { data: custData, error: custError } = await supabase.from('customers').insert({
            name: customerName,
            phone: customerPhone,
            tenant_id: user.tenantId,
            branch_id: selectedSalesBranchId || user.branchId || null,
            total_debt: debtAmount,
            total_credit: 0,
            offer_percentage: 0,
            created_at: now
          }).select().single();
          
          if (custError) {
            console.error("Customer registration error:", custError);
            throw custError;
          }
          
          // Optionally set it so later logic doesn't re-create or miss them
          // No need, we are just registering them here.
        }
      }

      // 3. Prepare Sale Record
      const saleData = {
        items: cart.map(c => {
          let price = c.item.price;
          if (c.type === 'product' || c.type === 'service') {
            const item = c.item as any;
            const offerPrice = item.offerPrice || item.offer_price;
            const discountPercentage = item.discountPercentage || item.discount_percentage;
            
            if (offerPrice && offerPrice > 0) {
              price = offerPrice;
            } else if (discountPercentage && discountPercentage > 0) {
              price = item.price * (1 - discountPercentage / 100);
            }
          }
          return {
            id: c.item.id,
            name: c.item.name,
            price: price,
            costPrice: (c.item as any).costPrice,
            costAccountId: (c.item as any).costAccountId,
            isDebt: (c.item as any).isDebt,
            supplierName: (c.item as any).supplierName,
            supplierPhone: (c.item as any).supplierPhone,
            qty: c.qty,
            subtotal: price * c.qty,
            type: c.type
          };
        }),
        total: finalTotal,
        tax: computedTaxAmount,
        paid_amount: actualPaidForSale,
        debt_amount: debtAmount,
        credit_used: creditUsed,
        customer_name: customerName || t('regular_customer'),
        status: debtAmount > 0 ? (actualPaidForSale > 0 ? 'partial' : 'debt') : 'paid',
        payment_methods: paidAmount > 0 ? paymentMethods.filter(pm => pm.amount > 0) : [],
        tenant_id: user.tenantId,
        branch_id: selectedSalesBranchId || user.branchId || null,
        created_at: editingSaleId ? allSales.find(s => s.id === editingSaleId)?.createdAt : now,
        debt_id: debtId,
        seller_name: user.displayName || user.username || 'System',
        is_edited: editingSaleId ? true : false
      };
      
      let saleDataResult;
      if (editingSaleId) {
        const { data, error: saleError } = await supabase
          .from('sales')
          .update(saleData)
          .eq('id', editingSaleId)
          .select()
          .single();
        if (saleError) throw saleError;
        saleDataResult = data;
      } else {
        const { data, error: saleError } = await supabase
          .from('sales')
          .insert(saleData)
          .select()
          .single();
        if (saleError) throw saleError;
        saleDataResult = data;
      }
        
      // 3.5 Update Customer Credit & Debt
      if (selectedCustomerId) {
        const customer = customers.find(c => c.id === selectedCustomerId);
        if (customer) {
          const newCredit = (customer.totalCredit || 0) + overpayment - creditUsed;
          const newDebt = (customer.totalDebt || 0) + debtAmount;
          
          const { error: customerUpdateError } = await supabase
            .from('customers')
            .update({ 
              total_credit: newCredit,
              total_debt: newDebt
            })
            .eq('id', selectedCustomerId);
          
          if (customerUpdateError) {
            console.error("Customer record update error:", customerUpdateError);
          }
        }
      } else if (overpayment > 0 && customerName && !selectedCustomerId) {
        // If it's a new customer and they overpaid, register them with credit balance
        const { error: custError } = await supabase.from('customers').insert({
          name: customerName,
          phone: customerPhone,
          tenant_id: user.tenantId,
          branch_id: selectedSalesBranchId || user.branchId || null,
          total_debt: 0,
          total_credit: overpayment,
          offer_percentage: 0,
          created_at: now
        });
        if (custError) {
          console.error("Customer registration with credit error:", custError);
        }
      }

      // 3.7 Log Credit Usage Transaction
      if (creditUsed > 0) {
        let finalCreditAccId = creditAccountId;
        
        // Final verification of the account
        if (!finalCreditAccId) {
          const { data: maybeAcc } = await supabase.from('accounts').select('id').eq('tenant_id', user.tenantId).maybeSingle();
          finalCreditAccId = maybeAcc?.id || '';
        }

        if (finalCreditAccId) {
           await supabase.from('account_transactions').insert({
             from_account_id: finalCreditAccId,
             amount: creditUsed,
             type: 'credit',
             description: `Credit used for sale ${saleDataResult.id} (Customer: ${saleDataResult.customer_name})`,
             tenant_id: user.tenantId,
             branch_id: selectedSalesBranchId || user.branchId || null,
             reference_id: saleDataResult.id,
             created_at: now
           });
        }
      }

      // 4. Update Inventory Quantities & Log Stock Changes
      for (const c of cart) {
        if (c.type === 'product') {
          const item = inventory.find(i => i.id === c.item.id);
          if (item) {
            // Note: if editing, we already reverted the old qty above, so we just subtract the new qty from the reverted total
            await supabase
              .from('inventory')
              .update({ quantity: item.quantity - c.qty })
              .eq('id', c.item.id);
            
            await logStockChange(user.tenantId, c.item.id, c.item.name, -c.qty, editingSaleId ? 'edit_sale' : 'sale', user.branchId);
          }
        }
      }

      // 5. Update Account Balances
      if (paidAmount > 0) {
        for (const pm of paymentMethods) {
          if (pm.amount > 0) {
            // Find or create account
            let accQuery = supabase
              .from('accounts')
              .select('*')
              .eq('tenant_id', user.tenantId)
              .eq('name', pm.method);
            
            if (user.branchId) accQuery = accQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
            
            let { data: accData } = await accQuery.maybeSingle();
            
            if (!accData) {
              const { data: newAcc } = await supabase
                .from('accounts')
                .insert({ 
                  name: pm.method, 
                  balance: pm.amount, 
                  tenant_id: user.tenantId,
                  branch_id: selectedSalesBranchId || user.branchId || null
                })
                .select()
                .single();
              accData = newAcc;
            } else {
              await supabase
                .from('accounts')
                .update({ balance: accData.balance + pm.amount })
                .eq('id', accData.id);
            }

            // Log Transaction
            if (accData) {
              await supabase.from('account_transactions').insert({
                to_account_id: accData.id,
                amount: pm.amount,
                type: 'sale',
                description: `Payment for sale ${saleDataResult.id} via ${pm.method}${overpayment > 0 && pm.method === 'Cash' ? ' (Includes Overpayment to Credit)' : ''}`,
                tenant_id: user.tenantId,
                branch_id: selectedSalesBranchId || user.branchId || null,
                reference_id: saleDataResult.id,
                created_at: now
              });
            }
          }
        }
      }

      // 5.5 Auto-Expense for Custom Items Cost Price
      const customItemCosts = saleData.items
        .filter(item => item.type === 'custom' && (item as any).costPrice > 0 && !(item as any).isDebt)
        .reduce((acc: Record<string, number>, item: any) => {
          const accountId = item.costAccountId || 'default';
          acc[accountId] = (acc[accountId] || 0) + (item.costPrice * item.qty);
          return acc;
        }, {});

      for (const [accountId, amount] of Object.entries(customItemCosts) as [string, number][]) {
        if (amount > 0) {
          const { data: expData } = await supabase.from('expenses').insert({
            category: 'supplies',
            description: `Cost of Custom Item(s) for Sale ${saleDataResult.id}`,
            amount: amount,
            date: now,
            tenant_id: user.tenantId,
            branch_id: selectedSalesBranchId || user.branchId || null,
            created_at: now
          }).select().single();

          let accQuery = supabase.from('accounts').select('*').eq('tenant_id', user.tenantId);
          if (accountId === 'default' || !accountId) {
             const deductAccName = paymentMethods.find(pm => pm.amount > 0)?.method || 'Cash';
             accQuery = accQuery.eq('name', deductAccName);
          } else if (accountId.length > 30) { // Likely a UUID
             accQuery = accQuery.eq('id', accountId);
          } else {
             accQuery = accQuery.eq('name', accountId);
          }
          let { data: expAcc } = await accQuery.maybeSingle();

          if (expAcc) {
            await supabase
              .from('accounts')
              .update({ balance: expAcc.balance - amount })
              .eq('id', expAcc.id);
            
            if (expData) {
              await supabase.from('account_transactions').insert({
                from_account_id: expAcc.id,
                amount: amount,
                type: 'expense',
                description: `Cost of Custom Item(s) out-of-pocket for Sale ${saleDataResult.id}`,
                tenant_id: user.tenantId,
                reference_id: expData.id,
                created_at: now
              });
            }
          }
        }
      }

      // 5.51 Handle Business Debt for Custom Items
      const customItemDebts = saleData.items
        .filter(item => item.type === 'custom' && (item as any).costPrice > 0 && (item as any).isDebt);
      
      for (const d of customItemDebts) {
        const item = d as any;
        const totalCost = item.costPrice * item.qty;
        await supabase.from('debts').insert({
          customer_name: item.supplierName || 'Unknown Supplier',
          phone: item.supplierPhone || '',
          amount: totalCost,
          paid_amount: 0,
          status: 'unpaid',
          tenant_id: user.tenantId,
          branch_id: selectedSalesBranchId || user.branchId || null,
          created_at: now,
          type: 'business',
          description: `Debt for custom item "${item.name}" in sale ${saleDataResult.id}`
        });
      }

      // 5.6 Update Hospital Visit if applicable
      if (currentVisitId) {
        await supabase
          .from('visits')
          .update({ 
            pharmacy_paid: true,
            status: 'completed' // Ensure it's completed if it wasn't already
          })
          .eq('id', currentVisitId);
        setCurrentVisitId(null);
      }

      // 6. Show Receipt & Reset POS
      const mappedSale = {
        id: saleDataResult.id,
        items: saleDataResult.items,
        total: saleDataResult.total,
        tax: saleDataResult.tax,
        subtotal: subtotal,
        discount: (autoDiscount + manualDiscount),
        paidAmount: saleDataResult.paid_amount,
        debtAmount: saleDataResult.debt_amount,
        customerName: saleDataResult.customer_name,
        status: saleDataResult.status,
        paymentMethods: saleDataResult.payment_methods,
        tenantId: saleDataResult.tenant_id,
        branchId: saleDataResult.branch_id,
        createdAt: saleDataResult.created_at,
        debtId: saleDataResult.debt_id,
        sellerName: saleDataResult.seller_name,
        creditUsed: saleDataResult.credit_used,
        isEdited: saleDataResult.is_edited
      };
      setLastSale(mappedSale);
      setShowReceipt(true);
      
      setCart([]);
      setCustomerName('');
      setCustomerPhone('');
      setDebtDescription('');
      setIsDebt(false);
      setRegisterCustomer(false);
      // setTaxPercentage(''); // DO NOT reset to empty so it persists across sales until manually cleared
      setManualDiscount(0);
      setUseCredit(false);
      setAvailableCredit(0);
      setSelectedCustomerId(null);
      setEditingSaleId(null);
      
      // Refresh data
      fetchData();
      setMessage({ type: 'success', text: editingSaleId ? t('edit_sale_success') : t('payment_success') });
      setTimeout(() => setMessage(null), 3000);

    } catch (error: any) {
      console.error("Checkout error details:", error);
      setMessage({ type: 'error', text: t('checkout_error') + (error.message ? `: ${error.message}` : '') });
      setTimeout(() => setMessage(null), 5000);
    } finally {
      setProcessing(false);
      processingRef.current = false;
    }
  };

  const uniqueProductCategories = React.useMemo(() => {
    const cats = inventory.map(item => item.category).filter(Boolean) as string[];
    return ['All', ...Array.from(new Set(cats))];
  }, [inventory]);

  const uniqueServiceCategories = React.useMemo(() => {
    const cats = services.map(s => s.category).filter(Boolean) as string[];
    return ['All', ...Array.from(new Set(cats))];
  }, [services]);

  const filteredInventory = React.useMemo(() => inventory.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) || (item.sku && item.sku.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = productCategoryFilter === 'All' || item.category === productCategoryFilter;
    const matchesBranch = !tenant?.isMultiBranch || (item.branchId === selectedSalesBranchId);
    return matchesSearch && matchesCategory && matchesBranch;
  }), [inventory, searchTerm, productCategoryFilter, selectedSalesBranchId, tenant?.isMultiBranch]);

  const filteredServices = React.useMemo(() => services.filter(service => {
    const matchesSearch = service.name.toLowerCase().includes(searchTerm.toLowerCase()) || (service.description && service.description.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = serviceCategoryFilter === 'All' || service.category === serviceCategoryFilter;
    return matchesSearch && matchesCategory;
  }), [services, searchTerm, serviceCategoryFilter]);

  const getLocalDateString = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const filteredSales = React.useMemo(() => allSales.filter(sale => {
    const saleDate = new Date(sale.createdAt);
    const saleDateStr = getLocalDateString(saleDate);
    const [saleYear, saleMonth, saleDay] = saleDateStr.split('-').map(Number);

    const selYear = selectedDate.getFullYear();
    const selMonth = selectedDate.getMonth() + 1;
    const selDay = selectedDate.getDate();

    let dateMatch = false;
    if (mode === 'day') {
      dateMatch = saleYear === selYear && saleMonth === selMonth && saleDay === selDay;
    } else if (mode === 'month') {
      dateMatch = saleYear === selYear && saleMonth === selMonth;
    } else if (mode === 'year') {
      dateMatch = saleYear === selYear;
    } else if (mode === 'range') {
      const start = new Date(startDate);
      start.setHours(0, 0, 0, 0);
      const end = new Date(endDate);
      end.setHours(23, 59, 59, 999);
      dateMatch = saleDate >= start && saleDate <= end;
    }

    const searchMatch = 
      sale.id.toLowerCase().includes(salesSearchTerm.toLowerCase()) ||
      sale.customerName.toLowerCase().includes(salesSearchTerm.toLowerCase()) ||
      (sale.sellerName && sale.sellerName.toLowerCase().includes(salesSearchTerm.toLowerCase())) ||
      (sale.paymentMethods && sale.paymentMethods.some(pm => pm.method.toLowerCase().includes(salesSearchTerm.toLowerCase()))) ||
      sale.items.some(item => item.name.toLowerCase().includes(salesSearchTerm.toLowerCase())) ||
      sale.status.toLowerCase().includes(salesSearchTerm.toLowerCase()) ||
      saleDate.toLocaleString().toLowerCase().includes(salesSearchTerm.toLowerCase());

    const debtMatch = !showOnlyDebt || (sale.debtAmount > 0);
    const branchMatch = selectedBranchFilter === 'All' || sale.branchId === selectedBranchFilter;

    return dateMatch && searchMatch && debtMatch && branchMatch;
  }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()), [allSales, selectedDate, mode, startDate, endDate, salesSearchTerm, showOnlyDebt, t, selectedBranchFilter]);

  const downloadPDF = async () => {
    let doc: any;
    try {
      doc = new jsPDF();
    } catch (e) {
      console.error("Error creating PDF:", e);
      return;
    }
    const businessName = tenant?.name || t('business_name_placeholder');
    const location = tenant?.location || '';
    const contact = tenant?.contact || '';
    
    // Header
    let yPos = 20;

    // Logo
    if (tenant?.logoUrl) {
      try {
        const base64 = await getBase64ImageFromURL(tenant.logoUrl);
        doc.addImage(base64, 'PNG', 165, 10, 30, 30);
      } catch (e) {
        console.warn('Could not load logo for PDF:', e);
      }
    }
    
    doc.setFontSize(16);
    doc.setTextColor(79, 70, 229); // Indigo-600
    doc.text(businessName, 14, yPos);
    yPos += 8;

    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139); // Slate-500
    if (location) {
      doc.text(location, 14, yPos);
      yPos += 5;
    }
    if (contact) {
      doc.text(contact, 14, yPos);
      yPos += 5;
    }
    
    yPos += 2;
    doc.setFontSize(12);
    const dateStr = mode === 'range' 
      ? `${startDate.toLocaleDateString()} - ${endDate.toLocaleDateString()}`
      : selectedDate.toLocaleDateString();
    doc.text(`${t('sales_report')} (${dateStr})`, 14, yPos);
    yPos += 10;

    const tableColumn = [t('customer'), t('date'), t('items'), t('total'), t('status'), t('payment_method')];
    const tableRows: any[] = [];

    const getStatusText = (sale: any) => {
      let baseStatus = t(`${sale.status}_status` as any) || t(sale.status as any) || sale.status;
      if (sale.status === 'returned' && sale.paymentMethods) {
        if (sale.paymentMethods.some((pm: any) => pm.method === 'refund_credit')) {
          baseStatus += ' (Credit)';
        } else if (sale.paymentMethods.some((pm: any) => pm.method === 'refund_cash')) {
          baseStatus += ' (Cash)';
        }
      }
      return `${baseStatus}${sale.isEdited ? ` (${t('edited')})` : ''}`;
    };

    filteredSales.forEach(sale => {
      const saleData = [
        sale.customerName || t('none'),
        new Date(sale.createdAt).toLocaleDateString(),
        sale.items.map((i: any) => `${i.name} (${i.qty})`).join(', '),
        `$${(sale.total || 0).toFixed(2)}`,
        getStatusText(sale),
        sale.paymentMethods ? sale.paymentMethods.map(pm => `${pm.method === 'refund_credit' ? (t('refund_credit' as any) || 'Refunded to Credit') : pm.method === 'refund_cash' ? (t('refund_cash' as any) || 'Refunded (Cash)') : pm.method} ($${pm.amount})`).join(', ') : '-'
      ];
      tableRows.push(saleData);
    });

    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: yPos,
      theme: 'grid',
      styles: { fontSize: 8, cellPadding: 3 },
      headStyles: { fillColor: [79, 70, 229], textColor: [255, 255, 255], fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [248, 250, 252] }
    });

    doc.save(`${businessName}_sales_report_${dateStr.replace(/\//g, '-')}.pdf`);
  };

  const downloadInvoicePDF = async (sale: Sale) => {
    const doc = new jsPDF();
    const businessName = tenant?.name || t('business_name_placeholder');
    const location = tenant?.location || '';
    const contact = tenant?.contact || '';
    const email = (tenant as any)?.email || '';

    // 1. INVOICE Header
    doc.setFontSize(28);
    doc.setTextColor(37, 99, 235); // Blue-600
    doc.text('INVOICE', 105, 25, { align: 'center' });

    // 2. Business Details (Left Top)
    doc.setFontSize(12);
    doc.setTextColor(30, 41, 59); // Slate-800
    doc.setFont('helvetica', 'bold');
    doc.text(businessName, 14, 45);
    
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139); // Slate-500
    let y = 52;
    if (location) {
      doc.text(location, 14, y);
      y += 5;
    }
    if (contact) {
      doc.text(`Mobile: ${contact}`, 14, y);
      y += 5;
    }
    if (email) {
      doc.text(`Email: ${email}`, 14, y);
      y += 5;
    }

    // 3. Logo (Right Top)
    if (tenant?.logoUrl) {
      try {
        const base64 = await getBase64ImageFromURL(tenant.logoUrl);
        doc.addImage(base64, 'PNG', 155, 35, 35, 35);
      } catch (e) {
        console.warn('Could not load logo for Invoice PDF:', e);
      }
    }

    // 4. Bill To & Invoice Info
    y = 85;
    doc.setDrawColor(226, 232, 240); // border-slate-200
    doc.line(14, y - 5, 196, y - 5);

    doc.setFontSize(12);
    doc.setTextColor(37, 99, 235); // Blue-600
    doc.setFont('helvetica', 'bold');
    doc.text(t('bill_to'), 14, y);
    
    // Right info block
    doc.text(`${t('invoice_no')} :`, 130, y);
    doc.setTextColor(30, 41, 59); 
    doc.text(sale.id.slice(0, 8).toUpperCase(), 165, y);

    y += 8;
    doc.setFontSize(10);
    doc.setTextColor(30, 41, 59);
    doc.text(sale.customerName || t('guest'), 14, y);
    
    doc.setTextColor(100, 116, 139);
    doc.text(`${t('invoice_date')} :`, 130, y);
    doc.text(new Date(sale.createdAt).toLocaleDateString(), 165, y);

    if (sale.status === 'debt' || sale.status === 'partial') {
        y += 7;
        doc.text(`${t('due_date')} :`, 130, y);
        const dueDate = new Date(sale.createdAt);
        dueDate.setDate(dueDate.getDate() + 7);
        doc.text(dueDate.toLocaleDateString(), 165, y);
    }

    // 5. Table
    const tableColumn = [t('sl_no'), t('description'), t('qty'), t('rate'), t('amount')];
    const tableRows = sale.items.map((item, index) => [
      index + 1,
      item.name,
      item.qty,
      `$${(item.price || 0).toLocaleString()}`,
      `$${(item.subtotal || 0).toLocaleString()}`
    ]);

    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: y + 15,
      theme: 'striped',
      headStyles: { fillColor: [37, 99, 235], textColor: [255, 255, 255], fontStyle: 'bold' },
      styles: { fontSize: 10, cellPadding: 5 },
      columnStyles: {
        0: { cellWidth: 15 },
        1: { cellWidth: 'auto' },
        2: { cellWidth: 20, halign: 'center' },
        3: { cellWidth: 35, halign: 'right' },
        4: { cellWidth: 35, halign: 'right' }
      }
    });

    // 6. Summary Block
    let finalY = (doc as any).lastAutoTable.finalY + 10;
    
    const calculatedSubtotal = sale.items.reduce((sum, i) => sum + (i.subtotal || 0), 0) || 0;
    const calculatedTax = sale.tax || 0;
    const calculatedDiscount = (sale as any).discount || 0;
    const calculatedCreditUsed = sale.creditUsed || 0;

    const addSummaryRow = (label: string, value: string, isBold = false, color = [100, 116, 139]) => {
      doc.setFontSize(10);
      doc.setFont('helvetica', isBold ? 'bold' : 'normal');
      doc.setTextColor(color[0], color[1], color[2]);
      doc.text(label, 130, finalY);
      doc.setTextColor(30, 41, 59);
      doc.text(value, 196, finalY, { align: 'right' });
      finalY += 7;
    };

    // Subtotal
    addSummaryRow(t('subtotal'), `$${calculatedSubtotal.toLocaleString()}`, true);

    // Discount
    if (calculatedDiscount > 0) {
      addSummaryRow(t('discount'), `-$${calculatedDiscount.toLocaleString()}`, false, [225, 29, 72]);
    }

    // Tax
    if (calculatedTax > 0) {
      addSummaryRow(t('tax'), `$${calculatedTax.toLocaleString()}`);
    }

    // Credit Used
    if (calculatedCreditUsed > 0) {
      addSummaryRow(t('use_credit'), `-$${calculatedCreditUsed.toLocaleString()}`, false, [5, 150, 105]);
    }

    // Total line with background
    finalY += 3;
    doc.setFillColor(241, 245, 249);
    doc.rect(120, finalY - 8, 76, 12, 'F');
    doc.setFontSize(14);
    doc.setTextColor(30, 41, 59);
    doc.setFont('helvetica', 'bold');
    doc.text(t('total'), 130, finalY);
    doc.setTextColor(37, 99, 235);
    doc.text(`$${(sale.total || 0).toLocaleString()}`, 190, finalY, { align: 'right' });

    // Paid & Balance
    finalY += 12;
    doc.setFontSize(11);
    doc.setFont('helvetica', 'normal');
    
    if (sale.status === 'paid') {
      doc.setFillColor(236, 253, 245); // Emerald-50
      doc.rect(120, finalY - 8, 76, 10, 'F');
      doc.setTextColor(5, 150, 105); // Emerald-600
      doc.setFont('helvetica', 'bold');
      doc.text(t('paid_status').toUpperCase(), 158, finalY - 1, { align: 'center' });
    } else {
      doc.setTextColor(30, 41, 59);
      doc.text(`${t('paid')} (${new Date(sale.createdAt).toLocaleDateString()})`, 130, finalY);
      doc.text(`$${(sale.paidAmount || 0).toLocaleString()}`, 196, finalY, { align: 'right' });

      finalY += 8;
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(225, 29, 72); // Rose-600
      doc.text(t('balance_due'), 130, finalY);
      doc.text(`$${(sale.debtAmount || 0).toLocaleString()}`, 196, finalY, { align: 'right' });
      
      // Status Stamp for Debt
      doc.setFontSize(30);
      doc.setTextColor(225, 29, 72, 0.2); // Very light rose
      doc.setFont('helvetica', 'bold');
      doc.text(sale.status === 'debt' ? 'DEBT' : 'PARTIAL', 50, 200, { angle: 45 });
    }

    // Payment Instructions
    let bottomY = (doc as any).lastAutoTable.finalY + 15;
    doc.setFontSize(11);
    doc.setTextColor(37, 99, 235);
    doc.text(t('payment_instructions'), 14, bottomY);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139);
    bottomY += 6;
    if (tenant?.paymentNumbers) {
      const pn = tenant.paymentNumbers as any;
      if (pn.evc) doc.text(`EVC: ${pn.evc}`, 14, bottomY), bottomY += 5;
      if (pn.edahab) doc.text(`eDahab: ${pn.edahab}`, 14, bottomY), bottomY += 5;
      if (pn.zaad) doc.text(`ZAAD: ${pn.zaad}`, 14, bottomY), bottomY += 5;
    }
    doc.text(t('thank_you_message'), 14, bottomY + 5);

    // 7. Signature Footer
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(30, 41, 59);
    doc.text('_______________________', 160, 260, { align: 'center' });
    doc.text(t('authorized_signatory'), 160, 266, { align: 'center' });

    doc.save(`Invoice_${sale.id.slice(0, 8).toUpperCase()}.pdf`);
  };

  const downloadExcel = () => {
    const businessName = tenant?.name || t('business_name_placeholder');
    const location = tenant?.location || '';
    const contact = tenant?.contact || '';
    
    const getStatusText = (sale: any) => {
      let baseStatus = t(`${sale.status}_status` as any) || t(sale.status as any) || sale.status;
      if (sale.status === 'returned' && sale.paymentMethods) {
        if (sale.paymentMethods.some((pm: any) => pm.method === 'refund_credit')) {
          baseStatus += ' (Credit)';
        } else if (sale.paymentMethods.some((pm: any) => pm.method === 'refund_cash')) {
          baseStatus += ' (Cash)';
        }
      }
      return `${baseStatus}${sale.isEdited ? ` (${t('edited')})` : ''}`;
    };

    const dateStr = mode === 'range' 
      ? `${startDate.toLocaleDateString()} - ${endDate.toLocaleDateString()}`
      : selectedDate.toLocaleDateString();

    // Create header rows
    const headerRows = [
      [businessName],
      [location],
      [contact],
      [`${t('sales_report')} (${dateStr})`],
      [] // Empty row
    ];

    // Create data rows starting from the headers
    const salesData = filteredSales.map(sale => [
      sale.customerName || t('none'),
      new Date(sale.createdAt).toLocaleDateString(),
      sale.items.map((i: any) => `${i.name} (${i.qty})`).join(', '),
      sale.total,
      getStatusText(sale),
      sale.paymentMethods ? sale.paymentMethods.map(pm => `${pm.method === 'refund_credit' ? (t('refund_credit' as any) || 'Refunded to Credit') : pm.method === 'refund_cash' ? (t('refund_cash' as any) || 'Refunded (Cash)') : pm.method} ($${pm.amount})`).join(', ') : '-'
    ]);

    const tableHeader = [t('customer'), t('date'), t('items'), t('total'), t('status'), t('payment_method')];
    
    const allRows = [...headerRows, tableHeader, ...salesData];
    const worksheet = XLSX.utils.aoa_to_sheet(allRows);
    
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Sales");
    
    const fileNameDate = mode === 'range' 
      ? `${startDate.toLocaleDateString()}_to_${endDate.toLocaleDateString()}`
      : selectedDate.toLocaleDateString();
      
    XLSX.writeFile(workbook, `${businessName}_sales_report_${fileNameDate.replace(/\//g, '-')}.xlsx`);
  };

  const handleReturnSale = (sale: Sale) => {
    setReturnModal({ isOpen: true, sale });
  };

  const processReturn = async (sale: Sale, refundType: 'cash' | 'credit') => {
    if (!user.tenantId) return;
    try {
      // 1. Update Sale Status
      const payload: any = { status: 'returned' };
      if (sale.paidAmount && sale.paidAmount > 0) {
        payload.payment_methods = [
          ...(sale.paymentMethods || []),
          { method: refundType === 'credit' ? 'refund_credit' : 'refund_cash', amount: -sale.paidAmount }
        ];
      }

      await supabase
        .from('sales')
        .update(payload)
        .eq('id', sale.id);

      // 2. Re-stock Inventory (Only for products)
      for (const item of sale.items) {
        if (item.type === 'product') {
          const { data: invItem } = await supabase
            .from('inventory')
            .select('quantity')
            .eq('id', item.id)
            .single();
            
          if (invItem) {
            await supabase
              .from('inventory')
              .update({ quantity: invItem.quantity + item.qty })
              .eq('id', item.id);
          }
        }
      }

      // 3. Handle Debts and Credits
      const adjustCustomerCredit = async (amount: number) => {
        if (amount <= 0) return;
        let query = supabase
          .from('customers')
          .select('id, total_credit')
          .eq('name', sale.customerName)
          .eq('tenant_id', user.tenantId);
        
        if (user.branchId) query = query.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
        
        const { data: customer } = await query.maybeSingle();

        if (customer) {
          await supabase
            .from('customers')
            .update({ total_credit: (customer.total_credit || 0) + amount })
            .eq('id', customer.id);
        } else {
          // Auto-register if not found
          await supabase.from('customers').insert({
            name: sale.customerName,
            phone: sale.customerPhone || '',
            tenant_id: user.tenantId,
            branch_id: sale.branchId || user.branchId || null,
            total_credit: amount,
            total_debt: 0,
            created_at: new Date().toISOString()
          });
        }
      };

      if (sale.status === 'debt' || sale.status === 'partial') {
        if (sale.debtId) {
          const { data: debtData } = await supabase
            .from('debts')
            .select('*')
            .eq('id', sale.debtId)
            .single();
            
          if (debtData) {
            // If they paid something, and user chose credit, add to credit
            if (debtData.paid_amount > 0 && refundType === 'credit') {
              await adjustCustomerCredit(debtData.paid_amount);
            }
            // Delete the debt record as the sale is returned
            await supabase.from('debts').delete().eq('id', sale.debtId);
          }
        }
      } else if (sale.status === 'paid') {
        // For fully paid sales, if user chose credit, add to credit
        if (refundType === 'credit') {
          await adjustCustomerCredit(sale.total);
        }
      }

      // 3.5 If credit was used in the sale, ALWAYS return it to the customer
      if (sale.creditUsed && sale.creditUsed > 0) {
        await adjustCustomerCredit(sale.creditUsed);
      }

      // 3.6 Handle Cash Refund (subtract from account)
      if (refundType === 'cash') {
        const amountToRefund = (sale.paidAmount || 0);
        if (amountToRefund > 0) {
          const refundAccountId = selectedRefundAccountId;
          const { data: accData } = await supabase
            .from('accounts')
            .select('*')
            .eq('id', refundAccountId)
            .single();
          
          if (accData) {
            await supabase
              .from('accounts')
              .update({ balance: accData.balance - amountToRefund })
              .eq('id', accData.id);
            
            await supabase.from('account_transactions').insert({
              from_account_id: accData.id,
              amount: amountToRefund,
              type: 'adjustment',
              description: `Cash Refund for returned sale: ${sale.id} (Customer: ${sale.customerName}${sale.customerPhone ? `, Phone: ${sale.customerPhone}` : ''})`,
              tenant_id: user.tenantId,
              branch_id: sale.branchId || user.branchId || null,
              reference_id: sale.id,
              created_at: new Date().toISOString()
            });
          }
        }
      } else if (refundType === 'credit') {
        // Handle Credit Transaction Recording
        const amountToCredit = (sale.paidAmount || 0);
        if (amountToCredit > 0 && selectedRefundAccountId) {
          await supabase.from('account_transactions').insert({
            to_account_id: selectedRefundAccountId, // Treat as "To" the credit pool (Backed by this account)
            amount: amountToCredit,
            type: 'credit',
            description: `Credit Issued (Refund) for sale: ${sale.id} (Customer: ${sale.customerName}${sale.customerPhone ? `, Phone: ${sale.customerPhone}` : ''})`,
            tenant_id: user.tenantId,
            branch_id: sale.branchId || user.branchId || null,
            reference_id: sale.id,
            created_at: new Date().toISOString()
          });
        }
      }

      // 3.65 Reverse Auto-Expense for Custom Items if applicable
      const customItemCosts = sale.items
        .filter((item: any) => item.type === 'custom' && (item as any).costPrice > 0)
        .reduce((acc: Record<string, number>, item: any) => {
          const accountId = item.costAccountId || 'default';
          acc[accountId] = (acc[accountId] || 0) + (item.costPrice * item.qty);
          return acc;
        }, {});

      for (const [accountId, amount] of Object.entries(customItemCosts) as [string, number][]) {
        if (amount > 0) {
          // Reverse the expense by adding back the cash that was deducted
          let accQuery = supabase.from('accounts').select('*').eq('tenant_id', user.tenantId);
          if (accountId === 'default') {
             const deductAccName = sale.paymentMethods?.find((pm: any) => pm.amount > 0)?.method || 'Cash';
             accQuery = accQuery.eq('name', deductAccName);
          } else {
             accQuery = accQuery.eq('id', accountId);
          }
          let { data: expAcc } = await accQuery.maybeSingle();

          if (expAcc) {
             await supabase
              .from('accounts')
              .update({ balance: expAcc.balance + amount })
              .eq('id', expAcc.id);
              
             await supabase.from('account_transactions').insert({
                to_account_id: expAcc.id,
                amount: amount,
                type: 'adjustment',
                description: `Reversal of Custom Item(s) cost for returned Sale ${sale.id}`,
                tenant_id: user.tenantId,
                branch_id: sale.branchId || user.branchId || null,
                reference_id: sale.id,
                created_at: new Date().toISOString()
             });
             
             // We do not delete the actual expense record, but maybe create a negative expense to balance reports?
             await supabase.from('expenses').insert({
                category: 'supplies',
                description: `Refund Reversal: Cost of Custom Item(s) for Sale ${sale.id}`,
                amount: -amount,
                date: new Date().toISOString(),
                tenant_id: user.tenantId,
                branch_id: selectedSalesBranchId || user.branchId || null,
                created_at: new Date().toISOString()
             });
          }
        }
      }

      // 4. Refresh data
      fetchData();
      setReturnModal({ isOpen: false, sale: null });
      setMessage({ type: 'success', text: t('return_success') });
      setTimeout(() => setMessage(null), 3000);
    } catch (error) {
      console.error("Return error:", error);
      setMessage({ type: 'error', text: t('error_processing_return') });
      setTimeout(() => setMessage(null), 3000);
    }
  };

  if (loading) return <div className="p-8 text-center text-ink-tertiary">{t('loading')}</div>;

  return (
    <div className="space-y-6">
      <RenderConfirmModal />
      <RenderReturnModal />
      
      {/* Message Notification */}
      {message && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-[100] animate-in fade-in slide-in-from-top-4">
          <div className={`px-6 py-3 rounded-2xl shadow-xl flex items-center gap-3 border ${
            message.type === 'success' ? 'bg-emerald-50 dark:bg-emerald-500/10 border-emerald-100 dark:border-emerald-500/20 text-emerald-600 dark:text-emerald-400' : 'bg-rose-50 dark:bg-rose-500/10 border-rose-100 dark:border-rose-500/20 text-rose-600 dark:text-rose-400'
          }`}>
            <div className={`p-1.5 rounded-lg ${message.type === 'success' ? 'bg-emerald-100 dark:bg-emerald-500/20' : 'bg-rose-100 dark:bg-rose-500/20'}`}>
              <Tag className="w-[var(--icon-md)] h-[var(--icon-md)]" />
            </div>
            <p className="text-sm font-bold">{message.text}</p>
          </div>
        </div>
      )}

      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6 mb-4">
        <div className="flex bg-surface-main p-1.5 rounded-[1.5rem] border border-border-main shadow-lg shadow-bg-tertiary">
          <button
            onClick={() => setActiveView('pos')}
            className={`px-8 py-2.5 rounded-2xl text-xs font-black uppercase tracking-[0.15em] flex items-center gap-2.5 transition-all active:scale-95 ${
              activeView === 'pos' 
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' 
                : 'text-ink-tertiary hover:text-ink hover:bg-bg-sec'
            }`}
          >
            <LayoutGrid size={16} strokeWidth={3} />
            {t('pos' as any) || 'POS'}
          </button>
          <button
            onClick={() => setActiveView('history')}
            className={`px-8 py-2.5 rounded-2xl text-xs font-black uppercase tracking-[0.15em] flex items-center gap-2.5 transition-all active:scale-95 ${
              activeView === 'history' 
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' 
                : 'text-ink-tertiary hover:text-ink hover:bg-bg-sec'
            }`}
          >
            <History size={16} strokeWidth={3} />
            {t('history')}
          </button>
          <button
            onClick={() => setShowSavedCarts(true)}
            className="px-6 py-2.5 rounded-2xl text-xs font-black uppercase tracking-widest flex items-center gap-2.5 transition-all text-ink-tertiary hover:text-ink hover:bg-bg-sec relative group"
          >
            <ShoppingCart size={16} strokeWidth={2.5} className="group-hover:rotate-12 transition-transform" />
            {t('cart_list')}
            {savedCarts.length > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-rose-500 text-white text-xs font-black rounded-full flex items-center justify-center border-2 border-surface-main animate-pulse shadow-lg">
                {savedCarts.length}
              </span>
            )}
          </button>
        </div>

        {activeView === 'history' && (
          <div className="flex flex-col xl:flex-row items-center gap-3 w-full sm:w-auto">
            <div className="relative w-full sm:w-80">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-accent-main" size={18} strokeWidth={3} />
              <input 
                type="text"
                placeholder={t('search_placeholder' as any) || 'Search transactions...'}
                value={salesSearchTerm}
                onChange={(e) => setSalesSearchTerm(e.target.value)}
                className="w-full bg-surface-main border border-border-main rounded-2xl pl-12 pr-4 py-3 text-xs font-black uppercase italic text-ink focus:border-accent-main transition-all placeholder:text-ink-tertiary placeholder:font-bold shadow-sm"
              />
            </div>
            {tenant?.isMultiBranch && branches.length > 0 && (
              <select
                value={selectedBranchFilter}
                onChange={e => setSelectedBranchFilter(e.target.value)}
                disabled={!!user.branchId}
                className={`w-full sm:w-auto bg-surface-main border border-border-main text-ink-secondary px-5 py-3 rounded-2xl font-bold shadow-sm focus:outline-none focus:border-accent-main transition-all text-xs uppercase ${!!user.branchId ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <option value="All">{t('all_branches' as any) || 'All Branches'}</option>
                {branches.map(b => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            )}
            <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
              <div className="bg-surface-main border border-border-main rounded-2xl p-1 shadow-sm">
                <DateSelector 
                  selectedDate={selectedDate} 
                  onChange={setSelectedDate} 
                  mode={mode} 
                  onModeChange={setMode} 
                  startDate={startDate}
                  endDate={endDate}
                  onRangeChange={(start, end) => {
                    setStartDate(start);
                    setEndDate(end);
                  }}
                />
              </div>
              
              <div className="flex gap-2">
                <button 
                  onClick={downloadPDF}
                  disabled={filteredSales.length === 0}
                  className="px-6 py-3.5 bg-rose-600 text-white rounded-xl shadow-lg shadow-rose-500/10 hover:bg-rose-700 active:scale-95 transition-all disabled:opacity-30 flex items-center gap-2 text-sm font-bold"
                >
                  <FileDown size={18} strokeWidth={2.5} />
                  <span>{t('download_pdf')}</span>
                </button>
                <button 
                  onClick={downloadExcel}
                  disabled={filteredSales.length === 0}
                  className="px-6 py-3.5 bg-emerald-600 text-white rounded-xl shadow-lg shadow-emerald-500/10 hover:bg-emerald-700 active:scale-95 transition-all disabled:opacity-30 flex items-center gap-2 text-sm font-bold"
                >
                  <FileDown size={18} strokeWidth={2.5} />
                  <span>{t('download_excel')}</span>
                </button>
                <button 
                  onClick={fetchData}
                  disabled={loading}
                  className="p-3 bg-surface-main text-ink-tertiary border border-border-main rounded-xl shadow-sm hover:text-accent-main hover:bg-bg-sec transition-all active:rotate-180 duration-500 disabled:opacity-30"
                >
                  <RefreshCw size={18} strokeWidth={2.5} className={loading ? 'animate-spin' : ''} />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {activeView === 'pos' ? (
        <>
          <div className="flex flex-col lg:grid lg:grid-cols-4 gap-6 lg:h-[calc(100vh-14rem)] relative">
            {/* Products Section - Restored and Re-integrated */}
            <div className="lg:col-span-2 flex flex-col bg-surface-main rounded-2xl shadow-2xl border border-border-main overflow-hidden print:hidden min-h-[500px] lg:min-h-0">
              <div className="p-3 sm:p-4 border-b border-border-main bg-bg-sec/30 space-y-3 sticky top-0 z-20 backdrop-blur-md">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex bg-bg-main p-1 rounded-xl border border-border-main shadow-inner w-fit">
                    {tenant?.type !== 'services' && (
                      <button
                        onClick={() => setActiveCategory('products')}
                        className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest flex items-center gap-2 transition-all ${
                          activeCategory === 'products' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-ink-tertiary hover:text-ink hover:bg-bg-sec'
                        }`}
                      >
                        <PackageIcon size={14} strokeWidth={2.5} />
                        {t('inventory')}
                      </button>
                    )}
                    {(tenant?.modules.services || tenant?.type === 'services') && (
                      <button
                        onClick={() => setActiveCategory('services')}
                        className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest flex items-center gap-2 transition-all ${
                          activeCategory === 'services' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-ink-tertiary hover:text-ink hover:bg-bg-sec'
                        }`}
                      >
                        <Briefcase size={14} strokeWidth={2.5} />
                        {t('services')}
                      </button>
                    )}
                    <button
                      onClick={() => setActiveCategory('custom')}
                      className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest flex items-center gap-2 transition-all ${
                        activeCategory === 'custom' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-ink-tertiary hover:text-ink hover:bg-bg-sec'
                      }`}
                    >
                      <Plus size={14} strokeWidth={2.5} />
                      {t('custom_item')}
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    {tenant?.isMultiBranch && branches.length > 0 && activeCategory === 'products' && (
                      <select
                        value={selectedSalesBranchId}
                        onChange={e => setSelectedSalesBranchId(e.target.value)}
                        disabled={!!user.branchId}
                        className={`bg-surface-main border border-border-main text-ink-secondary px-3 py-1.5 rounded-xl font-bold shadow-sm focus:outline-none focus:border-accent-main transition-all text-[11px] uppercase ${!!user.branchId ? 'opacity-50 cursor-not-allowed' : ''}`}
                      >
                        {branches.map(b => (
                          <option key={b.id} value={b.id}>{b.name}</option>
                        ))}
                      </select>
                    )}
                    {activeCategory !== 'custom' && (
                      <div className="relative flex-1 max-w-[200px]">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-tertiary" size={14} />
                        <input 
                          type="text" 
                          placeholder={t('search_product_sales_placeholder')} 
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="w-full pl-10 pr-4 py-1.5 bg-bg-main border border-border-main rounded-xl focus:outline-none focus:border-indigo-500/50 text-[11px] text-ink transition-all placeholder:text-ink-tertiary font-bold"
                        />
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {activeCategory === 'products' && uniqueProductCategories.length > 1 && (
                <div className="flex gap-2 px-6 pb-4 overflow-x-auto no-scrollbar border-b border-border-subtle bg-surface-main">
                  {uniqueProductCategories.map(cat => (
                    <button
                      key={cat}
                      onClick={() => setProductCategoryFilter(cat)}
                      className={`px-5 py-2.5 rounded-full text-sm font-bold whitespace-nowrap transition-all ${
                        productCategoryFilter === cat 
                          ? 'bg-accent-main text-white shadow-md' 
                          : 'bg-accent-soft text-accent-main hover:opacity-80'
                      }`}
                    >
                      {cat === 'All' ? t('all') : cat}
                    </button>
                  ))}
                </div>
              )}

              {activeCategory === 'services' && uniqueServiceCategories.length > 1 && (
                <div className="flex gap-2 px-6 pb-4 overflow-x-auto no-scrollbar border-b border-border-subtle bg-surface-main">
                  {uniqueServiceCategories.map(cat => (
                    <button
                      key={cat}
                      onClick={() => setServiceCategoryFilter(cat)}
                      className={`px-5 py-2.5 rounded-full text-sm font-bold whitespace-nowrap transition-all ${
                        serviceCategoryFilter === cat 
                          ? 'bg-accent-main text-white shadow-md' 
                          : 'bg-accent-soft text-accent-main hover:opacity-80'
                      }`}
                    >
                      {cat === 'All' ? t('all') : cat}
                    </button>
                  ))}
                </div>
              )}
              
              <div className="p-4 sm:p-6 overflow-y-auto flex-1 grid grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-6 content-start custom-scrollbar">
                {activeCategory === 'products' ? (
                  filteredInventory.map(item => (
                    <button
                      key={item.id}
                      onClick={() => addToCart(item, 'product')}
                      className={`relative p-3 rounded-2xl border text-left transition-all flex flex-col justify-between group h-fit ${
                        item.quantity > 0 
                          ? 'bg-surface-main border-border-main hover:border-accent-main hover:shadow-xl active:scale-[0.98]' 
                          : 'bg-bg-sec border-border-main opacity-80 hover:border-accent-main active:scale-[0.98]'
                      }`}
                    >
                      <div className="w-full text-ink">
                        {item.imageUrl || (item as any).image_url ? (
                          <div className="relative group/img overflow-hidden rounded-xl mb-3">
                            <img src={item.imageUrl || (item as any).image_url} alt={item.name} className="w-full h-24 object-cover group-hover/img:scale-110 transition-transform duration-700" referrerPolicy="no-referrer" />
                          </div>
                        ) : (
                          <div className="w-full h-24 bg-bg-sec rounded-xl mb-3 flex items-center justify-center text-ink-tertiary">
                            <PackageIcon className="w-6 h-6" strokeWidth={1.5} />
                          </div>
                        )}
                        <div className="font-bold text-ink mb-1 truncate text-xs leading-tight">{item.name}</div>
                        <div className="text-[10px] text-ink-tertiary font-mono mb-2 truncate">SKU: {item.sku}</div>
                      </div>
                      <div className="flex justify-between items-center gap-2">
                        <span className="font-black text-accent-main text-sm">${parseFloat(item.price as any).toFixed(2)}</span>
                        <span className="text-[10px] font-bold text-ink-tertiary bg-bg-sec px-1.5 py-0.5 rounded-md">
                          {item.quantity} {t('items_remaining')}
                        </span>
                      </div>
                    </button>
                  ))
                ) : activeCategory === 'services' ? (
                  filteredServices.map((service: any) => (
                    <button
                      key={service.id}
                      onClick={() => addToCart(service, 'service')}
                      className="p-3 rounded-2xl border text-left transition-all flex flex-col justify-between group bg-surface-main border-border-main hover:border-accent-main hover:shadow-xl"
                    >
                      <div className="w-full">
                        {service.imageUrl || (service as any).image_url ? (
                          <img src={service.imageUrl || (service as any).image_url} alt={service.name} className="w-full h-24 object-cover rounded-xl mb-3" referrerPolicy="no-referrer" />
                        ) : (
                          <div className="w-full h-24 bg-bg-sec rounded-xl mb-3 flex items-center justify-center text-ink-tertiary">
                            <Briefcase className="w-6 h-6" />
                          </div>
                        )}
                        <div className="font-bold text-ink mb-0.5 truncate text-xs leading-tight">{service.name}</div>
                        <div className="text-[10px] text-ink-tertiary font-mono mb-3 truncate">{service.description}</div>
                      </div>
                      <div className="flex justify-between items-center gap-2">
                        <span className="font-black text-accent-main text-sm">${parseFloat(service.price).toFixed(2)}</span>
                        <span className="text-[10px] font-bold text-accent-main bg-accent-soft px-1.5 py-0.5 rounded-md">SERVICE</span>
                      </div>
                    </button>
                  ))
                ) : (
                  <div className="col-span-full h-full flex flex-col items-center justify-center py-20 text-ink-tertiary space-y-6">
                    <div className="p-8 bg-indigo-500/5 rounded-full border border-dashed border-border-main relative">
                      <Plus size={48} className="text-indigo-500/40" />
                      <div className="absolute inset-0 bg-indigo-500/20 blur-2xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                    
                    <div className="w-full max-w-2xl bg-surface-main backdrop-blur-3xl p-10 rounded-[3rem] border border-border-main space-y-8 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.05)] dark:shadow-[0_32px_64px_-16px_rgba(0,0,0,0.5)] relative overflow-hidden group">
                      <div className="absolute top-0 right-0 p-4">
                        <div className="text-[10px] font-black text-indigo-500/30 uppercase tracking-[0.3em] font-mono select-none">
                          CM-WIDGET-01
                        </div>
                      </div>

                      <div className="space-y-3">
                        <label className="text-[11px] font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-[0.25em] ml-2 flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.5)]" />
                          {t('custom_item_name')}
                        </label>
                        <input 
                          type="text" 
                          placeholder={t('name')} 
                          value={customItemName}
                          onChange={(e) => setCustomItemName(e.target.value)}
                          className="w-full bg-bg-sec border border-border-main rounded-2xl px-7 py-5 text-base font-bold text-ink outline-none focus:border-indigo-500/50 transition-all placeholder:text-ink-tertiary ring-offset-0 focus:ring-8 focus:ring-indigo-500/5"
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="space-y-3">
                          <label className="text-[11px] font-black text-emerald-600 dark:text-emerald-400 uppercase tracking-[0.25em] ml-2 flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
                            {t('sell_price')}
                          </label>
                          <input 
                            type="number" 
                            placeholder={t('price')} 
                            value={customItemPrice}
                            onChange={(e) => setCustomItemPrice(e.target.value)}
                            className="w-full bg-bg-sec border border-border-main rounded-2xl px-7 py-5 text-base font-mono font-black text-emerald-600 dark:text-emerald-400 outline-none focus:border-emerald-500/50 transition-all focus:ring-8 focus:ring-emerald-500/5"
                          />
                        </div>
                        <div className="space-y-3">
                          <label className="text-[11px] font-black text-amber-600 dark:text-amber-400 uppercase tracking-[0.25em] ml-2 flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.5)]" />
                            {t('buy_price')}
                          </label>
                          <input 
                            type="number" 
                            placeholder={t('buy_price')} 
                            value={customItemCostPrice}
                            onChange={(e) => setCustomItemCostPrice(e.target.value)}
                            className="w-full bg-bg-sec border border-border-main rounded-2xl px-7 py-5 text-base font-mono font-black text-amber-600 dark:text-amber-400 outline-none focus:border-amber-500/50 transition-all focus:ring-8 focus:ring-amber-500/5"
                          />
                        </div>
                        <div className="space-y-3">
                          <label className="text-[11px] font-black text-blue-600 dark:text-blue-400 uppercase tracking-[0.25em] ml-2 flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.5)]" />
                            {t('qty')}
                          </label>
                          <input 
                            type="number" 
                            placeholder={t('qty')} 
                            value={customItemQty}
                            onChange={(e) => setCustomItemQty(e.target.value)}
                            className="w-full bg-bg-sec border border-border-main rounded-2xl px-7 py-5 text-base font-mono font-black text-blue-600 dark:text-blue-400 outline-none focus:border-blue-500/50 transition-all focus:ring-8 focus:ring-blue-500/5"
                          />
                        </div>
                      </div>

                      <div className="pt-4 space-y-6">
                        <div className="flex items-center gap-4 bg-bg-sec/50 p-4 rounded-2xl border border-border-main">
                          <button
                            onClick={() => setCustomItemIsDebt(!customItemIsDebt)}
                            className={`w-12 h-6 rounded-full relative transition-all ${customItemIsDebt ? 'bg-amber-500' : 'bg-bg-main border border-border-main'}`}
                          >
                            <div className={`absolute top-1 w-4 h-4 rounded-full transition-all ${customItemIsDebt ? 'right-1 bg-white' : 'left-1 bg-ink-tertiary'}`} />
                          </button>
                          <div>
                            <span className="text-xs font-black uppercase tracking-widest text-ink">{t('custom_item_debt' as any) || 'Buy on Debt'}</span>
                            <p className="text-[10px] text-ink-tertiary font-bold tracking-tight">{t('stock_debt_desc' as any) || 'Record this purchase as a business debt.'}</p>
                          </div>
                        </div>

                        {customItemIsDebt ? (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-3">
                              <label className="text-[11px] font-black text-amber-600 uppercase tracking-[0.25em] ml-2">{t('supplier_name')}</label>
                              <input 
                                type="text" 
                                placeholder={t('supplier_name')} 
                                value={customItemSupplierName}
                                onChange={(e) => setCustomItemSupplierName(e.target.value)}
                                className="w-full bg-bg-sec border border-amber-500/20 rounded-2xl px-7 py-5 text-sm font-bold text-ink outline-none focus:border-amber-500/50 appearance-none transition-all"
                              />
                            </div>
                            <div className="space-y-3">
                              <label className="text-[11px] font-black text-amber-600 uppercase tracking-[0.25em] ml-2">{t('phone')}</label>
                              <input 
                                type="text" 
                                placeholder={t('phone')} 
                                value={customItemSupplierPhone}
                                onChange={(e) => setCustomItemSupplierPhone(e.target.value)}
                                className="w-full bg-bg-sec border border-amber-500/20 rounded-2xl px-7 py-5 text-sm font-bold text-ink outline-none focus:border-amber-500/50 appearance-none transition-all"
                              />
                            </div>
                          </div>
                        ) : (
                          <div className="space-y-3">
                            <label className="text-[11px] font-black text-ink-tertiary uppercase tracking-[0.25em] ml-2">
                              {t('cost_deduction_note')}
                            </label>
                            <div className="relative">
                              <select 
                                value={customItemCostAccountId}
                                onChange={(e) => setCustomItemCostAccountId(e.target.value)}
                                className={`w-full bg-bg-sec border ${parseFloat(customItemCostPrice) > 0 && !customItemCostAccountId ? 'border-amber-500/50 shadow-[0_0_20px_-5px_rgba(245,158,11,0.3)]' : 'border-border-main'} rounded-2xl px-7 py-5 text-sm font-bold text-ink outline-none focus:border-indigo-500/50 appearance-none cursor-pointer transition-all`}
                              >
                                <option value="">{t('select_account')}</option>
                                {accounts.filter(acc => (acc.balance || 0) > 0).map(acc => (
                                  <option key={acc.id} value={acc.id}>{acc.name}</option>
                                ))}
                              </select>
                              <ChevronDown size={20} className="absolute right-6 top-1/2 -translate-y-1/2 text-ink-tertiary pointer-events-none" />
                            </div>
                          </div>
                        )}

                        <button 
                          onClick={addCustomToCart} 
                          className="h-[64px] w-full bg-indigo-600 text-white rounded-2xl font-black text-base uppercase tracking-[0.25em] shadow-2xl shadow-indigo-500/40 hover:bg-indigo-500 hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-4 group"
                        >
                          <Plus size={24} strokeWidth={3} className="group-hover:rotate-180 transition-transform duration-500" />
                          {t('add')}
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Middle Column: Current Order & Items (Design from Image Left) */}
            <div className="lg:col-span-1 flex flex-col bg-surface-main rounded-2xl shadow-2xl border border-border-main overflow-hidden print:hidden min-h-[500px] lg:min-h-0">
              <div className="p-5 border-b border-border-main bg-bg-sec/30 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-lg shadow-indigo-500/20">
                    <ShoppingCart size={24} />
                  </div>
                  <div>
                    <h2 className="text-lg font-black text-ink uppercase tracking-tighter leading-none">{t('current_order')}</h2>
                    <p className="text-[10px] text-ink-tertiary uppercase font-black tracking-widest mt-1">{cart.length} {t('items')}</p>
                  </div>
                </div>
                <div className="text-ink-tertiary opacity-40">
                  <Clock size={20} />
                </div>
              </div>
              
              <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
                {cart.map(c => (
                  <motion.div 
                    layout
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    key={`${c.type}-${c.item.id}`} 
                    className="group bg-bg-sec p-4 rounded-2xl flex items-center justify-between gap-4 border border-border-main hover:border-indigo-500/20 transition-all font-sans"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-sm text-ink truncate">{c.item.name}</div>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-sm font-mono font-black text-indigo-500">
                          ${(parseFloat(c.item.price as any) || 0).toFixed(2)}
                        </span>
                        <span className="text-[10px] text-ink-tertiary font-black">X {c.qty}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <div className="flex flex-col gap-1">
                        <button onClick={() => updateQty(c.item.id, c.type, 1)} className="p-1 text-ink-tertiary hover:text-indigo-600 transition-colors"><ChevronUp size={16} /></button>
                        <button onClick={() => updateQty(c.item.id, c.type, -1)} className="p-1 text-ink-tertiary hover:text-rose-600 transition-colors"><ChevronDown size={16} /></button>
                      </div>
                      <button onClick={() => removeFromCart(c.item.id, c.type)} className="p-3 text-ink-tertiary hover:text-rose-600 transition-colors bg-bg-main border border-border-main rounded-xl"><Trash2 size={16} /></button>
                    </div>
                  </motion.div>
                ))}
                
                {cart.length === 0 && (
                  <div className="h-full flex flex-col items-center justify-center py-20 space-y-6">
                    <div className="relative">
                      <div className="absolute inset-0 bg-indigo-500/10 blur-3xl rounded-full" />
                      <PackageIcon size={48} className="text-ink-tertiary opacity-20 relative" />
                    </div>
                    <div className="text-center">
                      <p className="text-xs uppercase font-black tracking-[0.2em] text-ink-tertiary opacity-40">{t('order_empty')}</p>
                    </div>
                    <button 
                      onClick={() => setShowSavedCarts(true)}
                      className="px-8 py-3 bg-bg-main border border-border-main text-indigo-600 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-600 hover:text-white transition-all flex items-center gap-3 shadow-sm"
                    >
                      <History size={16} />
                      {t('cart_list')}
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Right Column: Checkout Summary (Design from Image Right) */}
            <div className="lg:col-span-1 flex flex-col bg-surface-main rounded-2xl shadow-2xl border border-border-main overflow-hidden print:hidden lg:h-full">
              <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
                {/* Tax & Discount Inputs */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-ink-tertiary uppercase tracking-[0.2em] ml-1">TAX (%)</label>
                    <div className="bg-bg-sec border border-border-main p-4 rounded-2xl focus-within:border-indigo-500/50 transition-all shadow-inner">
                      <input
                        type="number"
                        min="0"
                        value={taxPercentage}
                        onChange={(e) => {
                          if (e.target.value === '') {
                            setTaxPercentage('');
                          } else {
                            const val = parseFloat(e.target.value);
                            setTaxPercentage(isNaN(val) ? '' : val);
                          }
                        }}
                        className="w-full bg-transparent text-lg font-mono font-black text-ink outline-none"
                        placeholder="0"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-ink-tertiary uppercase tracking-[0.2em] ml-1">DISCOUNT ($)</label>
                    <div className="bg-bg-sec border border-border-main p-4 rounded-2xl focus-within:border-indigo-500/50 transition-all shadow-inner">
                      <input
                        type="number"
                        value={manualDiscount}
                        onChange={(e) => setManualDiscount(parseFloat(e.target.value) || 0)}
                        className="w-full bg-transparent text-lg font-mono font-black text-ink outline-none"
                        placeholder="0"
                      />
                    </div>
                  </div>
                </div>

                {/* Enhanced Total Box */}
                <div className="relative group">
                  <div className="absolute inset-0 bg-indigo-600 blur-2xl opacity-10" />
                  <div className="relative bg-gradient-to-br from-indigo-500 to-indigo-700 p-6 rounded-3xl text-white shadow-2xl shadow-indigo-500/20 overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 opacity-10">
                      <Landmark size={64} strokeWidth={1} />
                    </div>
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-[10px] font-black uppercase tracking-[0.3em] opacity-80">{t('total_amount')}</span>
                      <span className="text-xs font-mono font-bold opacity-60">${subtotal.toFixed(2)}</span>
                    </div>
                    <div className="text-4xl font-black font-mono text-right tracking-tighter">
                      ${finalTotal.toFixed(2)}
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                   {/* Customer Selection */}
                  <div className="space-y-2">
                    <div className="space-y-3">
                      <div className="relative">
                        <select 
                          className="w-full bg-bg-sec border border-border-main rounded-2xl px-6 py-4 text-xs font-black text-ink appearance-none outline-none shadow-inner focus:border-indigo-500/50 transition-all hover:bg-bg-sec/50"
                          value={selectedCustomerId || ''}
                          onChange={(e) => {
                            const customer = customers.find(c => c.id === e.target.value);
                            if (customer) {
                              setCustomerName(customer.name);
                              setCustomerPhone(customer.phone);
                              setAvailableCredit(customer.totalCredit || 0);
                              setSelectedCustomerId(customer.id);
                            } else {
                              setCustomerName('');
                              setCustomerPhone('');
                              setAvailableCredit(0);
                              setSelectedCustomerId(null);
                              setUseCredit(false);
                            }
                          }}
                        >
                          <option value="" className="bg-surface-main">{selectedCustomerId ? t('regular_customer') : t('new_or_regular_customer' as any) || 'New/Regular Customer'}</option>
                          {customers.map(c => <option key={c.id} value={c.id} className="bg-surface-main">{c.name}</option>)}
                        </select>
                        <ChevronDown className="absolute right-5 top-1/2 -translate-y-1/2 text-ink-tertiary pointer-events-none" size={16} />
                      </div>

                      {!selectedCustomerId && (
                        <div className="space-y-3 pt-2">
                          <div className="relative">
                            <User className="absolute left-4 top-1/2 -translate-y-1/2 text-ink-tertiary opacity-40" size={16} />
                            <input 
                              type="text" 
                              placeholder={t('name_placeholder' as any) || 'Enter new customer name...'} 
                              value={customerName || ''}
                              onChange={(e) => setCustomerName(e.target.value)}
                              className="w-full bg-bg-sec border border-border-main rounded-2xl pl-12 pr-6 py-4 text-xs font-bold text-ink outline-none focus:border-indigo-500/50 transition-all"
                            />
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Customer CRM Balances */}
                    {selectedCustomerId && (
                      <div className="grid grid-cols-2 gap-2 mt-2">
                        {(() => {
                          const crmCustomer = customers.find(c => c.id === selectedCustomerId);
                          if (!crmCustomer) return null;
                          return (
                            <>
                              <div className="bg-rose-500/10 border border-rose-500/20 p-3 rounded-xl flex flex-col items-center justify-center">
                                <span className="text-xs font-black uppercase tracking-widest text-rose-500/60 mb-0.5">{t('debt')}</span>
                                <span className="text-sm font-mono font-black text-rose-400">${(crmCustomer.totalDebt || 0).toFixed(2)}</span>
                              </div>
                              <div className="bg-emerald-500/10 border border-emerald-500/20 p-3 rounded-xl flex flex-col items-center justify-center">
                                <span className="text-xs font-black uppercase tracking-widest text-emerald-500/60 mb-0.5">{t('credit_balance' as any) || 'Credit'}</span>
                                <span className="text-sm font-mono font-black text-emerald-300">${(crmCustomer.totalCredit || 0).toFixed(2)}</span>
                              </div>
                            </>
                          );
                        })()}
                      </div>
                    )}

                    {/* Credit Toggle */}
                    {selectedCustomerId && availableCredit > 0 && (
                      <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl flex items-center justify-between shadow-inner mt-2">
                        <div>
                          <p className="text-xs font-black text-emerald-600 uppercase tracking-[0.2em] mb-1">{t('use_credit' as any) || 'Use Credit Balance'}</p>
                          <p className="text-sm font-mono font-black text-emerald-500">Up to ${(availableCredit).toFixed(2)}</p>
                        </div>
                        <label className="relative flex items-center gap-2 cursor-pointer">
                          <input type="checkbox" checked={useCredit} onChange={(e) => setUseCredit(e.target.checked)} className="sr-only peer" />
                          <div className="w-12 h-6 bg-ink/10 rounded-full peer peer-checked:bg-emerald-500 transition-all after:content-[''] after:absolute after:top-1 after:left-1 after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:after:translate-x-6"></div>
                        </label>
                      </div>
                    )}
                  </div>

                  {/* Register as Debt */}
                  <div className="space-y-2">
                    <label 
                      className={`flex items-center gap-4 cursor-pointer group px-2 py-2 transition-all ${!selectedCustomerId ? 'opacity-50 grayscale cursor-not-allowed' : ''}`}
                      onClick={(e) => {
                        if (!selectedCustomerId) {
                          e.preventDefault();
                          setMessage({ type: 'error', text: t('select_customer_for_debt' as any) || 'You must select an existing CRM customer to register debt.' });
                          setTimeout(() => setMessage(null), 3000);
                        }
                      }}
                    >
                      <div className={`w-7 h-7 rounded-xl border-2 flex items-center justify-center transition-all ${isDebt ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'border-border-main bg-bg-sec group-hover:border-indigo-500/50'}`}>
                        <input 
                          type="checkbox" 
                          checked={isDebt} 
                          onChange={(e) => selectedCustomerId && toggleDebt(e.target.checked)} 
                          className="sr-only"
                          disabled={!selectedCustomerId}
                        />
                        {isDebt && <Check size={16} strokeWidth={4} />}
                      </div>
                      <div className="flex flex-col">
                        <span className={`text-xs font-black uppercase tracking-widest transition-colors ${isDebt ? 'text-indigo-600' : 'text-ink-tertiary group-hover:text-ink'}`}>{t('register_as_debt')}</span>
                        {!selectedCustomerId && <span className="text-[10px] text-rose-400 font-bold italic uppercase tracking-tighter">{t('crm_required' as any) || 'CRM Customer Required'}</span>}
                      </div>
                    </label>
                  </div>

                  {/* Payment Method Selector */}
                  <div className="bg-bg-sec p-5 rounded-3xl border border-border-main space-y-4 shadow-inner">
                     <div className="flex items-center justify-between">
                      <span className="text-[9px] font-black text-ink-tertiary uppercase tracking-[0.2em]">{t('payment_method')}</span>
                      <button 
                        onClick={() => {
                          const currentTotalPaid = paymentMethods.reduce((sum, pm) => sum + pm.amount, 0);
                          const remaining = Math.max(0, (remainingToPay - manualDebt) - currentTotalPaid);
                          setPaymentMethods([...paymentMethods, { method: 'Cash', amount: remaining }]);
                        }} 
                        className="text-indigo-600 text-[9px] font-black uppercase tracking-widest hover:text-indigo-500 transition-colors"
                      >
                        {t('add_split' as any) || 'Add Split'}
                      </button>
                    </div>
                    <div className="space-y-3">
                      {paymentMethods.map((pm, idx) => (
                        <div key={idx} className="flex gap-3 items-center">
                          <div className="relative flex-1">
                            <select 
                              value={pm.method} 
                              onChange={(e) => {
                                const nm = [...paymentMethods]; nm[idx].method = e.target.value; setPaymentMethods(nm);
                              }}
                              className="w-full bg-bg-main border border-border-main px-4 py-2.5 rounded-xl text-[11px] font-black text-ink appearance-none outline-none focus:border-indigo-500/30"
                            >
                              {[...new Set(['Cash', 'EVC', 'ZAAD', 'eDahab', 'SAHAL', 'Bank Account', 'Merchant', ...accounts.map(a => a.name)])].map(m => {
                                return (
                                  <option key={m} value={m}>
                                    {m}
                                  </option>
                                );
                              })}
                            </select>
                            <ChevronDown size={12} className="absolute right-4 top-1/2 -translate-y-1/2 text-ink-tertiary pointer-events-none" />
                          </div>
                          <input 
                            type="number" 
                            value={pm.amount || ''} 
                            onChange={(e) => {
                              const val = parseFloat(e.target.value) || 0;
                              const nm = [...paymentMethods];
                              nm[idx].amount = val;
                              
                              // Auto-balance if exactly two payment methods
                              if (paymentMethods.length === 2) {
                                const otherIdx = 1 - idx;
                                nm[otherIdx].amount = Math.max(0, (remainingToPay - manualDebt) - val);
                              }
                              
                              setPaymentMethods(nm);
                            }}
                            className="w-20 bg-bg-main border border-border-main px-3 py-2.5 rounded-xl text-[11px] font-mono font-black text-ink outline-none focus:border-indigo-500/30 text-right"
                          />
                          {paymentMethods.length > 1 && (
                            <button 
                              type="button"
                              onClick={() => {
                                const nm = paymentMethods.filter((_, i) => i !== idx);
                                
                                // If we're reducing to 1 method, let the single-method logic in useEffect 
                                // handle setting the correct amount. Otherwise, just update the list.
                                if (nm.length === 1) {
                                  nm[0].amount = Math.max(0, remainingToPay - manualDebt);
                                }
                                
                                setPaymentMethods(nm);
                              }}
                              className="text-rose-500 hover:text-white hover:bg-rose-600 p-2 rounded-xl transition-all active:scale-90 flex-shrink-0 bg-rose-500/10 border border-rose-500/20"
                              title={t('remove')}
                            >
                              <X size={16} strokeWidth={3} />
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom Actions */}
              <div className="p-6 bg-bg-sec/30 border-t border-border-main grid grid-cols-4 gap-3">
                <button 
                  onClick={() => {
                    if (cart.length > 0) {
                      setHoldCartName(customerName || '');
                      setShowHoldModal(true);
                    }
                  }}
                  disabled={cart.length === 0}
                  className="col-span-1 py-4 rounded-2xl bg-bg-sec border border-border-main text-ink-tertiary font-black flex items-center justify-center hover:bg-bg-main transition-all disabled:opacity-20 active:scale-95 shadow-sm"
                  title={t('park_order')}
                >
                  <History size={20} />
                </button>

                <button 
                  onClick={handleCheckout}
                  disabled={cart.length === 0 || processing}
                  className="col-span-3 py-4 rounded-2xl bg-indigo-600 text-white font-black text-xs uppercase tracking-[0.2em] shadow-xl shadow-indigo-600/20 flex items-center justify-center gap-3 transition-all hover:bg-indigo-500 active:scale-95 disabled:opacity-20"
                >
                  {processing ? <RefreshCw className="animate-spin" size={16} /> : (
                    <>
                      <div className="bg-white/20 p-1.5 rounded-lg">
                        <CreditCard size={16} />
                      </div>
                      {cart.length === 0 ? (t('add_items' as any) || 'Add Items') : t('pay_now')}
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Floating Cart Button for Mobile */}
          {!showMobileCart && cart.length > 0 && (
            <button 
              onClick={() => setShowMobileCart(true)}
              className="lg:hidden fixed bottom-6 right-6 z-40 w-16 h-16 bg-indigo-600 text-white rounded-full shadow-2xl flex items-center justify-center animate-bounce-subtle active:scale-95 transition-transform"
            >
              <div className="relative">
                <ShoppingCart size={28} />
                <span className="absolute -top-2 -right-2 bg-rose-500 text-white text-xs font-black w-6 h-6 rounded-full flex items-center justify-center border-2 border-indigo-600 shadow-lg">
                  {cart.length}
                </span>
              </div>
            </button>
          )}
        </>
      ) : (
        <div className="space-y-4">
          {/* Alert Banner for sales below expected price or sold below cost */}
          {(() => {
            const problematicSales = filteredSales.filter(sale => {
              if (sale.status === 'returned') return false;
              const expectedSubtotal = sale.items?.reduce((sum: number, item: any) => sum + ((item as any).subtotal || 0), 0) || 0;
              const expectedTotal = expectedSubtotal + (sale.tax || 0);
              const discountGiven = expectedTotal - (sale.total || 0);
              const totalCost = sale.items?.reduce((sum: number, item: any) => sum + ((item.costPrice || 0) * (item.qty || 0)), 0) || 0;
              const isBelowCost = sale.total < totalCost;
              return discountGiven > 0.01 || isBelowCost;
            });
            
            if (problematicSales.length === 0) return null;
            
            return (
              <div className="bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-500/20 rounded-2xl p-4 shadow-sm flex items-start gap-4">
                <div className="p-2 bg-rose-100 dark:bg-rose-500/20 rounded-xl text-rose-600 dark:text-rose-400">
                  <AlertTriangle size={20} />
                </div>
                <div className="flex-1">
                  <h3 className="text-sm font-bold text-rose-900 dark:text-rose-400 mb-1">{t('alert_sales_below_price' as any) || 'Alert: Sales below expected price or cost'}</h3>
                  <div className="space-y-1 mt-2">
                    {problematicSales.slice(0, 5).map(sale => {
                      const expectedSubtotal = sale.items?.reduce((sum: number, item: any) => sum + ((item as any).subtotal || 0), 0) || 0;
                      const expectedTotal = expectedSubtotal + (sale.tax || 0);
                      const discountGiven = expectedTotal - (sale.total || 0);
                      const totalCost = sale.items?.reduce((sum: number, item: any) => sum + ((item.costPrice || 0) * (item.qty || 0)), 0) || 0;
                      const isBelowCost = sale.total < totalCost;
                      const lossAmount = isBelowCost ? totalCost - sale.total : 0;
                      
                      return (
                        <div key={sale.id} className="text-xs text-rose-700 dark:text-rose-400 flex justify-between items-center bg-surface-main/50 px-3 py-1.5 rounded-lg border border-rose-100/50 dark:border-rose-500/10">
                          <span><span className="font-mono font-bold mr-2">{t('receipt_reference')}: #{sale.id.slice(0,8).toUpperCase()}</span> &bull; {sale.customerName}</span>
                          <span className="font-bold flex items-center gap-1.5">
                            <ArrowDownRight size={12} /> 
                            {isBelowCost ? `SOLD BELOW COST (-$${lossAmount.toFixed(2)})` : `DISCOUNT (-$${discountGiven.toFixed(2)})`}
                          </span>
                        </div>
                      );
                    })}
                    {problematicSales.length > 5 && (
                      <div className="text-xs font-bold text-rose-600 dark:text-rose-400 pt-1 pl-1">
                        ...and {problematicSales.length - 5} more.
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })()}

          <div className="bg-surface-main rounded-2xl shadow-lg border border-border-main overflow-hidden">
            <div className="p-6 border-b border-border-main bg-bg-sec/30 flex justify-between items-center flex-wrap gap-4">
              <div>
                <h3 className="text-lg font-bold text-ink uppercase flex items-center gap-2">
                  <Clock size={20} />
                  {t('sales_history' as any) || 'Sales History'}
                </h3>
                <p className="text-xs text-ink-tertiary">{t('view_past_sales')}</p>
              </div>
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => setShowOnlyDebt(!showOnlyDebt)}
                  className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all flex items-center gap-2 border ${
                    showOnlyDebt 
                      ? 'bg-rose-500 text-white border-rose-500 shadow-lg shadow-rose-500/20' 
                      : 'bg-bg-sec text-ink-tertiary border-border-main hover:bg-bg-main hover:text-ink'
                  }`}
                >
                  <AlertTriangle size={14} className={showOnlyDebt ? 'animate-pulse' : ''} />
                  {t('show_credit_only' as any) || 'Credit Sales'}
                </button>
                <div className="text-right">
                  <span className="text-xs font-bold text-ink-tertiary uppercase tracking-wider block">{t('total_amount')}</span>
                  <div className="text-xl font-bold font-mono text-accent-main">
                    ${(filteredSales.filter(s => s.status !== 'returned').reduce((sum, s) => sum + (s.total || 0), 0) || 0).toFixed(2)}
                  </div>
                </div>
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-bg-sec text-xs font-bold uppercase tracking-[0.1em] text-ink-tertiary border-b border-border-main">
                    <th className="px-8 py-5">{t('receipt_reference')}</th>
                    <th className="px-8 py-5">{t('customer')} & {t('seller')}</th>
                    <th className="px-8 py-5 text-center">{t('total_amount')}</th>
                    <th className="px-8 py-5 text-center">{t('status')} & {t('payment')}</th>
                    <th className="px-8 py-5 text-right">{t('actions')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border-main/50 font-sans">
                  {filteredSales.map((sale, idx) => (
                    <motion.tr 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.03 }}
                      key={sale.id} 
                      className="hover:bg-bg-sec/50 transition-colors group"
                    >
                      <td className="px-8 py-6">
                        <div className="flex flex-col">
                           <span className="font-mono text-sm font-black text-accent-main tracking-tighter bg-accent-soft px-2 py-0.5 rounded border border-accent-main/20 inline-block w-fit">
                             #{sale.id.slice(0, 8).toUpperCase()}
                           </span>
                           {sale.isEdited && (
                             <span className="text-[10px] text-amber-600 font-black uppercase tracking-widest mt-1.5 flex items-center gap-1">
                               <RefreshCw size={10} className="animate-spin-slow" /> {t('edited')}
                             </span>
                           )}
                          <span className="text-[10px] font-black text-ink-tertiary uppercase tracking-widest mt-2 opacity-60">
                            {new Date(sale.createdAt).toLocaleDateString()} • {new Date(sale.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                          {tenant?.isMultiBranch && sale.branchId && (
                            <span className="text-[10px] font-black text-indigo-500 uppercase tracking-widest mt-1 opacity-80">
                              {branches.find(b => b.id === sale.branchId)?.name || 'Unknown Branch'}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <div className="flex flex-col">
                          <span className="font-black text-ink text-lg tracking-tight uppercase italic group-hover:text-accent-main transition-colors">
                            {sale.customerName || t('regular_customer')}
                          </span>
                          <span className="text-xs font-bold text-ink-tertiary mt-1 flex items-center gap-1.5">
                            <span className="w-4 h-4 rounded bg-bg-sec flex items-center justify-center text-[10px] border border-border-main">S</span>
                            {t('seller')}: {sale.sellerName || '-'}
                          </span>
                        </div>
                      </td>
                      <td className="px-8 py-6 text-center">
                        <div className="flex flex-col items-center">
                          <div className="text-xl font-black font-mono text-ink tracking-tighter">
                            ${(sale.total || 0).toLocaleString()}
                          </div>
                          {(() => {
                            if (sale.status === 'returned') return null;
                            const expectedTotal = (sale.items?.reduce((sum: number, item: any) => sum + ((item as any).subtotal || 0), 0) || 0) + (sale.tax || 0);
                            const discountGiven = expectedTotal - (sale.total || 0);
                            const totalCost = sale.items?.reduce((sum: number, item: any) => sum + ((item.costPrice || 0) * (item.qty || 0)), 0) || 0;
                            const isBelowCost = sale.total < totalCost;
                            
                            if (isBelowCost) return <span className="text-[10px] text-rose-600 font-black uppercase tracking-tighter mt-1 bg-rose-50 px-2 py-0.5 rounded border border-rose-100">Loss sale</span>;
                            if (discountGiven > 0.1) return <span className="text-[10px] text-rose-500 font-black uppercase tracking-tighter mt-1">Disc: -${discountGiven.toFixed(2)}</span>;
                            return null;
                          })()}
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <div className="flex flex-col items-center gap-2">
                          <span className={`px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-[0.15em] border shadow-sm ${
                            sale.status === 'paid' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 
                            sale.status === 'partial' ? 'bg-amber-50 text-amber-700 border-amber-200' : 
                            'bg-rose-50 text-rose-700 border-rose-200'
                          }`}>
                            {t(`${sale.status}_status` as any) || sale.status}
                          </span>
                          <div className="flex flex-wrap gap-1.5 justify-center mt-1">
                            {sale.paymentMethods?.map((pm, i) => (
                              pm.amount > 0 ? (
                                <span key={i} className="text-[10px] font-bold text-ink-tertiary bg-bg-sec px-2.5 py-1 rounded-lg border border-border-main/50 shadow-inner">
                                  {pm.method}: <span className="font-mono">${pm.amount.toLocaleString()}</span>
                                </span>
                              ) : null
                            ))}
                            {sale.creditUsed > 0 && (
                              <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200 shadow-inner">
                                Credit: <span className="font-mono">${sale.creditUsed.toLocaleString()}</span>
                              </span>
                            )}
                            {sale.debtAmount > 0 && (
                              <span className="text-[10px] font-bold text-rose-700 bg-rose-50 px-2.5 py-1 rounded-lg border border-rose-200 shadow-inner">
                                Debt: <span className="font-mono">${sale.debtAmount.toLocaleString()}</span>
                              </span>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-6 text-right whitespace-nowrap">
                        <div className="flex justify-end gap-2 transition-all duration-300">
                          <button 
                            onClick={() => { setLastSale(sale); setShowReceipt(true); }}
                            className="p-3 text-ink-tertiary hover:text-accent-main hover:bg-accent-soft rounded-2xl transition-all shadow-sm active:scale-95"
                            title={t('print_receipt')}
                          >
                            <Printer size={20} strokeWidth={2.5} />
                          </button>
                          <button 
                            onClick={() => handleEditSale(sale)}
                            className="p-3 text-ink-tertiary hover:text-blue-600 hover:bg-blue-50 rounded-2xl transition-all shadow-sm active:scale-95"
                            title={t('edit_sale' as any) || 'Edit'}
                          >
                            <Edit2 size={20} strokeWidth={2.5} />
                          </button>
                          <button 
                            onClick={() => setReturnModal({ isOpen: true, sale })} 
                            className="p-3 text-ink-tertiary hover:text-amber-500 hover:bg-amber-50 rounded-2xl transition-all shadow-sm active:scale-95"
                            title={t('return_item')}
                          >
                            <RotateCcw size={20} strokeWidth={2.5} />
                          </button>
                        </div>
                      </td>
                    </motion.tr>
                  ))}
                  {filteredSales.length === 0 && (
                    <tr>
                      <td colSpan={10} className="px-6 py-12 text-center text-ink-tertiary opacity-50">
                        <p className="text-xs uppercase font-bold tracking-widest">{t('no_recent_sales')}</p>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
      </div>
      )}

      {/* Hold Cart Modal */}
      {showHoldModal && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-ink/60 backdrop-blur-sm">
          <div className="bg-surface-main rounded-2xl shadow-xl w-full max-w-sm overflow-hidden p-6 space-y-6 border border-border-main">
            <div className="flex items-center gap-3 text-accent-main">
              <Archive className="w-6 h-6" />
              <h3 className="text-lg font-bold text-ink">{t('hold_cart')}</h3>
            </div>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-ink-tertiary uppercase tracking-wider">{t('customer')}</label>
                <select 
                  className="w-full px-4 py-3 bg-bg-sec border border-border-main rounded-xl focus:outline-none focus:ring-2 focus:ring-accent-main/20 text-ink text-sm outline-none appearance-none"
                  value={selectedCustomerId || ''}
                  onChange={(e) => {
                    const customer = customers.find(c => c.id === e.target.value);
                    if (customer) {
                      setSelectedCustomerId(customer.id);
                      setCustomerName(customer.name);
                      setCustomerPhone(customer.phone);
                      setAvailableCredit(customer.totalCredit || 0);
                    } else {
                      setSelectedCustomerId(null);
                      setCustomerName('');
                      setCustomerPhone('');
                      setAvailableCredit(0);
                    }
                  }}
                >
                  <option value="" className="bg-surface-main">{t('select_customer')}</option>
                  {customers.map(c => <option key={c.id} value={c.id} className="bg-surface-main">{c.name}</option>)}
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-ink-tertiary uppercase tracking-wider">
                  {t('cart_name')} / CRM
                </label>
                <input 
                  type="text"
                  placeholder={t('save_cart_placeholder')}
                  value={holdCartName}
                  onChange={(e) => setHoldCartName(e.target.value)}
                  className="w-full px-4 py-3 bg-bg-sec border border-border-main rounded-xl focus:outline-none focus:ring-2 focus:ring-accent-main/20 text-ink font-bold outline-none placeholder:text-ink-tertiary"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleHoldCart();
                  }}
                  autoFocus
                />
                <p className="text-xs text-ink-tertiary leading-tight">
                  {language === 'so' ? 'Fadlan qor magaca macmiilka ama tixraaca si aad hadhow u soo celiso.' : 'Please enter the customer name or a reference to retrieve this later.'}
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <button 
                onClick={() => setShowHoldModal(false)}
                className="flex-1 px-4 py-3 bg-bg-sec text-ink-secondary rounded-xl font-bold hover:bg-border-main transition-all"
              >
                {t('cancel')}
              </button>
              <button 
                onClick={handleHoldCart}
                className="flex-1 px-4 py-3 bg-accent-main text-white rounded-xl font-bold hover:bg-accent-main/90 transition-all shadow-lg shadow-accent-main/20 dark:shadow-none"
              >
                {t('confirm')}
              </button>
            </div>
          </div>
        </div>
      )}

      {showSavedCarts && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-ink/60 backdrop-blur-sm">
          <div className="bg-surface-main rounded-2xl shadow-xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[80vh] border border-border-main">
            <div className="p-6 border-b border-border-main flex items-center justify-between bg-bg-sec/50">
              <div className="flex items-center gap-3 text-accent-main">
                <Archive className="w-6 h-6" />
                <h3 className="text-lg font-bold text-ink">{t('cart_list')}</h3>
              </div>
              <div className="flex items-center gap-3">
                {savedCarts.length > 1 && (
                  <button 
                    onClick={handlePayAll}
                    disabled={processing}
                    className="px-4 py-2 bg-emerald-600 dark:bg-emerald-500/20 text-white dark:text-emerald-400 text-xs font-bold rounded-xl hover:bg-emerald-700 transition-all flex items-center gap-2 shadow-lg shadow-emerald-500/10 disabled:opacity-50"
                  >
                    <CreditCard className="w-4 h-4" />
                    {t('pay_all')}
                  </button>
                )}
                <button onClick={() => setShowSavedCarts(false)} className="text-ink-tertiary hover:text-ink p-2">
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-6">
              {savedCarts.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-ink-tertiary space-y-4">
                  <Archive size={48} className="opacity-20" />
                  <p>{t('no_saved_carts')}</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {savedCarts.map(sc => (
                    <div key={sc.id} className="p-4 border border-border-main rounded-2xl hover:border-accent-main transition-all group bg-surface-main">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h4 className="font-bold text-ink">{sc.name}</h4>
                          {sc.customerName && (
                            <p className="text-xs text-accent-main font-medium flex items-center gap-1">
                              <User size={10} />
                              {sc.customerName}
                            </p>
                          )}
                          <p className="text-xs text-ink-tertiary">{new Date(sc.createdAt).toLocaleString()}</p>
                        </div>
                           <button 
                          onClick={() => handleDeleteSavedCart(sc.id, sc.dbId)}
                          className="p-1.5 text-ink-tertiary hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-lg transition-all"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                      <div className="space-y-1 mb-4">
                        {sc.items.slice(0, 3).map((item, i) => (
                          <div key={i} className="text-xs text-ink-secondary flex justify-between">
                            <span className="truncate flex-1">{item.item.name}</span>
                            <span className="font-mono ml-2">x{item.qty}</span>
                          </div>
                        ))}
                        {sc.items.length > 3 && (
                          <p className="text-xs text-ink-tertiary italic">+{sc.items.length - 3} more items</p>
                        )}
                      </div>
                      <div className="flex justify-between items-center pt-3 border-t border-border-main gap-2">
                        <span className="font-bold text-accent-main">${sc.items.reduce((sum, i) => sum + ((i.item.price || 0) * i.qty), 0).toFixed(2)}</span>
                        <div className="flex gap-2">
                          <button 
                            onClick={() => handleQuickPay(sc)}
                            disabled={processing}
                            className="px-3 py-1.5 bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400 text-xs font-bold rounded-lg hover:bg-emerald-600 hover:text-white dark:hover:bg-emerald-500 dark:hover:text-white transition-all disabled:opacity-50"
                          >
                            {t('quick_pay')}
                          </button>
                          <button 
                            onClick={() => handleResumeCart(sc)}
                            disabled={processing}
                            className="px-4 py-1.5 bg-accent-main text-white text-xs font-bold rounded-lg hover:bg-accent-main/90 transition-all disabled:opacity-50"
                          >
                            {t('resume_cart')}
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Receipt Modal */}
      <Modal 
        isOpen={showReceipt && !!lastSale && !!tenant} 
        onClose={() => setShowReceipt(false)} 
        title={t('sales_receipt')}
        containerClassName="print:bg-white print:p-0"
        contentClassName="print:shadow-none print:w-full print:max-w-none max-w-md"
      >
        {lastSale && tenant && (
          <div className="p-4 print:p-0 font-sans" id="receipt-content">
            <div className="text-center mb-6">
              {tenant.logoUrl && (
                <img src={tenant.logoUrl} alt="Logo" className="w-20 h-20 object-contain mx-auto mb-4" referrerPolicy="no-referrer" />
              )}
              <h2 className="text-xl font-bold text-ink uppercase tracking-tight">{tenant.name}</h2>
              <div className="flex flex-col items-center gap-1 mt-1">
                <p className="text-[10px] text-ink-tertiary uppercase tracking-widest font-black opacity-60">{t('sales_receipt')}</p>
                <div className={`px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-[0.2em] shadow-sm border ${
                  lastSale.status === 'paid' ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20' :
                  lastSale.status === 'partial' ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20' :
                  'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/20'
                }`}>
                  {t(`${lastSale.status}_status` as any) || lastSale.status}
                </div>
              </div>
              
              <div className="flex items-center justify-center gap-2 mt-2 opacity-60">
                <Clock size={10} />
                <p className="text-xs font-medium">{new Date(lastSale.createdAt).toLocaleString()}</p>
              </div>

              {lastSale.isEdited && (
                <div className="inline-block bg-amber-100 text-amber-700 px-2 py-0.5 rounded text-[10px] font-bold uppercase mt-2">
                  {t('edited')}
                </div>
              )}
              
              <div className="mt-4 p-4 bg-bg-sec rounded-2xl border border-border-main text-left space-y-4">
                <div>
                  <p className="font-black text-[10px] text-ink-tertiary uppercase tracking-widest mb-2 opacity-50">{t('customer' as any) || 'Customer'}</p>
                  <p className="font-black text-sm text-ink uppercase tracking-tight italic">
                    {lastSale.customer_name || lastSale.customerName || t('regular_customer')}
                  </p>
                  {(lastSale.customerPhone || lastSale.phone) && (
                    <p className="text-xs font-mono font-bold text-ink-secondary mt-0.5">
                      {lastSale.customerPhone || lastSale.phone}
                    </p>
                  )}
                </div>

                <div>
                  <p className="font-black text-[10px] text-ink-tertiary uppercase tracking-widest mb-2 opacity-50">{t('payment_info' as any) || 'Payment Info'}</p>
                  <div className="space-y-1.5">
                    {lastSale.paymentMethods ? lastSale.paymentMethods.map((pm: any, i: number) => (
                      <div key={i} className="flex justify-between text-xs font-bold">
                        <span className="text-ink-secondary">{pm.method === 'refund_credit' ? (t('refund_credit' as any) || 'Refunded to Credit') : pm.method === 'refund_cash' ? (t('refund_cash' as any) || 'Refunded (Cash)') : pm.method}</span>
                        <span className={`font-mono ${pm.amount < 0 ? 'text-rose-600' : 'text-ink'}`}>{pm.amount < 0 ? '-' : ''}${Math.abs(pm.amount || 0).toLocaleString()}</span>
                      </div>
                    )) : (lastSale.status === 'debt' ? (
                      <div className="flex items-center gap-2 text-rose-600">
                        <div className="w-2 h-2 rounded-full bg-rose-600 animate-pulse" />
                        <span className="text-xs font-black uppercase tracking-widest">{t('debt')}</span>
                      </div>
                    ) : '-')}
                  </div>
                </div>
              </div>

              <div className="mt-4 text-xs text-ink-tertiary uppercase tracking-wider">
                {t('receipt_reference')}: <span className="text-ink font-mono">#{lastSale.id.slice(0, 8).toUpperCase()}</span>
              </div>
            </div>

            <div className="space-y-3 mb-6">
              {lastSale.items.map((item: any, idx: number) => (
                <div key={idx} className="flex justify-between items-start gap-4 text-sm">
                  <div className="flex-1">
                    <p className="font-bold text-ink">{item.name}</p>
                    <p className="text-xs text-ink-tertiary mt-0.5">
                      {item.qty} × ${(item.price || 0).toLocaleString()}
                    </p>
                  </div>
                  <p className="font-bold text-ink font-mono">${(item.subtotal || 0).toLocaleString()}</p>
                </div>
              ))}
            </div>

            <div className="space-y-2 border-t border-border-main pt-4 mb-6">
              <div className="flex justify-between text-xs text-ink-secondary">
                <span className="uppercase tracking-wider">{t('subtotal')}</span>
                <span className="font-mono">${(lastSale.subtotal || 0).toLocaleString()}</span>
              </div>
              {lastSale.discount > 0 && (
                <div className="flex justify-between text-xs text-rose-500">
                  <span className="uppercase tracking-wider">{t('discount')}</span>
                  <span className="font-mono">-${(lastSale.discount || 0).toLocaleString()}</span>
                </div>
              )}
              <div className="flex justify-between text-xs text-ink-secondary">
                <span className="uppercase tracking-wider">{t('tax')}</span>
                <span className="font-mono">${(lastSale.tax || 0).toLocaleString()}</span>
              </div>
              <div className="flex justify-between pt-2 text-ink">
                <span className="text-sm font-bold uppercase tracking-wider">{t('total_amount')}</span>
                <span className="text-xl font-bold text-accent-main font-mono">${(lastSale.total || 0).toLocaleString()}</span>
              </div>
              {lastSale.creditUsed > 0 && (
                <div className="flex justify-between text-xs font-bold text-emerald-600 uppercase">
                  <span>{t('use_credit')}</span>
                  <span className="font-mono">-${(lastSale.creditUsed || 0).toLocaleString()}</span>
                </div>
              )}
              {(lastSale.status === 'partial' || lastSale.status === 'debt') && (
                <div className="pt-4 space-y-2 border-t-2 border-dashed border-border-main mt-4">
                  {lastSale.paidAmount > 0 && (
                    <div className="flex justify-between text-xs text-emerald-600 font-black uppercase tracking-widest">
                      <span>{t('paid')}</span>
                      <span className="font-mono bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">${(lastSale.paidAmount || 0).toLocaleString()}</span>
                    </div>
                  )}
                  <div className="flex justify-between items-center p-3 bg-rose-50 border-2 border-rose-100 rounded-xl">
                    <span className="text-xs text-rose-700 font-black uppercase tracking-[0.1em]">
                      {lastSale.status === 'debt' ? t('debt') : (t('remaining_debt' as any) || 'Remaining Debt')}
                    </span>
                    <span className="text-lg font-black text-rose-600 font-mono italic">
                      ${(lastSale.debtAmount || 0).toLocaleString()}
                    </span>
                  </div>
                </div>
              )}
            </div>

            {tenant?.paymentNumbers && typeof tenant.paymentNumbers === 'object' && (
              <div className="mb-6 p-4 bg-bg-sec rounded-xl border border-border-main text-center">
                <h4 className="text-xs font-bold text-ink uppercase tracking-wider mb-2">{t('payment_numbers')}</h4>
                <div className="grid grid-cols-2 gap-2">
                  {(tenant.paymentNumbers as any)?.evc && (
                    <div className="p-1">
                      <span className="block text-[10px] text-ink-tertiary uppercase">EVC</span>
                      <span className="text-xs text-ink font-bold font-mono">{(tenant.paymentNumbers as any).evc}</span>
                    </div>
                  )}
                  {(tenant.paymentNumbers as any)?.edahab && (
                    <div className="p-1">
                      <span className="block text-[10px] text-ink-tertiary uppercase">eDahab</span>
                      <span className="text-xs text-ink font-bold font-mono">{(tenant.paymentNumbers as any).edahab}</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            <div className="text-center mb-6">
               <p className="text-sm font-bold text-ink">{t('thank_you_message')}</p>
               <p className="text-xs text-ink-tertiary mt-1">{t('come_again_message')}</p>
            </div>

            <div className="flex flex-col gap-2 print:hidden">
              <button 
                onClick={() => downloadInvoicePDF(lastSale)}
                className="w-full px-4 py-3 bg-accent-main text-white rounded-xl font-bold uppercase text-xs hover:bg-accent-main/90 transition-all flex items-center justify-center gap-2 shadow-lg"
              >
                <FileDown size={16} />
                {t('download_pdf' as any) || 'Download PDF'}
              </button>
              <div className="flex gap-2">
                <button 
                  onClick={() => {
                    setShowReceipt(false);
                    setLastSale(null);
                  }} 
                  className="flex-1 px-4 py-3 bg-bg-sec text-ink-secondary rounded-xl font-bold uppercase text-xs hover:bg-border-main transition-all"
                >
                  {t('close')}
                </button>
                <button 
                  onClick={() => window.print()} 
                  className="flex-1 px-4 py-3 bg-ink text-white rounded-xl font-bold uppercase text-xs hover:bg-ink/90 transition-all flex items-center justify-center gap-2 shadow-lg"
                >
                  <Printer size={16} />
                  {t('print')}
                </button>
              </div>
              <button 
                onClick={() => {
                  const itemsList = lastSale.items.map((i: any) => `${i.name} (${i.qty}x)`).join(', ');
                  const message = t('whatsapp_receipt_message')
                    .replace('{businessName}', tenant?.name || '')
                    .replace('{ref}', lastSale.id.slice(0, 8).toUpperCase())
                    .replace('{items}', itemsList)
                    .replace('{total}', (lastSale.total || 0).toFixed(2));
                  window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
                }}
                className="w-full px-4 py-3 bg-emerald-600 text-white rounded-xl font-bold uppercase text-xs hover:bg-emerald-700 transition-all flex items-center justify-center gap-2 shadow-lg"
              >
                <MessageCircle size={16} />
                {t('send_whatsapp')}
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
