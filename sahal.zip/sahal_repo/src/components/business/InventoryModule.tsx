import React, { useState, useEffect } from 'react';
import { supabase } from '../../supabase';
import { InventoryItem, UserProfile, Sale, Tenant, Branch } from '../../types';
import { Plus, Search, Edit2, Trash2, AlertTriangle, Package, TrendingUp, DollarSign, ArrowUpRight, RefreshCw, TrendingDown, FileDown, Table, History, Printer, AlertCircle, Tag, ArrowRight, PlusCircle } from 'lucide-react';
import { useLanguage } from '../LanguageContext';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { logStockChange } from '../../services/stockService';
import DateSelector from '../DateSelector';
import { filterByDate } from '../../lib/dateUtils';
import Modal from '../Modal';
import { motion, AnimatePresence } from 'motion/react';

export default function InventoryModule({ 
  user,
  initialSearch = '',
  onSearchCleared
}: { 
  user: UserProfile,
  initialSearch?: string,
  onSearchCleared?: () => void
}) {
  const { t } = useLanguage();
  const [tenant, setTenant] = useState<Tenant | null>(null);
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [historyLogs, setHistoryLogs] = useState<any[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [selectedBranchFilter, setSelectedBranchFilter] = useState<string>(user.branchId || 'All');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [dateMode, setDateMode] = useState<'day' | 'month' | 'year' | 'range'>('day');
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isBulkOfferModalOpen, setIsBulkOfferModalOpen] = useState(false);
  const [bulkOfferValue, setBulkOfferValue] = useState('');
  const [bulkOfferType, setBulkOfferType] = useState<'percentage' | 'fixed'>('percentage');
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
  const [isBranchModalOpen, setIsBranchModalOpen] = useState(false);
  const [newBranchName, setNewBranchName] = useState('');
  const [newBranchLocation, setNewBranchLocation] = useState('');
  const [selectedHistoryItem, setSelectedHistoryItem] = useState<InventoryItem | null>(null);
  const [sortConfig, setSortConfig] = useState<{ key: string, direction: 'asc' | 'desc' } | null>(null);

  const getBase64ImageFromURL = (url: string): Promise<string> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.setAttribute('crossOrigin', 'anonymous');
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0);
        const dataURL = canvas.toDataURL('image/png');
        resolve(dataURL);
      };
      img.onerror = (error) => reject(error);
      img.src = url;
    });
  };

  const fetchHistory = async (item: InventoryItem | null = null) => {
    if (!user.tenantId) return;
    
    setSelectedHistoryItem(item);
    
    let query = supabase
      .from('stock_logs')
      .select('*')
      .eq('tenant_id', user.tenantId);
    
    if (user.branchId) query = query.eq('branch_id', user.branchId);

    query = query.order('timestamp', { ascending: false })
      .limit(10000);
      
    if (item) {
      query = query.eq('item_id', item.id);
    }
      
    const { data: logs, error } = await query;
    
    if (logs) {
      setHistoryLogs(logs);
      setIsHistoryModalOpen(true);
    }
  };

  const openConfirm = (title: string, message: string, onConfirm: () => void) => {
    setConfirmModal({
      isOpen: true,
      title,
      message,
      onConfirm: () => {
        onConfirm();
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const handleLogStockChange = async (itemId: string, itemName: string, change: number, reason: string) => {
    if (!user.tenantId) return;
    await logStockChange(user.tenantId, itemId, itemName, change, reason, user.branchId);
    // Refetch logs to update calculations
    let logsQuery = supabase
      .from('stock_logs')
      .select('*')
      .eq('tenant_id', user.tenantId);
    if (user.branchId) logsQuery = logsQuery.eq('branch_id', user.branchId);
    
    const { data: logsData } = await logsQuery
      .order('timestamp', { ascending: false })
      .limit(10000);
    setHistoryLogs(logsData || []);
  };

  const handleStockPayment = async (amount: number, method: string, description: string) => {
    if (!user.tenantId || amount <= 0) return;
    
    // Find or create account
    let accQuery = supabase.from('accounts').select('*').eq('tenant_id', user.tenantId);
    if (user.branchId) accQuery = accQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
    let { data: accs } = await accQuery.eq('name', method);
    
    let accData = accs?.[0];
    
    if (!accData) {
      const { data: newAcc } = await supabase
        .from('accounts')
        .insert({ 
          name: method, 
          balance: -amount, 
          tenant_id: user.tenantId,
          branch_id: user.branchId || null
        })
        .select()
        .single();
      accData = newAcc;
    } else {
      await supabase
        .from('accounts')
        .update({ balance: accData.balance - amount })
        .eq('id', accData.id);
    }

    // Log Transaction
    if (accData) {
      await supabase.from('account_transactions').insert({
        from_account_id: accData.id,
        amount: amount,
        type: 'expense',
        description: description,
        tenant_id: user.tenantId,
        branch_id: user.branchId || null,
        created_at: new Date().toISOString()
      });
    }
  };

  const RenderConfirmModal = () => (
    <Modal 
      isOpen={confirmModal.isOpen} 
      onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))} 
      title={confirmModal.title}
      contentClassName="max-w-sm"
    >
      <div className="space-y-6">
        <div className="flex items-center gap-4 p-4 bg-rose-50 rounded-2xl text-rose-600">
          <Trash2 size={24} />
          <p className="text-sm font-medium">{confirmModal.message}</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
            className="flex-1 px-4 py-2 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 transition-all"
          >
            {t('cancel')}
          </button>
          <button 
            onClick={confirmModal.onConfirm}
            className="flex-1 px-4 py-2 bg-rose-600 text-white rounded-xl font-bold hover:bg-rose-700 transition-all shadow-lg shadow-rose-200"
          >
            {t('delete')}
          </button>
        </div>
      </div>
    </Modal>
  );

  const [formData, setFormData] = useState({
    name: '',
    sku: '',
    quantity: 0,
    costPrice: 0,
    price: 0,
    minStock: 5,
    category: '',
    imageUrl: '',
    paymentMethod: 'Cash',
    discountPercentage: 0,
    offerPrice: 0,
    branchId: ''
  });

  const fetchInventory = async () => {
    if (!user.tenantId) return;
    setLoading(true);
    try {
      const { data: tenantData } = await supabase
        .from('tenants')
        .select('*')
        .eq('id', user.tenantId)
        .single();
        
      if (tenantData) {
        setTenant({
          ...tenantData,
          isMultiBranch: tenantData.is_multi_branch,
          paymentNumbers: tenantData.payment_numbers
        });
        
        if (tenantData.is_multi_branch) {
          const { data: branchesData } = await supabase.from('branches').select('*').eq('tenant_id', user.tenantId);
          if (branchesData) {
            setBranches(branchesData);
          }
        }
        
        let query = supabase.from('inventory').select('*').eq('tenant_id', user.tenantId);
        if (user.branchId) {
            query = query.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
        }
        
        const { data: invData } = await query;
        if (invData) {
          setItems(invData.map(item => ({
            id: item.id,
            name: item.name,
            sku: item.sku,
            quantity: item.quantity,
            costPrice: item.cost_price,
            price: item.price,
            minStock: item.min_stock,
            category: item.category,
            imageUrl: item.image_url,
            tenantId: item.tenant_id,
            branchId: item.branch_id,
            createdAt: item.created_at,
            discountPercentage: item.discount_percentage,
            offerPrice: item.offer_price
          })));
        } else {
          setItems([]);
        }

        let logsQuery = supabase
          .from('stock_logs')
          .select('*')
          .eq('tenant_id', user.tenantId);
        if (user.branchId) logsQuery = logsQuery.eq('branch_id', user.branchId);
        
        const { data: logsData } = await logsQuery
          .order('timestamp', { ascending: false })
          .limit(10000);
        setHistoryLogs(logsData || []);

        let salesQuery = supabase.from('sales').select('*').eq('tenant_id', user.tenantId);
        if (user.branchId) {
            salesQuery = salesQuery.eq('branch_id', user.branchId);
        }
        const { data: salesData } = await salesQuery;
        setSales(salesData || []);

        let accQuery = supabase.from('accounts').select('*').eq('tenant_id', user.tenantId);
        if (user.branchId) accQuery = accQuery.or(`branch_id.eq.${user.branchId},branch_id.is.null`);
        const { data: accData } = await accQuery;
        setAccounts(accData || []);
      }
    } catch (error) {
      console.error("Error fetching inventory:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInventory();
  }, [user.tenantId]);

  useEffect(() => {
    if (initialSearch) {
      setSearchTerm(initialSearch);
      onSearchCleared?.();
    }
  }, [initialSearch]);

  const compressImage = async (file: File): Promise<Blob> => {
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error("Compression timeout")), 10000);
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          clearTimeout(timeout);
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          const maxDim = 800;
          if (width > height && width > maxDim) {
            height = (height * maxDim) / width;
            width = maxDim;
          } else if (height > maxDim) {
            width = (width * maxDim) / height;
            height = maxDim;
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          canvas.toBlob((blob) => {
            if (blob) resolve(blob);
            else reject(new Error("Blob creation failed"));
          }, 'image/jpeg', 0.8);
        };
        img.onerror = () => {
          clearTimeout(timeout);
          reject(new Error("Image loading failed"));
        };
        img.src = e.target?.result as string;
      };
      reader.onerror = () => {
        clearTimeout(timeout);
        reject(new Error("File reading failed"));
      };
      reader.readAsDataURL(file);
    });
  };

  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.tenantId) {
      alert("Cillad: Ma jiro Tenant ID. Fadlan dib u soco (refresh).");
      return;
    }
    if (submitting) return;
    
    setSubmitting(true);
    setStatusMessage("Keydinuhu waa bilaawday...");
    
    try {
      let finalImageUrl = formData.imageUrl;
      if (selectedFile) {
        setStatusMessage("Sawirka ayaa la diyaarinayaa (compressing)...");
        try {
          const compressed = await compressImage(selectedFile);
          setStatusMessage("Sawirka ayaa loo gudbinayaa server-ka (uploading)...");
          const fileName = `${Date.now()}_${selectedFile.name.replace(/[^a-zA-Z0-9.]/g, '_')}`;
          const filePath = `tenants/${user.tenantId}/${fileName}`;
          const { error: uploadError } = await supabase.storage
            .from('app-images')
            .upload(filePath, compressed, {
              contentType: 'image/jpeg',
              cacheControl: '3600',
              upsert: true
            });
          if (uploadError) {
            if (uploadError.message.includes('Bucket not found')) {
              throw new Error('Bucket "app-images" lama helin. Fadlan orodshii SQL-ka dashboard-ka lagugu siiyay.');
            }
            throw uploadError;
          }
          const { data: { publicUrl } } = supabase.storage.from('app-images').getPublicUrl(filePath);
          finalImageUrl = publicUrl;
        } catch (imgErr: any) {
          console.error("Image upload error:", imgErr);
          alert("Garasho sawirka laguma guulaysan: " + imgErr.message);
          setSubmitting(false);
          setStatusMessage(null);
          return;
        }
      }

      setStatusMessage("Xogta ayaa la keydinayaa (saving to database)...");
      const dbData: any = {
        name: formData.name,
        sku: formData.sku,
        quantity: formData.quantity,
        cost_price: formData.costPrice,
        price: formData.price,
        min_stock: formData.minStock,
        category: formData.category,
        image_url: finalImageUrl,
        discount_percentage: formData.discountPercentage,
        offer_price: formData.offerPrice
      };

      if (tenant?.isMultiBranch) {
        dbData.branch_id = formData.branchId || null;
      }

      if (editingItem) {
        const change = formData.quantity - editingItem.quantity;
        const { error: updateError } = await supabase.from('inventory').update(dbData).eq('id', editingItem.id);
        if (updateError) throw updateError;
        

        
        // If stock increased, handle payment for the new stock
        if (change > 0 && formData.costPrice > 0) {
          setStatusMessage("Lacag bixinta saamiga (stock payment) ayaa la keydinayaa...");
          const totalCost = change * formData.costPrice;
          await handleStockPayment(totalCost, formData.paymentMethod, `Stock increase: ${formData.name} (+${change})`);
        }
        
        if (change !== 0) {
          const reason = change > 0 ? 'restock' : 'manual_reduction';
          await handleLogStockChange(editingItem.id, formData.name, change, reason);
        }
      } else {
        const { data, error } = await supabase.from('inventory').insert({
          ...dbData,
          tenant_id: user.tenantId,
          created_at: new Date().toISOString()
        }).select().single();
        
        if (error) throw error;
        
        // Handle payment for initial stock
        if (formData.quantity > 0 && formData.costPrice > 0) {
          setStatusMessage("Lacag bixinta bilowga ah (initial payment) ayaa la keydinayaa...");
          const totalCost = formData.quantity * formData.costPrice;
          await handleStockPayment(totalCost, formData.paymentMethod, `Initial stock: ${formData.name} (${formData.quantity})`);
        }
        
        await handleLogStockChange(data.id, formData.name, formData.quantity, 'initial_stock');
      }

      setStatusMessage("Guul! Waa la keydiyay.");
      setTimeout(() => {
        setIsModalOpen(false);
        setEditingItem(null);
        setSelectedFile(null);
        setFormData({ 
          name: '', 
          sku: '', 
          quantity: 0, 
          costPrice: 0, 
          price: 0, 
          minStock: 5, 
          category: '',
          imageUrl: '', 
          offerPrice: 0, 
          discountPercentage: 0, 
          paymentMethod: 'Cash',
          branchId: ''
        });
        setStatusMessage(null);
        fetchInventory();
      }, 500);
    } catch (error: any) {
      console.error("Error saving item:", error);
      alert("Cillad keydinta: " + (error.message || "Unknown error"));
      setStatusMessage("Cillad: " + (error.message || "Unknown error"));
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!user.tenantId) return;
    openConfirm(t('delete'), t('delete_product_confirm'), async () => {
      try {
        const item = items.find(i => i.id === id);
        const { error: deleteError } = await supabase.from('inventory').delete().eq('id', id);
        if (deleteError) throw deleteError;
        
        if (item) {
          await handleLogStockChange(id, item.name, -item.quantity, 'item_deleted');
        }
        fetchInventory();
      } catch (error: any) {
        console.error("Error deleting item:", error);
        if (error.message && error.message.includes('foreign key')) {
          alert('Badeecadan waa la iibiyay horay, markaa lama tirtiri karo si aanay xisaabta u khaldamin. Fadlan tirada (Quantity) ka dhig 0 si ay u qarsoonto.');
        } else {
          alert(error.message || 'Cilad ayaa dhacday, lama tirtiri karo.');
        }
      }
    });
  };

  const openEdit = (item: InventoryItem) => {
    setEditingItem(item);
    setSelectedFile(null);
    setFormData({
      name: item.name || '',
      sku: item.sku || '',
      quantity: item.quantity || 0,
      costPrice: item.costPrice || 0,
      price: item.price || 0,
      minStock: item.minStock || 0,
      category: item.category || '',
      imageUrl: item.imageUrl || '',
      paymentMethod: 'Cash',
      discountPercentage: item.discountPercentage || 0,
      offerPrice: item.offerPrice || 0,
      branchId: item.branchId || ''
    });
    setIsModalOpen(true);
  };

  const handleBulkOffer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.tenantId || submitting) return;
    setSubmitting(true);

    try {
      const val = parseFloat(bulkOfferValue) || 0;
      let query = supabase.from('inventory').update(bulkOfferType === 'percentage' ? { discount_percentage: val, offer_price: 0 } : { offer_price: val, discount_percentage: 0 }).eq('tenant_id', user.tenantId);
      if (user.branchId) query = query.eq('branch_id', user.branchId);
      
      const { error: bulkError } = await query;
      if (bulkError) throw bulkError;
      
      setIsBulkOfferModalOpen(false);
      setBulkOfferValue('');
      fetchInventory();
    } catch (error) {
      console.error("Error applying bulk offer:", error);
    } finally {
      setSubmitting(false);
    }
  };

  const handleCreateBranch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.tenantId || !newBranchName.trim() || submitting) return;
    setSubmitting(true);
    try {
      const { data, error } = await supabase.from('branches').insert({
        tenant_id: user.tenantId,
        name: newBranchName,
        location: newBranchLocation
      }).select().single();
      if (error) throw error;
      if (data) {
        setBranches([...branches, data]);
      }
      setIsBranchModalOpen(false);
      setNewBranchName('');
      setNewBranchLocation('');
    } catch (error) {
      console.error("Error creating branch:", error);
    } finally {
      setSubmitting(false);
    }
  };

  const getClosingDate = () => {
    const date = new Date(selectedDate);
    if (dateMode === 'day') date.setHours(23, 59, 59, 999);
    else if (dateMode === 'month') { date.setMonth(date.getMonth() + 1, 0); date.setHours(23, 59, 59, 999); }
    else if (dateMode === 'year') { date.setMonth(11, 31); date.setHours(23, 59, 59, 999); }
    else if (dateMode === 'range' && endDate) { const end = new Date(endDate); end.setHours(23, 59, 59, 999); return end; }
    return date;
  };

  const closingDate = getClosingDate();
  const isHistorical = closingDate < new Date();

  const filteredItems = items.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          item.sku.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'All' || item.category === categoryFilter;
    const matchesBranch = selectedBranchFilter === 'All' || item.branchId === selectedBranchFilter;
    
    const itemExisted = !isHistorical || !(item as any).createdAt || new Date((item as any).createdAt) <= closingDate;
    
    return matchesSearch && matchesCategory && matchesBranch && itemExisted;
  }).sort((a, b) => new Date((b as any).createdAt || 0).getTime() - new Date((a as any).createdAt || 0).getTime());

  const uniqueCategories = React.useMemo(() => {
    const cats = items.map(item => item.category).filter(Boolean) as string[];
    return ['All', ...Array.from(new Set(cats))];
  }, [items]);

  const downloadPDF = async () => {
    let doc: any;
    try {
      doc = new jsPDF();
    } catch (e) {
      console.error("Error creating PDF:", e);
      return;
    }
    const businessName = tenant?.name || t('business_name_placeholder');
    const location = tenant?.location || '';
    const contact = tenant?.contact || '';
    
    // Header
    let yPos = 20;

    // Logo
    if (tenant?.logoUrl) {
      try {
        const base64 = await getBase64ImageFromURL(tenant.logoUrl);
        doc.addImage(base64, 'PNG', 165, 10, 30, 30);
      } catch (e) {
        console.warn('Could not load logo for PDF:', e);
      }
    }
    
    doc.setFontSize(20);
    doc.setTextColor(79, 70, 229); // Indigo-600
    doc.text(businessName, 14, yPos);
    yPos += 8;

    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139); // Slate-500
    if (location) {
      doc.text(location, 14, yPos);
      yPos += 5;
    }
    if (contact) {
      doc.text(contact, 14, yPos);
      yPos += 5;
    }
    
    yPos += 2;
    doc.setFontSize(12);
    doc.text(`${t('inventory_report')} (${new Date().toLocaleDateString()})`, 14, yPos);
    yPos += 10;

    const tableColumn = [t('product_name'), t('sku_barcode'), t('cost_price'), t('selling_price'), t('stock_remaining')];
    const tableRows: any[] = [];

    filteredItems.forEach(item => {
      const rowData = [
        item.name,
        item.sku,
        `$${(item.costPrice || 0).toFixed(2)}`,
        `$${(item.price || 0).toFixed(2)}`,
        item.quantity
      ];
      tableRows.push(rowData);
    });

    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: yPos,
      theme: 'grid',
      styles: { fontSize: 8, cellPadding: 3 },
      headStyles: { fillColor: [79, 70, 229], textColor: [255, 255, 255], fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [248, 250, 252] }
    });

    doc.save(`${businessName}_inventory_report_${new Date().toLocaleDateString().replace(/\//g, '-')}.pdf`);
  };

  const downloadExcel = () => {
    const businessName = tenant?.name || t('business_name_placeholder');
    const location = tenant?.location || '';
    const contact = tenant?.contact || '';

    // Create header rows
    const headerRows = [
      [businessName],
      [location],
      [contact],
      [`${t('inventory_report')} (${new Date().toLocaleDateString()})`],
      [] // Empty row
    ];

    const dataRows = filteredItems.map(item => [
      item.name,
      item.sku,
      item.costPrice,
      item.price,
      item.quantity
    ]);

    const tableHeader = [t('product_name'), t('sku_barcode'), t('cost_price'), t('selling_price'), t('stock_remaining')];
    
    const allRows = [...headerRows, tableHeader, ...dataRows];
    const worksheet = XLSX.utils.aoa_to_sheet(allRows);
    
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Inventory");
    XLSX.writeFile(workbook, `${businessName}_inventory_report_${new Date().toLocaleDateString().replace(/\//g, '-')}.xlsx`);
  };

  const branchFilteredStatsItems = items.filter(item => selectedBranchFilter === 'All' || item.branchId === selectedBranchFilter);

  const getHistoricalStock = (item: any, date: Date) => {
    if (item.createdAt && new Date(item.createdAt) > date) return 0;
    
    // 1. Get changes from stock_logs
    let changesAfter = historyLogs
      .filter(log => (log.item_id === item.id || log.itemId === item.id) && new Date(log.timestamp || log.created_at) > date)
      .reduce((sum, log) => sum + (Number(log.change) || 0), 0);
      
    // 2. Fallback to sales table for older records not in stock_logs
    const oldestLogDate = historyLogs.length > 0 
      ? new Date(Math.min(...historyLogs.map(l => new Date(l.timestamp || l.created_at).getTime())))
      : new Date();
      
    const salesAfter = sales.filter(sale => {
      const saleDate = new Date(sale.created_at || sale.createdAt);
      return saleDate > date && (historyLogs.length === 0 || saleDate < oldestLogDate);
    });
    
    salesAfter.forEach(sale => {
      const saleItem = sale.items?.find((i: any) => i.id === item.id);
      if (saleItem) {
        changesAfter -= saleItem.qty; // Sales reduce stock, so they are negative changes
      }
    });

    return Math.max(0, item.quantity - changesAfter);
  };

  const historicalStats = branchFilteredStatsItems.reduce((acc, item) => {
    const qty = getHistoricalStock(item, closingDate);
    const itemExisted = !(item as any).createdAt || new Date((item as any).createdAt) <= closingDate;
    
    if (itemExisted) {
      acc.totalItems += 1;
      acc.totalValue += qty * (item.costPrice || 0);
      acc.expectedRevenue += qty * (item.price || 0);
      if (qty <= item.minStock) {
        acc.lowStockItems += 1;
      }
    }
    return acc;
  }, { totalItems: 0, totalValue: 0, expectedRevenue: 0, lowStockItems: 0 });

  const totalItems = isHistorical ? historicalStats.totalItems : branchFilteredStatsItems.length;
  const totalValue = isHistorical ? historicalStats.totalValue : branchFilteredStatsItems.reduce((sum, item) => sum + (item.quantity * (item.costPrice || 0)), 0);
  const totalExpectedRevenue = isHistorical ? historicalStats.expectedRevenue : branchFilteredStatsItems.reduce((sum, item) => sum + (item.quantity * item.price), 0);
  const lowStockItems = isHistorical ? historicalStats.lowStockItems : branchFilteredStatsItems.filter(i => i.quantity <= i.minStock).length;

  const historicalTotalValue = historicalStats.totalValue;

  // Product Performance Logic
  const filteredSalesForPerformance = sales.filter(s => filterByDate(s.createdAt || (s as any).created_at, selectedDate, dateMode, startDate, endDate));
  
  const productSales = filteredSalesForPerformance.reduce((acc, sale) => {
    sale.items.forEach(item => {
      // support legacy items without type
      const isProduct = item.type === 'product' || !item.type; 
      if (isProduct) {
        acc[item.id] = (acc[item.id] || 0) + (item.qty || item.quantity || 0);
      }
    });
    return acc;
  }, {} as Record<string, number>);

  const filteredLogsForIn = historyLogs.filter(log => filterByDate(log.timestamp || log.created_at, selectedDate, dateMode, startDate, endDate) && log.change > 0);
  const productIn = filteredLogsForIn.reduce((acc, log) => {
    const itemId = log.item_id || log.itemId;
    if (itemId) {
      acc[itemId] = (acc[itemId] || 0) + Number(log.change);
    }
    return acc;
  }, {} as Record<string, number>);

  const filteredLogsForOut = historyLogs.filter(log => filterByDate(log.timestamp || log.created_at, selectedDate, dateMode, startDate, endDate) && log.change < 0);
  const productOut = filteredLogsForOut.reduce((acc, log) => {
    const itemId = log.item_id || log.itemId;
    if (itemId) {
      acc[itemId] = (acc[itemId] || 0) + Math.abs(Number(log.change));
    }
    return acc;
  }, {} as Record<string, number>);

  const performanceData = items.map(item => ({
    ...item,
    unitsSold: productSales[item.id] || 0,
    unitsAdded: productIn[item.id] || 0
  })).sort((a, b) => b.unitsSold - a.unitsSold);

  const topSelling = performanceData.slice(0, 10);
  const leastSelling = [...performanceData].filter(i => i.unitsSold > 0).reverse().slice(0, 5);

  if (loading) return <div className="p-8 text-center text-ink-secondary">{t('loading')}</div>;

  const handleSort = (key: string) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const sortedItems = [...filteredItems].sort((a, b) => {
    if (!sortConfig) return 0;
    
    let aValue: any = a[sortConfig.key as keyof InventoryItem];
    let bValue: any = b[sortConfig.key as keyof InventoryItem];

    if (sortConfig.key === 'units_sold') {
      aValue = productSales[a.id] || 0;
      bValue = productSales[b.id] || 0;
    }

    if (sortConfig.key === 'net_profit') {
      aValue = a.price - (a.costPrice || 0);
      bValue = b.price - (b.costPrice || 0);
    }

    if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
    if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
    return 0;
  });

  return (
    <div className="space-y-8 pb-12 text-ink">
      <RenderConfirmModal />
      
      {/* Header Section */}
      <div className="bg-surface-main p-8 rounded-[2.5rem] border border-border-main shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-accent-soft rounded-full -mr-32 -mt-32 opacity-50 blur-3xl" />
        <div className="relative z-10 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8">
          <div className="flex items-center gap-5">
            <div className="w-16 h-16 bg-accent-main rounded-2xl flex items-center justify-center text-white shadow-xl shadow-accent-soft">
              <Package className="w-[var(--icon-lg)] h-[var(--icon-lg)]" />
            </div>
            <div>
              <h2 className="text-3xl font-display font-bold text-ink tracking-tight">{t('inventory_title')}</h2>
              <p className="text-ink-secondary font-medium mt-1">{t('manage_stock_and_products' as any) || 'Manage stock and products'}</p>
            </div>
          </div>
          
          <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
            <div className="relative flex-1 lg:flex-none lg:min-w-[300px]">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-ink-tertiary" size={18} />
              <input
                type="text"
                placeholder={t('search_inventory')}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-3.5 bg-bg-sec border border-border-main rounded-xl focus:outline-none focus:ring-2 focus:ring-accent-main/20 focus:border-accent-main transition-all font-medium text-ink"
              />
            </div>
            <div className="flex items-center gap-2">
              {tenant?.isMultiBranch && branches.length > 0 && (
                <select
                  value={selectedBranchFilter}
                  onChange={e => setSelectedBranchFilter(e.target.value)}
                  disabled={!!user.branchId}
                  className={`bg-bg-sec border border-border-main text-ink-secondary px-5 py-3.5 rounded-xl font-bold shadow-sm focus:outline-none focus:border-accent-main transition-all text-sm h-full ${!!user.branchId ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  <option value="All">{t('all_branches' as any) || 'All Branches'}</option>
                  {branches.map(b => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </select>
              )}
              {tenant?.isMultiBranch && !user.isStaff && (
                <button
                  onClick={() => setIsBranchModalOpen(true)}
                  className="bg-indigo-50 border border-indigo-200 text-indigo-700 px-5 py-3.5 rounded-xl font-bold shadow-sm hover:bg-indigo-100 transition-all flex items-center gap-2 text-sm"
                >
                  <Plus className="w-[var(--icon-md)] h-[var(--icon-md)]" />
                  <span className="hidden sm:inline">{t('add_branch' as any) || 'Add Branch'}</span>
                </button>
              )}
              <button 
                onClick={() => fetchHistory(null)}
                className="bg-indigo-600 text-white px-5 py-3.5 rounded-xl font-bold shadow-lg shadow-indigo-500/20 hover:bg-indigo-700 transition-all flex items-center gap-2 text-sm"
              >
                <History className="w-[var(--icon-md)] h-[var(--icon-md)]" />
                <span className="hidden sm:inline">{t('inventory_history')}</span>
              </button>
              <button 
                onClick={() => setIsBulkOfferModalOpen(true)}
                className="bg-amber-500 text-white px-5 py-3.5 rounded-xl font-bold shadow-lg shadow-amber-500/20 hover:bg-amber-600 transition-all flex items-center gap-2 text-sm"
              >
                <Tag className="w-[var(--icon-md)] h-[var(--icon-md)]" />
                <span className="hidden sm:inline">{t('apply_bulk_offer')}</span>
              </button>
              <button 
                onClick={() => {
                  setEditingItem(null);
                  setSelectedFile(null);
                  setFormData({ 
                    name: '', 
                    sku: '', 
                    quantity: 0, 
                    costPrice: 0, 
                    price: 0, 
                    minStock: 5, 
                    category: '', 
                    imageUrl: '', 
                    paymentMethod: 'Cash', 
                    discountPercentage: 0, 
                    offerPrice: 0, 
                    branchId: user.branchId || '' 
                  });
                  setIsModalOpen(true);
                }}
                className="bg-accent-main text-white px-5 py-3.5 rounded-xl font-bold shadow-lg shadow-accent-soft hover:bg-accent-hover transition-all flex items-center gap-2 text-sm"
              >
                <Plus className="w-[var(--icon-md)] h-[var(--icon-md)]" />
                <span className="hidden sm:inline">{t('add_product')}</span>
              </button>
              <button 
                onClick={fetchInventory}
                disabled={loading}
                className="p-3.5 bg-surface-main border border-border-main text-ink-secondary rounded-xl hover:bg-bg-sec transition-all shadow-sm flex items-center justify-center"
                title={t('refresh')}
              >
                <RefreshCw className={`w-[var(--icon-md)] h-[var(--icon-md)] ${loading ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-8">
        <div className="bg-surface-main p-5 sm:p-8 rounded-3xl shadow-sm border border-border-main hover:shadow-md transition-all group flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-indigo-600 text-white rounded-2xl group-hover:scale-110 transition-transform shadow-lg shadow-indigo-100">
              <Package size={24} />
            </div>
          </div>
          <div>
            <h3 className="font-bold text-ink-tertiary uppercase tracking-widest text-[8px] sm:text-[10px] mb-2">{t('product_count')}</h3>
            <div className="text-2xl sm:text-3xl font-display font-bold text-ink tracking-tight">{isHistorical ? historicalStats.totalItems : totalItems}</div>
          </div>
        </div>

        <div className="bg-surface-main p-5 sm:p-8 rounded-3xl shadow-sm border border-border-main hover:shadow-md transition-all group flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-emerald-600 text-white rounded-2xl group-hover:scale-110 transition-transform shadow-lg shadow-emerald-100">
              <DollarSign size={24} />
            </div>
          </div>
          <div>
            <h3 className="font-bold text-ink-tertiary uppercase tracking-widest text-[8px] sm:text-[10px] mb-2">{isHistorical ? t('historical_value') : t('inventory_value')}</h3>
            <div className="text-2xl sm:text-3xl font-display font-bold text-ink tracking-tight">${(isHistorical ? historicalTotalValue : totalValue || 0).toLocaleString()}</div>
          </div>
        </div>

        <div className="bg-surface-main p-5 sm:p-8 rounded-3xl shadow-sm border border-border-main hover:shadow-md transition-all group flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-blue-600 text-white rounded-2xl group-hover:scale-110 transition-transform shadow-lg shadow-blue-100">
              <TrendingUp size={24} />
            </div>
          </div>
          <div>
            <h3 className="font-bold text-ink-tertiary uppercase tracking-widest text-[8px] sm:text-[10px] mb-2">{t('expected_profit')}</h3>
            <div className="text-2xl sm:text-3xl font-display font-bold text-ink tracking-tight">${((isHistorical ? historicalStats.expectedRevenue : totalExpectedRevenue || 0) - (isHistorical ? historicalTotalValue : totalValue || 0)).toLocaleString()}</div>
          </div>
        </div>

        <div className="bg-surface-main p-5 sm:p-8 rounded-3xl shadow-sm border border-border-main hover:shadow-md transition-all group flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-rose-600 text-white rounded-2xl group-hover:scale-110 transition-transform shadow-lg shadow-rose-100">
              <AlertCircle size={24} />
            </div>
          </div>
          <div>
            <h3 className="font-bold text-ink-tertiary uppercase tracking-widest text-[8px] sm:text-[10px] mb-2">{t('low_stock_items_count')}</h3>
            <div className="text-2xl sm:text-3xl font-display font-bold text-rose-600 tracking-tight">{isHistorical ? historicalStats.lowStockItems : lowStockItems}</div>
          </div>
        </div>
      </div>

      {isHistorical && (
        <div className="bg-indigo-50 border border-indigo-100 p-6 rounded-[2rem] flex items-center gap-4 text-indigo-700 shadow-sm">
          <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-sm">
            <History size={24} />
          </div>
          <div className="text-sm">
            <span className="font-bold block text-indigo-900 mb-0.5">{t('historical_view_active')}</span>
            <p className="text-indigo-600/80 font-medium">
              {t('viewing_stock_for')} <span className="font-bold text-indigo-700 underline decoration-2 underline-offset-4">{closingDate.toLocaleDateString()}</span>. {t('new_entries_disabled')}
            </p>
          </div>
        </div>
      )}

      {/* Slow Movers Awareness - Reminder to Business Owner */}
      {performanceData.filter(i => i.quantity > 0 && i.unitsSold <= 1).length > 0 && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-br from-rose-50 to-amber-50 border border-rose-100 p-4 sm:p-5 rounded-2xl shadow-sm relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <TrendingDown size={64} />
          </div>
          <div className="relative z-10 flex flex-col lg:flex-row gap-4 items-start lg:items-center">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1.5">
                <div className="p-1.5 bg-rose-500 text-white rounded-lg shadow-sm shadow-rose-200">
                  <AlertTriangle size={14} strokeWidth={3} />
                </div>
                <h3 className="text-sm font-display font-black text-rose-900 tracking-tight uppercase italic">
                  {t('slow_movers') || 'Badeecadaha aan soconin'}
                </h3>
              </div>
              <p className="text-rose-800/70 text-[10px] font-medium max-w-xl leading-snug">
                {t('slow_movers_desc' as any) || 'Alaabtan waxay u baahan yihiin fiiro gaar ah. Waxaad kordhin kartaa xayaysiinta ama waxaad u samayn kartaa qiimo dhimis si ay dhaqso ugu baxaan.'}
              </p>
            </div>

            <div className="flex-1 w-full grid grid-cols-1 sm:grid-cols-2 gap-2">
              {performanceData
                .filter(i => i.quantity > 0)
                .sort((a, b) => a.unitsSold - b.unitsSold)
                .slice(0, 2)
                .map(item => (
                  <div key={item.id} className="bg-white/80 p-2 rounded-xl border border-rose-100 flex items-center justify-between group hover:bg-white transition-all shadow-sm">
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-8 h-8 rounded-md bg-rose-50 flex items-center justify-center text-rose-500 overflow-hidden shrink-0">
                        {item.imageUrl ? (
                          <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          <Package size={14} />
                        )}
                      </div>
                      <div className="min-w-0 pr-2">
                        <p className="text-xs font-bold text-slate-800 truncate uppercase">{item.name}</p>
                        <p className="text-[9px] font-black text-rose-500 uppercase tracking-widest opacity-70">
                          {item.unitsSold} {t('sold' as any) || 'Sold'}
                        </p>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-xs font-black text-slate-900">${item.price}</p>
                      <p className="text-[9px] font-bold text-slate-400">{item.quantity} {t('in_stock' as any) || 'In Stock'}</p>
                    </div>
                  </div>
                ))}
            </div>
            
            <div className="flex items-center gap-2 shrink-0">
              <button 
                onClick={() => setIsBulkOfferModalOpen(true)}
                className="px-3 py-2 bg-rose-600 text-white rounded-lg font-black text-[10px] uppercase tracking-widest hover:bg-rose-700 transition-all shadow-sm flex items-center gap-1.5"
              >
                <Tag size={12} strokeWidth={3} />
                OFFER
              </button>
              <button 
               onClick={() => {
                 const firstSlow = performanceData.filter(i => i.quantity > 0).sort((a, b) => a.unitsSold - b.unitsSold)[0];
                 if (firstSlow) {
                   setSearchTerm(firstSlow.name);
                 }
               }}
               className="p-2 bg-white text-rose-600 border border-rose-200 rounded-lg hover:bg-rose-50 transition-all flex items-center justify-center"
               title={t('view_all' as any) || 'View All'}
              >
                <ArrowRight size={14} strokeWidth={3} />
              </button>
            </div>
          </div>
        </motion.div>
      )}

      {/* Filters & Export */}
      <div className="bg-surface-main p-6 rounded-[2.5rem] border border-border-main shadow-sm flex flex-col xl:flex-row justify-between items-center gap-6">
        <div className="w-full xl:w-auto">
          <DateSelector 
            selectedDate={selectedDate}
            onChange={setSelectedDate}
            mode={dateMode}
            onModeChange={setDateMode}
            startDate={startDate}
            endDate={endDate}
            onRangeChange={(start, end) => { setStartDate(start); setEndDate(end); }}
          />
        </div>
        <div className="flex items-center gap-3 w-full xl:w-auto">
          <button 
            onClick={() => window.print()}
            disabled={filteredItems.length === 0}
            className="flex-1 xl:flex-none p-3.5 bg-surface-main border border-border-main text-ink-secondary rounded-xl hover:bg-bg-sec transition-all shadow-sm flex items-center justify-center"
            title={t('print')}
          >
            <Printer className="w-[var(--icon-md)] h-[var(--icon-md)]" />
          </button>
          <button 
            onClick={downloadPDF}
            disabled={filteredItems.length === 0}
            className="flex-1 xl:flex-none bg-emerald-600 text-white px-6 py-3.5 rounded-xl font-bold shadow-lg shadow-emerald-500/10 hover:bg-emerald-700 transition-all flex items-center gap-2 text-sm"
          >
            <FileDown className="w-5 h-5" />
            <span>{t('download_pdf')}</span>
          </button>
          <button 
            onClick={downloadExcel}
            disabled={filteredItems.length === 0}
            className="flex-1 xl:flex-none bg-blue-600 text-white px-6 py-3.5 rounded-xl font-bold shadow-lg shadow-blue-500/10 hover:bg-blue-700 transition-all flex items-center gap-2 text-sm"
          >
            <Table className="w-[var(--icon-md)] h-[var(--icon-md)]" />
            <span className="hidden sm:inline">{t('download_excel')}</span>
          </button>
        </div>
      </div>

      {/* Category Filter */}
      {uniqueCategories.length > 1 && (
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2 mb-4">
          {uniqueCategories.map(cat => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-5 py-2.5 rounded-xl text-sm font-bold whitespace-nowrap transition-all ${
                categoryFilter === cat 
                  ? 'bg-accent-main text-white shadow-md border border-accent-main' 
                  : 'bg-accent-soft text-accent-main border border-transparent hover:opacity-80'
              }`}
            >
              {cat === 'All' ? t('all') : cat}
            </button>
          ))}
        </div>
      )}

      {/* Inventory Table */}
      <div className="bg-surface-main rounded-[2.5rem] border border-border-main shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-bg-sec">
                <th className="px-8 py-5 text-xs font-bold uppercase tracking-[0.15em] text-ink-tertiary border-b border-border-main">{t('product')} & {t('sku_barcode')}</th>
                <th className="px-8 py-5 text-xs font-bold uppercase tracking-[0.15em] text-ink-tertiary border-b border-border-main text-center">
                  {t('stock')} ({dateMode === 'day' ? t('prev') : t('start')} / {dateMode === 'day' ? t('now') : t('end')})
                </th>
                <th className="px-8 py-5 text-xs font-bold uppercase tracking-[0.15em] text-ink-tertiary border-b border-border-main text-center">{t('pricing')}</th>
                <th className="px-8 py-5 text-xs font-bold uppercase tracking-[0.15em] text-ink-tertiary border-b border-border-main text-center cursor-pointer hover:text-accent-main transition-colors" onClick={() => handleSort('quantity')}>{t('remaining')}</th>
                <th className="px-8 py-5 text-xs font-bold uppercase tracking-[0.15em] text-ink-tertiary border-b border-border-main text-center cursor-pointer hover:text-accent-main transition-colors" onClick={() => handleSort('units_sold')}>{t('units_sold')}</th>
                <th className="px-8 py-5 text-xs font-bold uppercase tracking-[0.15em] text-ink-tertiary border-b border-border-main text-right">{t('actions')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border-subtle">
              {sortedItems.map(item => (
                <tr key={item.id} className="hover:bg-bg-sec/50 transition-colors group border-b border-border-main last:border-0">
                  {/* Product & Identity */}
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-5">
                      <div className="w-16 h-16 rounded-2xl bg-bg-sec flex items-center justify-center text-ink-tertiary overflow-hidden shadow-sm border border-border-main/50 group-hover:border-accent-main/30 transition-colors">
                        {(item.imageUrl || (item as any).image_url) ? (
                          <img src={item.imageUrl || (item as any).image_url} alt={item.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" referrerPolicy="no-referrer" />
                        ) : (
                          <Package className="w-8 h-8 opacity-20" />
                        )}
                      </div>
                      <div className="flex flex-col gap-1.5 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-base font-black text-ink truncate group-hover:text-accent-main transition-colors uppercase tracking-tight italic">{item.name}</p>
                          {(() => {
                            const rank = topSelling.findIndex(i => i.id === item.id) + 1;
                            const isLeast = leastSelling.some(i => i.id === item.id);
                            
                            if (rank > 0 && rank <= 10) {
                              return (
                                <span 
                                  className={`flex items-center gap-1 h-6 px-2 rounded-full text-[10px] font-black ${
                                    rank <= 3 
                                      ? 'bg-amber-100 text-amber-600 border border-amber-200' 
                                      : 'bg-slate-100 text-slate-500 border border-slate-200'
                                  } shadow-sm tracking-tighter shrink-0`} 
                                  title={`${t('top_selling')}: #${rank}`}
                                >
                                  <TrendingUp size={10} strokeWidth={3} />
                                  TOP {rank}
                                </span>
                              );
                            }
                            
                            if (isLeast) {
                              return (
                                <span 
                                  className="flex items-center gap-1 h-6 px-2 rounded-full text-[10px] font-black bg-rose-50 text-rose-500 border border-rose-100 shadow-sm shrink-0 uppercase" 
                                  title={t('least_selling')}
                                >
                                  <TrendingDown size={10} strokeWidth={3} />
                                  {t('low_stock_status') === 'Gabaabi' ? 'HOOSE' : 'LOW'}
                                </span>
                              );
                            }
                            return null;
                          })()}
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="px-2.5 py-1 rounded-lg bg-bg-sec text-xs font-mono font-bold text-ink-tertiary border border-border-main/50">{item.sku}</span>
                          {tenant?.isMultiBranch && item.branchId && (
                            <span className="px-2.5 py-1 rounded-lg bg-indigo-50 text-[10px] font-black text-indigo-600 border border-indigo-100 uppercase tracking-wider italic">
                              {branches.find(b => b.id === item.branchId)?.name || 'Unknown Branch'}
                            </span>
                          )}
                          {item.quantity <= item.minStock && (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[10px] font-black bg-rose-500 text-white uppercase tracking-wider shadow-sm shadow-rose-100 italic">
                              <AlertCircle size={10} strokeWidth={3} /> {t('low')}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </td>

                  {/* Stock Tracking */}
                  <td className="px-8 py-6 text-center">
                    <div className="flex items-center justify-center gap-4">
                      <div className="flex flex-col items-center">
                        <span className="text-[10px] font-black text-ink-tertiary uppercase tracking-wider opacity-50 mb-1">{t('prev')}</span>
                        <span className="text-sm font-mono font-black text-ink-tertiary bg-bg-sec px-3 py-1.5 rounded-xl border border-border-main/30 shadow-inner">
                          {(() => {
                            const getOpeningComparisonDate = () => {
                              const date = new Date(selectedDate);
                              if (dateMode === 'day') {
                                date.setDate(date.getDate() - 1);
                                date.setHours(23, 59, 59, 999);
                              } else if (dateMode === 'month') {
                                date.setDate(1);
                                date.setHours(0, 0, 0, 0);
                                date.setMilliseconds(-1);
                              } else if (dateMode === 'year') {
                                date.setMonth(0, 1);
                                date.setHours(0, 0, 0, 0);
                                date.setMilliseconds(-1);
                              } else if (dateMode === 'range' && startDate) {
                                const start = new Date(startDate);
                                start.setHours(0, 0, 0, 0);
                                start.setMilliseconds(-1);
                                return start;
                              }
                              return date;
                            };
                            return getHistoricalStock(item, getOpeningComparisonDate());
                          })()}
                        </span>
                      </div>
                      <ArrowRight size={14} className="text-ink-tertiary opacity-30 mt-5" />
                      <div className="flex flex-col items-center">
                        <span className="text-[10px] font-black text-accent-main uppercase tracking-wider mb-1">{t('now')}</span>
                        <span className="text-sm font-mono font-black text-ink bg-accent-soft px-3 py-1.5 rounded-xl border border-accent-main/20 shadow-sm">
                          {(() => {
                            const getClosingComparisonDate = () => {
                              const date = new Date(selectedDate);
                              if (dateMode === 'day') {
                                date.setHours(23, 59, 59, 999);
                              } else if (dateMode === 'month') {
                                date.setMonth(date.getMonth() + 1, 0);
                                date.setHours(23, 59, 59, 999);
                              } else if (dateMode === 'year') {
                                date.setMonth(11, 31);
                                date.setHours(23, 59, 59, 999);
                              } else if (dateMode === 'range' && endDate) {
                                const end = new Date(endDate);
                                end.setHours(23, 59, 59, 999);
                                return end;
                              }
                              return date;
                            };
                            return getHistoricalStock(item, getClosingComparisonDate());
                          })()}
                        </span>
                      </div>
                    </div>
                  </td>

                  {/* Pricing Economics */}
                  <td className="px-8 py-6">
                    <div className="flex flex-col items-center gap-2">
                      <div className="flex items-center gap-4">
                        <div className="flex flex-col items-end">
                          <span className="text-[10px] font-black text-ink-tertiary uppercase leading-none opacity-50 mb-1">{t('cost')}</span>
                          <span className="text-sm font-bold text-ink-tertiary">${(item.costPrice || 0).toLocaleString()}</span>
                        </div>
                        <div className="w-px h-8 bg-border-main mx-1" />
                        <div className="flex flex-col items-start font-black">
                          <span className="text-[10px] font-black text-accent-main uppercase leading-none mb-1">{t('sale')}</span>
                          <span className="text-lg font-black text-ink tracking-tighter italic">${(item.price || 0).toLocaleString()}</span>
                        </div>
                      </div>
                      <div className="bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20 shadow-sm">
                        <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest italic">
                          Profit: ${(item.price - (item.costPrice || 0)).toLocaleString()}
                        </span>
                      </div>
                    </div>
                  </td>

                  {/* Quantity */}
                  <td className="px-8 py-6 text-center">
                    <div className={`inline-flex flex-col items-center p-3 rounded-2xl border min-w-[90px] ${
                      item.quantity <= item.minStock 
                        ? "bg-rose-500/5 border-rose-500/20 shadow-inner" 
                        : "bg-surface-main border-border-main shadow-sm"
                    }`}>
                      <span className={`text-2xl font-black font-mono leading-none ${
                        item.quantity <= item.minStock ? "text-rose-600" : "text-ink"
                      }`}>
                        {item.quantity}
                      </span>
                      <span className="text-[10px] font-black text-ink-tertiary uppercase mt-1.5 opacity-50 tracking-[0.2em]">{t('harsan')}</span>
                    </div>
                  </td>

                  <td className="px-8 py-6 text-center">
                    <div className="flex flex-col items-center">
                      <span className="text-lg font-black text-emerald-600 font-mono">{(productSales[item.id] || 0).toLocaleString()}</span>
                      <span className="text-[8px] font-black text-ink-tertiary uppercase tracking-wider">{t('units_sold')}</span>
                    </div>
                  </td>

                  {/* Actions */}
                  <td className="px-8 py-6 text-right">
                      <div className="flex justify-end gap-2 transition-all duration-300">
                        <button onClick={() => fetchHistory(item)} className="p-3 text-ink-tertiary hover:text-accent-main hover:bg-accent-soft rounded-2xl transition-all shadow-sm active:scale-95" title={t('history')}>
                          <History size={18} strokeWidth={2.5} />
                        </button>
                        <button 
                          onClick={() => openEdit(item)} 
                          className={`flex items-center gap-2 px-5 py-3 rounded-2xl transition-all shadow-md active:scale-95 ${
                            item.quantity <= (item.minStock || 0)
                              ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-emerald-200 ring-4 ring-emerald-50 animate-pulse' 
                              : 'text-ink-tertiary hover:text-blue-600 hover:bg-blue-50'
                          }`} 
                          title={item.quantity <= (item.minStock || 0) ? t('restock_product' as any) || 'Restock Product' : t('edit')}
                        >
                          {item.quantity <= (item.minStock || 0) ? <PlusCircle size={20} strokeWidth={3} /> : <Edit2 size={18} strokeWidth={2.5} />}
                          {(item.quantity <= (item.minStock || 0)) && (
                            <span className="text-xs font-black uppercase tracking-widest whitespace-nowrap">
                              {t('restock_product' as any) || 'Restock'}
                            </span>
                          )}
                        </button>
                        <button onClick={() => handleDelete(item.id)} className="p-3 text-ink-tertiary hover:text-rose-600 hover:bg-rose-50 rounded-2xl transition-all shadow-sm active:scale-95">
                          <Trash2 size={18} strokeWidth={2.5} />
                        </button>
                      </div>
                  </td>
                </tr>
              ))}
              {filteredItems.length === 0 && (
                <tr>
                  <td colSpan={10} className="p-20 text-center">
                    <div className="flex flex-col items-center gap-4">
                      <div className="w-16 h-16 bg-bg-sec rounded-2xl flex items-center justify-center text-ink-tertiary">
                        <Package className="w-[var(--icon-lg)] h-[var(--icon-lg)]" />
                      </div>
                      <p className="text-ink-tertiary font-medium italic">{t('no_products_found')}</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <Modal 
        isOpen={isHistoryModalOpen} 
        onClose={() => setIsHistoryModalOpen(false)} 
        title={selectedHistoryItem ? `${t('inventory_history')} - ${selectedHistoryItem.name}` : t('inventory_history')}
        contentClassName="max-w-2xl"
      >
        <div className="overflow-x-auto">
          {selectedHistoryItem && (
            <div className="flex items-center gap-4 mb-6 p-4 bg-white border-2 border-slate-100 rounded-3xl shadow-sm">
              <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600">
                <Package className="w-6 h-6" />
              </div>
              <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{t('current_stock')}</p>
                <p className="text-xl font-black text-slate-900">{selectedHistoryItem.quantity} <span className="text-xs text-slate-400 font-medium ml-1">{t('items_remaining')}</span></p>
              </div>
            </div>
          )}

          <div className="mb-6 p-6 bg-indigo-50 border-2 border-indigo-100 text-indigo-700 rounded-[2rem] text-sm font-black flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 shadow-inner">
            <div className="flex flex-col gap-1">
              <span className="uppercase tracking-[0.1em]">
                {selectedHistoryItem 
                  ? `${t('product_added_on' as any) || 'Product added on'}: ${new Date((selectedHistoryItem as any).createdAt || new Date()).toLocaleDateString()}`
                  : t('inventory_history')}
              </span>
              {selectedHistoryItem && (
                <button 
                  onClick={() => {
                    setIsHistoryModalOpen(false);
                    openEdit(selectedHistoryItem as any);
                  }}
                  className="bg-emerald-600 text-white px-5 py-2.5 rounded-xl font-bold shadow-lg shadow-emerald-500/20 hover:bg-emerald-700 transition-all flex items-center gap-2 text-xs"
                >
                  <PlusCircle size={16} />
                  <span>{t('restock')}</span>
                </button>
              )}
            </div>
            <div className="flex gap-6">
              <span className="text-emerald-700 font-black italic">
                {t('total_in' as any) || 'Total In'}: {historyLogs.filter((log: any) => selectedHistoryItem ? true : filterByDate(log.timestamp || log.created_at, selectedDate, dateMode, startDate, endDate))
                  .filter(log => log.change > 0)
                  .reduce((sum, log) => sum + Number(log.change), 0)}
              </span>
              <span className="text-rose-700 font-black italic">
                {t('total_out' as any) || 'Total Out'}: {Math.abs(historyLogs.filter((log: any) => selectedHistoryItem ? true : filterByDate(log.timestamp || log.created_at, selectedDate, dateMode, startDate, endDate))
                  .filter(log => log.change < 0)
                  .reduce((sum, log) => sum + Number(log.change), 0))}
              </span>
            </div>
          </div>
            <table className="w-full text-left text-sm font-sans">
              <thead className="bg-slate-50 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 border-b-2 border-slate-200">
                <tr>
                  <th className="px-6 py-4">{t('product_name')}</th>
                  <th className="px-6 py-4">{t('change')}</th>
                  <th className="px-6 py-4">{t('stock_balance' as any) || 'Balance'}</th>
                  <th className="px-6 py-4">{t('reason')}</th>
                  <th className="px-6 py-4">{t('date')}</th>
                </tr>
              </thead>
              <tbody className="divide-y-2 divide-slate-100">
                {(() => {
                  const filteredLogs = historyLogs.filter((log: any) => selectedHistoryItem ? log.item_id === selectedHistoryItem.id : filterByDate(log.timestamp || log.created_at, selectedDate, dateMode, startDate, endDate));
                  
                  // Calculate balance if showing specific item
                  let runningBalance = 0;
                  const logsWithBalance = [...filteredLogs]
                    .sort((a, b) => new Date(a.timestamp || a.created_at).getTime() - new Date(b.timestamp || b.created_at).getTime())
                    .map(log => {
                      runningBalance += Number(log.change);
                      return { ...log, balance: runningBalance };
                    })
                    .reverse(); // Return to newest first for display

                  return logsWithBalance.map((log: any) => (
                    <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 font-bold text-slate-700">{log.item_name}</td>
                      <td className={`px-6 py-4 font-black italic text-lg ${log.change > 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {log.change > 0 ? '+' : ''}{log.change}
                      </td>
                      <td className="px-6 py-4 font-bold text-slate-900 border-x border-slate-50">
                        {log.balance !== undefined ? log.balance : '-'}
                      </td>
                      <td className="px-6 py-4 text-slate-500 font-medium">
                        <span className={`px-3 py-1 border rounded-lg shadow-sm text-[10px] font-bold uppercase tracking-wider ${
                          log.reason === 'sale' || log.reason === 'edit_sale' ? 'bg-amber-50 border-amber-100 text-amber-600' :
                          log.reason === 'initial_stock' || log.reason === 'restock' || (log.change > 0 && log.reason !== 'item_refunded') ? 'bg-emerald-50 border-emerald-100 text-emerald-600' :
                          'bg-slate-50 border-slate-200 text-slate-500'
                        }`}>
                          {log.reason === 'sale' || log.reason === 'edit_sale' ? (t('sold' as any) || 'Sold') :
                           log.reason === 'initial_stock' ? (t('initial_stock' as any) || 'Initial Stock') :
                           log.reason === 'restock' ? (t('restock' as any) || 'Restock') :
                           log.reason === 'manual_reduction' ? (t('manual_adjustment' as any) || 'Reduction') :
                           log.reason}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-slate-400 font-mono text-xs">
                        {log.timestamp ? new Date(log.timestamp).toLocaleString() : ''}
                      </td>
                    </tr>
                  ));
                })()}
              </tbody>
            </table>
        </div>
      </Modal>
      {isModalOpen && (
        <Modal 
          isOpen={isModalOpen} 
          onClose={() => setIsModalOpen(false)} 
          title={editingItem ? t('edit_product') : t('add_new_product')}
        >
          <form onSubmit={handleSubmit} className="p-8 space-y-6">
            <div>
              <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{t('product_name')}</label>
              <input required type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full px-6 py-4 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-indigo-500 text-base font-bold shadow-sm" />
            </div>
            <div>
              <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{t('category' as any) || 'Category'}</label>
              <input 
                type="text" 
                value={formData.category} 
                onChange={e => setFormData({...formData, category: e.target.value})} 
                className="w-full px-6 py-4 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-indigo-500 text-base font-bold shadow-sm" 
                placeholder="e.g. Electronics, Clothing..."
                list="category-suggestions"
              />
              <datalist id="category-suggestions">
                {uniqueCategories.filter(c => c !== 'All').map(cat => (
                  <option key={cat} value={cat} />
                ))}
              </datalist>
            </div>
            <div>
              <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{t('sku_barcode')}</label>
              <input required type="text" value={formData.sku} onChange={e => setFormData({...formData, sku: e.target.value})} className="w-full px-6 py-4 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-indigo-500 font-mono text-base font-bold shadow-sm" />
            </div>
            <div>
              <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{t('product_image')}</label>
              <div className="flex items-center gap-6 p-4 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
                {(formData.imageUrl || (formData as any).image_url || selectedFile) && (
                  <div className="w-24 h-24 rounded-2xl bg-white overflow-hidden border-2 border-slate-200 shrink-0 shadow-lg">
                    <img 
                      src={selectedFile ? URL.createObjectURL(selectedFile) : (formData.imageUrl || (formData as any).image_url)} 
                      alt="Preview" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                <input 
                  type="file" 
                  accept="image/*" 
                  onChange={e => setSelectedFile(e.target.files?.[0] || null)} 
                  className="w-full text-sm text-slate-500 file:mr-4 file:py-2.5 file:px-6 file:rounded-xl file:border-0 file:text-xs file:font-black file:uppercase file:tracking-widest file:bg-indigo-600 file:text-white hover:file:bg-indigo-700 transition-all cursor-pointer" 
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{t('cost_price')}</label>
                <input required type="number" step="0.01" value={formData.costPrice} onChange={e => setFormData({...formData, costPrice: parseFloat(e.target.value) || 0})} className="w-full px-6 py-4 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-indigo-500 text-lg font-black text-slate-600 shadow-sm" />
              </div>
              <div>
                <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{t('selling_price')}</label>
                <input required type="number" step="0.01" value={formData.price} onChange={e => setFormData({...formData, price: parseFloat(e.target.value) || 0})} className="w-full px-6 py-4 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-indigo-500 text-xl font-black text-indigo-600 shadow-sm" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{t('stock_remaining')}</label>
                <input required type="number" step="any" value={formData.quantity} onChange={e => setFormData({...formData, quantity: parseFloat(e.target.value) || 0})} className="w-full px-6 py-4 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-indigo-500 text-lg font-black text-slate-600 shadow-sm" />
              </div>
              <div>
                <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{t('remind_at_stock')}</label>
                <input required type="number" step="any" value={formData.minStock} onChange={e => setFormData({...formData, minStock: parseFloat(e.target.value) || 0})} className="w-full px-6 py-4 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-indigo-500 text-lg font-black text-rose-600 shadow-sm" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{t('discount_percentage')} (%)</label>
                <input type="number" step="0.1" value={formData.discountPercentage} onChange={e => setFormData({...formData, discountPercentage: parseFloat(e.target.value) || 0, offerPrice: 0})} className="w-full px-6 py-4 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-indigo-500 text-lg font-bold shadow-sm" />
              </div>
              <div>
                <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{t('offer_price')} ($)</label>
                <input type="number" step="0.01" value={formData.offerPrice} onChange={e => setFormData({...formData, offerPrice: parseFloat(e.target.value) || 0, discountPercentage: 0})} className="w-full px-6 py-4 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-indigo-500 text-lg font-bold shadow-sm" />
              </div>
            </div>

            <div>
              <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{t('payment_method')}</label>
              <select 
                value={formData.paymentMethod} 
                onChange={e => setFormData({...formData, paymentMethod: e.target.value})} 
                className="w-full px-6 py-4 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-indigo-500 text-base font-bold bg-white shadow-sm"
              >
                {['EVC', 'eDahab', 'ZAAD', 'SAHAL', 'Cash', 'Bank Account', 'Merchant'].map(m => <option key={m} value={m}>{m}</option>)}
                {accounts.filter(acc => acc.balance > 0).map(acc => (
                  <option key={acc.id} value={acc.name}>{acc.name}</option>
                ))}
              </select>
              <p className="text-xs text-slate-500 mt-2 italic font-medium">
                {t('stock_payment_desc' as any) || 'The total cost (quantity × cost price) will be deducted from this account.'}
              </p>
            </div>
            {tenant?.isMultiBranch && branches.length > 0 && (
              <div>
                <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{t('branch' as any) || 'Branch'}</label>
                <select 
                  value={formData.branchId || ''} 
                  onChange={e => setFormData({...formData, branchId: e.target.value})} 
                  disabled={!!user.branchId}
                  className={`w-full px-6 py-4 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-indigo-500 text-base font-bold bg-white shadow-sm ${!!user.branchId ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  <option value="">{t('select_branch' as any) || 'Select Branch...'}</option>
                  {branches.map(b => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </select>
              </div>
            )}
            <div className="pt-6 flex gap-4">
              <button type="button" onClick={() => setIsModalOpen(false)} disabled={submitting} className="flex-1 px-6 py-4 border-2 border-slate-200 text-slate-600 rounded-2xl font-black uppercase tracking-widest hover:bg-slate-50 disabled:opacity-50 transition-all">{t('cancel')}</button>
              <button type="submit" disabled={submitting} className="flex-1 px-6 py-4 bg-indigo-600 text-white rounded-2xl font-black uppercase tracking-widest hover:bg-indigo-700 disabled:opacity-50 shadow-lg shadow-indigo-200 transition-all active:scale-95">{submitting ? t('saving') || 'Saving...' : (editingItem ? t('save_changes') : t('add_to_inventory'))}</button>
            </div>
          </form>
        </Modal>
      )}

      {isBulkOfferModalOpen && (
        <Modal 
          isOpen={isBulkOfferModalOpen} 
          onClose={() => setIsBulkOfferModalOpen(false)} 
          title={t('apply_bulk_offer')}
        >
          <form onSubmit={handleBulkOffer} className="p-8 space-y-8">
            <div className="space-y-4">
              <label className="block text-sm font-black text-slate-700 uppercase tracking-widest">{t('offer_type')}</label>
              <div className="flex bg-slate-100 p-2 rounded-2xl gap-2">
                <button
                  type="button"
                  onClick={() => setBulkOfferType('percentage')}
                  className={`flex-1 py-4 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${bulkOfferType === 'percentage' ? 'bg-white text-indigo-600 shadow-md translate-y-[-1px]' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  {t('percentage')} (%)
                </button>
                <button
                  type="button"
                  onClick={() => setBulkOfferType('fixed')}
                  className={`flex-1 py-4 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${bulkOfferType === 'fixed' ? 'bg-white text-indigo-600 shadow-md translate-y-[-1px]' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  {t('fixed_price')} ($)
                </button>
              </div>
            </div>
            <div>
              <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-4">
                {bulkOfferType === 'percentage' ? t('discount_percentage') : t('offer_price')}
              </label>
              <input 
                required 
                type="number" 
                step="any" 
                value={bulkOfferValue} 
                onChange={e => setBulkOfferValue(e.target.value)} 
                className="w-full px-6 py-5 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-indigo-500 text-2xl font-black text-center shadow-inner italic" 
              />
            </div>
            <div className="pt-4 flex gap-4">
              <button type="button" onClick={() => setIsBulkOfferModalOpen(false)} disabled={submitting} className="flex-1 px-6 py-4 border-2 border-slate-200 text-slate-600 rounded-2xl font-black uppercase tracking-widest hover:bg-slate-50 transition-all disabled:opacity-50">{t('cancel')}</button>
              <button type="submit" disabled={submitting} className="flex-1 px-6 py-4 bg-indigo-600 text-white rounded-2xl font-black uppercase tracking-widest hover:bg-indigo-700 shadow-lg shadow-indigo-100 transition-all disabled:opacity-50 active:scale-95">{submitting ? t('saving') || 'Saving...' : t('apply')}</button>
            </div>
          </form>
        </Modal>
      )}

      {isBranchModalOpen && (
        <Modal 
          isOpen={isBranchModalOpen} 
          onClose={() => setIsBranchModalOpen(false)} 
          title={t('add_branch' as any) || 'Add Branch'}
        >
          <form onSubmit={handleCreateBranch} className="p-8 space-y-6">
            <div>
              <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{t('branch_name' as any) || 'Branch Name'}</label>
              <input 
                required 
                type="text" 
                value={newBranchName} 
                onChange={e => setNewBranchName(e.target.value)} 
                className="w-full px-6 py-4 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-indigo-500 text-base font-bold shadow-sm" 
              />
            </div>
            <div>
              <label className="block text-sm font-black text-slate-700 uppercase tracking-widest mb-3">{t('location' as any) || 'Location'}</label>
              <input 
                type="text" 
                value={newBranchLocation} 
                onChange={e => setNewBranchLocation(e.target.value)} 
                className="w-full px-6 py-4 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-indigo-500 text-base font-bold shadow-sm" 
              />
            </div>
            <div className="pt-6 flex gap-4">
              <button type="button" onClick={() => setIsBranchModalOpen(false)} disabled={submitting} className="flex-1 px-6 py-4 border-2 border-slate-200 text-slate-600 rounded-2xl font-black uppercase tracking-widest hover:bg-slate-50 disabled:opacity-50 transition-all">{t('cancel')}</button>
              <button type="submit" disabled={submitting} className="flex-1 px-6 py-4 bg-indigo-600 text-white rounded-2xl font-black uppercase tracking-widest hover:bg-indigo-700 disabled:opacity-50 shadow-lg shadow-indigo-200 transition-all active:scale-95">{submitting ? t('saving') || 'Saving...' : (t('add_branch' as any) || 'Add Branch')}</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
