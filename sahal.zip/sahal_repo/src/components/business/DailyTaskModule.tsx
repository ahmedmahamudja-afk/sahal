import React, { useState, useEffect } from 'react';
import { supabase } from '../../supabase';
import { DailyTask, UserProfile } from '../../types';
import { Plus, Search, Edit2, Trash2, CheckSquare, ChevronRight, Square, Check, RefreshCw } from 'lucide-react';
import { useLanguage } from '../LanguageContext';
import Modal from '../Modal';
import { motion, AnimatePresence } from 'motion/react';

export default function DailyTaskModule({ user }: { user: UserProfile }) {
  const { t } = useLanguage();
  const [tasks, setTasks] = useState<DailyTask[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<DailyTask | null>(null);
  const [formData, setFormData] = useState({
    task: '',
    completed: false
  });

  const fetchTasks = async () => {
    if (!user.tenantId) return;
    setLoading(true);
    try {
      let query = supabase
        .from('daily_tasks')
        .select('*')
        .eq('tenant_id', user.tenantId);
      
      if (user.branchId) {
        query = query.eq('branch_id', user.branchId);
      }
      
      const { data: tasksData } = await query;
      setTasks(tasksData || []);
    } catch (error) {
      console.error("Error fetching tasks:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, [user.tenantId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.tenantId) return;
    try {
      const taskData = {
        task: formData.task,
        completed: formData.completed,
        tenant_id: user.tenantId,
        branch_id: user.branchId || null,
        created_at: editingTask ? editingTask.createdAt : new Date().toISOString()
      };

      if (editingTask) {
        await supabase.from('daily_tasks').update(taskData).eq('id', editingTask.id);
      } else {
        await supabase.from('daily_tasks').insert(taskData);
      }
      setIsModalOpen(false);
      setEditingTask(null);
      setFormData({ task: '', completed: false });
      fetchTasks();
    } catch (error) {
      console.error("Error saving task:", error);
    }
  };

  const handleDelete = async (id: string) => {
    if (!user.tenantId || !window.confirm(t('delete_confirm'))) return;
    try {
      await supabase.from('daily_tasks').delete().eq('id', id);
      fetchTasks();
    } catch (error) {
      console.error("Error deleting task:", error);
    }
  };

  const toggleComplete = async (task: DailyTask) => {
    if (!user.tenantId) return;
    try {
      await supabase.from('daily_tasks').update({
        completed: !task.completed
      }).eq('id', task.id);
      fetchTasks();
    } catch (error) {
      console.error("Error toggling task:", error);
    }
  };

  const openEdit = (task: DailyTask) => {
    setEditingTask(task);
    setFormData({
      task: task.task || '',
      completed: task.completed || false
    });
    setIsModalOpen(true);
  };

  const completedCount = tasks.filter(t => t.completed).length;
  const progress = tasks.length > 0 ? (completedCount / tasks.length) * 100 : 0;

  return (
    <div className="space-y-8 pb-12">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6">
        <div className="flex items-center gap-4">
           <div className="w-14 h-14 bg-accent-main rounded-2xl flex items-center justify-center text-white shadow-xl shadow-accent-soft">
             <CheckSquare size={28} strokeWidth={2.5} />
           </div>
           <div>
             <h2 className="text-3xl font-display font-black text-ink tracking-tight uppercase italic">{t('daily_task')}</h2>
             <p className="text-ink-tertiary text-sm font-bold opacity-60 italic">{t('manage_tasks_desc' as any) || 'Track your daily business tasks and progress.'}</p>
           </div>
        </div>
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <button 
            onClick={fetchTasks}
            disabled={loading}
            className={`p-3 bg-white text-slate-600 rounded-xl font-bold text-sm border border-slate-200 hover:bg-slate-50 transition-all flex items-center gap-2 ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
            title={t('refresh')}
          >
            <RefreshCw size={18} className={loading ? 'animate-spin' : ''} />
          </button>
          <button
            onClick={() => {
              setEditingTask(null);
              setFormData({ task: '', completed: false });
              setIsModalOpen(true);
            }}
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-8 py-4 bg-accent-main text-white rounded-2xl font-black uppercase tracking-widest hover:opacity-90 active:scale-95 transition-all shadow-xl shadow-accent-soft"
          >
            <Plus size={20} strokeWidth={3} />
            <span>{t('add_task')}</span>
          </button>
        </div>
      </div>

      <div className="bg-ink p-10 rounded-[2.5rem] text-white relative overflow-hidden shadow-2xl group">
        <div className="absolute top-0 right-0 p-12 opacity-5 group-hover:scale-110 transition-transform">
          <CheckSquare size={180} strokeWidth={1} />
        </div>
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="text-center md:text-left">
            <p className="text-slate-400 text-xs font-black uppercase tracking-[0.3em] mb-3 border-b border-white/10 pb-2 w-fit mx-auto md:mx-0">{t('daily_progress' as any) || 'Daily Progress'}</p>
            <h3 className="text-6xl font-display font-black tracking-tighter">
              {completedCount} <span className="text-2xl text-slate-500 opacity-50">/</span> {tasks.length}
            </h3>
          </div>
          <div className="text-center md:text-right">
            <span className="text-5xl font-display font-black text-emerald-400 tracking-tighter italic">{progress.toFixed(0)}%</span>
            <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mt-1 italic">Completion Rate</p>
          </div>
        </div>
        <div className="w-full h-4 bg-white/5 rounded-full overflow-hidden mt-8 border border-white/5 p-1">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 1.5, ease: "circOut" }}
            className={`h-full rounded-full transition-all duration-1000 shadow-lg ${progress === 100 ? 'bg-emerald-500' : 'bg-accent-main'}`} 
          />
        </div>
      </div>

      <div className="bg-surface-main rounded-[2.5rem] border border-border-main shadow-sm overflow-hidden">
        <div className="divide-y divide-border-main">
          {tasks.map(task => (
            <motion.div
              layout
              key={task.id}
              className="p-6 flex items-center justify-between group hover:bg-bg-sec/50 transition-all duration-300"
            >
              <div className="flex items-center gap-5 flex-1 p-2">
                <button
                  onClick={() => toggleComplete(task)}
                  className={`w-10 h-10 rounded-xl border-2 flex items-center justify-center transition-all duration-500 transform active:scale-90 ${
                    task.completed 
                      ? 'bg-emerald-500 border-emerald-500 text-white shadow-lg shadow-emerald-500/20' 
                      : 'bg-bg-sec border-border-main text-transparent hover:border-accent-main/50'
                  }`}
                >
                  <Check size={20} strokeWidth={3.5} className={task.completed ? 'scale-100' : 'scale-0 transition-transform duration-500'} />
                </button>
                <div className="flex flex-col">
                  <span className={`text-lg font-black tracking-tight transition-all duration-500 ${task.completed ? 'text-ink-tertiary line-through italic opacity-50' : 'text-ink uppercase italic'}`}>
                    {task.task}
                  </span>
                  {task.completed && (
                     <span className="text-[8px] font-black uppercase text-emerald-500 tracking-widest mt-1">Status: Completed</span>
                  )}
                </div>
              </div>
              <div className="flex gap-2 transition-all duration-300">
                <button 
                  onClick={() => openEdit(task)} 
                  className="p-3 text-accent-main hover:bg-accent-soft rounded-xl transition-all shadow-sm bg-surface-main border border-border-main/50"
                  title={t('edit')}
                >
                  <Edit2 size={18} strokeWidth={2.5} />
                </button>
                <button 
                  onClick={() => handleDelete(task.id)} 
                  className="p-3 text-rose-600 hover:bg-rose-50 rounded-xl transition-all shadow-sm bg-surface-main border border-border-main/50"
                  title={t('delete')}
                >
                  <Trash2 size={18} strokeWidth={2.5} />
                </button>
              </div>
            </motion.div>
          ))}
          {tasks.length === 0 && (
            <div className="p-20 text-center">
              <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <CheckSquare size={32} className="text-slate-200" />
              </div>
              <p className="text-slate-400 font-medium italic">{t('no_data')}</p>
            </div>
          )}
        </div>
      </div>

      <Modal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        title={editingTask ? t('edit' as any) || 'Edit' : t('add_task')}
        contentClassName="max-w-md"
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('task_name')}</label>
            <input
              type="text"
              required
              value={formData.task}
              onChange={e => setFormData({ ...formData, task: e.target.value })}
              className="sahal-input"
              placeholder={t('task_name')}
            />
          </div>
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="flex-1 px-6 py-4 bg-slate-100 text-slate-600 rounded-2xl font-bold hover:bg-slate-200 transition-all"
            >
              {t('cancel')}
            </button>
            <button
              type="submit"
              className="flex-1 px-6 py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
            >
              {t('save')}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
