import React, { useState } from 'react';
import { supabase } from '../supabase';
import { UserProfile } from '../types';
import { ShieldCheck, User, Lock, ArrowRight, Eye, EyeOff, ArrowLeft, AlertCircle, Globe } from 'lucide-react';
import { motion } from 'motion/react';
import { is9DigitNumber, USERNAME_FORMAT_ERROR } from '../lib/validation';
import { useLanguage } from './LanguageContext';
import { LanguageSelector } from './LanguageSelector';

interface AuthProps {
  onAuthSuccess: (user: UserProfile) => void;
  onBack?: () => void;
}

export const Auth: React.FC<AuthProps> = ({ onAuthSuccess, onBack }) => {
  const { t } = useLanguage();
  const [staffCreds, setStaffCreds] = useState({ username: '', password: '' });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const username = staffCreds.username.trim();
      const password = staffCreds.password.trim();

      // 9-digit validation for everyone
      if (!is9DigitNumber(username) && username !== '100100100' && username !== 'Ahmedmoha') {
        setError(t('invalid_username_format' as any) || USERNAME_FORMAT_ERROR);
        setLoading(false);
        return;
      }

      console.log("Login attempt for:", username);

      // 1. Check 'users' table
      const { data: userMatches, error: userError } = await supabase
        .from('users')
        .select('*')
        .eq('username', username)
        .eq('password', password);
      
      if (userError) throw userError;

      let userData = userMatches && userMatches.length > 0 ? userMatches[0] : null;
      let isStaff = false;

      // 2. If not found in users, check 'staff' table
      if (!userData) {
        const { data: staffMatches, error: staffError } = await supabase
          .from('staff')
          .select('*')
          .eq('username', username)
          .eq('password', password);
        
        if (staffError) throw staffError;

        if (staffMatches && staffMatches.length > 0) {
          userData = staffMatches[0];
          isStaff = true;
        }
      }

      if (!userData) {
        const { count } = await supabase.from('users').select('*', { count: 'exact', head: true });
        if (count === 0) {
          setError(t('system_no_users' as any) || "System-ka ma laha wax users ah. Fadlan la xiriir maamulaha.");
        } else {
          setError(t('invalid_credentials' as any) || "Username ama Password-ka waa khalad.");
        }
        return;
      }

      console.log("User found, creating profile...");

      const profile: UserProfile = {
        uid: userData.uid || userData.id,
        username: userData.username,
        displayName: userData.display_name || userData.username || 'User',
        role: isStaff ? 'staff' : userData.role,
        tenantId: userData.tenant_id,
        createdAt: userData.created_at,
        email: userData.email,
        phone: userData.phone,
        photoURL: userData.photo_url,
        isStaff: isStaff || userData.is_staff || false,
        staffRoles: userData.roles || userData.staff_roles || [],
        isLocked: userData.is_locked || false,
        isExpired: userData.is_expired || false,
        planExpiry: userData.plan_expiry,
        branchId: userData.branch_id
      };

      // Check tenant status if applicable
      if (profile.tenantId) {
        const { data: tenantData } = await supabase
          .from('tenants')
          .select('*')
          .eq('id', profile.tenantId)
          .single();
          
        if (tenantData) {
          profile.isLocked = tenantData.is_locked || profile.isLocked || false;
          profile.planExpiry = tenantData.plan_expiry;
          profile.isExpired = tenantData.plan_expiry ? new Date(tenantData.plan_expiry) < new Date() : false;
        }
      }

      console.log("Login successful, role:", profile.role);
      localStorage.setItem('sahal_user', JSON.stringify(profile));
      onAuthSuccess(profile);
    } catch (err: any) {
      console.error("Login Error:", err);
      if (err.message && err.message.includes("Failed to fetch")) {
        setError("Khadka internet-kaaga ayaa go'an ama xiriirkii server-ka (Supabase URL / Key) ma shaqaynayo. Fadlan hubi netkaaga iyo Settings-ka.");
      } else if (err.message && err.message.includes("Invalid path specified in request URL")) {
        setError("URL-ka Supabase ee aad gelisay qaladaad ayaa ku jira. Fadlan hubi qeybta Settings > Secrets inuu URL-ku yahay qaabkan: https://XXXXX.supabase.co");
      } else {
        setError(err.message || "Login-ku wuu fashilmay.");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[var(--bg)] flex overflow-hidden lg:transition-colors lg:duration-300">
      <div className="hidden lg:flex lg:w-1/2 bg-[#0F172A] relative items-center justify-center p-12">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 left-0 w-96 h-96 bg-indigo-500 rounded-full blur-[120px] -translate-x-1/2 -translate-y-1/2" />
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-emerald-500 rounded-full blur-[120px] translate-x-1/2 translate-y-1/2" />
        </div>
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="relative z-10 text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-white/10 backdrop-blur-xl rounded-2xl border border-white/20 mb-8">
            <ShieldCheck size={40} className="text-white" />
          </div>
          <h1 className="text-6xl font-display font-bold text-white tracking-tight mb-6">SAHAL</h1>
          <p className="text-xl text-slate-400 max-w-md mx-auto font-light leading-relaxed">Nidaamka ugu casrisan ee maamulka ganacsiyada iyo isbitaalada.</p>
        </motion.div>
      </div>

      <div className="w-full lg:w-1/2 flex relative items-center justify-center p-8 bg-[var(--surface)] transition-colors duration-300">
        <div className="absolute top-8 right-8 z-10 flex items-center gap-4">
          <LanguageSelector />
        </div>
        {onBack && (
          <button 
            onClick={onBack}
            className="absolute top-8 left-8 sm:left-12 p-2 sm:px-4 sm:py-2 text-slate-500 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center gap-2 font-medium z-10"
            aria-label="Back to home"
          >
            <ArrowLeft size={20} />
            <span className="hidden sm:inline">{t('back_to_home' as any) || 'Ku Noqo Bilowga'}</span>
          </button>
        )}
        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="max-w-md w-full mt-12 sm:mt-0">
          <div className="mb-10">
            <h2 className="text-3xl font-display font-bold text-[var(--ink)] mb-2">{t('welcome_back')}</h2>
            <p className="text-slate-500">{t('login_instructions' as any) || 'Fadlan ku qor Username-ka iyo Password-ka laguu abuuray.'}</p>
          </div>

          {error && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="bg-red-50 dark:bg-red-950/20 border border-red-100 dark:border-red-900/30 rounded-xl p-4 mb-6 text-red-600 text-sm"
            >
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse mt-1.5 shrink-0" />
                <div className="flex-1">
                  <p className="font-bold mb-1">{t('error_occurred' as any) || 'Cilad baa dhacday'}</p>
                  <p>{error}</p>
                </div>
              </div>
            </motion.div>
          )}

          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="block text-sm font-bold text-slate-400 mb-2 ml-1 uppercase tracking-widest text-[10px]">{t('username')}</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400">
                  <User size={18} />
                </div>
                <input
                  type="text"
                  required
                  value={staffCreds.username}
                  onChange={(e) => setStaffCreds({...staffCreds, username: e.target.value})}
                  className="block w-full pl-11 pr-4 py-4 bg-[var(--bg)] border border-[var(--border)] rounded-xl text-[var(--ink)] focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none font-medium"
                  placeholder={t('username_placeholder') || 'Gali username-kaaga'}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-400 mb-2 ml-1 uppercase tracking-widest text-[10px]">{t('password')}</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400">
                  <Lock size={18} />
                </div>
                <input
                  type={showPassword ? "text" : "password"}
                  required
                  value={staffCreds.password}
                  onChange={(e) => setStaffCreds({...staffCreds, password: e.target.value})}
                  className="block w-full pl-11 pr-12 py-4 bg-[var(--bg)] border border-[var(--border)] rounded-xl text-[var(--ink)] focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none font-medium"
                  placeholder="••••••••"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-4 flex items-center text-slate-400 hover:text-slate-600 transition-colors"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-indigo-600 text-white py-4 px-6 rounded-xl hover:bg-indigo-700 transition-all duration-300 disabled:opacity-50 font-bold text-lg shadow-lg shadow-indigo-100 dark:shadow-none flex items-center justify-center gap-2"
              aria-label={t('sign_in')}
            >
              {loading ? (
                <div className="w-6 h-6 border-3 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  {t('sign_in' as any) || 'Gali System-ka'}
                  <ArrowRight size={20} />
                </>
              )}
            </button>
          </form>

          <div className="mt-12 pt-8 border-t border-[var(--border)] text-center">
            <p className="text-slate-400 text-sm">
              {t('need_help' as any) || 'Ma u baahan tahay caawinaad?'} <br/>
              <span className="text-slate-600 font-medium">{t('contact_manager_short' as any) || 'La xiriir maamulahaaga.'}</span>
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
