import React, { useState, useEffect } from 'react';
import { supabase } from '../supabase';
import { 
  CheckCircle2, 
  BarChart3, 
  ShieldCheck, 
  Zap, 
  ArrowRight, 
  Globe, 
  Smartphone, 
  Users,
  User,
  LayoutDashboard,
  Stethoscope,
  ShoppingCart,
  Receipt,
  Phone,
  Mail,
  MapPin,
  Sun,
  Moon
} from 'lucide-react';
import { motion } from 'motion/react';
import { LanguageSelector } from './LanguageSelector';
import { useLanguage } from './LanguageContext';
import { useTheme } from './ThemeContext';

interface TeamMember {
  id: string;
  name: string;
  role: string;
  imageUrl: string;
  phone?: string;
  email?: string;
}

interface LandingPageProps {
  onGetStarted: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onGetStarted }) => {
  const { t } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const [team, setTeam] = useState<TeamMember[]>([]);
  const [contact, setContact] = useState<{ pricingPhone?: string, demoUrl?: string } | null>(null);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('landing_settings')
        .select('*')
        .eq('id', 'global-settings')
        .single();
      
      if (data && !error) {
        if (data.team) setTeam(data.team);
        if (data.contact) setContact(data.contact);
      }
    } catch (error) {
      console.error('Error fetching landing settings:', error);
    }
  };

  return (
    <div className="min-h-screen bg-[var(--bg)] text-[var(--ink)] font-sans selection:bg-indigo-100 selection:text-indigo-600 transition-colors duration-300">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-surface-main/80 backdrop-blur-md z-50 border-b border-border-main transition-colors duration-300" role="navigation" aria-label="Main Navigation">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 sm:h-20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 sm:w-10 sm:h-10 bg-accent-main rounded-lg sm:rounded-xl flex items-center justify-center text-white shadow-lg shadow-accent-soft">
              <Zap className="w-5 h-5 sm:w-6 sm:h-6" fill="currentColor" aria-hidden="true" />
            </div>
            <span className="text-xl sm:text-2xl font-display font-black tracking-tighter uppercase text-ink">{t('sahal')}</span>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-sm font-bold text-ink-secondary hover:text-accent-main transition-colors" aria-label="View Features">{t('features')}</a>
            <a href="#pricing" className="text-sm font-bold text-ink-secondary hover:text-accent-main transition-colors" aria-label="View Pricing">{t('pricing')}</a>
            <button 
              onClick={toggleTheme}
              className="p-2 text-ink-tertiary hover:text-accent-main hover:bg-accent-soft rounded-lg transition-all"
              title={theme === 'light' ? 'Switch to Dark Mode' : 'Switch to Light Mode'}
            >
              {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
            </button>
            <LanguageSelector />
            <button 
              onClick={onGetStarted}
              className="px-6 py-2.5 bg-accent-main text-white rounded-full font-bold text-sm hover:bg-accent-hover transition-all shadow-lg shadow-accent-soft"
              aria-label="Get Started with SAHAL"
            >
              {t('get_started')}
            </button>
          </div>
          <div className="md:hidden flex items-center gap-3">
            <button 
              onClick={toggleTheme}
              className="p-2 text-ink-tertiary hover:text-accent-main transition-all"
            >
              {theme === 'light' ? <Moon size={18} /> : <Sun size={18} />}
            </button>
            <LanguageSelector />
            <button 
              onClick={onGetStarted}
              className="px-4 py-2 bg-indigo-600 text-white rounded-full font-bold text-xs hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
              aria-label="Get Started"
            >
              {t('get_started')}
            </button>
          </div>
        </div>
      </nav>

      <main>
        {/* Hero Section */}
        <section className="pt-32 pb-16 sm:pt-40 sm:pb-20 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="px-4 py-1.5 bg-accent-soft text-accent-main rounded-full text-[10px] sm:text-xs font-black uppercase tracking-widest mb-6 inline-block">
              {t('ultimate_os')}
            </span>
            <h1 className="text-4xl sm:text-6xl md:text-8xl font-display font-black tracking-tighter leading-[1] sm:leading-[0.9] mb-6 sm:mb-8 uppercase text-ink">
              {t('hero_title').split('<br />')[0]} <br className="hidden sm:block" />
              <span className="text-accent-main">{t('hero_title').split('<br />')[1] || ''}</span>
            </h1>
            <p className="max-w-2xl mx-auto text-base sm:text-lg text-ink-secondary font-medium mb-8 sm:mb-10 leading-relaxed">
              {t('hero_desc')}
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button 
                onClick={onGetStarted}
                className="w-full sm:w-auto px-8 sm:px-10 py-4 sm:py-5 bg-accent-main text-white rounded-2xl font-bold text-lg hover:bg-accent-hover transition-all shadow-xl shadow-accent-soft flex items-center justify-center gap-3 group"
              >
                {t('start_now')}
                <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </button>
              <button 
                className="w-full sm:w-auto px-8 sm:px-10 py-4 sm:py-5 bg-surface-main text-ink border-2 border-border-main rounded-2xl font-bold text-lg hover:bg-bg-sec transition-all flex items-center justify-center gap-3 group"
                onClick={() => window.open(contact?.demoUrl || 'https://www.youtube.com', '_blank')}
              >
                <Zap size={20} className="text-accent-main" />
                {t('watch_demo')}
              </button>
            </div>
          </motion.div>

          {/* Dashboard Preview */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="mt-20 relative"
          >
            <div className="absolute -inset-4 bg-gradient-to-b from-indigo-500/20 to-transparent blur-3xl -z-10 rounded-[3rem]" />
            <div className="bg-slate-900 rounded-[2.5rem] p-4 shadow-2xl border border-slate-800 overflow-hidden">
              <div className="bg-slate-800/50 rounded-[1.5rem] aspect-video flex items-center justify-center overflow-hidden">
                <img 
                  src="https://picsum.photos/seed/dashboard/1200/800" 
                  alt="SAHAL Dashboard Preview" 
                  className="w-full h-full object-cover opacity-80"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-20 h-20 bg-white/10 backdrop-blur-md rounded-full flex items-center justify-center text-white border border-white/20 cursor-pointer hover:scale-110 transition-transform">
                    <Zap size={32} fill="currentColor" />
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-32 bg-bg-sec">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-5xl font-display font-black tracking-tight mb-4 uppercase text-ink">{t('why_sahal')}</h2>
            <p className="text-ink-secondary font-medium">{t('why_sahal_desc')}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: LayoutDashboard,
                title: t('modern_dashboard'),
                desc: t('modern_dashboard_desc'),
                color: "bg-blue-500"
              },
              {
                icon: Stethoscope,
                title: t('hospital_mgmt'),
                desc: t('hospital_mgmt_desc'),
                color: "bg-emerald-500"
              },
              {
                icon: ShoppingCart,
                title: t('inventory_sales'),
                desc: t('inventory_sales_desc'),
                color: "bg-amber-500"
              },
              {
                icon: Receipt,
                title: t('accounts_tax'),
                desc: t('accounts_tax_desc'),
                color: "bg-indigo-500"
              },
              {
                icon: Users,
                title: t('staff_mgmt'),
                desc: t('staff_mgmt_desc'),
                color: "bg-rose-500"
              },
              {
                icon: Smartphone,
                title: t('mobile_ready'),
                desc: t('mobile_ready_desc'),
                color: "bg-purple-500"
              }
            ].map((feature, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -10, scale: 1.02 }}
                className="bg-surface-main p-10 rounded-[2.5rem] border border-border-subtle shadow-sm hover:shadow-2xl transition-all group"
              >
                <div className={`w-14 h-14 ${feature.color} rounded-2xl flex items-center justify-center text-white mb-6 shadow-lg group-hover:scale-110 transition-transform`}>
                  <feature.icon size={28} />
                </div>
                <h3 className="text-xl font-display font-black mb-4 uppercase tracking-tight text-ink">{feature.title}</h3>
                <p className="text-ink-secondary font-medium leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-32">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-5xl font-display font-black tracking-tight mb-4 uppercase">{t('pricing_plans')}</h2>
            <p className="text-slate-500 font-medium">{t('pricing_plans_desc')}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {[
              {
                name: t('monthly'),
                price: t('negotiable'),
                period: t('month'),
                features: [t('all_modules'), t('unlimited_staff'), t('support_247'), t('mobile_ready'), t('cloud_storage')],
                popular: true
              },
              {
                name: t('yearly'),
                price: t('negotiable'),
                period: t('year'),
                features: [t('all_modules'), t('unlimited_staff'), t('support_247'), t('mobile_ready'), t('priority_support'), t('free_training')],
                popular: false
              }
            ].map((plan, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2 }}
                className={`relative p-10 rounded-[3rem] border-2 transition-all ${
                  plan.popular 
                    ? 'border-indigo-600 bg-indigo-600 text-white shadow-2xl shadow-indigo-200 scale-105 z-10' 
                    : 'border-slate-100 bg-white text-slate-900 hover:border-indigo-200'
                }`}
              >
                {plan.popular && (
                  <span className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-amber-400 text-slate-900 text-[10px] font-black uppercase tracking-widest rounded-full">
                    {t('most_popular')}
                  </span>
                )}
                <h3 className="text-2xl font-display font-black mb-2 uppercase tracking-tight">{plan.name}</h3>
                <div className="flex items-baseline gap-1 mb-8">
                  <span className="text-5xl font-display font-black">{plan.price}</span>
                  <span className={`text-sm font-bold ${plan.popular ? 'text-indigo-100' : 'text-slate-400'}`}>/ {plan.period}</span>
                </div>
                <ul className="space-y-4 mb-10">
                  {plan.features.map((f, j) => (
                    <li key={j} className="flex items-center gap-3 text-sm font-medium">
                      <CheckCircle2 size={18} className={plan.popular ? 'text-indigo-200' : 'text-indigo-600'} />
                      {f}
                    </li>
                  ))}
                </ul>
                <a 
                  href={contact?.pricingPhone ? `https://wa.me/${contact.pricingPhone.replace(/\D/g, '')}` : "https://wa.me/252619476309"}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`w-full py-4 rounded-2xl font-bold transition-all text-center block ${
                    plan.popular 
                      ? 'bg-white text-indigo-600 hover:bg-slate-50' 
                      : 'bg-slate-900 text-white hover:bg-slate-800'
                  }`}
                >
                  {t('contact_whatsapp')}
                </a>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-32 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-5xl font-display font-black tracking-tight mb-4 uppercase">{t('testimonials')}</h2>
            <p className="text-slate-500 font-medium">{t('testimonials_desc')}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: "Dr. Ahmed Ali",
                role: "Maamulaha Isbitaalka Banaadir",
                text: "SAHAL wuxuu wax weyn ka beddelay habka aan u maamulno bukaannada. Hadda wax walba waa digital oo isku xiran.",
                avatar: "https://picsum.photos/seed/dr/100/100"
              },
              {
                name: "Fartuun Hassan",
                role: "Milkiilaha Farmashiyaha SAHAL",
                text: "Iibka iyo bakhaarka maamulkooda hadda waa mid aad u fudud. Waxaan ka arki karaa mobile-kayga meel kasta oo aan joogo.",
                avatar: "https://picsum.photos/seed/pharm/100/100"
              },
              {
                name: "Mohamed Farah",
                role: "Maamulaha Retail Store",
                text: "Warbixinada maaliyadeed ee SAHAL waxay iga caawiyeen inaan fahmo dakhligayga iyo kharashkayga si dhab ah.",
                avatar: "https://picsum.photos/seed/retail/100/100"
              }
            ].map((t, i) => (
              <div key={i} className="p-10 rounded-[2.5rem] bg-slate-50 border border-slate-100">
                <div className="flex items-center gap-4 mb-6">
                  <img src={t.avatar} alt={t.name} className="w-14 h-14 rounded-2xl object-cover" referrerPolicy="no-referrer" />
                  <div>
                    <h4 className="font-display font-bold text-slate-900">{t.name}</h4>
                    <p className="text-xs text-slate-400 font-medium">{t.role}</p>
                  </div>
                </div>
                <p className="text-slate-600 font-medium italic leading-relaxed">"{t.text}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      {team.length > 0 && (
        <section id="team" className="py-32 bg-white">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-20">
              <span className="px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-[9px] font-black uppercase tracking-widest mb-3 inline-block">
                {t('team_section_badge')}
              </span>
              <h2 className="text-4xl md:text-5xl font-display font-black tracking-tight mb-4 uppercase text-slate-900">{t('team_section_title')}</h2>
              <p className="text-slate-500 font-medium">{t('team_section_subtitle')}</p>
            </div>
            <div className="flex flex-wrap justify-center gap-12 sm:gap-20">
              {team.map((member) => (
                <div key={member.id} className="group text-center w-full sm:w-64">
                  <div className="w-40 h-40 mx-auto rounded-3xl overflow-hidden mb-6 bg-slate-100 shadow-xl border border-slate-200">
                    {member.imageUrl ? (
                      <img src={member.imageUrl} alt={member.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-slate-400">
                        <User size={48} />
                      </div>
                    )}
                  </div>
                  <h4 className="text-xl font-display font-bold text-slate-900">{member.name}</h4>
                  <p className="text-sm font-bold text-indigo-600 uppercase tracking-widest mb-4">{member.role}</p>
                  <div className="flex items-center justify-center gap-3">
                    {member.phone && (
                      <a href={`https://wa.me/${member.phone.replace(/\D/g, '')}`} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-slate-600 hover:bg-indigo-50 hover:text-indigo-600 transition-colors" title="Contact via Phone/WhatsApp">
                        <Phone size={18} />
                      </a>
                    )}
                    {member.email && (
                      <a href={`mailto:${member.email}`} className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-slate-600 hover:bg-emerald-50 hover:text-emerald-600 transition-colors" title="Contact via Email">
                        <Mail size={18} />
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* FAQ Section */}
      <section id="faq" className="py-32 bg-slate-50">
        <div className="max-w-3xl mx-auto px-6">
          <div className="text-center mb-20">
            <h2 className="text-4xl font-display font-black tracking-tight mb-4 uppercase">{t('faq')}</h2>
            <p className="text-slate-500 font-medium">{t('faq_desc')}</p>
          </div>

          <div className="space-y-6">
            {[
              {
                q: t('faq_q1'),
                a: t('faq_a1')
              },
              {
                q: t('faq_q2'),
                a: t('faq_a2')
              },
              {
                q: t('faq_q3'),
                a: t('faq_a3')
              },
              {
                q: t('faq_q4'),
                a: t('faq_a4')
              }
            ].map((faq, i) => (
              <div key={i} className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
                <h4 className="font-display font-bold text-lg text-slate-900 mb-3">{faq.q}</h4>
                <p className="text-slate-500 font-medium text-sm leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      </main>

      {/* Footer */}
      <footer className="py-20 bg-slate-900 text-white" role="contentinfo">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <div className="flex items-center justify-center gap-2 mb-8">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white">
              <Zap size={24} fill="currentColor" />
            </div>
            <span className="text-2xl font-display font-black tracking-tighter uppercase">SAHAL</span>
          </div>
          <p className="text-slate-400 max-w-md mx-auto mb-10 font-medium">
            SAHAL waa saaxiibka ganacsigaaga. Waxaan kaa caawinaynaa inaad ganacsigaaga u maamusho si casri ah oo fudud.
          </p>
          <div className="flex justify-center gap-6 mb-10">
            <Globe className="text-slate-500 hover:text-white cursor-pointer transition-colors" />
            <Smartphone className="text-slate-500 hover:text-white cursor-pointer transition-colors" />
            <ShieldCheck className="text-slate-500 hover:text-white cursor-pointer transition-colors" />
          </div>
          <div className="pt-10 border-t border-slate-800 text-slate-500 text-xs font-bold uppercase tracking-widest">
            {t('all_rights_reserved')}
          </div>
        </div>
      </footer>
    </div>
  );
};
