import React, { useState, useEffect, Suspense, lazy } from 'react';
import { UserProfile, Tenant } from '../types';
import { supabase } from '../supabase';
import { 
  LayoutDashboard, 
  Users, 
  Building2, 
  Package, 
  LogOut, 
  Settings, 
  Menu, 
  X,
  ShoppingCart,
  Receipt,
  Wallet,
  PieChart,
  ShieldCheck,
  Stethoscope,
  CreditCard,
  DollarSign,
  AlertTriangle,
  UserCircle,
  Activity,
  Briefcase,
  TrendingUp,
  FileText,
  CheckSquare,
  Lightbulb,
  Droplets,
  Zap,
  Search,
  Bot,
  Phone,
  Sun,
  Moon,
  Globe
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { LanguageSelector } from './LanguageSelector';
import { useLanguage } from './LanguageContext';
import { useTheme } from './ThemeContext';
const SuperAdminDashboard = lazy(() => import('./SuperAdminDashboard'));
const SystemManagerDashboard = lazy(() => import('./SystemManagerDashboard'));
const BusinessDashboard = lazy(() => import('./BusinessDashboard'));

interface SidebarItemProps {
  icon: React.ReactNode;
  label: string;
  active: boolean;
  onClick: () => void;
  key?: string | number;
}

const SidebarItem = ({ icon, label, active, onClick }: SidebarItemProps) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 text-sm font-medium ${
      active 
        ? 'bg-accent-main text-white shadow-lg shadow-accent-soft' 
        : 'text-ink-secondary hover:bg-bg-sec hover:text-ink'
    }`}
  >
    <div className="flex-shrink-0 w-[var(--icon-md)] h-[var(--icon-md)]">
      {icon}
    </div>
    <span>{label}</span>
  </button>
);

const NavItem = ({ icon, label, active, onClick }: SidebarItemProps) => (
  <button
    onClick={onClick}
    className={`flex items-center gap-2 px-3 py-1.5 rounded-lg transition-all duration-200 text-[10px] font-bold uppercase tracking-tight whitespace-nowrap ${
      active 
        ? 'bg-accent-main text-white shadow-sm ring-1 ring-accent-main' 
        : 'text-ink-secondary hover:bg-bg-sec hover:text-ink'
    }`}
  >
    <div className="flex-shrink-0 w-3.5 h-3.5">
      {icon}
    </div>
    <span>{label}</span>
  </button>
);

export default function Dashboard({ user, onLogout, managerPhone }: { user: UserProfile, onLogout: () => void, managerPhone?: string }) {
  const { t } = useLanguage();
  const { theme, toggleTheme, fontSize, setFontSize } = useTheme();
  const [isSidebarOpen, setIsSidebarOpen] = useState(window.innerWidth >= 1024);
  const [tenant, setTenant] = useState<Tenant | null>(null);
  const [activeTab, setActiveTab] = useState(() => {
    if (user.isStaff && user.staffRoles && user.staffRoles.length > 0) {
      return user.staffRoles[0];
    }
    return 'overview';
  });
  const [initialSearch, setInitialSearch] = useState('');
  const [initialModuleTab, setInitialModuleTab] = useState<string | undefined>(undefined);

  const handleWhatsAppContact = () => {
    if (!managerPhone) return;
    const cleanPhone = managerPhone.replace(/\D/g, '');
    const message = encodeURIComponent(`Salaan, waxaan u baahanahay caawimaad ku saabsan akoonkayga SAHAL.`);
    window.open(`https://wa.me/${cleanPhone}?text=${message}`, '_blank');
  };

  useEffect(() => {
    const fetchTenant = async () => {
      if ((user.role === 'business_user' || user.role === 'staff') && user.tenantId) {
        const { data: tenantData } = await supabase
          .from('tenants')
          .select('*')
          .eq('id', user.tenantId)
          .single();
        if (tenantData) {
          setTenant(tenantData as Tenant);
        }
      }
    };
    fetchTenant();
  }, [user]);

  const handleLogout = () => onLogout();

  const renderContent = () => {
    switch (user.role) {
      case 'super_admin':
        return <SuperAdminDashboard activeTab={activeTab} user={user} setActiveTab={setActiveTab} />;
      case 'system_manager':
        return <SystemManagerDashboard activeTab={activeTab} user={user} />;
      case 'business_user':
      case 'staff':
        return <BusinessDashboard 
          activeTab={activeTab} 
          user={user} 
          setActiveTab={setActiveTab} 
          managerPhone={managerPhone} 
          initialSearch={initialSearch}
          setInitialSearch={setInitialSearch}
          initialModuleTab={initialModuleTab}
          setInitialModuleTab={setInitialModuleTab}
        />;
      default:
        return <div>{t('unauthorized')}</div>;
    }
  };

  const getSidebarItems = () => {
    if (user.role === 'super_admin') {
      return [
        { id: 'overview', label: t('dashboard'), icon: <LayoutDashboard className="w-full h-full" /> },
        { id: 'business', label: t('business_management'), icon: <Building2 className="w-full h-full" /> },
        { id: 'users', label: t('staff_management'), icon: <Users className="w-full h-full" /> },
        { id: 'landing_page', label: t('landing_page' as any) || 'Landing Page', icon: <Globe className="w-full h-full" /> },
        { id: 'managers_performance', label: t('managers_performance'), icon: <PieChart className="w-full h-full" /> },
        { id: 'branch_performance', label: t('branch_performance'), icon: <Activity className="w-full h-full" /> },
      ];
    }
    if (user.role === 'system_manager') {
      return [
        { id: 'overview', label: t('dashboard'), icon: <LayoutDashboard className="w-full h-full" /> },
        { id: 'business', label: t('business_portfolio'), icon: <Building2 className="w-full h-full" /> },
        { id: 'settings', label: t('settings'), icon: <Settings className="w-full h-full" /> },
      ];
    }
    
    const businessItems = [
      { id: 'overview', label: t('dashboard'), icon: <LayoutDashboard className="w-full h-full" /> },
      { id: 'inventory', label: t('inventory'), icon: <Package className="w-full h-full" />, module: 'inventory' },
      { id: 'sales', label: t('sales'), icon: <ShoppingCart className="w-full h-full" />, module: 'sales' },
      { id: 'services', label: t('services'), icon: <Briefcase className="w-full h-full" />, module: 'services' },
      { id: 'debts', label: t('debts'), icon: <Wallet className="w-full h-full" />, module: 'debts' },
      { id: 'expenses', label: t('expenses'), icon: <Receipt className="w-full h-full" />, module: 'expenses' },
      { id: 'finance', label: t('finance_management' as any) || 'Finance', icon: <DollarSign className="w-full h-full" /> },
      { id: 'crm', label: t('crm'), icon: <UserCircle className="w-full h-full" />, module: 'crm' },
      { id: 'hospital', label: tenant ? tenant.name : t('hospital_name'), icon: <Stethoscope className="w-full h-full" />, module: 'hospital' },
      { id: 'saving', label: t('saving_module'), icon: <Wallet className="w-full h-full" />, module: 'saving' },
      { id: 'investment', label: t('investment'), icon: <Activity className="w-full h-full" />, module: 'investment' },
      { id: 'working_note', label: t('working_note'), icon: <FileText className="w-full h-full" />, module: 'working_note' },
      { id: 'daily_task', label: t('daily_task'), icon: <CheckSquare className="w-full h-full" />, module: 'daily_task' },
      { id: 'keeping_ideas', label: t('keeping_ideas'), icon: <Lightbulb className="w-full h-full" />, module: 'keeping_ideas' },
      { id: 'utility_water', label: t('utility_water'), icon: <Droplets className="w-full h-full" />, module: 'utility_water' },
      { id: 'utility_electricity', label: t('utility_electricity'), icon: <Zap className="w-full h-full" />, module: 'utility_electricity' },
      { id: 'reports', label: t('reports'), icon: <PieChart className="w-full h-full" />, module: 'reports' },
      { id: 'users', label: t('staff_management'), icon: <Users className="w-full h-full" /> },
      { id: 'ai_assistant', label: t('ai_assistant'), icon: <Bot className="w-full h-full" /> },
      { id: 'company', label: t('company'), icon: <TrendingUp className="w-full h-full" /> },
      { id: 'subscription', label: t('subscription'), icon: <CreditCard className="w-full h-full" /> },
      { id: 'business', label: t('settings'), icon: <Settings className="w-full h-full" /> },
    ];

    // Filter based on tenant modules if tenant data is available
    if (user.role === 'business_user' || user.role === 'staff') {
      if (!tenant) return []; // Don't show modules until tenant data is loaded
      
      let filteredItems = businessItems.filter(item => {
        if (!item.module) return true; // Always show overview, users, settings, and non-module items
        return tenant.modules[item.module as keyof typeof tenant.modules];
      });

      if (user.isStaff) {
        filteredItems = filteredItems.filter(item => {
          if (item.id === 'overview' || item.id === 'business' || item.id === 'help_center') return true;
          if (user.staffRoles?.includes(item.id)) return true;
          // Special check for modules with sub-roles
          if (item.id === 'hospital' && user.staffRoles?.some(role => role.startsWith('hospital_'))) return true;
          if ((item.id === 'utility_water' || item.id === 'utility_electricity') && user.staffRoles?.includes(item.id)) return true;
          return false;
        });
      }
      
      if (managerPhone) {
        filteredItems.push({
          id: 'help_center',
          label: t('help_center' as any) || 'Help Center',
          icon: <Phone className="w-full h-full" />
        });
      }
      
      return filteredItems;
    }

    if (managerPhone) {
      businessItems.push({
        id: 'help_center',
        label: t('help_center' as any) || 'Help Center',
        icon: <Phone className="w-full h-full" />
      });
    }

    return businessItems;
  };

  const SubscriptionAlert = () => {
    if (user.role !== 'business_user' && user.role !== 'staff') return null;
    
    const endDateStr = user.subscription?.endDate || user.planExpiry;
    if (!endDateStr) return null;
    
    const endDate = new Date(endDateStr);
    const now = new Date();
    const diffTime = endDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays > 7) return null;
    
    return (
      <div className={`mb-8 p-4 rounded-2xl flex items-center gap-4 border ${
        diffDays <= 0 
          ? 'bg-red-50 dark:bg-red-950/20 border-red-100 dark:border-red-900/30 text-red-600 dark:text-red-400' 
          : 'bg-amber-50 dark:bg-amber-950/20 border-amber-100 dark:border-amber-900/30 text-amber-600 dark:text-amber-400'
      }`}>
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
          diffDays <= 0 ? 'bg-red-100' : 'bg-amber-100'
        }`}>
          <AlertTriangle size={20} />
        </div>
        <div className="flex-1">
          <p className="text-sm font-bold uppercase tracking-wider mb-0.5">
            {diffDays <= 0 ? t('subscription_expired') : t('subscription_expiring_soon')}
          </p>
          <p className="text-xs font-medium opacity-80">
            {diffDays <= 0 
              ? t('subscription_expired_desc') 
              : t('subscription_expiring_desc').replace('{days}', diffDays.toString())}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {managerPhone && (
            <button 
              onClick={handleWhatsAppContact}
              className="px-4 py-2 bg-[#25D366] text-white rounded-xl hover:bg-[#128C7E] transition-all shadow-sm flex items-center gap-2 text-xs font-bold"
              title={t('contact_whatsapp')}
            >
              <Phone size={16} />
              <span className="hidden sm:inline">WhatsApp: {managerPhone}</span>
            </button>
          )}
          <button 
            onClick={() => setActiveTab('subscription')}
            className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-widest transition-all ${
              diffDays <= 0 
                ? 'bg-red-600 text-white hover:bg-red-700' 
                : 'bg-amber-600 text-white hover:bg-amber-700'
            }`}
          >
            {t('renew_now')}
          </button>
        </div>
      </div>
    );
  };

  const LimitedStatusAlert = () => {
    if (user.role !== 'business_user' || !tenant || tenant.status !== 'limited') return null;
    
    return (
      <div className="fixed inset-0 bg-slate-900/90 backdrop-blur-md z-[100] flex items-center justify-center p-6 text-center">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="max-w-md w-full bg-white rounded-3xl p-8 shadow-2xl"
        >
          <div className="w-20 h-20 bg-red-100 rounded-2xl flex items-center justify-center text-red-600 mx-auto mb-6">
            <AlertTriangle size={40} />
          </div>
          <h2 className="text-2xl font-display font-bold text-ink mb-4">{t('restricted_access')}</h2>
          <p className="text-ink-tertiary mb-8 leading-relaxed">
            {t('limited_desc')}
          </p>
          <button 
            onClick={handleLogout}
            className="w-full py-4 bg-ink text-white rounded-2xl font-bold hover:bg-ink-secondary transition-all flex items-center justify-center gap-3"
          >
            <LogOut size={20} />
            <span>{t('sign_out')}</span>
          </button>
        </motion.div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-[var(--bg)] flex transition-colors duration-300">
      <LimitedStatusAlert />
      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-40 lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <AnimatePresence mode="wait">
        {isSidebarOpen && (
          <motion.aside
            initial={{ x: -280 }}
            animate={{ x: 0 }}
            exit={{ x: -280 }}
            className="fixed lg:relative z-50 w-72 h-screen bg-[var(--surface)] border-r border-[var(--border)] flex flex-col shadow-2xl lg:shadow-none no-print transition-colors duration-300"
          >
            <div className="p-8 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-accent-main rounded-xl text-white flex items-center justify-center shadow-lg shadow-accent-soft overflow-hidden">
                  {tenant?.logo_url ? (
                    <img 
                      src={tenant.logo_url} 
                      alt="Logo" 
                      className="w-full h-full object-contain bg-white" 
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <ShieldCheck className="w-[var(--icon-md)] h-[var(--icon-md)]" />
                  )}
                </div>
                <span className="font-display font-bold text-xl tracking-tight text-ink truncate max-w-[150px]">
                  {tenant ? tenant.name : 'SAHAL'}
                </span>
              </div>
              <button onClick={() => setIsSidebarOpen(false)} className="p-2 hover:bg-bg-sec rounded-xl transition-all">
                <X className="w-[var(--icon-md)] h-[var(--icon-md)] text-ink-secondary" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-4 py-2">
              <div className="mb-8">
                <p className="px-4 text-[10px] font-bold uppercase tracking-[0.2em] text-ink-tertiary mb-4">{t('main_menu')}</p>
                <div className="space-y-1">
                  {getSidebarItems().map((item) => (
                    <SidebarItem
                      key={item.id}
                      icon={item.icon}
                      label={item.label}
                      active={activeTab === item.id}
                      onClick={() => {
                        if ((item as any).action) {
                          (item as any).action();
                        } else {
                          setActiveTab(item.id);
                          if (window.innerWidth < 1024) setIsSidebarOpen(false);
                        }
                      }}
                    />
                  ))}
                </div>
              </div>
            </div>

            <div className="p-6 mt-auto">
              <div className="bg-[var(--bg)] rounded-2xl p-4 mb-4 transition-colors duration-300">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-[var(--surface)] border border-[var(--border)] flex items-center justify-center text-sm font-bold text-indigo-600 shadow-sm">
                    {user.displayName?.[0] || t('n_a')}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-[var(--ink)] truncate">{user.displayName}</p>
                    <p className="text-[10px] font-medium uppercase text-ink-tertiary truncate tracking-wider">
                      {t(`role_${user.role.replace('business_', '')}` as any) || user.role.replace('_', ' ')}
                    </p>
                  </div>
                </div>
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-[var(--surface)] border border-[var(--border)] rounded-xl text-red-500 hover:bg-red-50 dark:hover:bg-red-950/20 hover:border-red-100 transition-all text-xs font-semibold"
                >
                  <LogOut size={14} />
                  <span>{t('sign_out')}</span>
                </button>
              </div>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        <header className="h-20 bg-surface-main/80 backdrop-blur-md border-b border-border-main flex items-center justify-between px-4 sm:px-8 sticky top-0 z-40 no-print transition-colors duration-300">
          <div className="flex items-center gap-6 flex-1">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)} 
              className={`p-2.5 hover:bg-bg-sec rounded-xl border border-border-main transition-all ${isSidebarOpen ? 'bg-bg-sec border-accent-main/30' : ''}`}
              aria-label={isSidebarOpen ? "Close Sidebar" : "Open Sidebar"}
            >
              <Menu className="w-[var(--icon-md)] h-[var(--icon-md)] text-ink-secondary" />
            </button>
            <div className="hidden md:flex items-center gap-6 flex-1">
              <div className="flex items-center gap-3 bg-bg-sec border border-border-main px-4 py-2 rounded-xl w-full max-w-md group focus-within:border-accent-main/30 shadow-sm transition-all">
                <Search className="w-[var(--icon-sm)] h-[var(--icon-sm)] text-ink-tertiary group-focus-within:text-accent-main" aria-hidden="true" />
                <input 
                  type="text" 
                  placeholder={t('search_placeholder') || 'Search anything...'} 
                  className="bg-transparent border-none focus:ring-0 text-sm w-full placeholder:text-ink-tertiary text-ink"
                  aria-label="Search"
                />
              </div>

              {tenant && (
                <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 bg-bg-sec border border-border-main rounded-xl">
                  <div className="w-5 h-5 rounded bg-accent-main flex items-center justify-center overflow-hidden">
                    {tenant.logo_url ? (
                      <img src={tenant.logo_url} alt="" className="w-full h-full object-contain" />
                    ) : (
                      <ShieldCheck className="w-3 h-3 text-white" />
                    )}
                  </div>
                  <span className="text-[10px] font-bold text-ink uppercase tracking-wider truncate max-w-[120px]">{tenant.name}</span>
                </div>
              )}
            </div>
            <div className="md:hidden">
              <h2 className="text-lg font-display font-bold text-ink capitalize">
                {t(activeTab as any) || activeTab.replace('-', ' ')}
              </h2>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 mr-4 text-right">
              <div>
                <p className="text-sm font-bold text-ink">{user.displayName}</p>
                <p className="text-[10px] font-medium uppercase text-ink-tertiary tracking-wider">
                  {t(`role_${user.role.replace('business_', '')}` as any) || user.role.replace('_', ' ')}
                </p>
              </div>
            </div>
            
            <button
              onClick={toggleTheme}
              className="p-2.5 hover:bg-bg-sec rounded-xl border border-border-main transition-colors text-ink-secondary"
              aria-label="Toggle Theme"
            >
              {theme === 'light' ? <Moon className="w-[var(--icon-md)] h-[var(--icon-md)]" /> : <Sun className="w-[var(--icon-md)] h-[var(--icon-md)]" />}
            </button>
 
            {/* Font Size Selector */}
            <div className="hidden lg:flex items-center bg-bg-sec border border-border-main rounded-xl overflow-hidden p-0.5">
              {(['small', 'normal', 'large'] as const).map((size) => (
                <button
                  key={size}
                  onClick={() => setFontSize(size)}
                  className={`px-3 py-1.5 text-[10px] font-bold uppercase transition-all rounded-lg ${
                    fontSize === size 
                      ? 'bg-accent-main text-white shadow-sm' 
                      : 'text-ink-tertiary hover:text-ink'
                  }`}
                >
                  {t(size as any)}
                </button>
              ))}
            </div>

            <LanguageSelector />
            <button 
              onClick={() => setActiveTab('business')}
              className="p-2.5 hover:bg-bg-sec rounded-xl border border-border-main transition-colors text-ink-secondary relative group"
              aria-label="Settings"
            >
              <Settings size={20} />
              <span className="absolute top-0 right-0 w-2 h-2 bg-indigo-500 rounded-full border-2 border-surface-main" />
            </button>
            <button
              onClick={handleLogout}
              className="lg:hidden p-2.5 hover:bg-red-50 dark:hover:bg-red-950/20 rounded-xl border border-border-main transition-colors text-red-500 group"
              aria-label={t('sign_out')}
            >
              <LogOut size={20} />
            </button>
          </div>
        </header>

        {/* Horizontal Nav Bar for PC - Compact */}
        <div className="hidden lg:flex items-center gap-1 px-8 py-2 bg-surface-main/50 backdrop-blur-sm border-b border-border-main overflow-x-auto no-scrollbar no-print sticky top-20 z-30 transition-all">
          {getSidebarItems().map((item) => (
            <NavItem 
              key={item.id}
              icon={item.icon}
              label={item.label}
              active={activeTab === item.id}
              onClick={() => {
                if ((item as any).action) {
                  (item as any).action();
                } else {
                  setActiveTab(item.id);
                }
              }}
            />
          ))}
          <div className="ml-auto flex items-center pl-4 border-l border-border-main">
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg transition-all duration-200 text-[10px] font-bold uppercase tracking-tight whitespace-nowrap text-red-500 hover:bg-red-50 dark:hover:bg-red-950/20"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>{t('sign_out')}</span>
            </button>
          </div>
        </div>

        <main className="flex-1 overflow-y-auto p-4 sm:p-8 lg:p-12 scroll-smooth">
          <SubscriptionAlert />
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Suspense fallback={
              <div className="flex items-center justify-center p-20">
                <div className="w-10 h-10 border-4 border-bg-sec border-t-indigo-600 rounded-full animate-spin" />
              </div>
            }>
              {renderContent()}
            </Suspense>
          </motion.div>
        </main>
      </div>
    </div>
  );
}
