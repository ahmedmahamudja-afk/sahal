import React, { useState, useEffect } from 'react';
import { supabase } from '../supabase';
import { Tenant, UserProfile, StaffMember, SubscriptionPlan, Branch } from '../types';
import { getDefaultModulesForBusinessType } from '../utils/moduleHelpers';
import { Plus, Building2, Users, Activity, ArrowUpRight, Search, Filter, X as CloseIcon, Check, Key, Trash2, Shield, UserPlus, ChevronRight, AlertCircle, Edit2, ShieldCheck, DollarSign, Eye, EyeOff, Lock, AlertTriangle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from './LanguageContext';
import Modal from './Modal';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';

import LandingPageManager from './LandingPageManager';

import { is9DigitNumber, checkUsernameExists, USERNAME_FORMAT_ERROR, USERNAME_EXISTS_ERROR } from '../lib/validation';

const StatCard = ({ label, value, icon, trend, color }: any) => (
  <div className="sahal-card p-8 group hover:border-indigo-500/30 transition-all">
    <div className="flex justify-between items-start mb-6">
      <div className={`p-4 rounded-2xl ${color} group-hover:scale-110 transition-transform text-white`}>
        {icon}
      </div>
      {trend && (
        <div className="flex items-center gap-1 text-emerald-600 bg-emerald-50 px-3 py-1.5 rounded-full text-xs font-bold">
          <ArrowUpRight size={14} />
          {trend}
        </div>
      )}
    </div>
    <h3 className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-2">{label}</h3>
    <p className="text-4xl font-display font-bold text-slate-900">{value}</p>
  </div>
);

export default function SuperAdminDashboard({ activeTab, user, setActiveTab }: { activeTab: string, user: UserProfile, setActiveTab: (tab: string) => void }) {
  const { t } = useLanguage();
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [managers, setManagers] = useState<UserProfile[]>([]);
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [allStaff, setAllStaff] = useState<StaffMember[]>([]);
  const [allBranches, setAllBranches] = useState<Branch[]>([]);
  const [allSales, setAllSales] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Modal States
  const [isBusinessModalOpen, setIsBusinessModalOpen] = useState(false);
  const [editingBusiness, setEditingBusiness] = useState<Tenant | null>(null);
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<UserProfile | null>(null);
  const [showBusinessPassword, setShowBusinessPassword] = useState(false);
  const [showUserPassword, setShowUserPassword] = useState(false);
  
  const [isCustomType, setIsCustomType] = useState(false);

  // Confirmation Modal State
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  const openConfirm = (title: string, message: string, onConfirm: () => void) => {
    setConfirmModal({
      isOpen: true,
      title,
      message,
      onConfirm: () => {
        onConfirm();
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const RenderConfirmModal = () => (
    <Modal 
      isOpen={confirmModal.isOpen} 
      onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))} 
      title={confirmModal.title}
    >
      <div className="space-y-6">
        <div className="flex items-center gap-4 p-4 bg-rose-50 rounded-2xl text-rose-600">
          <AlertCircle size={24} />
          <p className="text-sm font-medium">{confirmModal.message}</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
            className="flex-1 px-6 py-4 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 transition-all"
          >
            {t('cancel')}
          </button>
          <button 
            onClick={confirmModal.onConfirm}
            className="flex-1 px-6 py-4 bg-rose-600 text-white rounded-xl font-bold hover:bg-rose-700 transition-all shadow-lg shadow-rose-200"
          >
            {t('delete')}
          </button>
        </div>
      </div>
    </Modal>
  );
  
  // Form States
  const [newBusiness, setNewBusiness] = useState({ 
    name: '', 
    type: 'retail',
    adminUsername: '',
    adminPassword: '',
    plan: 'monthly' as SubscriptionPlan,
    customPrice: '',
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0],
    status: 'active' as 'active' | 'limited',
    isLocked: false,
    isMultiBranch: false,
    planExpiry: new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0],
    modules: getDefaultModulesForBusinessType('retail')
  });
  const [newUser, setNewUser] = useState({ displayName: '', role: 'system_manager', username: '', password: '', phone: '' });
  const [submitting, setSubmitting] = useState(false);
  const [registerError, setRegisterError] = useState<string | null>(null);
  const [userError, setUserError] = useState<string | null>(null);

  useEffect(() => {
    if (!newBusiness.startDate) return;
    const start = new Date(newBusiness.startDate);
    const end = new Date(start);
    const plan = newBusiness.plan;
    
    if (plan === 'daily') end.setDate(start.getDate() + 1);
    else if (plan === 'weekly') end.setDate(start.getDate() + 7);
    else if (plan === 'monthly') end.setMonth(start.getMonth() + 1);
    else if (plan === '2months') end.setMonth(start.getMonth() + 2);
    else if (plan === '3months') end.setMonth(start.getMonth() + 3);
    else if (plan === 'yearly') end.setFullYear(start.getFullYear() + 1);
    else if (plan === 'custom') end.setMonth(start.getMonth() + 1);
    
    setNewBusiness(prev => ({ ...prev, endDate: end.toISOString().split('T')[0] }));
  }, [newBusiness.plan, newBusiness.startDate]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data: tenantsData } = await supabase.from('tenants').select('*');
      const mappedTenants = (tenantsData || []).map(t => ({
        id: t.id,
        name: t.name,
        type: t.type,
        modules: t.modules,
        managerId: t.manager_id,
        subscriptionPlan: t.subscription_plan,
        planExpiry: t.plan_expiry,
        isLocked: t.is_locked,
        createdAt: t.created_at,
        logoUrl: t.logo_url,
        status: t.status,
        isMultiBranch: t.is_multi_branch,
        location: t.location,
        contact: t.contact,
        paymentNumbers: t.payment_numbers
      }));
      setTenants(mappedTenants as Tenant[]);

      const { data: usersData } = await supabase.from('users').select('*');
      const mappedUsers = (usersData || []).map(u => ({
        id: u.id,
        uid: u.uid,
        email: u.email,
        displayName: u.display_name,
        role: u.role,
        tenantId: u.tenant_id,
        createdAt: u.created_at,
        username: u.username,
        password: u.password,
        phone: u.phone,
        photoURL: u.photo_url,
        isStaff: u.is_staff,
        staffRoles: u.staff_roles,
        subscription: u.subscription,
        isLocked: u.is_locked,
        isExpired: u.is_expired,
        planExpiry: u.plan_expiry,
        branchId: u.branch_id
      }));
      setAllUsers(mappedUsers as UserProfile[]);

      const { data: staffData } = await supabase.from('staff').select('*');
      const mappedStaff = (staffData || []).map(s => ({
        id: s.id,
        username: s.username,
        password: s.password,
        displayName: s.display_name,
        phone: s.phone,
        photoURL: s.photo_url,
        roles: s.roles,
        tenantId: s.tenant_id,
        branchId: s.branch_id,
        isLocked: s.is_locked,
        createdAt: s.created_at,
        position: s.position,
        salary: s.salary,
        address: s.address,
        email: s.email,
        status: s.status,
        hireDate: s.hire_date
      }));
      setAllStaff(mappedStaff as StaffMember[]);

      // Fetch all branches across all tenants
      const { data: branchesData } = await supabase.from('branches').select('*');
      setAllBranches(branchesData || []);

      // Fetch all sales across all tenants
      const { data: salesData } = await supabase.from('sales').select('*');
      setAllSales(salesData || []);

      // Include system_manager in the managers list for performance tracking
      setManagers(mappedUsers.filter(u => ['super_admin', 'system_manager'].includes(u.role)) as UserProfile[]);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleAddBusiness = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setRegisterError(null);
    try {
      const trimmedUsername = newBusiness.adminUsername.trim();
      
      // 9-digit validation
      if (!is9DigitNumber(trimmedUsername)) {
        throw new Error(USERNAME_FORMAT_ERROR);
      }

      // Check for uniqueness
      const exists = await checkUsernameExists(trimmedUsername);
      if (exists) {
        throw new Error(USERNAME_EXISTS_ERROR);
      }

      const tenantData = {
        name: newBusiness.name,
        type: newBusiness.type,
        modules: newBusiness.modules,
        is_locked: newBusiness.isLocked,
        is_multi_branch: newBusiness.isMultiBranch,
        plan_expiry: new Date(newBusiness.planExpiry).toISOString(),
        created_at: new Date().toISOString()
      };
      const { data: tenantRef, error: tenantError } = await supabase.from('tenants').insert(tenantData).select().single();
      if (tenantError) throw tenantError;
      if (!tenantRef) throw new Error("Failed to create tenant record");

      const adminUid = `user_${Date.now()}`;
      
      const adminData = {
        uid: adminUid,
        display_name: `${newBusiness.name.trim()} Admin`,
        email: `${newBusiness.adminUsername.trim()}@business.sahal`,
        username: newBusiness.adminUsername.trim(),
        password: newBusiness.adminPassword.trim(),
        role: 'business_user',
        tenant_id: tenantRef.id,
        created_at: new Date(newBusiness.startDate).toISOString(),
        subscription: {
          plan: newBusiness.plan,
          startDate: new Date(newBusiness.startDate).toISOString(),
          endDate: new Date(newBusiness.endDate).toISOString(),
          status: 'active',
          price: (newBusiness.customPrice && !isNaN(parseFloat(newBusiness.customPrice))) ? parseFloat(newBusiness.customPrice) : null
        }
      };
      const { error: adminError } = await supabase.from('users').insert(adminData);
      if (adminError) throw adminError;

      // Update tenant with managerId (the person who registered the business)
      await supabase.from('tenants').update({ manager_id: user.uid }).eq('id', tenantRef.id);

      setIsBusinessModalOpen(false);
      setNewBusiness({ 
        name: '', 
        type: 'retail', 
        adminUsername: '', 
        adminPassword: '',
        plan: 'monthly',
        customPrice: '',
        startDate: new Date().toISOString().split('T')[0],
        endDate: new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0],
        status: 'active' as 'active' | 'limited',
        isLocked: false,
        isMultiBranch: false,
        planExpiry: new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0],
        modules: getDefaultModulesForBusinessType('retail')
      });
      fetchData();
    } catch (error: any) {
      console.error("Error adding business:", error);
      const errorMessage = error?.message || error?.details || error?.hint || JSON.stringify(error);
      setRegisterError(`Error registering business: ${errorMessage}`);
    } finally {
      setSubmitting(false);
    }
  };

  const handleUpdateBusiness = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBusiness) return;
    setSubmitting(true);
    setRegisterError(null);
    try {
      const trimmedUsername = newBusiness.adminUsername.trim();

      // Find the current admin user for this tenant
      const currentAdmin = allUsers.find(u => u.tenantId === editingBusiness.id && u.role === 'business_user' && !u.isStaff);

      // Only validate if username changed
      if (currentAdmin?.username !== trimmedUsername) {
        // 9-digit validation
        if (!is9DigitNumber(trimmedUsername)) {
          throw new Error(USERNAME_FORMAT_ERROR);
        }

        // Check for uniqueness
        const exists = await checkUsernameExists(trimmedUsername);
        if (exists) {
          throw new Error(USERNAME_EXISTS_ERROR);
        }
      }

      const tenantData = {
        name: newBusiness.name,
        type: newBusiness.type,
        modules: newBusiness.modules,
        status: newBusiness.status,
        is_locked: newBusiness.isLocked,
        is_multi_branch: newBusiness.isMultiBranch,
        plan_expiry: new Date(newBusiness.planExpiry).toISOString(),
      };
      await supabase.from('tenants').update(tenantData).eq('id', editingBusiness.id);

      // Update admin user credentials
      const adminUser = allUsers.find(u => u.tenantId === editingBusiness.id && u.role === 'business_user' && !u.isStaff);
      if (adminUser) {
        await supabase.from('users').update({
          username: newBusiness.adminUsername,
          password: newBusiness.adminPassword,
          display_name: `${newBusiness.name} Admin`,
          subscription: {
            ...adminUser.subscription,
            plan: newBusiness.plan,
            startDate: new Date(newBusiness.startDate).toISOString(),
            endDate: new Date(newBusiness.endDate).toISOString(),
            price: (newBusiness.customPrice && !isNaN(parseFloat(newBusiness.customPrice))) ? parseFloat(newBusiness.customPrice) : null
          }
        }).eq('uid', adminUser.uid);
      }

      setIsBusinessModalOpen(false);
      setEditingBusiness(null);
      setNewBusiness({ 
        name: '', 
        type: 'retail', 
        adminUsername: '', 
        adminPassword: '',
        plan: 'monthly',
        customPrice: '',
        startDate: new Date().toISOString().split('T')[0],
        endDate: new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0],
        status: 'active' as 'active' | 'limited',
        isLocked: false,
        isMultiBranch: false,
        planExpiry: new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0],
        modules: getDefaultModulesForBusinessType('retail')
      });
      fetchData();
    } catch (error: any) {
      console.error("Error updating business:", error);
      const errorMessage = error?.message || error?.details || error?.hint || JSON.stringify(error);
      setRegisterError(`Error updating business: ${errorMessage}`);
    } finally {
      setSubmitting(false);
    }
  };

  const openEditBusinessModal = (tenant: Tenant) => {
    setEditingBusiness(tenant);
    // Find the admin user for this tenant
    const adminUser = allUsers.find(u => u.tenantId === tenant.id && u.role === 'business_user' && !u.isStaff);
    const isStandard = ['retail', 'pharmacy', 'hospital', 'restaurant'].includes(tenant.type);
    setIsCustomType(!isStandard);
    setNewBusiness({
      name: tenant.name || '',
      type: tenant.type || 'retail',
      adminUsername: adminUser?.username || '',
      adminPassword: adminUser?.password || '',
      plan: (adminUser?.subscription?.plan as SubscriptionPlan) || 'monthly',
      customPrice: adminUser?.subscription?.price?.toString() || '',
      startDate: adminUser?.subscription?.startDate?.split('T')[0] || new Date().toISOString().split('T')[0],
      endDate: adminUser?.subscription?.endDate?.split('T')[0] || new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0],
      status: tenant.status || 'active',
      isLocked: tenant.isLocked || false,
      isMultiBranch: tenant.isMultiBranch || false,
      planExpiry: tenant.planExpiry ? tenant.planExpiry.split('T')[0] : (adminUser?.subscription?.endDate?.split('T')[0] || new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0]),
      modules: {
        ...getDefaultModulesForBusinessType(tenant.type || 'retail'),
        ...tenant.modules
      }
    });
    setIsBusinessModalOpen(true);
  };

  const handleToggleBusinessLock = async (tenant: Tenant) => {
    try {
      await supabase.from('tenants').update({
        is_locked: !tenant.isLocked
      }).eq('id', tenant.id);
      fetchData();
    } catch (error) {
      console.error("Error toggling business lock:", error);
    }
  };

  const handleToggleUserLock = async (u: UserProfile) => {
    try {
      await supabase.from('users').update({
        is_locked: !u.isLocked
      }).eq('uid', u.uid);
      fetchData();
    } catch (error) {
      console.error("Error toggling user lock:", error);
    }
  };

  const handleDeleteBusiness = async (tenantId: string) => {
    openConfirm(t('delete'), t('delete_business_confirm'), async () => {
      try {
        // 1. Delete associated users
        await supabase.from('users').delete().eq('tenant_id', tenantId);

        // 1.5 Delete associated staff
        await supabase.from('staff').delete().eq('tenant_id', tenantId);

        // 2. Delete the tenant
        await supabase.from('tenants').delete().eq('id', tenantId);
        
        fetchData();
      } catch (error) {
        console.error("Error deleting business:", error);
      }
    });
  };

  const handleAddUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setUserError(null);
    try {
      const trimmedUsername = newUser.username.trim();
      const trimmedPassword = newUser.password.trim();
      const trimmedDisplayName = newUser.displayName.trim();

      // 9-digit validation
      if (!is9DigitNumber(trimmedUsername)) {
        throw new Error(USERNAME_FORMAT_ERROR);
      }

      // Check if username already exists
      const exists = await checkUsernameExists(trimmedUsername);
      if (exists) {
        throw new Error(USERNAME_EXISTS_ERROR);
      }

      const tempId = `user_${Date.now()}`;
      const userData = {
        uid: tempId,
        display_name: trimmedDisplayName,
        role: newUser.role as any,
        username: trimmedUsername,
        password: trimmedPassword,
        phone: newUser.phone.trim(),
        created_at: new Date().toISOString()
      };
      const { error } = await supabase.from('users').insert(userData);
      if (error) {
        if (error.code === '23505' || error.message?.includes('unique constraint')) {
           throw new Error(`Username-kan '${trimmedUsername}' mar hore ayaa la isticmaalay. Fadlan dooro mid kale.`);
        }
        throw error;
      }
      
      setIsUserModalOpen(false);
      setEditingUser(null);
      setNewUser({ displayName: '', role: 'super_admin', username: '', password: '', phone: '' });
      await fetchData();
    } catch (error: any) {
      console.error("Error adding user:", error);
      setUserError(error.message || "Qalad ayaa dhacay markii xogta la kaydinayay.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleUpdateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    setSubmitting(true);
    setUserError(null);
    try {
      const trimmedUsername = newUser.username.trim();

      // Only validate if username changed
      if (editingUser.username !== trimmedUsername) {
        // 9-digit validation
        if (!is9DigitNumber(trimmedUsername)) {
          throw new Error(USERNAME_FORMAT_ERROR);
        }

        // Check for uniqueness
        const exists = await checkUsernameExists(trimmedUsername);
        if (exists) {
          throw new Error(USERNAME_EXISTS_ERROR);
        }
      }

      const userData = {
        display_name: newUser.displayName,
        role: newUser.role as any,
        username: trimmedUsername,
        password: newUser.password,
        phone: newUser.phone.trim(),
      };
      const { error } = await supabase.from('users').update(userData).eq('uid', editingUser.uid);
      if (error) {
        throw error;
      }

      setIsUserModalOpen(false);
      setEditingUser(null);
      setNewUser({ displayName: '', role: 'super_admin', username: '', password: '', phone: '' });
      await fetchData();
    } catch (error: any) {
      console.error("Error updating user:", error);
      setUserError(error.message || "Qalad ayaa dhacay markii xogta la cusboonaysiinayay.");
    } finally {
      setSubmitting(false);
    }
  };

  const openEditUserModal = (user: UserProfile) => {
    console.log('Editing user:', user);
    setEditingUser(user);
    setNewUser({
      displayName: user.displayName || '',
      role: user.role as any,
      username: user.username || '',
      password: user.password || '',
      phone: user.phone || ''
    });
    setIsUserModalOpen(true);
  };

  // Assignment State
  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
  const [isStaffModalOpen, setIsStaffModalOpen] = useState(false);
  const [isBranchModalOpen, setIsBranchModalOpen] = useState(false);
  const [editingStaff, setEditingStaff] = useState<StaffMember | null>(null);
  const [selectedBusiness, setSelectedBusiness] = useState<Tenant | null>(null);
  const [selectedManagerId, setSelectedManagerId] = useState('');
  const [businessStaff, setBusinessStaff] = useState<StaffMember[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);

  const fetchBusinessStaff = async (tenantId: string) => {
    try {
      const { data: staffData } = await supabase
        .from('staff')
        .select('*')
        .eq('tenant_id', tenantId);
      setBusinessStaff(staffData || []);
    } catch (error) {
      console.error("Error fetching business staff:", error);
    }
  };

  const fetchBranches = async (tenantId: string) => {
    try {
      const { data: branchesData } = await supabase
        .from('branches')
        .select('*')
        .eq('tenant_id', tenantId);
      setBranches(branchesData || []);
    } catch (error) {
      console.error("Error fetching branches:", error);
    }
  };

  const handleAssignManager = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBusiness || !selectedManagerId) return;
    setSubmitting(true);
    try {
      await supabase
        .from('tenants')
        .update({ manager_id: selectedManagerId })
        .eq('id', selectedBusiness.id);
      setIsAssignModalOpen(false);
      setSelectedBusiness(null);
      setSelectedManagerId('');
      fetchData();
    } catch (error) {
      console.error("Error assigning manager:", error);
    } finally {
      setSubmitting(false);
    }
  };

  const getTenantRevenue = (tenantId: string) => {
    const adminUser = allUsers.find(u => u.tenantId === tenantId && u.role === 'business_user');
    if (adminUser?.subscription?.price) return adminUser.subscription.price;
    const plan = adminUser?.subscription?.plan || 'monthly';
    if (plan === 'daily') return 2;
    if (plan === 'weekly') return 10;
    if (plan === 'monthly') return 35;
    if (plan === '2months') return 65;
    if (plan === '3months') return 95;
    if (plan === 'yearly') return 350;
    return 0;
  };

  if (activeTab === 'overview') {
    const calculateRevenue = () => {
      return tenants.reduce((acc, tenant) => {
        const businessAdmin = allUsers.find(u => u.tenantId === tenant.id && u.role === 'business_user');
        if (businessAdmin?.subscription?.status === 'active') {
          return acc + getTenantRevenue(tenant.id);
        }
        return acc;
      }, 0);
    };

    // Data for charts
    const typeData = tenants.reduce((acc: any[], tenant) => {
      const existing = acc.find(d => d.name === tenant.type);
      if (existing) existing.value += 1;
      else acc.push({ name: tenant.type, value: 1 });
      return acc;
    }, []);

    const planData = tenants.reduce((acc: any[], tenant) => {
      const businessAdmin = allUsers.find(u => u.tenantId === tenant.id && u.role === 'business_user');
      const plan = businessAdmin?.subscription?.plan || 'N/A';
      const existing = acc.find(d => d.name === plan);
      if (existing) existing.value += 1;
      else acc.push({ name: plan, value: 1 });
      return acc;
    }, []);

    const COLORS = ['#4f46e5', '#10b981', '#f59e0b', '#ef4444', '#6366f1'];

    return (
      <div className="space-y-10">
        <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          <div className="sahal-card p-5 sm:p-8 flex flex-col justify-between group hover:border-indigo-500/30 transition-all min-h-[160px] sm:min-h-0">
             <div className="flex justify-between items-start mb-4">
                <div className="p-3 rounded-2xl bg-indigo-600 group-hover:scale-110 transition-transform text-white">
                   <Users size={20} />
                </div>
                <div className="flex items-center gap-1 text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full text-[10px] font-bold">
                   <ArrowUpRight size={12} />
                   +12%
                </div>
             </div>
             <div>
                <h3 className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1">{t('total_business')}</h3>
                <p className="text-2xl sm:text-4xl font-display font-bold text-slate-900">{tenants.length}</p>
             </div>
          </div>

          <div className="sahal-card p-5 sm:p-8 flex flex-col justify-between group hover:border-emerald-500/30 transition-all min-h-[160px] sm:min-h-0">
             <div className="flex justify-between items-start mb-4">
                <div className="p-3 rounded-2xl bg-emerald-600 group-hover:scale-110 transition-transform text-white">
                   <Users size={20} />
                </div>
             </div>
             <div>
                <h3 className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1">{t('active_users')}</h3>
                <p className="text-2xl sm:text-4xl font-display font-bold text-slate-900">{allUsers.length}</p>
             </div>
          </div>

          <div className="sahal-card p-5 sm:p-8 flex flex-col justify-between group hover:border-amber-500/30 transition-all min-h-[160px] sm:min-h-0">
             <div className="flex justify-between items-start mb-4">
                <div className="p-3 rounded-2xl bg-amber-500 group-hover:scale-110 transition-transform text-white">
                   <Activity size={20} />
                </div>
             </div>
             <div>
                <h3 className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1">{t('system_health')}</h3>
                <p className="text-2xl sm:text-4xl font-display font-bold text-slate-900">99.9%</p>
             </div>
          </div>

          <div className="sahal-card p-5 sm:p-8 flex flex-col justify-between group hover:border-slate-800/30 transition-all min-h-[160px] sm:min-h-0">
             <div className="flex justify-between items-start mb-4">
                <div className="p-3 rounded-2xl bg-slate-900 group-hover:scale-110 transition-transform text-white">
                   <DollarSign size={20} />
                </div>
             </div>
             <div>
                <h3 className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1">{t('monthly_revenue')}</h3>
                <p className="text-2xl sm:text-4xl font-display font-bold text-slate-900 tracking-tighter">${calculateRevenue().toLocaleString()}</p>
             </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="sahal-card p-8">
            <h3 className="font-display font-bold text-xl text-slate-900 mb-6">{t('business_distribution')}</h3>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={typeData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {typeData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                  <Legend verticalAlign="bottom" height={36}/>
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="sahal-card p-8">
            <h3 className="font-display font-bold text-xl text-slate-900 mb-6">{t('subscription_plans')}</h3>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={planData}>
                  <XAxis dataKey="name" axisLine={false} tickLine={false} />
                  <YAxis axisLine={false} tickLine={false} />
                  <Tooltip 
                    cursor={{ fill: '#f8fafc' }}
                    contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                  <Bar dataKey="value" fill="#4f46e5" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div className="sahal-card p-8">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h3 className="font-display font-bold text-xl text-slate-900">{t('system_activity_dashboard')}</h3>
              <p className="text-sm text-slate-400">{t('system_activity_desc')}</p>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {tenants.slice(0, 3).map((tenant) => (
              <div key={tenant.id} className="p-6 bg-slate-50 rounded-2xl border border-slate-100 hover:border-indigo-500/20 transition-all">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 rounded-xl bg-white flex items-center justify-center text-indigo-600 shadow-sm">
                    <Building2 size={24} />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900">{tenant.name}</h4>
                    <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">{tenant.type}</span>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400">{t('status')}</span>
                    <span className="text-emerald-600 font-bold">{t('active')}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400">{t('modules')}</span>
                    <span className="text-slate-900 font-bold">{t('modules_enabled').replace('{count}', Object.values(tenant.modules).filter(Boolean).length.toString())}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <RenderConfirmModal />
      </div>
    );
  }

  if (activeTab === 'business') {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h2 className="text-3xl font-display font-bold text-slate-900">{t('business_management')}</h2>
          <div className="flex items-center gap-3">
            <button 
              onClick={fetchData}
              disabled={loading}
              className="p-2.5 bg-white border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 transition-all disabled:opacity-50"
              title="Refresh Data"
            >
              <Activity size={18} className={loading ? 'animate-spin' : ''} />
            </button>
            <button 
              onClick={() => setIsBusinessModalOpen(true)}
              className="flex items-center gap-2 bg-indigo-600 text-white px-5 py-2.5 rounded-xl text-sm font-bold shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all"
            >
              <Plus size={18} />
              {t('add_business')}
            </button>
          </div>
        </div>

        <Modal 
          isOpen={isBusinessModalOpen} 
          onClose={() => {
            setIsBusinessModalOpen(false);
            setEditingBusiness(null);
            setNewBusiness({ 
              name: '', 
              type: 'retail', 
              adminUsername: '', 
              adminPassword: '',
              plan: 'monthly',
              customPrice: '',
              startDate: new Date().toISOString().split('T')[0],
              endDate: new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0],
              status: 'active',
              isLocked: false,
              isMultiBranch: false,
              planExpiry: new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0],
              modules: getDefaultModulesForBusinessType('retail')
            });
          }} 
          title={editingBusiness ? t('edit_business') : t('register_new_business')}
          contentClassName="max-w-4xl"
        >
          <form onSubmit={editingBusiness ? handleUpdateBusiness : handleAddBusiness} className="space-y-6">
            {registerError && (
              <div className="p-4 bg-red-50 text-red-600 rounded-xl text-sm font-medium flex items-start gap-3">
                <AlertCircle size={18} className="shrink-0 mt-0.5" />
                <p>{registerError}</p>
              </div>
            )}
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
              <div className="space-y-6">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('business_name')}</label>
                  <input 
                    required
                    type="text" 
                    value={newBusiness.name}
                    onChange={(e) => setNewBusiness({...newBusiness, name: e.target.value})}
                    placeholder={t('business_name_placeholder')} 
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('business_type')}</label>
                  <select 
                    value={isCustomType ? 'other' : newBusiness.type}
                    onChange={(e) => {
                      if (e.target.value === 'other') {
                        setIsCustomType(true);
                        setNewBusiness({...newBusiness, type: '', modules: getDefaultModulesForBusinessType('other')});
                      } else {
                        setIsCustomType(false);
                        setNewBusiness({...newBusiness, type: e.target.value, modules: getDefaultModulesForBusinessType(e.target.value)});
                      }
                    }}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all"
                  >
                    <option value="inventory">{t('inventory_management')}</option>
                    <option value="services">{t('service_business')}</option>
                    <option value="services_inventory">{t('type_services_inventory')}</option>
                    <option value="hospital">{t('hospital_management')}</option>
                    <option value="personal">{t('personal_management')}</option>
                    <option value="utility">{t('utility_management')}</option>
                    <option value="other">{t('other_business')}</option>
                  </select>
                </div>
                {isCustomType && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                  >
                    <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('custom_business_type')}</label>
                    <input 
                      required
                      type="text"
                      value={newBusiness.type}
                      onChange={(e) => setNewBusiness({...newBusiness, type: e.target.value, modules: getDefaultModulesForBusinessType(e.target.value)})}
                      placeholder={t('enter_custom_business_type')}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold"
                    />
                  </motion.div>
                )}
                {editingBusiness && (
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('business_status')}</label>
                    <select 
                      value={newBusiness.status}
                      onChange={(e) => setNewBusiness({...newBusiness, status: e.target.value as any})}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all"
                    >
                      <option value="active">{t('active')}</option>
                      <option value="limited">{t('limited')}</option>
                    </select>
                  </div>
                )}
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('subscription_plan')}</label>
                  <select 
                    value={newBusiness.plan}
                    onChange={(e) => setNewBusiness({...newBusiness, plan: e.target.value as SubscriptionPlan})}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all"
                  >
                    <option value="daily">{t('daily_plan')}</option>
                    <option value="weekly">{t('weekly_plan')}</option>
                    <option value="monthly">{t('monthly_plan')}</option>
                    <option value="2months">{t('two_months_plan')}</option>
                    <option value="3months">{t('three_months_plan')}</option>
                    <option value="yearly">{t('yearly_plan')}</option>
                    <option value="custom">{t('custom_plan')}</option>
                  </select>
                </div>

                {(newBusiness.plan === 'custom' || newBusiness.customPrice) && (
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('custom_price')}</label>
                    <input 
                      type="number"
                      value={newBusiness.customPrice || ''}
                      onChange={(e) => setNewBusiness({...newBusiness, customPrice: e.target.value})}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all"
                      placeholder="e.g. 50"
                    />
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('start_date')}</label>
                    <input 
                      type="date"
                      value={newBusiness.startDate}
                      onChange={(e) => setNewBusiness({...newBusiness, startDate: e.target.value})}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('end_date')}</label>
                    <input 
                      type="date"
                      value={newBusiness.endDate}
                      onChange={(e) => setNewBusiness({...newBusiness, endDate: e.target.value})}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('lock_status')}</label>
                    <select 
                      value={newBusiness.isLocked ? 'locked' : 'unlocked'}
                      onChange={(e) => setNewBusiness({...newBusiness, isLocked: e.target.value === 'locked'})}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all"
                    >
                      <option value="unlocked">{t('unlocked')}</option>
                      <option value="locked">{t('locked')}</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Branches</label>
                    <select 
                      value={newBusiness.isMultiBranch ? 'multi' : 'single'}
                      onChange={(e) => setNewBusiness({...newBusiness, isMultiBranch: e.target.value === 'multi'})}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all"
                    >
                      <option value="single">Single Branch</option>
                      <option value="multi">Multiple Branches</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('plan_expiry')}</label>
                  <input 
                    type="date"
                    value={newBusiness.planExpiry}
                    onChange={(e) => setNewBusiness({...newBusiness, planExpiry: e.target.value})}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all"
                  />
                </div>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">{t('enabled_modules')}</label>
                  <div className="grid grid-cols-2 lg:grid-cols-3 gap-2">
                    {Object.keys(newBusiness.modules).map((module) => (
                      <label key={module} className={`flex items-center gap-2 p-2 rounded-lg border transition-all cursor-pointer group ${
                        (newBusiness.modules as any)[module] ? 'bg-indigo-50 border-indigo-100' : 'bg-slate-50 border-transparent hover:border-slate-200'
                      }`}>
                        <input 
                          type="checkbox"
                          checked={(newBusiness.modules as any)[module]}
                          onChange={(e) => setNewBusiness({
                            ...newBusiness,
                            modules: {
                              ...newBusiness.modules,
                              [module]: e.target.checked
                            }
                          })}
                          className="w-3.5 h-3.5 text-indigo-600 rounded focus:ring-indigo-500"
                        />
                        <span className={`text-[10px] font-bold capitalize transition-colors ${(newBusiness.modules as any)[module] ? 'text-indigo-700' : 'text-slate-500'}`}>
                          {t(module)}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-100">
                  <h4 className="text-sm font-bold text-slate-900 mb-4">
                    {editingBusiness ? t('edit_credentials') : t('initial_admin_account')}
                  </h4>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('username')}</label>
                      <input 
                        required
                        type="text" 
                        inputMode="numeric"
                        pattern="\d{9}"
                        maxLength={9}
                        value={newBusiness.adminUsername}
                        onChange={(e) => setNewBusiness({...newBusiness, adminUsername: e.target.value.replace(/\D/g, '')})}
                        placeholder="e.g. 615123456" 
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('password')}</label>
                      <input 
                        required
                        type="text" 
                        value={newBusiness.adminPassword}
                        onChange={(e) => setNewBusiness({...newBusiness, adminPassword: e.target.value})}
                        placeholder={t('password_placeholder')} 
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-6 border-t border-slate-100">
              <button 
                disabled={submitting}
                type="submit" 
                className="w-full bg-slate-900 text-white py-4 rounded-xl font-bold hover:bg-slate-800 transition-all disabled:opacity-50"
              >
                {submitting ? (editingBusiness ? t('saving') : t('registering')) : (editingBusiness ? t('save_changes') : t('complete_registration'))}
              </button>
            </div>
          </form>
        </Modal>
        <Modal 
          isOpen={isAssignModalOpen} 
          onClose={() => setIsAssignModalOpen(false)} 
          title={`${t('assign_manager')} to ${selectedBusiness?.name}`}
        >
          <form onSubmit={handleAssignManager} className="space-y-6">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('select_manager')}</label>
              <select 
                required
                value={selectedManagerId}
                onChange={(e) => setSelectedManagerId(e.target.value)}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all"
              >
                <option value="">{t('choose_manager')}</option>
                {managers.map(m => (
                  <option key={m.uid} value={m.uid}>{m.displayName} ({m.username})</option>
                ))}
              </select>
            </div>
            <button 
              disabled={submitting || !selectedManagerId}
              type="submit" 
              className="w-full bg-slate-900 text-white py-4 rounded-xl font-bold hover:bg-slate-800 transition-all disabled:opacity-50"
            >
              {submitting ? t('assigning') : t('confirm_assignment')}
            </button>
          </form>
        </Modal>

        <Modal 
          isOpen={isStaffModalOpen} 
          onClose={() => setIsStaffModalOpen(false)} 
          title={`Staff of ${selectedBusiness?.name}`}
        >
          <div className="space-y-6">
            <div className="divide-y divide-slate-50 max-h-[400px] overflow-y-auto pr-2">
              {businessStaff.map((member) => (
                <div key={member.id} className="py-4 flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-slate-50 flex items-center justify-center text-indigo-600 font-bold text-xs">
                       {member.displayName?.[0]}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-900">{member.displayName}</p>
                      <div className="flex gap-2">
                        <p className="text-[10px] text-slate-400 font-mono">@{member.username}</p>
                        <p className="text-[10px] text-slate-400 font-mono">| PWD: {member.password}</p>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-[10px] font-bold uppercase text-slate-400 bg-slate-100 px-2 py-0.5 rounded">
                      {member.role}
                    </span>
                    <button 
                      onClick={() => setEditingStaff(member)}
                      className="text-indigo-400 hover:text-indigo-600 transition-colors"
                    >
                      <Edit2 size={14} />
                    </button>
                    <button 
                      onClick={() => {
                        if (selectedBusiness) {
                          openConfirm(t('delete'), 'Delete this staff member?', async () => {
                            await supabase.from('staff').delete().eq('id', member.id);
                            fetchBusinessStaff(selectedBusiness.id);
                          });
                        }
                      }}
                      className="text-red-400 hover:text-red-600 transition-colors"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              ))}
              {businessStaff.length === 0 && (
                <div className="py-10 text-center">
                  <p className="text-sm text-slate-400 italic">No staff members registered for this business.</p>
                </div>
              )}
            </div>
            <div className="pt-6 border-t border-slate-100">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4">
                {editingStaff ? 'Edit Staff Member' : 'Quick Add Staff'}
              </p>
              <form 
                key={editingStaff ? editingStaff.id : 'new'}
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (!selectedBusiness) return;
                  const form = e.target as HTMLFormElement;
                  if (!(form instanceof HTMLFormElement)) return;
                  const formData = new FormData(form);
                  const staffData = {
                    displayName: formData.get('displayName') as string,
                    username: formData.get('username') as string,
                    password: formData.get('password') as string,
                    role: formData.get('role') as any,
                    tenantId: selectedBusiness.id,
                    createdAt: editingStaff ? editingStaff.createdAt : new Date().toISOString()
                  };
                  if (editingStaff) {
                    await supabase.from('staff').update({
                      display_name: staffData.displayName,
                      username: staffData.username,
                      password: staffData.password,
                      roles: staffData.role ? [staffData.role] : [],
                      tenant_id: selectedBusiness.id
                    }).eq('id', editingStaff.id);
                    setEditingStaff(null);
                  } else {
                    await supabase.from('staff').insert({
                      display_name: staffData.displayName,
                      username: staffData.username,
                      password: staffData.password,
                      roles: staffData.role ? [staffData.role] : [],
                      tenant_id: selectedBusiness.id,
                      created_at: new Date().toISOString()
                    });
                  }
                  form.reset();
                  fetchBusinessStaff(selectedBusiness.id);
                }}
                className="grid grid-cols-2 gap-3"
              >
                <input name="displayName" defaultValue={editingStaff?.displayName} required placeholder="Full Name" className="col-span-2 px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs" />
                <input name="username" defaultValue={editingStaff?.username} required placeholder="9-Digit Username" inputMode="numeric" pattern="\d{9}" maxLength={9} onChange={(e) => e.target.value = e.target.value.replace(/\D/g, '')} className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs" />
                <input name="password" defaultValue={editingStaff?.password} required type="text" placeholder="Password" className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs" />
                <select name="role" defaultValue={editingStaff?.role} className="col-span-2 px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs">
                  <option value="cashier">Cashier</option>
                  <option value="inventory">Inventory</option>
                  <option value="admin">Admin</option>
                </select>
                <div className="col-span-2 flex gap-2">
                  <button type="submit" className="flex-1 bg-slate-900 text-white py-2.5 rounded-lg text-xs font-bold hover:bg-slate-800 transition-all">
                    {editingStaff ? 'Update Staff Account' : 'Create Staff Account'}
                  </button>
                  {editingStaff && (
                    <button 
                      type="button" 
                      onClick={() => setEditingStaff(null)}
                      className="px-4 bg-slate-100 text-slate-600 py-2.5 rounded-lg text-xs font-bold hover:bg-slate-200 transition-all"
                    >
                      Cancel
                    </button>
                  )}
                </div>
              </form>
            </div>
          </div>
        </Modal>

        <Modal 
          isOpen={isBranchModalOpen} 
          onClose={() => setIsBranchModalOpen(false)} 
          title={`Branches of ${selectedBusiness?.name}`}
        >
          <div className="space-y-6">
            <div className="divide-y divide-slate-50 max-h-[400px] overflow-y-auto pr-2">
              {branches.map((branch) => (
                <div key={branch.id} className="py-4 flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-600 font-bold text-xs">
                       {branch.name?.[0]}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-900">{branch.name}</p>
                      <p className="text-[10px] text-slate-400">{branch.location || 'No location'}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <button 
                      onClick={() => {
                        if (selectedBusiness) {
                          openConfirm(t('delete'), 'Delete this branch?', async () => {
                            await supabase.from('branches').delete().eq('id', branch.id);
                            fetchBranches(selectedBusiness.id);
                          });
                        }
                      }}
                      className="text-red-400 hover:text-red-600 transition-colors"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              ))}
              {branches.length === 0 && (
                <div className="py-10 text-center">
                  <p className="text-sm text-slate-400 italic">No branches registered for this business.</p>
                </div>
              )}
            </div>
            <div className="pt-6 border-t border-slate-100">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4">Add New Branch</p>
              <form 
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (!selectedBusiness) return;
                  const form = e.target as HTMLFormElement;
                  if (!(form instanceof HTMLFormElement)) return;
                  const formData = new FormData(form);
                  const branchData = {
                    name: formData.get('name') as string,
                    location: formData.get('location') as string,
                    phone: formData.get('phone') as string,
                    tenantId: selectedBusiness.id,
                    createdAt: new Date().toISOString()
                  };
                  await supabase.from('branches').insert({
                    ...branchData,
                    tenant_id: selectedBusiness.id,
                    created_at: new Date().toISOString()
                  });
                  form.reset();
                  fetchBranches(selectedBusiness.id);
                }}
                className="space-y-3"
              >
                <input name="name" required placeholder="Branch Name" className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs" />
                <input name="location" placeholder="Location" className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs" />
                <input name="phone" placeholder="Phone" className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs" />
                <button type="submit" className="w-full bg-slate-900 text-white py-2.5 rounded-lg text-xs font-bold hover:bg-slate-800 transition-all">
                  Create Branch
                </button>
              </form>
            </div>
          </div>
        </Modal>

        <div className="sahal-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50/50">
                      <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('business_name')}</th>
                      <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('business_admin')}</th>
                      <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('username')}</th>
                      <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('password')}</th>
                      <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('portfolio_manager')}</th>
                      <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('plan')}</th>
                      <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('revenue_generated')}</th>
                      <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('expiry')}</th>
                      <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('lock_status')}</th>
                      <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('status')}</th>
                      <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100 text-right">{t('action')}</th>
                    </tr>
                  </thead>
              <tbody className="divide-y divide-slate-50">
                {tenants.map((tenant) => {
                  const businessAdmin = allUsers.find(u => u.tenantId === tenant.id && u.role === 'business_user') || allUsers.find(u => u.uid === tenant.managerId);
                  const businessStaff = allStaff.find(s => s.tenantId === tenant.id && s.roles.includes('admin'));
                  
                  const displayAdmin = businessAdmin || businessStaff;
                  const portfolioManager = allUsers.find(u => u.uid === tenant.managerId);
                  return (
                    <tr key={tenant.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-6">
                        <p className="font-bold text-slate-900">{tenant.name}</p>
                        <p className="text-xs text-slate-400 uppercase">{tenant.type}</p>
                      </td>
                      <td className="p-6">
                        <p className="text-sm font-bold text-slate-900">{displayAdmin?.displayName || 'N/A'}</p>
                        <p className="text-xs text-slate-400">@{displayAdmin?.username || 'N/A'}</p>
                      </td>
                      <td className="p-6">
                        <p className="text-sm font-mono text-slate-600">{displayAdmin?.username || 'N/A'}</p>
                      </td>
                      <td className="p-6">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-mono text-slate-600">
                            {showBusinessPassword ? displayAdmin?.password : '••••••••'}
                          </p>
                          <button 
                            onClick={() => setShowBusinessPassword(!showBusinessPassword)}
                            className="text-slate-400 hover:text-slate-600 transition-colors"
                          >
                            {showBusinessPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                          </button>
                        </div>
                      </td>
                      <td className="p-6">
                        {tenant.managerId && portfolioManager ? (
                          <div className="flex items-center gap-2">
                            <div className="w-6 h-6 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center text-[10px] font-bold">
                              {portfolioManager.displayName.charAt(0)}
                            </div>
                            <span className="text-sm text-slate-600 font-medium">
                              {portfolioManager.displayName}
                            </span>
                          </div>
                        ) : (
                            <span className="text-xs text-slate-300 italic">{t('unassigned')}</span>
                        )}
                      </td>
                      <td className="p-6">
                        <span className="text-xs font-bold uppercase px-3 py-1.5 bg-indigo-50 text-indigo-600 rounded-lg">
                          {businessAdmin?.subscription?.plan || 'N/A'}
                        </span>
                      </td>
                      <td className="p-6">
                        <p className="text-sm font-bold text-emerald-600">${getTenantRevenue(tenant.id)}</p>
                      </td>
                      <td className="p-6">
                        <p className="text-xs font-bold text-slate-600">
                          {tenant.planExpiry ? new Date(tenant.planExpiry).toLocaleDateString() : (businessAdmin?.subscription?.endDate ? new Date(businessAdmin.subscription.endDate).toLocaleDateString() : 'N/A')}
                        </p>
                      </td>
                      <td className="p-6">
                        <span className={`text-[10px] font-bold uppercase px-2 py-1 rounded-md ${
                          tenant.isLocked ? 'bg-red-50 text-red-600' : 'bg-blue-50 text-blue-600'
                        }`}>
                          {tenant.isLocked ? t('locked') : t('unlocked')}
                        </span>
                      </td>
                      <td className="p-6">
                        <span className={`text-[10px] font-bold uppercase px-2 py-1 rounded-md ${
                          tenant.status === 'limited' ? 'bg-rose-50 text-rose-600' : 'bg-emerald-50 text-emerald-600'
                        }`}>
                          {tenant.status === 'limited' ? t('limited') : t('active')}
                        </span>
                      </td>
                      <td className="p-6 text-right">
                      <div className="flex items-center justify-end gap-3">
                        <button 
                          onClick={() => handleToggleBusinessLock(tenant)}
                          className={`p-2 transition-colors ${tenant.isLocked ? 'text-amber-500 hover:text-amber-600' : 'text-slate-400 hover:text-indigo-600'}`}
                          title={tenant.isLocked ? t('unlock') : t('lock')}
                        >
                          {tenant.isLocked ? <Lock size={18} /> : <ShieldCheck size={18} />}
                        </button>
                        <button 
                          onClick={() => openEditBusinessModal(tenant)}
                          className="p-2 text-slate-400 hover:text-indigo-600 transition-colors"
                          title={t('edit_business')}
                        >
                          <Edit2 size={18} />
                        </button>
                        <button 
                          onClick={() => handleDeleteBusiness(tenant.id)}
                          className="p-2 text-slate-400 hover:text-red-600 transition-colors"
                          title="Delete Business"
                        >
                          <Trash2 size={18} />
                        </button>
                        <button 
                          onClick={() => {
                            setSelectedBusiness(tenant);
                            fetchBusinessStaff(tenant.id);
                            setIsStaffModalOpen(true);
                          }}
                          className="text-xs font-bold text-slate-600 hover:text-indigo-600 transition-colors"
                        >
                          {t('staff')}
                        </button>
                        {tenant.isMultiBranch && (
                          <button 
                            onClick={() => {
                              setSelectedBusiness(tenant);
                              fetchBranches(tenant.id);
                              setIsBranchModalOpen(true);
                            }}
                            className="text-xs font-bold text-emerald-600 hover:text-emerald-800 transition-colors"
                          >
                            Branches
                          </button>
                        )}
                        <button 
                          onClick={() => {
                            setSelectedBusiness(tenant);
                            setIsAssignModalOpen(true);
                          }}
                          className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors"
                        >
                          {t('assign')}
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
            </table>
          </div>
        </div>
        <RenderConfirmModal />
      </div>
    );
  }

  if (activeTab === 'users') {
    return (
      <div className="space-y-8">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-3xl font-display font-bold text-slate-900">{t('system_users')}</h2>
            <p className="text-slate-500 mt-1">{t('manage_system_users_desc')}</p>
          </div>
          <button 
            onClick={() => setIsUserModalOpen(true)}
            className="bg-slate-900 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-slate-800 transition-all shadow-lg shadow-slate-200"
          >
            <UserPlus size={20} />
            {t('add_system_user')}
          </button>
        </div>

        <Modal 
          isOpen={isUserModalOpen} 
          onClose={() => {
            setIsUserModalOpen(false);
            setEditingUser(null);
            setUserError(null);
            setNewUser({ displayName: '', role: 'super_admin', username: '', password: '', phone: '' });
          }} 
          title={editingUser ? t('edit_system_user') : t('add_system_user')}
        >
          <form onSubmit={editingUser ? handleUpdateUser : handleAddUser} className="space-y-6">
            {userError && (
              <div className="p-4 bg-red-50 text-red-600 rounded-xl text-sm font-medium flex items-start gap-3">
                <AlertCircle size={18} className="shrink-0 mt-0.5" />
                <p>{userError}</p>
              </div>
            )}
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('full_name')}</label>
                <input 
                  required
                  value={newUser.displayName}
                  onChange={(e) => setNewUser({...newUser, displayName: e.target.value})}
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  placeholder={t('full_name_placeholder')}
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('phone')}</label>
                <input 
                  value={newUser.phone}
                  onChange={(e) => setNewUser({...newUser, phone: e.target.value})}
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  placeholder="e.g. +252..."
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('username')}</label>
                  <input 
                    required
                    type="text"
                    inputMode="numeric"
                    pattern="\d{9}"
                    maxLength={9}
                    value={newUser.username}
                    onChange={(e) => setNewUser({...newUser, username: e.target.value.replace(/\D/g, '')})}
                    className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                    placeholder="e.g. 615123456"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Password</label>
                  <div className="relative">
                    <input 
                      required
                      type={showUserPassword ? "text" : "password"}
                      value={newUser.password}
                      onChange={(e) => setNewUser({...newUser, password: e.target.value})}
                      className="w-full px-5 py-4 pr-12 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                      placeholder="••••••••"
                    />
                    <button
                      type="button"
                      onClick={() => setShowUserPassword(!showUserPassword)}
                      className="absolute inset-y-0 right-0 pr-4 flex items-center text-slate-400 hover:text-slate-600 transition-colors"
                    >
                      {showUserPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{t('system_role')}</label>
                <select 
                  value={newUser.role}
                  onChange={(e) => setNewUser({...newUser, role: e.target.value as any})}
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                >
                  <option value="super_admin">{t('super_admin')}</option>
                  <option value="system_manager">{t('system_manager')}</option>
                </select>
              </div>
            </div>
            <button 
              disabled={submitting}
              type="submit" 
              className="w-full bg-slate-900 text-white py-4 rounded-xl font-bold hover:bg-slate-800 transition-all disabled:opacity-50"
            >
              {submitting ? t('creating') : t('create_user_account')}
            </button>
          </form>
        </Modal>

        <div className="sahal-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/50">
                  <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('user')}</th>
                  <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('phone')}</th>
                  <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('username')}</th>
                  <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('password')}</th>
                  <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('role')}</th>
                  <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('created_at')}</th>
                  <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100 text-right">{t('action')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {allUsers.filter(u => ['super_admin', 'system_manager'].includes(u.role)).map((u) => (
                  <tr key={u.id || u.uid} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-6">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                          {u.displayName?.[0]}
                        </div>
                        <div>
                          <p className="font-bold text-slate-900">{u.displayName}</p>
                          <p className="text-xs text-slate-400">@{u.username}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-6">
                      <p className="text-sm text-slate-600">{u.phone || 'N/A'}</p>
                    </td>
                    <td className="p-6">
                      <p className="text-sm font-mono text-slate-600">{u.username || 'N/A'}</p>
                    </td>
                    <td className="p-6">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-mono text-slate-600">
                          {showUserPassword ? u.password : '••••••••'}
                        </p>
                        <button 
                          onClick={() => setShowUserPassword(!showUserPassword)}
                          className="text-slate-400 hover:text-slate-600 transition-colors"
                        >
                          {showUserPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                        </button>
                      </div>
                    </td>
                    <td className="p-6">
                      <span className={`text-[10px] font-bold uppercase px-2 py-1 rounded-md ${
                        u.role === 'super_admin' ? 'bg-purple-50 text-purple-600' : 'bg-blue-50 text-blue-600'
                      }`}>
                        {u.role.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="p-6 text-xs text-slate-500">
                      {new Date(u.createdAt).toLocaleDateString()}
                    </td>
                    <td className="p-6 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button 
                          onClick={() => handleToggleUserLock(u)}
                          className={`p-2 transition-colors ${u.isLocked ? 'text-amber-500 hover:text-amber-600' : 'text-slate-400 hover:text-indigo-600'}`}
                          title={u.isLocked ? t('unlock') : t('lock')}
                        >
                          {u.isLocked ? <Lock size={18} /> : <ShieldCheck size={18} />}
                        </button>
                        <button 
                          onClick={() => openEditUserModal(u)}
                          className="p-2 text-slate-400 hover:text-indigo-600 transition-colors"
                        >
                          <Edit2 size={18} />
                        </button>
                        <button 
                          onClick={() => {
                            openConfirm(t('delete'), t('delete_user_confirm'), async () => {
                              await supabase.from('users').delete().eq('uid', u.uid);
                              fetchData();
                            });
                          }}
                          className="p-2 text-slate-400 hover:text-red-600 transition-colors"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <RenderConfirmModal />
      </div>
    );
  }

  if (activeTab === 'managers_performance') {
    const managerPerformance = allUsers
      .filter(u => ['super_admin', 'system_manager'].includes(u.role))
      .map(manager => {
        const managedTenants = tenants.filter(t => t.managerId === manager.uid);
        
        // Calculate revenue based on subscription plans
        const revenue = managedTenants.reduce((acc, tenant) => {
          return acc + getTenantRevenue(tenant.id);
        }, 0);

        return {
          ...manager,
          businessesCount: managedTenants.length,
          revenue
        };
      });

    const unassignedTenants = tenants.filter(t => !allUsers.some(u => u.uid === t.managerId && ['super_admin', 'system_manager'].includes(u.role)));
    const unassignedRevenue = unassignedTenants.reduce((acc, t) => acc + getTenantRevenue(t.id), 0);

    return (
      <div className="space-y-8">
        <div>
          <h2 className="text-3xl font-display font-bold text-slate-900">{t('managers_performance')}</h2>
          <p className="text-slate-500 mt-1">{t('system_manager_performance')}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <StatCard 
            label={t('total_revenue')} 
            value={`$${managerPerformance.reduce((acc, m) => acc + m.revenue, 0) + unassignedRevenue}`}
            icon={<DollarSign size={24} />}
            color="bg-emerald-500"
          />
          <StatCard 
            label={t('registered_businesses')} 
            value={tenants.length}
            icon={<Building2 size={24} />}
            color="bg-indigo-500"
          />
          <StatCard 
            label={t('performance_overview')} 
            value={managerPerformance.length}
            icon={<Users size={24} />}
            color="bg-purple-500"
          />
        </div>

        {unassignedRevenue > 0 && (
          <div className="p-6 bg-amber-50 border border-amber-100 rounded-2xl flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-amber-100 text-amber-600 rounded-xl flex items-center justify-center">
                <AlertTriangle size={24} />
              </div>
              <div>
                <h4 className="font-bold text-amber-900">{t('unassigned_revenue_detected')}</h4>
                <p className="text-sm text-amber-700">
                  {t('unassigned_revenue_desc').replace('{amount}', unassignedRevenue.toString()).replace('{count}', unassignedTenants.length.toString())}
                </p>
              </div>
            </div>
            <button 
              onClick={() => setActiveTab('business')}
              className="px-6 py-2.5 bg-white text-amber-600 border border-amber-200 rounded-xl font-bold text-sm hover:bg-amber-50 transition-all shadow-sm"
            >
              {t('assign_managers_now')}
            </button>
          </div>
        )}

        <div className="sahal-card overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/30">
            <h3 className="font-display font-bold text-slate-900">{t('revenue_by_manager')}</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/50">
                  <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('manager_name')}</th>
                  <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('username')}</th>
                  <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('password')}</th>
                  <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('businesses_count')}</th>
                  <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">{t('revenue_generated')}</th>
                  <th className="p-6 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100 text-right">{t('action')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {managerPerformance.map((m) => (
                  <tr key={m.uid} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-6">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                          {m.displayName?.[0]}
                        </div>
                        <div>
                          <p className="font-bold text-slate-900">{m.displayName}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-6">
                      <p className="text-sm font-mono text-slate-600">{m.username}</p>
                    </td>
                    <td className="p-6">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-mono text-slate-600">
                          {showUserPassword ? m.password : '••••••••'}
                        </p>
                        <button 
                          onClick={() => setShowUserPassword(!showUserPassword)}
                          className="text-slate-400 hover:text-slate-600 transition-colors"
                        >
                          {showUserPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                        </button>
                      </div>
                    </td>
                    <td className="p-6">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900">{m.businessesCount}</span>
                        <span className="text-xs text-slate-400">{t('businesses')}</span>
                      </div>
                    </td>
                    <td className="p-6">
                      <p className="font-bold text-emerald-600">${m.revenue.toLocaleString()}</p>
                    </td>
                    <td className="p-6 text-right">
                      <button 
                        onClick={() => openEditUserModal(m)}
                        className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors"
                      >
                        {t('edit')}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Performance Chart */}
        <div className="sahal-card p-8">
          <h3 className="text-xl font-display font-bold text-slate-900 mb-8">{t('revenue_by_manager')}</h3>
          <div className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={managerPerformance}>
                <XAxis dataKey="displayName" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} />
                <Tooltip 
                  contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 25px -5px rgba(0,0,0,0.1)' }}
                />
                <Bar dataKey="revenue" fill="#6366f1" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <RenderConfirmModal />
      </div>
    );
  }

  if (activeTab === 'branch_performance') {
    const multiBranchTenants = tenants.filter(t => t.isMultiBranch);
    
    return (
      <div className="space-y-8">
        <div>
          <h2 className="text-3xl font-display font-bold text-slate-900">{t('branch_performance')}</h2>
          <p className="text-slate-500 mt-1">Detailed performance tracking for businesses with multiple branches</p>
        </div>

        <div className="grid grid-cols-1 gap-8">
          {multiBranchTenants.map(tenant => {
            const tenantBranches = allBranches.filter(b => b.tenantId === tenant.id);
            const tenantSales = allSales.filter(s => s.tenantId === tenant.id);
            
            const branchStats = tenantBranches.map(branch => {
              const branchSales = tenantSales.filter(s => s.branchId === branch.id);
              const revenue = branchSales.reduce((acc, s) => acc + (s.total || 0), 0);
              return {
                name: branch.name,
                revenue,
                salesCount: branchSales.length
              };
            });

            // Add "Main Branch" or unassigned sales
            const unassignedSales = tenantSales.filter(s => !s.branchId);
            if (unassignedSales.length > 0) {
              branchStats.push({
                name: 'Main/Unassigned',
                revenue: unassignedSales.reduce((acc, s) => acc + (s.total || 0), 0),
                salesCount: unassignedSales.length
              });
            }

            return (
              <div key={tenant.id} className="sahal-card p-8">
                <div className="flex items-center gap-4 mb-8">
                  <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center shadow-sm">
                    <Building2 size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-display font-bold text-slate-900">{tenant.name}</h3>
                    <p className="text-xs text-slate-400 uppercase tracking-widest font-bold">{tenant.type}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-50/50">
                          <th className="p-4 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">Branch</th>
                          <th className="p-4 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">Sales</th>
                          <th className="p-4 text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100 text-right">Revenue</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                        {branchStats.map((stat, idx) => (
                          <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                            <td className="p-4">
                              <p className="font-bold text-slate-900 text-sm">{stat.name}</p>
                            </td>
                            <td className="p-4">
                              <p className="text-sm text-slate-600">{stat.salesCount} sales</p>
                            </td>
                            <td className="p-4 text-right">
                              <p className="font-bold text-emerald-600 text-sm">${stat.revenue.toLocaleString()}</p>
                            </td>
                          </tr>
                        ))}
                        {branchStats.length === 0 && (
                          <tr>
                            <td colSpan={3} className="p-8 text-center text-slate-400 italic text-sm">
                              No branches or sales data found for this business.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>

                  <div className="h-[250px]">
                    {branchStats.length > 0 ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={branchStats}>
                          <XAxis dataKey="name" axisLine={false} tickLine={false} fontSize={10} />
                          <YAxis axisLine={false} tickLine={false} fontSize={10} />
                          <Tooltip 
                            contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 25px -5px rgba(0,0,0,0.1)' }}
                          />
                          <Bar dataKey="revenue" fill="#6366f1" radius={[4, 4, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    ) : (
                      <div className="h-full flex items-center justify-center bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                        <p className="text-xs text-slate-400">No data for visualization</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
          {multiBranchTenants.length === 0 && (
            <div className="sahal-card p-20 text-center">
              <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6 text-slate-300">
                <Building2 size={40} />
              </div>
              <h3 className="text-xl font-display font-bold text-slate-900 mb-2">No Multi-Branch Businesses</h3>
              <p className="text-slate-500 max-w-md mx-auto">
                Businesses with multiple branches will appear here with detailed performance metrics.
              </p>
            </div>
          )}
        </div>
        <RenderConfirmModal />
      </div>
    );
  }

  if (activeTab === 'landing_page') {
    return (
      <div className="space-y-6">
        <LandingPageManager />
        <RenderConfirmModal />
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center p-20 text-center">
      <div className="w-20 h-20 bg-slate-50 rounded-3xl flex items-center justify-center mb-6">
        <Activity size={40} className="text-slate-200" />
      </div>
      <h3 className="text-xl font-display font-bold text-slate-900 mb-2">{t('module_under_construction')}</h3>
      <p className="text-slate-400 max-w-sm">{t('module_under_construction_desc')}</p>
      <RenderConfirmModal />
    </div>
  );
}
