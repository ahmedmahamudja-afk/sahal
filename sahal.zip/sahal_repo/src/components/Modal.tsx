import React from 'react';
import { X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  containerClassName?: string;
  contentClassName?: string;
}

const Modal = ({ 
  isOpen, 
  onClose, 
  title, 
  children, 
  containerClassName = '', 
  contentClassName = '' 
}: ModalProps) => (
  <AnimatePresence>
    {isOpen && (
      <div className={`fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 ${containerClassName}`}>
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" 
          onClick={onClose} 
        />
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className={`relative bg-surface-main rounded-3xl w-full ${contentClassName.includes('max-w-') ? '' : 'max-w-2xl'} max-h-[90vh] overflow-hidden shadow-2xl flex flex-col m-4 transition-colors duration-300 border border-border-main ${contentClassName}`}
        >
          <div className="flex items-center justify-between p-6 sm:p-8 border-b border-border-main bg-surface-main/50 backdrop-blur-md sticky top-0 z-10 shrink-0">
            <h3 className="text-xl font-display font-bold text-ink">{title}</h3>
            <button 
              onClick={onClose}
              className="p-2 text-ink-tertiary hover:text-ink hover:bg-bg-sec rounded-full transition-colors flex items-center justify-center h-10 w-10 sm:h-12 sm:w-12"
            >
              <X className="w-[var(--icon-md)] h-[var(--icon-md)]" />
            </button>
          </div>
          <div className="p-6 sm:p-8 overflow-y-auto custom-scrollbar flex-1 text-ink">
            {children}
          </div>
        </motion.div>
      </div>
    )}
  </AnimatePresence>
);

export default Modal;
