import { supabase } from '../supabase';

interface OfflineOperation {
  id: string;
  table: string;
  method: 'insert' | 'update' | 'upsert' | 'delete';
  data: any;
  timestamp: number;
}

const OFFLINE_QUEUE_KEY = 'sahal_offline_queue';

export const offlineSync = {
  queue: (): OfflineOperation[] => {
    try {
      const q = localStorage.getItem(OFFLINE_QUEUE_KEY);
      return q ? JSON.parse(q) : [];
    } catch {
      return [];
    }
  },

  enqueue: (table: string, method: 'insert' | 'update' | 'upsert' | 'delete', data: any) => {
    try {
      const queue = offlineSync.queue();
      const operation: OfflineOperation = {
        id: (typeof crypto !== 'undefined' && crypto.randomUUID) ? crypto.randomUUID() : Math.random().toString(36).substring(2) + Date.now().toString(36),
        table,
        method,
        data,
        timestamp: Date.now(),
      };
      queue.push(operation);
      localStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(queue));
    } catch (err) {
      console.warn("Could not save to offline queue:", err);
    }
  },

  perform: async (table: string, method: 'insert' | 'update' | 'upsert' | 'delete', data: any, filter?: { column: string, value: any }) => {
    // If we're offline, or the operation fails, we enqueue it.
    if (!navigator.onLine) {
      console.log(`Offline: Enqueueing ${method} for ${table}`);
      offlineSync.enqueue(table, method, { ...data, _filter: filter });
      return { error: null, data: data, offline: true };
    }

    try {
      let query: any = supabase.from(table);
      
      switch (method) {
        case 'insert':
          query = query.insert(data);
          break;
        case 'update':
          query = query.update(data);
          if (filter) query = query.eq(filter.column, filter.value);
          break;
        case 'upsert':
          query = query.upsert(data);
          break;
        case 'delete':
          query = query.delete();
          if (filter) query = query.eq(filter.column, filter.value);
          break;
      }

      const response = await query.select().single();
      // If there's an error but it might be network related, enqueue it
      if (response.error) {
        if (!navigator.onLine || response.error.message.includes('fetch')) {
           offlineSync.enqueue(table, method, { ...data, _filter: filter });
           return { error: null, data: data, offline: true };
        }
        throw response.error;
      }
      return response;
    } catch (error) {
      console.error(`OfflineSync error for ${table} ${method}:`, error);
      // Only enqueue if it looks like a connection error
      const isConnectionError = !navigator.onLine || (error instanceof Error && (error.message.includes('fetch') || error.message.includes('Network')));
      if (isConnectionError) {
        offlineSync.enqueue(table, method, { ...data, _filter: filter });
        return { error: null, data: data, offline: true };
      }
      return { error, data: null, offline: false };
    }
  },

  processQueue: async () => {
    if (!navigator.onLine) return;
    
    const queue = offlineSync.queue();
    if (queue.length === 0) return;

    console.log(`Processing ${queue.length} offline operations...`);
    const successfulIds: string[] = [];

    for (const op of queue) {
      try {
        let query: any = supabase.from(op.table);
        const { _filter, ...data } = op.data;
        
        switch (op.method) {
          case 'insert':
            query = query.insert(data);
            break;
          case 'update':
            query = query.update(data);
            if (_filter) query = query.eq(_filter.column, _filter.value);
            break;
          case 'upsert':
            query = query.upsert(data);
            break;
          case 'delete':
            query = query.delete();
            if (_filter) query = query.eq(_filter.column, _filter.value);
            break;
        }

        const result = await query;
        if (!result.error) {
          successfulIds.push(op.id);
        }
      } catch (err) {
        console.error(`Failed to sync op ${op.id}:`, err);
      }
    }

    const remainingQueue = queue.filter(op => !successfulIds.includes(op.id));
    localStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(remainingQueue));
  }
};
