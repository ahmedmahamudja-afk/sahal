import { supabase } from '../supabase';

/**
 * Validates if a username is a 9-digit number.
 */
export const is9DigitNumber = (username: string): boolean => {
  return /^\d{9}$/.test(username);
};

/**
 * Checks if a username already exists in either 'users' or 'staff' table.
 */
export const checkUsernameExists = async (username: string): Promise<boolean> => {
  // Check users table
  const { data: userData, error: userError } = await supabase
    .from('users')
    .select('username')
    .eq('username', username)
    .maybeSingle();
  
  if (userData) return true;

  // Check staff table
  const { data: staffData, error: staffError } = await supabase
    .from('staff')
    .select('username')
    .eq('username', username)
    .maybeSingle();

  return !!staffData;
};

export const USERNAME_FORMAT_ERROR = "Username-ku waa inuu ahaadaa 9 lambar oo kaliya (e.g. 615123456).";
export const USERNAME_EXISTS_ERROR = "Username-kan mar hore ayaa la isticmaalay, fadlan doooro mid ka duwan (Username already exists, please choose a different one).";
