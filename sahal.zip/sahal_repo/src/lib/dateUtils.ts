export const getLocalDateString = (date: Date) => {
  if (!date || isNaN(date.getTime())) return '';
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

export const filterByDate = (
  dateInput: Date | string,
  selectedDate: Date,
  mode: 'day' | 'month' | 'year' | 'range',
  startDate?: Date,
  endDate?: Date
) => {
  if (!selectedDate || isNaN(selectedDate.getTime())) return true;
  let dateStr = '';
  let dateObj: Date;

  if (typeof dateInput === 'string') {
    if (dateInput.includes('T')) {
      // ISO string
      dateObj = new Date(dateInput);
      dateStr = getLocalDateString(dateObj);
    } else {
      // YYYY-MM-DD string
      dateStr = dateInput;
      const [y, m, d] = dateInput.split('-').map(Number);
      dateObj = new Date(y, m - 1, d);
    }
  } else {
    dateObj = dateInput;
    dateStr = getLocalDateString(dateObj);
  }

  const [year, month, day] = dateStr.split('-').map(Number);
  const selYear = selectedDate.getFullYear();
  const selMonth = selectedDate.getMonth() + 1;
  const selDay = selectedDate.getDate();

  if (mode === 'day') {
    return year === selYear && month === selMonth && day === selDay;
  } else if (mode === 'month') {
    return year === selYear && month === selMonth;
  } else if (mode === 'year') {
    return year === selYear;
  } else if (mode === 'range' && startDate && endDate) {
    const start = new Date(startDate);
    start.setHours(0, 0, 0, 0);
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999);
    return dateObj >= start && dateObj <= end;
  }
  return true;
};
