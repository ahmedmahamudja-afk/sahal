export type UserRole = 'super_admin' | 'system_manager' | 'business_user' | 'staff';
export type SubscriptionPlan = 'daily' | 'weekly' | 'monthly' | '2months' | '3months' | 'yearly' | 'custom';

export interface SubscriptionInfo {
  plan: SubscriptionPlan;
  startDate: string;
  endDate: string;
  status: 'active' | 'expired' | 'pending';
  price?: number;
}

export interface UserProfile {
  uid: string;
  email?: string;
  displayName: string;
  role: UserRole;
  tenantId?: string;
  createdAt: string;
  username?: string;
  password?: string;
  phone?: string;
  photoURL?: string;
  isStaff?: boolean;
  staffRoles?: string[];
  subscription?: SubscriptionInfo;
  isLocked?: boolean;
  isExpired?: boolean;
  planExpiry?: string;
  branchId?: string;
}

export interface TenantModules {
  inventory: boolean;
  sales: boolean;
  debts: boolean;
  crm: boolean;
  expenses: boolean;
  tax: boolean;
  alerts: boolean;
  reports: boolean;
  hospital: boolean;
  services: boolean;
  saving: boolean;
  investment: boolean;
  working_note: boolean;
  daily_task: boolean;
  keeping_ideas: boolean;
  utility_water: boolean;
  utility_electricity: boolean;
}

export interface Tenant {
  id: string;
  name: string;
  type: 'inventory' | 'services' | 'services_inventory' | 'hospital' | 'personal' | 'utility' | 'other';
  modules: TenantModules;
  managerId: string;
  subscriptionPlan?: string;
  planExpiry?: string;
  isLocked?: boolean;
  createdAt: string;
  logoUrl?: string;
  status?: 'active' | 'limited';
  isMultiBranch?: boolean;
  location?: string;
  contact?: string;
  paymentNumbers?: {
    evc?: string;
    edahab?: string;
    zaad?: string;
    sahal?: string;
    bank?: string;
    merchant?: string;
  };
}

export interface Branch {
  id: string;
  tenantId: string;
  name: string;
  location?: string;
  phone?: string;
  createdAt: string;
  managerId?: string;
}

export interface StaffMember {
  id: string;
  username?: string;
  password?: string;
  displayName: string;
  phone?: string;
  photoURL?: string;
  roles: string[];
  tenantId: string;
  branchId?: string;
  isLocked?: boolean;
  createdAt: string;
  // HR Fields
  position?: string;
  salary?: number;
  address?: string;
  email?: string;
  status?: 'active' | 'inactive' | 'on_leave';
  hireDate?: string;
}

export interface InventoryItem {
  id: string;
  name: string;
  sku: string;
  quantity: number;
  costPrice: number;
  price: number;
  minStock: number;
  category?: string;
  tenantId: string;
  branchId?: string;
  imageUrl?: string;
  discountPercentage?: number;
  offerPrice?: number;
  created_at?: string;
}

export interface Sale {
  id: string;
  items: any[];
  total: number;
  tax: number;
  paidAmount?: number;
  debtAmount?: number;
  customerName: string;
  customerPhone?: string;
  status: 'paid' | 'debt' | 'returned' | 'partial';
  paymentMethods?: { method: string; amount: number }[];
  tenantId: string;
  branchId?: string;
  createdAt: string;
  debtId?: string;
  sellerName?: string;
  creditUsed?: number;
  isEdited?: boolean;
}

export interface Account {
  id: string;
  name: string;
  balance: number;
  tenantId: string;
  branchId?: string;
  createdAt: string;
}

export interface AccountTransaction {
  id: string;
  fromAccountId?: string;
  toAccountId?: string;
  amount: number;
  type: 'transfer' | 'deposit' | 'withdrawal' | 'sale' | 'expense' | 'debt_payment' | 'adjustment' | 'credit' | 'equity';
  description?: string;
  tenantId: string;
  branchId?: string;
  referenceId?: string;
  createdAt: string;
}

export interface Debt {
  id: string;
  customerName: string;
  phone: string;
  amount: number;
  paidAmount: number;
  status: 'unpaid' | 'partial' | 'paid';
  tenantId: string;
  branchId?: string;
  createdAt: string;
  dueDate?: string;
  type?: 'customer' | 'business';
  description?: string;
}

export interface Expense {
  id: string;
  category: string;
  description: string;
  amount: number;
  date: string;
  tenantId: string;
  branchId?: string;
  createdAt: string;
  status?: 'paid' | 'pending';
  approvalStatus?: 'pending' | 'approved' | 'rejected';
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  tenantId: string;
  branchId?: string;
  createdAt: string;
  totalDebt: number;
  totalCredit?: number;
  offerPercentage?: number;
}

export interface Patient {
  id: string;
  name: string;
  age: string;
  phone: string;
  insuranceProvider?: string;
  type?: 'outpatient' | 'inpatient';
  tenantId: string;
  branchId?: string;
  createdAt: string;
}

export interface PrescriptionItem {
  medicineId: string;
  medicineName: string;
  dosage: string;
  quantity: number;
  price: number;
}

export interface PatientVisit {
  id: string;
  patientId: string;
  patientName: string;
  patientAge?: string;
  doctorId?: string;
  doctorName?: string;
  doctorPhone?: string;
  status: 'reception' | 'doctor' | 'pharmacy' | 'accounts' | 'completed';
  registrationFee: number;
  consultationFee?: number;
  diagnosis?: string;
  prescription?: PrescriptionItem[];
  totalBill?: number;
  paidAmount?: number;
  consultationPaid?: boolean;
  pharmacyPaid?: boolean;
  dispensed?: boolean;
  tenantId: string;
  branchId?: string;
  createdAt: string;
}

export interface Service {
  id: string;
  name: string;
  description?: string;
  price: number;
  category?: string;
  tenantId: string;
  branchId?: string;
  createdAt: string;
  imageUrl?: string;
  offerPrice?: number;
  discountPercentage?: number;
}

export interface Saving {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  tenantId: string;
  createdAt: string;
}

export interface Investment {
  id: string;
  name: string;
  amount: number;
  expectedReturn?: number;
  status: 'active' | 'completed' | 'failed';
  paymentMethod?: string;
  tenantId: string;
  createdAt: string;
}

export interface WorkingNote {
  id: string;
  title: string;
  content: string;
  tenantId: string;
  createdAt: string;
}

export interface DailyTask {
  id: string;
  task: string;
  completed: boolean;
  tenantId: string;
  createdAt: string;
}

export interface KeepingIdea {
  id: string;
  title: string;
  description: string;
  tenantId: string;
  createdAt: string;
}

export interface Shareholder {
  id: string;
  name: string;
  initialInvestment: number;
  currentValue: number;
  sharePercentage: number;
  paymentMethod?: string;
  tenantId: string;
  createdAt: string;
}
