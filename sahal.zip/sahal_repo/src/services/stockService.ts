import { supabase } from '../supabase';

export const logStockChange = async (tenantId: string, itemId: string, itemName: string, change: number, reason: string, branchId?: string | null) => {
  await supabase.from('stock_logs').insert({
    tenant_id: tenantId,
    item_id: itemId,
    item_name: itemName,
    change,
    reason,
    branch_id: branchId || null,
    timestamp: new Date().toISOString()
  });
};
