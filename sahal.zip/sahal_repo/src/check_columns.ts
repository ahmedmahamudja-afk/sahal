import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';

dotenv.config();

const supabase = createClient(
  process.env.VITE_SUPABASE_URL!,
  process.env.VITE_SUPABASE_ANON_KEY!
);

async function checkColumns() {
  const { data, error } = await supabase.from('staff').select('address').limit(1);
  console.log("Select address:", { data, error });
}

checkColumns();
