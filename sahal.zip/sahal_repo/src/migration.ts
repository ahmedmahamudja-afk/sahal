import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

const supabaseUrl = process.env.VITE_SUPABASE_URL!;
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY!;
const supabase = createClient(supabaseUrl, supabaseKey);

async function runMigration() {
  console.log("Running database migration...");

  // We'll try to run these one by one using a simple trick: 
  // try to select the column, if it fails, try to add it.
  // Actually, the best way is to use a custom RPC if available, 
  // but since we don't know if it exists, we'll just provide the SQL for the user.
  
  const sql = `
-- 1. Ensure tenants table has all columns
DO $$ 
BEGIN 
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='tenants' AND column_name='subscription_plan') THEN
        ALTER TABLE tenants ADD COLUMN subscription_plan TEXT;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='tenants' AND column_name='location') THEN
        ALTER TABLE tenants ADD COLUMN location TEXT;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='tenants' AND column_name='contact') THEN
        ALTER TABLE tenants ADD COLUMN contact TEXT;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='tenants' AND column_name='status') THEN
        ALTER TABLE tenants ADD COLUMN status TEXT DEFAULT 'active';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='tenants' AND column_name='is_multi_branch') THEN
        ALTER TABLE tenants ADD COLUMN is_multi_branch BOOLEAN DEFAULT FALSE;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='tenants' AND column_name='payment_numbers') THEN
        ALTER TABLE tenants ADD COLUMN payment_numbers JSONB DEFAULT '{}';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='tenants' AND column_name='manager_id') THEN
        ALTER TABLE tenants ADD COLUMN manager_id TEXT;
    ELSE
        IF (SELECT data_type FROM information_schema.columns WHERE table_name='tenants' AND column_name='manager_id') = 'uuid' THEN
            ALTER TABLE tenants ALTER COLUMN manager_id TYPE TEXT;
        END IF;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='tenants' AND column_name='plan_expiry') THEN
        ALTER TABLE tenants ADD COLUMN plan_expiry TIMESTAMPTZ;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='tenants' AND column_name='is_locked') THEN
        ALTER TABLE tenants ADD COLUMN is_locked BOOLEAN DEFAULT FALSE;
    END IF;
END $$;

-- 2. Ensure users table has all columns
DO $$ 
BEGIN 
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='password') THEN
        ALTER TABLE users ADD COLUMN password TEXT;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='uid') THEN
        ALTER TABLE users ADD COLUMN uid TEXT UNIQUE;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='subscription') THEN
        ALTER TABLE users ADD COLUMN subscription JSONB DEFAULT '{}';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='username') THEN
        ALTER TABLE users ADD COLUMN username TEXT UNIQUE;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='is_staff') THEN
        ALTER TABLE users ADD COLUMN is_staff BOOLEAN DEFAULT FALSE;
    END IF;
END $$;

-- 3. Ensure services table has all columns
DO $$ 
BEGIN 
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='services' AND column_name='image_url') THEN
        ALTER TABLE services ADD COLUMN image_url TEXT;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='services' AND column_name='offer_price') THEN
        ALTER TABLE services ADD COLUMN offer_price NUMERIC DEFAULT 0;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='services' AND column_name='discount_percentage') THEN
        ALTER TABLE services ADD COLUMN discount_percentage NUMERIC DEFAULT 0;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='services' AND column_name='category') THEN
        ALTER TABLE services ADD COLUMN category TEXT;
    END IF;
END $$;

-- 4. Ensure inventory table has category column
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='inventory' AND column_name='category') THEN
        ALTER TABLE inventory ADD COLUMN category TEXT;
    END IF;
END $$;

-- 1. Ensure storage buckets exist and are public
DO $$
BEGIN
    -- Ensure bucket app-images exists and is public
    IF EXISTS (SELECT 1 FROM storage.buckets WHERE id = 'app-images') THEN
        UPDATE storage.buckets SET public = true WHERE id = 'app-images';
    ELSE
        INSERT INTO storage.buckets (id, name, public) VALUES ('app-images', 'app-images', true);
    END IF;
    
    -- Ensure bucket staff-photos exists and is public
    IF EXISTS (SELECT 1 FROM storage.buckets WHERE id = 'staff-photos') THEN
        UPDATE storage.buckets SET public = true WHERE id = 'staff-photos';
    ELSE
        INSERT INTO storage.buckets (id, name, public) VALUES ('staff-photos', 'staff-photos', true);
    END IF;
END $$;

-- 2. Ensure storage policies are robust
DO $$
BEGIN
    DROP POLICY IF EXISTS "Public Access" ON storage.objects;
    DROP POLICY IF EXISTS "Public Insert" ON storage.objects;
    DROP POLICY IF EXISTS "Public Update" ON storage.objects;
    DROP POLICY IF EXISTS "Public Delete" ON storage.objects;
    
    CREATE POLICY "Public Access" ON storage.objects FOR SELECT USING (true);
    CREATE POLICY "Public Insert" ON storage.objects FOR INSERT WITH CHECK (true);
    CREATE POLICY "Public Update" ON storage.objects FOR UPDATE USING (true);
    CREATE POLICY "Public Delete" ON storage.objects FOR DELETE USING (true);
END $$;

-- 3. Create landing_settings table
CREATE TABLE IF NOT EXISTS landing_settings (
    id TEXT PRIMARY KEY,
    team JSONB DEFAULT '[]'::jsonb,
    contact JSONB DEFAULT '{}'::jsonb,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Disable RLS on all tables
DO $$ 
DECLARE 
    t TEXT;
BEGIN 
    FOR t IN SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' LOOP
        EXECUTE format('ALTER TABLE %I DISABLE ROW LEVEL SECURITY', t);
    END LOOP;
END $$;

ALTER TABLE tenants DROP CONSTRAINT IF EXISTS tenants_type_check;
  `;

  console.log("MIGRATION SQL (Run this in Supabase SQL Editor):");
  console.log("===============================================");
  console.log(sql);
  console.log("===============================================");
  console.log("FADLAN: Haddii aad aragto 'relation inventory does not exist', macnaheedu waa jadwallada lama abuurin.");
  console.log("Fadlan koobi gareey dhammaan SQL-ka ku jira faylka 'supabase_setup.sql' oo ku dhex orodshii Supabase SQL Editor.");
}

runMigration();
