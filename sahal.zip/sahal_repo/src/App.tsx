import React, { useState, useEffect, Suspense, lazy } from 'react';
import { supabase } from './supabase';
import { UserProfile } from './types';
import { offlineSync } from './lib/offline';

import { useLanguage, LanguageProvider } from './components/LanguageContext';
import { ThemeProvider } from './components/ThemeContext';
import { SubscriptionLock } from './components/SubscriptionLock';
import { ErrorBoundary } from './components/ErrorBoundary';
import ConnectionStatus from './components/ConnectionStatus';

const Auth = lazy(() => import('./components/Auth').then(m => ({ default: m.Auth })));
const Dashboard = lazy(() => import('./components/Dashboard'));
const LandingPage = lazy(() => import('./components/LandingPage').then(m => ({ default: m.LandingPage })));

function LoadingScreen() {
  const { t } = useLanguage();
  const configMissing = !import.meta.env.VITE_SUPABASE_URL || !import.meta.env.VITE_SUPABASE_ANON_KEY;
  
  return (
    <div className="min-h-screen bg-white dark:bg-slate-900 flex items-center justify-center">
      <div className="flex flex-col items-center gap-4 text-center px-4">
        <div className="w-12 h-12 border-4 border-slate-200 dark:border-slate-700 border-t-indigo-600 rounded-full animate-spin" />
        <p className="text-slate-500 dark:text-slate-400 font-mono text-xs uppercase tracking-widest animate-pulse">{t('initializing_system')}</p>
        
        {configMissing && (
          <div className="mt-8 p-4 bg-amber-50 border border-amber-200 rounded-lg text-amber-800 text-sm max-w-md">
            <p className="font-bold mb-2">Supabase Configuration Missing</p>
            <p>Please ensure <code className="bg-amber-100 px-1 rounded">VITE_SUPABASE_URL</code> and <code className="bg-amber-100 px-1 rounded">VITE_SUPABASE_ANON_KEY</code> are set in your environment variables.</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [showAuth, setShowAuth] = useState(false);
  const [managerPhone, setManagerPhone] = useState<string | undefined>();

  useEffect(() => {
    const handleOnline = () => {
      offlineSync.processQueue();
    };

    const initUserAndData = async () => {
      try {
        if (navigator.onLine) {
          handleOnline();
        }
        window.addEventListener('online', handleOnline);

        const savedUser = localStorage.getItem('sahal_user');
        if (savedUser) {
          const parsedUser = JSON.parse(savedUser) as UserProfile;
          setUser(parsedUser);
          
          // Background update check if online - don't block main UI
          if (navigator.onLine) {
            // Use an async function to handle the update safely
            (async () => {
              try {
                const { data } = await supabase.from(parsedUser.isStaff ? 'staff' : 'users')
                  .select('*')
                  .eq(parsedUser.isStaff ? 'id' : 'uid', parsedUser.uid)
                  .single();
                  
                if (data) {
                  const updatedUser = { ...parsedUser, ...data };
                  setUser(updatedUser);
                  localStorage.setItem('sahal_user', JSON.stringify(updatedUser));
                }
              } catch (e) {
                console.warn("[SAHAL] Background check failed:", e);
              }
            })();
          }
        }
        
      } catch (e) {
        console.error("[SAHAL] Critical initialization error:", e);
      } finally {
        setLoading(false);
      }
    };

    initUserAndData();
    return () => {
      window.removeEventListener('online', handleOnline);
    };
  }, []);

  // Fetch manager phone for business/staff users
  useEffect(() => {
    const fetchManagerPhone = async () => {
      if (!user || (user.role !== 'business_user' && user.role !== 'staff') || !user.tenantId) return;
      
      try {
        // First get the tenant to find the managerId
        const { data: tenantData } = await supabase
          .from('tenants')
          .select('manager_id')
          .eq('id', user.tenantId)
          .single();

        if (tenantData?.manager_id) {
          // Then get the manager's phone from users table
          const { data: userData } = await supabase
            .from('users')
            .select('phone')
            .eq('uid', tenantData.manager_id)
            .single();
          
          if (userData?.phone) {
            setManagerPhone(userData.phone);
          }
        }
      } catch (error) {
        console.error("Error fetching manager phone:", error);
      }
    };

    fetchManagerPhone();
  }, [user?.uid, user?.tenantId]);

    // Real-time subscription and lock status check
    useEffect(() => {
      if (!user || (user.role !== 'business_user' && !user.isStaff)) return;

      // Listen to tenant status
      const tenantChannel = supabase
        .channel('tenant_status')
        .on('postgres_changes', { 
          event: 'UPDATE', 
          schema: 'public', 
          table: 'tenants',
          filter: `id=eq.${user.tenantId}`
        }, (payload) => {
          const tenantData = payload.new;
          const tenantLocked = tenantData.is_locked || false;
          const planExpiry = tenantData.plan_expiry;
          const isExpired = planExpiry ? new Date(planExpiry) < new Date() : false;

          if (tenantLocked !== user.isLocked || isExpired !== user.isExpired || planExpiry !== user.planExpiry) {
            setUser(prev => {
              if (!prev) return prev;
              const updatedUser = { ...prev, isLocked: tenantLocked || prev.isStaffLocked, isExpired, planExpiry };
              localStorage.setItem('sahal_user', JSON.stringify(updatedUser));
              return updatedUser;
            });
          }
        })
        .subscribe();

      // Listen to staff status if applicable
      let staffChannel: any = null;
      if (user.isStaff && user.tenantId) {
        staffChannel = supabase
          .channel('staff_status')
          .on('postgres_changes', { 
            event: 'UPDATE', 
            schema: 'public', 
            table: 'staff',
            filter: `id=eq.${user.uid}`
          }, (payload) => {
            const staffData = payload.new;
            const isStaffLocked = staffData.is_locked || false;
            const staffRoles = staffData.roles || [];
            
            const rolesChanged = JSON.stringify(staffRoles) !== JSON.stringify(user.staffRoles);
            
            if (isStaffLocked !== user.isStaffLocked || rolesChanged) {
              setUser(prev => {
                if (!prev) return prev;
                const updatedUser = { 
                  ...prev, 
                  isStaffLocked, 
                  isLocked: prev.isLocked || isStaffLocked,
                  staffRoles
                };
                localStorage.setItem('sahal_user', JSON.stringify(updatedUser));
                return updatedUser;
              });
            }
          })
          .subscribe();
      }

      // Listen to system user status (Super Admin / System Manager)
      const userChannel = supabase
        .channel('user_status')
        .on('postgres_changes', { 
          event: 'UPDATE', 
          schema: 'public', 
          table: 'users',
          filter: `uid=eq.${user.uid}`
        }, (payload) => {
          const userData = payload.new;
          const isLocked = userData.is_locked || false;
          const subscription = userData.subscription;
          
          const subscriptionChanged = JSON.stringify(subscription) !== JSON.stringify(user.subscription);
          
          if (isLocked !== user.isLocked || subscriptionChanged) {
            setUser(prev => {
              if (!prev) return prev;
              const updatedUser = { ...prev, isLocked, subscription: subscription || prev.subscription };
              localStorage.setItem('sahal_user', JSON.stringify(updatedUser));
              return updatedUser;
            });
          }
        })
        .subscribe();

      // Also check every minute for expiry (if user stays on the page)
      const interval = setInterval(() => {
        setUser(prev => {
          if (!prev || !prev.planExpiry) return prev;
          const isExpired = new Date(prev.planExpiry) < new Date();
          if (isExpired !== prev.isExpired) {
            const updatedUser = { ...prev, isExpired };
            localStorage.setItem('sahal_user', JSON.stringify(updatedUser));
            return updatedUser;
          }
          return prev;
        });
      }, 60000);

      return () => {
        supabase.removeChannel(tenantChannel);
        if (staffChannel) supabase.removeChannel(staffChannel);
        supabase.removeChannel(userChannel);
        clearInterval(interval);
      };
    }, [user?.uid, user?.tenantId]);

  const handleLogout = () => {
    localStorage.removeItem('sahal_user');
    setUser(null);
    setShowAuth(false);
  };

  return (
    <LanguageProvider>
      <ThemeProvider>
        <Suspense fallback={<LoadingScreen />}>
          <ConnectionStatus />
          {loading ? (
            <LoadingScreen />
          ) : !user ? (
            showAuth ? (
              <Auth onAuthSuccess={(profile) => setUser(profile)} onBack={() => setShowAuth(false)} />
            ) : (
              <LandingPage onGetStarted={() => setShowAuth(true)} />
            )
          ) : user.isLocked || ((user.role === 'business_user' || user.isStaff) && user.isExpired) ? (
            <SubscriptionLock 
              onLogout={handleLogout} 
              reason={user.isLocked ? 'locked' : 'expired'} 
              managerPhone={managerPhone}
            />
          ) : (
            <Dashboard user={user} onLogout={handleLogout} managerPhone={managerPhone} />
          )}
        </Suspense>
      </ThemeProvider>
    </LanguageProvider>
  );
}
