import { createClient } from '@supabase/supabase-js';

let supabaseUrl = (import.meta.env.VITE_SUPABASE_URL || '').trim();
let supabaseAnonKey = (import.meta.env.VITE_SUPABASE_ANON_KEY || '').trim();

// Fallback values for development if missing
if (!supabaseUrl) {
  supabaseUrl = 'https://placeholder.supabase.co';
}
if (!supabaseAnonKey) {
  supabaseAnonKey = 'placeholder';
}

try {
  // Validate URL format
  if (supabaseUrl && supabaseUrl !== 'https://placeholder.supabase.co') {
    const parsed = new URL(supabaseUrl);
    supabaseUrl = parsed.origin;
  }
} catch (e) {
  console.warn("Invalid Supabase URL format provided:", supabaseUrl);
}

// Create client with fallback or real values
export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Log warnings to console for debugging
if (!import.meta.env.VITE_SUPABASE_URL || !import.meta.env.VITE_SUPABASE_ANON_KEY) {
  console.warn('%cSupabase Configuration Missing!', 'color: orange; font-weight: bold; font-size: 20px;');
  console.warn('Please ensure VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY are set in your Settings.');
}
