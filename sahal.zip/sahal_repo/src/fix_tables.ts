import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

const supabaseUrl = process.env.VITE_SUPABASE_URL!;
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY!;
const supabase = createClient(supabaseUrl, supabaseKey);

async function runFix() {
  console.log("Generating SQL for missing tables...");
  
  const sql = `
-- Create missing tables
CREATE TABLE IF NOT EXISTS working_notes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT,
    content TEXT,
    tenant_id TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS savings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT,
    target_amount NUMERIC DEFAULT 0,
    current_amount NUMERIC DEFAULT 0,
    tenant_id TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS investments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT,
    amount NUMERIC DEFAULT 0,
    expected_return NUMERIC DEFAULT 0,
    status TEXT DEFAULT 'active',
    payment_method TEXT,
    tenant_id TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS daily_tasks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    task TEXT,
    completed BOOLEAN DEFAULT FALSE,
    tenant_id TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS keeping_ideas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT,
    description TEXT,
    tenant_id TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS hospital_visits (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id TEXT,
    doctor_id TEXT,
    diagnosis TEXT,
    prescription JSONB DEFAULT '[]',
    status TEXT DEFAULT 'waiting',
    total_bill NUMERIC DEFAULT 0,
    paid_amount NUMERIC DEFAULT 0,
    tenant_id TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    type TEXT,
    amount NUMERIC DEFAULT 0,
    description TEXT,
    tenant_id TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS landing_settings (
    id TEXT PRIMARY KEY,
    team JSONB DEFAULT '[]'::jsonb,
    contact JSONB DEFAULT '{}'::jsonb,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Ensure RLS is disabled on these new tables
ALTER TABLE working_notes DISABLE ROW LEVEL SECURITY;
ALTER TABLE savings DISABLE ROW LEVEL SECURITY;
ALTER TABLE investments DISABLE ROW LEVEL SECURITY;
ALTER TABLE daily_tasks DISABLE ROW LEVEL SECURITY;
ALTER TABLE keeping_ideas DISABLE ROW LEVEL SECURITY;
ALTER TABLE hospital_visits DISABLE ROW LEVEL SECURITY;
ALTER TABLE transactions DISABLE ROW LEVEL SECURITY;
  `;

  console.log("COPY AND RUN THIS SQL IN SUPABASE SQL EDITOR:");
  console.log("===============================================");
  console.log(sql);
  console.log("===============================================");
}

runFix();
