import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App';
import './index.css';

// Global error handling for production debugging
window.onerror = (message, source, lineno, colno, error) => {
  console.error('Global Error Layout:', { message, source, lineno, colno, error });
  // You could also show a UI element here if root is still empty
};

window.onunhandledrejection = (event) => {
  console.error('Unhandled Promise Rejection:', event.reason);
};

/* 
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    // Check if we already have a service worker registered by VitePWA
    // or just let VitePWA handle it via vite.config.ts
    // For now, let's keep it but handle errors gracefully
    navigator.serviceWorker.register('/service-worker.js').then((registration) => {
      console.log('ServiceWorker registration successful with scope: ', registration.scope);
    }).catch((err) => {
      console.warn('ServiceWorker registration failed: ', err);
    });
  });
}
*/

import {ErrorBoundary} from './components/ErrorBoundary';

const rootElement = document.getElementById('root');

if (!rootElement) {
  console.error('[SAHAL] Critical Error: #root element not found in DOM');
  document.body.innerHTML = '<div style="color:red; padding: 20px; text-align: center;"><h1>System Error</h1><p>#root element missing. Contact support.</p></div>';
} else {
  try {
    const root = createRoot(rootElement);
    root.render(
      <StrictMode>
        <ErrorBoundary>
          <App />
        </ErrorBoundary>
      </StrictMode>,
    );
  } catch (err) {
    console.error('[SAHAL] Mounting failed:', err);
    rootElement.innerHTML = `
      <div style="padding: 20px; text-align: center; color: #ef4444;">
        <h2 style="margin-bottom: 10px;">Startup Error</h2>
        <p style="margin-bottom: 20px;">Could not start the application.</p>
        <code style="display: block; background: #fee2e2; padding: 10px; border-radius: 4px; overflow: auto; max-height: 200px; text-align: left;">
          ${err instanceof Error ? err.message : String(err)}
        </code>
        <button onclick="window.location.reload()" style="margin-top: 20px; background: #4f46e5; color: white; border: none; padding: 10px 20px; border-radius: 8px; cursor: pointer;">
          Try Again
        </button>
      </div>
    `;
  }
}
