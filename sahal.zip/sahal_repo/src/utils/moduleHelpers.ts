import { TenantModules } from '../types';

export const getDefaultModulesForBusinessType = (type: string): TenantModules => {
  const defaultModules: TenantModules = {
    inventory: false,
    sales: false,
    debts: false,
    crm: false,
    expenses: false,
    tax: false,
    alerts: false,
    reports: false,
    hospital: false,
    services: false,
    saving: false,
    investment: false,
    working_note: false,
    daily_task: false,
    keeping_ideas: false,
    utility_water: false,
    utility_electricity: false,
  };

  switch (type) {
    case 'inventory':
      return { ...defaultModules, inventory: true, sales: true, debts: true, crm: true, expenses: true, tax: true, alerts: true, reports: true };
    case 'services':
      return { ...defaultModules, services: true, sales: true, debts: true, crm: true, expenses: true, tax: true, alerts: true, reports: true };
    case 'services_inventory':
      return { ...defaultModules, services: true, inventory: true, sales: true, debts: true, crm: true, expenses: true, tax: true, alerts: true, reports: true };
    case 'hospital':
      return { ...defaultModules, hospital: true, inventory: true, sales: true, debts: true, crm: true, expenses: true, tax: true, alerts: true, reports: true };
    case 'personal':
      return { ...defaultModules, expenses: true, saving: true, investment: true, working_note: true, daily_task: true, keeping_ideas: true };
    case 'utility':
      return { ...defaultModules, utility_water: true, utility_electricity: true, debts: true, crm: true, expenses: true, tax: true, alerts: true, reports: true };
    default:
      // Default for 'other' or unknown types
      return { ...defaultModules, inventory: true, sales: true, debts: true, crm: true, expenses: true, tax: true, alerts: true, reports: true };
  }
};
