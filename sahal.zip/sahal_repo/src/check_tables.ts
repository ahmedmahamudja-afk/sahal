
import { supabase } from './supabase';

async function checkTables() {
  const tables = [
    'tenants', 'users', 'staff', 'inventory', 'sales', 'expenses', 
    'debts', 'customers', 'patients', 'visits', 'services', 'branches'
  ];
  
  console.log("Checking tables...");
  
  for (const table of tables) {
    const { error } = await supabase.from(table).select('*').limit(1);
    if (error) {
      if (error.code === '42P01') {
        console.log(`❌ Table "${table}" is MISSING.`);
      } else {
        console.log(`❓ Table "${table}" error: ${error.message}`);
      }
    } else {
      console.log(`✅ Table "${table}" exists.`);
    }
  }
}

checkTables();
