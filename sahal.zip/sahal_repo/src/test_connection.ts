import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';
dotenv.config();

const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = process.env.VITE_SUPABASE_ANON_KEY || '';

console.log('--- Supabase Connection Test ---');
console.log('URL:', supabaseUrl);
console.log('Anon Key:', supabaseAnonKey ? 'PRESENT' : 'MISSING');

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('ERROR: Supabase credentials are not set in the environment.');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseAnonKey);

async function testConnection() {
  try {
    console.log('Testing connection to Supabase...');
    const { data, error } = await supabase.from('tenants').select('count', { count: 'exact', head: true });
    
    if (error) {
      console.error('Connection Error:', error.message);
      if (error.message.includes('failed to fetch') || error.message.includes('NetworkError')) {
        console.log('Suggestion: Check if the Supabase URL is correct and accessible.');
      }
    } else {
      console.log('SUCCESS: Connected to Supabase!');
      console.log('Tenants table accessible.');
    }
  } catch (err: any) {
    console.error('Unexpected Error:', err.message);
  }
}

testConnection();
