import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';

dotenv.config();

const supabase = createClient(
  process.env.VITE_SUPABASE_URL!,
  process.env.VITE_SUPABASE_ANON_KEY!
);

async function testInsert() {
  const tenantId = '66b8a725-798a-4b65-ae6e-8243daf64d9b'; // from previous query
  const staffData = {
    display_name: 'Test Staff',
    username: null,
    password: null,
    photo_url: '',
    roles: [],
    phone: '123456',
    tenant_id: tenantId,
    position: 'Manager',
    salary: 1000,
    address: 'Test Address',
    email: 'test@example.com',
    status: 'active',
    hire_date: new Date().toISOString()
  };

  console.log("Inserting:", staffData);
  const { data, error } = await supabase.from('staff').insert([staffData]);
  console.log("Result:", { data, error });
}

testInsert();
