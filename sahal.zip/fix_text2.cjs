const fs = require('fs');
const file = 'src/components/business/SalesModule.tsx';
let content = fs.readFileSync(file, 'utf8');
content = content.replace(/text-\[8px\]/g, 'text-[10px]');
fs.writeFileSync(file, content);
console.log('Fixed text[8px]');
