const fs = require('fs');
const file = 'src/components/business/SalesModule.tsx';
let content = fs.readFileSync(file, 'utf8');
content = content.replace(/text-\[10px\]/g, 'text-xs');
// Also add translation for 'view_past_sales' in translations.ts
const tFile = 'src/translations.ts';
let tContent = fs.readFileSync(tFile, 'utf8');
tContent = tContent.replace(/sales_history: 'Sales History',/g, "sales_history: 'Sales History',\n    view_past_sales: 'View your sales history',");
tContent = tContent.replace(/sales_history: 'Taariikhda Iibka',/g, "sales_history: 'Taariikhda Iibka',\n    view_past_sales: 'Arag taariikhda iibkaagii hore',");
tContent = tContent.replace(/sales_history: 'سجل المبيعات',/g, "sales_history: 'سجل المبيعات',\n    view_past_sales: 'عرض المبيعات السابقة',");
tContent = tContent.replace(/sales_history: 'Satış Geçmişi',/g, "sales_history: 'Satış Geçmişi',\n    view_past_sales: 'Önceki satışları görüntüle',");
fs.writeFileSync(file, content);
fs.writeFileSync(tFile, tContent);
console.log('Fixed text size and added translations');
