
import * as fs from 'fs';

const filePath = 'src/translations.ts';
const content = fs.readFileSync(filePath, 'utf-8');

// Match sections like so: {, en: {, ar: {, etc.
const sections = content.split(/(\n\s*\w+:\s*{)/);
let newContent = sections[0];

for (let i = 1; i < sections.length; i += 2) {
    const header = sections[i]; // e.g. "\n  en: {" 
    const blockWithRest = sections[i + 1];
    
    // The problem might be finding where this specific language section ends.
    // Since it's nested in the main translations object, it's followed by "}," then "  ar: {" or similar.
    // Or just "}" then "};" at the very end.
    
    let endMatch = blockWithRest.match(/\n\s*},/);
    if (!endMatch) {
        endMatch = blockWithRest.match(/\n\s*}/);
    }
    
    if (endMatch) {
        const endPos = endMatch.index!;
        const entryContent = blockWithRest.substring(0, endPos);
        const remainder = blockWithRest.substring(endPos);
        
        const lines = entryContent.split('\n');
        const seenKeys = new Set<string>();
        const newLines: string[] = [];
        let count = 0;
        
        for (const line of lines) {
            const keyMatch = line.match(/^\s*(\w+):/);
            if (keyMatch) {
                const key = keyMatch[1];
                if (seenKeys.has(key)) {
                    count++;
                    continue;
                }
                seenKeys.add(key);
            }
            newLines.push(line);
        }
        
        if (count > 0) {
            console.log(`Removed ${count} duplicates from section ${header.trim()}`);
        }
        
        newContent += header + newLines.join('\n') + remainder;
    } else {
        newContent += header + blockWithRest;
    }
}

fs.writeFileSync(filePath, newContent);
console.log('Deduplication complete');
