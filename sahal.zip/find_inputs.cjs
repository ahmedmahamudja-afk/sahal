const fs = require('fs');
const path = require('path');

function walkDir(dir, callback) {
  fs.readdirSync(dir).forEach(f => {
    let dirPath = path.join(dir, f);
    let isDirectory = fs.statSync(dirPath).isDirectory();
    isDirectory ? 
      walkDir(dirPath, callback) : callback(dirPath);
  });
}

const inputs = [];
walkDir('src', function(filePath) {
  if (filePath.endsWith('.tsx')) {
    const content = fs.readFileSync(filePath, 'utf8');
    const lines = content.split('\n');
    lines.forEach((line, i) => {
      if (line.includes('<input') && line.includes('value={')) {
        if (!line.includes('||')) {
          inputs.push(`${filePath}:${i+1} - ${line.trim()}`);
        }
      }
    });
  }
});

console.log(inputs.join('\n'));
